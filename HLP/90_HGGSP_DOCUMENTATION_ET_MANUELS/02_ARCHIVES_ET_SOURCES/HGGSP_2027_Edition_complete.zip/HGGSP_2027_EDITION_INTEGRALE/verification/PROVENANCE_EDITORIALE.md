# Provenance et décisions de consolidation

## Matériaux réellement récupérés

Le module 00 candidat et son autocorrection, le référentiel fondateur, le registre fondateur, une banque partielle transcrite, un fragment d’ouverture du cours P01 et un relevé de sommaire sont conservés dans `sources/originaux/`. Leurs sept empreintes ont été comparées à l’inventaire d’entrée. Les images historiques et l’intégralité des archives de récupération restent dans le checkpoint 02 transmis auparavant ; cette édition ne prétend pas les avoir toutes réintégrées.

La banque récupérée apportait 32 exercices, 20 QCM et quatre nouveaux tests issus de P01, P02, P03 et T06. Les corrigés avancés n’avaient pas été récupérés. Trois paragraphes de l’ouverture du cours P01 sont signalés comme fragment transcrit ; les développements manquants sont nouveaux.

## Nouveaux développements

Les onze chapitres ont été rédigés ou complétés à partir du référentiel et des sources identifiées. Les méthodes, les six remédiations, les compléments de banque, tous les corrigés avancés, les neuf épreuves blanches et leurs corrections sont des rédactions nouvelles. Les neuf illustrations du carnet ont été nouvellement réalisées ; elles ne sont pas les quatre illustrations historiques.

Les deux dissertations proposées dans chaque blanc N2 ont chacune une correction développée. La banque distingue les exercices de consolidation, de maîtrise et d’approfondissement des parcours éditoriaux N1 et N2. Les corrigés E7 sont annoncés comme des modèles condensés, tandis que les corrections de blancs développent les démarches et propositions rédigées.

## Adaptations tracées

P02-E3 renvoie à D07 pour la chronologie de l’OTAN ; P03-E3 renvoie à D04 pour Schengen. Dans T06-E3, deux valeurs illisibles de la trace ont conduit à un **nouveau jeu fictif explicitement signalé** ; elles n’ont pas été présentées comme des valeurs retrouvées. Les exercices récupérés et leurs adaptations sont décrits objet par objet dans la banque JSON.

Les identifiants du module 00 ont été préfixés par `00-` pour éviter des collisions. Les identifiants documentaires P01-DOC1/2 et P02-DOC1/2 ont été harmonisés en `Doc1/2` dans les sources de l’édition. Les numéros de blancs ont été harmonisés en N1-1 à N1-5 et N2-1 à N2-4. Les témoins originaux n’ont pas été modifiés.

Le document NSF utilisé dans N2-3 est une adaptation du communiqué **du 1er février 2023**, non une citation verbatim ni une présentation de sa politique en 2026. Le registre signale le caractère archivé de la page. Les autres documents contemporains sont datés dans le cours ou le registre.

## Fabrication et contrôles

La source canonique est le contenu de `sources/`. Les cinq assemblages et leurs exports sont produits par `production/assemble.py` et `production/build.py`. Aucun ancien chemin `_hggsp_work/` n’est nécessaire. Le script initial d’import, lié à l’environnement de récupération, a été retiré du paquet de fabrication sans suppression des originaux.

Les ajustements de rendu ont porté sur le choix d’une police OpenType disponible (Noto Serif), les flèches et signes moins, la largeur des numéros du sommaire, les espaces insécables de ponctuation, les encadrés des schémas et la séparation des références utiles aux blancs. Les fichiers de police ne sont pas distribués.

La couverture des jalons est contrôlée par correspondance des objets et par présence de texte développé ; les seuils automatiques ne prouvent ni l’exactitude de toutes les propositions ni la qualité d’une démonstration. L’édition n’a pas fait l’objet d’une relecture disciplinaire indépendante. Les vérifications historiques de 730 tests ne sont pas revendiquées comme réexécutées ici.
