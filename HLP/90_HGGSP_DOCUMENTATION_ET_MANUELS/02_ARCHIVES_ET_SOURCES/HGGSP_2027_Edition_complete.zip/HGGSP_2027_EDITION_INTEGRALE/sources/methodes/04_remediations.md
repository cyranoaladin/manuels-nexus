# Six remédiations ciblées {#remediations}

Une remédiation commence par une erreur observée dans votre copie. Elle se termine par une tâche différente, réalisée sans regarder le modèle. Recopier le corrigé n’est pas une preuve de maîtrise. Les solutions des micro-tests ci-dessous figurent dans le compagnon ; consulter ensuite le nouveau test du thème.

## R1 — Je mélange les périodes et les acteurs {#R1}

**Signal.** Vous attribuez la convention de 1972 au patrimoine immatériel, ou présentez la proclamation de 1871 comme une cérémonie de Louis-Philippe.

**Réparation, 15 minutes.** Tracez trois colonnes : date ou durée, acteur, opération. Placez seulement cinq repères du thème. Pour chacun, écrivez une phrase avec un verbe précis : inaugurer, signer, créer, contester. Ajoutez ensuite une relation « avant », « après » ou « pendant », sans affirmer que succession signifie causalité. Cachez la colonne des dates et restituez-la ; cachez celle des acteurs et recommencez.

**Exemple.** 1837 : Louis-Philippe inaugure les galeries historiques de Versailles. 1871 : proclamation de l’Empire allemand dans la galerie des Glaces. 1919 : signature du traité de Versailles. La permanence du lieu ne signifie pas la permanence du régime.

**Micro-test R1-T, 5 minutes.** Associez 1972 et 2003 à deux conventions patrimoniales, puis 1993 et 1994 au TPIY et au génocide des Tutsi. Écrivez une phrase expliquant pourquoi la chronologie interdit de confondre ces deux dernières entrées.

**Critère.** Quatre associations exactes, puis une distinction entre institution judiciaire et événement criminel. À J+2, reprenez trois autres dates ; à J+7, réutilisez deux repères dans un paragraphe sans consulter la frise.

## R2 — J’emploie un mot sans maîtriser le concept {#R2}

**Signal.** Vous écrivez « puissance », « démocratie », « mémoire » ou « souveraineté » comme des étiquettes qui expliqueraient seules un phénomène.

**Réparation, 20 minutes.** Pour la notion fragile, écrivez une définition en une phrase, un exemple, un contre-exemple et un mot voisin à distinguer. Évitez de définir un terme par sa répétition. Testez ensuite votre définition sur une situation nouvelle : elle doit aider à décider ce qui entre dans la catégorie et ce qui n’y entre pas.

**Exemple.** Une ZEE attribue notamment des droits souverains sur certaines ressources ; elle ne constitue pas une mer territoriale de 200 milles. Le navire qui la traverse n’exerce pas pour autant un droit d’exploitation des ressources. Les deux activités relèvent de compétences distinctes.

**Micro-test R2-T, 5 minutes.** Une sanction économique est-elle du soft power parce qu’elle n’emploie pas l’armée ? Un film apprécié à l’étranger prouve-t-il le soutien au gouvernement du pays producteur ? Donnez un argument pour chaque réponse.

**Critère.** Distinguer contrainte et attraction, puis ressource culturelle et effet politique. À J+2, refaire avec atténuation/adaptation ; à J+7, comparer patrimoine matériel/immatériel à partir d’un exemple inédit.

## R3 — Je raconte, mais je n’explique pas {#R3}

**Signal.** Votre paragraphe juxtapose des dates ; le lecteur ne comprend ni le mécanisme ni le lien avec le sujet.

**Réparation, 20 minutes.** Soulignez une affirmation. Ajoutez « parce que » et identifiez un mécanisme. Donnez un fait situé qui le rend observable. Terminez par la réponse partielle au sujet et, si nécessaire, une limite. Les connecteurs ne remplacent pas l’explication : « donc » exige une relation démontrée.

**Exemple.** Une ville peut gagner en fréquentation tout en perdant des habitants parce que la conversion de logements vers des usages touristiques réduit l’offre résidentielle. Ce mécanisme doit être vérifié par des données localisées ; il ne résulte pas automatiquement de toute hausse de visiteurs.

**Micro-test R3-T, 8 minutes.** Transformez « L’ONU existe depuis 1945, mais il y a encore des guerres » en un paragraphe de six phrases : fonction, instrument, dépendance politique, exemple du cours, limite et réponse à l’idée d’inutilité.

**Critère.** Un instrument nommé et une dépendance expliquée, sans promesse d’efficacité absolue. À J+2, relire un ancien paragraphe ; à J+7, refaire le raisonnement avec une organisation différente.

## R4 — Je paraphrase le document {#R4}

**Signal.** Votre étude suit ligne après ligne le texte et remplace quelques mots par des synonymes. Les connaissances sont absentes ou ajoutées dans un bloc sans lien.

**Réparation, 20 minutes.** Construisez trois colonnes : élément précis du document ; explication par le cours ; portée et limite. Une citation courte est utile si elle devient un point d’appui. N’inventez pas d’intention de l’auteur : distinguez intention explicitée et interprétation argumentée. La critique ne consiste pas à écrire automatiquement « subjectif donc faux ».

**Exemple.** Une convention affirme un devoir de protection. Le cours permet d’identifier les États responsables et les instruments d’application. Le document établit une norme, pas la preuve que tous les sites seraient effectivement protégés. Cette limite découle de sa nature juridique.

**Micro-test R4-T, 8 minutes.** Un document éditorial expose le rôle des contributions nationales dans l’accord de Paris. Produisez une phrase d’appui, deux phrases d’explication et une phrase de limite. Indiquez ce qu’il faudrait consulter pour mesurer les résultats.

**Critère.** Au moins un élément documentaire explicite, une connaissance pertinente et une limite précise. À J+2, travailler un tableau ; à J+7, confronter deux documents de natures différentes.

## R5 — J’impose toujours le même plan {#R5}

**Signal.** Tous les sujets deviennent « causes/conséquences/solutions » ou « avantages/inconvénients », même lorsque la question porte sur une comparaison ou une transformation.

**Réparation, 20 minutes.** Soulignez le verbe et la relation du sujet. Reformulez en une question dont la réponse n’est pas une simple liste. Écrivez ensuite deux ou trois réponses partielles qui se complètent. Chaque partie doit apporter une étape de la démonstration, pas un thème appris par cœur. Vérifiez la place d’un contre-exemple.

**Exemple.** « Protéger le patrimoine impose-t-il de le figer ? » appelle une discussion sur conservation et transformation. Une progression recevable examine les limites indispensables aux destructions, puis les transformations nécessaires à la transmission. Une troisième partie sur les arbitrages est possible, non obligatoire.

**Micro-test R5-T, 8 minutes.** Proposez deux titres de parties pour « Les frontières empêchent-elles les échanges ? ». Placez le Rhin et une frontière fermée. Expliquez pourquoi « histoire/géographie/géopolitique » ne constitue pas ici un plan démonstratif suffisant.

**Critère.** Deux fonctions ou conditions distinctes, avec des exemples qui les démontrent. À J+2, changer le verbe du sujet ; à J+7, élaborer un plan sur un autre thème sans reprendre les mêmes titres.

## R6 — Je n’achève pas mon travail {#R6}

**Signal.** Le brouillon est très développé, mais une partie de la copie ou l’un des deux exercices de l’écrit terminal manque.

**Réparation.** Sur le prochain entraînement, fixez trois alarmes silencieuses ou repères de montre. Réservez dès le départ une durée aux deux exercices et à la relecture. Au brouillon, rédigez seulement problématique, titres argumentatifs, exemples et transitions essentielles ; ne produisez pas une première copie intégrale. Pour N1, testez 25 minutes d’analyse et plan, 80 minutes de rédaction et 15 minutes de vérification, puis ajustez à votre rythme. Pour N2, une répartition initiale proche de deux heures par exercice est un repère pédagogique, non une prescription officielle.

**Exercice R6-T.** En 25 minutes, traitez un sujet déjà étudié : 5 minutes de plan, 15 minutes pour une introduction et un paragraphe, 5 minutes pour la conclusion et la relecture. Notez le nombre de phrases utiles et les passages réellement manquants.

**Critère.** Toutes les fonctions attendues existent, même si le développement doit ensuite s’allonger. À J+2, refaire en 30 minutes sur une question nouvelle ; à J+7, réaliser une épreuve complète. Ne compensez pas un exercice absent par une introduction interminable à l’autre.
