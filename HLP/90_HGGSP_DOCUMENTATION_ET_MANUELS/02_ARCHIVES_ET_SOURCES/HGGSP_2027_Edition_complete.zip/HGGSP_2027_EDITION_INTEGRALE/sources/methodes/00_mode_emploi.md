# Commencer : choisir son parcours et organiser son travail {#mode-emploi}

## Ce que contient cette édition

Ce manuel prépare la spécialité **histoire-géographie, géopolitique et sciences politiques** du baccalauréat général. Il couvre les cinq thèmes de Première et les six thèmes de Terminale. Il ne prépare pas, à lui seul, toutes les disciplines du baccalauréat et ne vaut pas autorisation administrative d’inscription.

Deux parcours éditoriaux sont proposés. **N1** concerne la spécialité non poursuivie après la Première. **N2** concerne la spécialité conservée en Terminale, avec une progression intensive possible en une année. Ces parcours ne sont pas des degrés de difficulté : les exercices possèdent séparément trois degrés, **consolidation, maîtrise, approfondissement**. Un candidat préparant le bac en un an mais ne conservant pas HGGSP relève de N1 pour cette spécialité.

Le manuel et son compagnon sont complémentaires. Tenter une activité avant d’ouvrir sa correction permet d’identifier un besoin réel. Les corrigés ne sont pas réservés à un enseignant : ils expliquent les démarches et les limites. Les exemples commentés intégrés au cours peuvent, eux, être lus immédiatement. Les neuf épreuves blanches sont également fournies dans un volume sans réponses, utilisable en temps limité.

**Provenance de l’édition.** Le module 00 et les fragments explicitement identifiés proviennent du dossier fondateur ou des transcriptions récupérées. Les développements nécessaires, les méthodes, les compléments d’exercices et tous les corrigés du corpus avancé ont été nouvellement rédigés. Ils ne sont pas présentés comme les anciens fichiers retrouvés. Les originaux restent séparés dans les sources modifiables. Cette édition est autonome : elle n’a pas été déclarée charte canonique du dépôt de la collection.

## Les règles d’examen à connaître — vérification du 8 septembre 2026

| Situation | Épreuve HGGSP | Format et coefficient |
|---|---|---|
| N1 : spécialité non poursuivie | Évaluation ponctuelle écrite | Composition, 2 heures, note sur 20, coefficient 8. |
| N2 : spécialité conservée | Épreuve terminale écrite | 4 heures, coefficient 16 ; dissertation sur 10 et étude critique de document(s) sur 10. |
| Grand oral, voie générale, session 2027 | Épreuve distincte | Préparation 20 minutes ; présentation 10 minutes puis échange 10 minutes ; coefficient 8. |

Pour **N1**, le sujet porte sur l’un des axes ou sur l’objet de travail conclusif d’un thème de Première. L’entraînement doit donc apprendre à délimiter un objet, non à réciter les cinq thèmes. La passation pendant la première année et le choix d’une évaluation à la fin du cycle dépendent de la modalité d’inscription du candidat individuel ; l’année d’apprentissage, l’année de passation et la session du diplôme ne sont pas synonymes. Le choix de modalité est encadré par les textes et l’inscription : il ne se décide pas librement matière par matière dans ce manuel. [S05–S07]

Pour **N2**, deux sujets de dissertation au choix portent sur deux thèmes différents ; l’étude critique porte sur un troisième thème. Le candidat rédige **une** dissertation et réalise **l’étude critique**. Pour l’écrit de **2027**, année impaire, les thèmes concernés sont **T02 : guerre et paix ; T04 : patrimoine ; T05 : environnement ; T06 : connaissance**. T01 et T03 demeurent dans le programme enseigné et dans ce livre ; ils ne sont pas à supprimer. Le manuel ne prédit aucun sujet officiel. [S03–S04]

Le **Grand oral** mobilise les deux spécialités conservées. Les deux questions préparées doivent, prises ensemble, concerner ces deux enseignements ; elles peuvent être disciplinaires ou transversales selon les conditions officielles. Le jury choisit une question. Le support préparé pendant les vingt minutes peut servir à la présentation, mais n’est pas une production évaluée en tant que telle. Les modalités particulières des candidats individuels et les documents attendus sont à vérifier auprès du service organisateur. [S08]

L’**oral de contrôle HGGSP**, lorsqu’un candidat y est admis et choisit cette discipline, dure 20 minutes après 20 minutes de préparation ; la présentation est suivie d’un échange. Le programme d’évaluation suit le périmètre de l’écrit. Ce n’est ni le Grand oral ni une composition réduite. Voir la méthode M11 et la simulation proposée dans les annexes. [S04]

**Préparer en un an n’autorise pas automatiquement à regrouper toutes les épreuves.** Les conditions permettant de passer les épreuves anticipées la même année que les épreuves terminales sont encadrées : l’âge de vingt ans atteint au 31 décembre de l’année de l’examen constitue notamment un cas, à côté de situations réglementaires particulières. Ne pas transformer ces cas en conditions cumulatives ni présumer que le lecteur en bénéficie. Les dispenses, notes conservées, aménagements et modalités locales relèvent du dossier personnel et du service des examens. Aucun calendrier tunisien n’est fabriqué ici. [S06]

## Parcours N1 — 24 semaines indicatives

Cette proposition représente **un cadre pédagogique**, pas un horaire officiel obligatoire. Prévoir généralement cinq à six heures de travail personnel par semaine, à ajuster après le diagnostic. Un lecteur ayant des lacunes importantes en expression ou en repères doit allonger les phases concernées.

| Semaines | Travail principal | Production à conserver |
|---|---|---|
| 1–2 | Module 00 ; M1 à M5 ; repères chronologiques et géographiques. | Diagnostic et première rédaction corrigée. |
| 3–6 | P01 : démocratie. | Paragraphe, plan, composition N1-1. |
| 7–10 | P02 : puissances. | Tableau comparatif, composition N1-2. |
| 11–14 | P03 : frontières. | Lecture de schéma, composition N1-3. |
| 15–18 | P04 : information. | Critique de source, composition N1-4. |
| 19–22 | P05 : États et religions. | Comparaison argumentée, composition N1-5. |
| 23–24 | Reprises espacées et nouvelle rédaction des points faibles. | Une composition complète sans aide et son bilan. |

À chaque thème : lire l’introduction, faire le diagnostic, travailler un axe à la fois, répondre aux exercices correspondants, puis traiter l’objet conclusif. Les QCM vérifient des distinctions ; ils ne suffisent pas à prouver la capacité à rédiger. Faire le nouveau test après un délai d’au moins deux jours, et non immédiatement après avoir copié le corrigé.

## Parcours N2 intensif — 32 semaines indicatives

Prévoir environ dix à douze heures hebdomadaires pour cette spécialité lorsque les fondations sont à construire, puis adapter ce volume aux résultats. Cette charge doit être articulée aux autres matières ; ce n’est pas une garantie de réussite ni une prescription officielle.

| Semaines | Priorité | Validation |
|---|---|---|
| 1–2 | Module 00 ; diagnostic ; méthodes M1–M7. | Présenter une source et rédiger un paragraphe. |
| 3–7 | Fondations P01–P05, un thème par semaine. | Notions, repères, E1–E5 et nouveau test de chaque thème. |
| 8–10 | T02 : guerre et paix. | Dissertation et étude critique guidées. |
| 11–13 | T04 : patrimoine. | Plan problématisé et dossier à deux documents. |
| 14–16 | T05 : environnement. | Indicateur exact et argumentation à plusieurs échelles. |
| 17–19 | T06 : connaissance. | Attribution prudente, rédaction et oral explicatif. |
| 20–21 | T01 : espaces de conquête. | Comparaison coopération/rivalité et transfert vers T02/T06. |
| 22–23 | T03 : histoire et mémoires. | Distinction histoire/mémoire/justice ; transfert vers T04. |
| 24–27 | Quatre blancs N2, un par semaine avec correction approfondie. | Deux exercices achevés en quatre heures. |
| 28–30 | Grand oral avec l’autre spécialité ; remédiations ciblées. | Deux questions conformes et simulations chronométrées. |
| 31–32 | Réactivation, nouvelle étude critique, écrit de synthèse. | Bilan des critères et reprise des erreurs persistantes. |

**Fondations à ne pas sauter.** P01 éclaire les institutions et les libertés ; P02 les mécanismes de puissance ; P03 les territoires et le droit maritime ; P04 la critique de l’information ; P05 les relations entre pouvoir et croyances. Le parcours accéléré réduit certains entraînements redondants, pas les notions nécessaires. Les E7–E8 de Première restent disponibles lorsque le diagnostic révèle un besoin.

## Une séance de travail et une preuve observable

Pour une séance de 90 minutes : 10 minutes de rappel sans cours ; 25 minutes de lecture active d’une unité ; 25 minutes de production ; 20 minutes de correction argumentée ; 10 minutes de réécriture d’un point faible. Les durées sont adaptables. La lecture active consiste à reformuler un mécanisme, repérer les acteurs et dater un exemple, pas à surligner chaque ligne.

Trois preuves sont à distinguer : **restituer**, sans notes, une notion et un repère ; **expliquer**, par une relation causale ou une comparaison ; **mobiliser**, dans une question différente de celle du cours. Une connaissance n’est pas durablement acquise au seul motif que sa correction paraît compréhensible.

| Date / objet | Restituer | Expliquer | Mobiliser ailleurs | Erreur précise | Reprise prévue |
|---|---|---|---|---|---|
| À compléter dans le cahier | Sans aide / avec aide | Relation établie / absente | Exemple pertinent / plaqué | Une phrase descriptive | J+2, J+7, J+21 |

**Orientation.** Si les dates et acteurs sont confondus, R1 ; si les mots restent vagues, R2 ; si la réponse raconte, R3 ; si elle répète le document, R4 ; si le plan est interchangeable, R5 ; si elle reste inachevée, R6. Le retour au cours vise la section concernée. Refaire tout le thème sans identifier l’erreur produit souvent moins de progrès qu’une reprise courte et ciblée.

## Lire les références et les documents

Les codes **S** désignent les textes officiels, **R** les ressources d’accompagnement, **B** les appuis historiques et institutionnels, **D** les documents de référence. Leur registre figure en annexe et dans les sources modifiables. Les identifiants P01/T01 et ceux des jalons sont locaux, non ministériels. Les liens numériques ne remplacent pas les documents nécessaires : les activités évaluées disposent de leurs matériaux dans le livre ou dans leur dossier de sujet.

Une **citation authentique** reproduit les mots d’une source ; une **adaptation** modifie sa présentation ou sa longueur et le signale ; une **synthèse éditoriale** expose des informations avec les mots du manuel ; une **fiction pédagogique** sert à une tâche méthodologique sans prétendre décrire un fait réel. Ne pas transformer une synthèse ou une fiction en témoignage historique dans une copie.

Cette édition a fait l’objet de contrôles de structure, de correspondance, d’assemblage et de rendu, décrits dans le rapport joint. Ces contrôles ne constituent pas une relecture disciplinaire indépendante ni une approbation ministérielle. Les faits contemporains sont arrêtés à la date de vérification indiquée ; leur évolution doit être distinguée des connaissances historiques stabilisées.
