# Corrigés des micro-tests de remédiation {#corr-remediations}

## R1-T — Reconstituer les repères

1972 : convention concernant le patrimoine mondial culturel et naturel. 2003 : convention pour la sauvegarde du patrimoine culturel immatériel. 1993 : création du Tribunal pénal international pour l’ex-Yougoslavie, le TPIY. 1994 : génocide des Tutsi au Rwanda. Les deux dernières entrées ne renvoient ni au même territoire ni à la même nature d’événement. Le TPIY n’est pas créé pour juger un crime ultérieur commis au Rwanda ; un autre tribunal, le TPIR, est créé en 1994. Une réponse satisfaisante associe les quatre dates, nomme les objets et explique cette distinction. Reprendre les repères de T03 et T04 en cas de confusion.

## R2-T — Distinguer contrainte et attraction

Une sanction économique peut imposer un coût pour faire modifier une conduite : elle relève alors de la contrainte, même sans emploi de l’armée. Le soft power repose sur l’attraction, et ne désigne pas tous les moyens non militaires. Un film apprécié peut accroître une familiarité culturelle ou l’attractivité d’un pays, mais ne démontre pas un soutien à son gouvernement. Il faut donc distinguer instrument, réception et résultat politique. La réussite suppose ces deux distinctions, pas seulement deux réponses négatives. Reprendre P02, introduction et axe 2.

## R3-T — Expliquer le rôle de l’ONU

**Un paragraphe recevable en six phrases.** L’ONU, fondée en 1945, a notamment pour fonction de contribuer au maintien de la paix et de la sécurité internationales. Le Conseil de sécurité dispose d’instruments comme les sanctions et, dans les conditions de la Charte, l’autorisation du recours à la force. Leur mise en œuvre dépend cependant des décisions des États, des moyens engagés et des rapports de puissance, notamment du veto des membres permanents. L’intervention autorisée contre l’Irak en 1991 après l’invasion du Koweït montre la possibilité d’une action collective. À l’inverse, l’intervention de 2003 ne peut pas être présentée comme une nouvelle opération explicitement autorisée selon le même schéma. La persistance des guerres établit donc les limites du système, non l’absence de toute fonction diplomatique, juridique ou opérationnelle.

D’autres exemples du cours sont recevables s’ils distinguent clairement instrument, décision et effets. Éviter de confondre l’ONU et une armée mondiale indépendante des États.

## R4-T — Analyser sans paraphraser

**Appui.** Le document décrit les contributions nationales comme un instrument de l’accord de Paris. **Explication.** Les États formulent des engagements dans un cadre collectif, plutôt qu’une autorité mondiale imposant une même politique à tous. L’efficacité dépend notamment de l’ambition des contributions, des mesures réellement mises en œuvre et des capacités de financement. **Limite.** La présentation du dispositif ne prouve pas à elle seule une baisse effective des émissions.

Pour apprécier les résultats, confronter des séries d’émissions datées et comparables, les politiques réalisées, les bilans de mise en œuvre et les financements ; distinguer une promesse, une trajectoire projetée et un résultat observé. Une réponse qui écrit uniquement « le document est subjectif » ne satisfait pas le critère de critique.

## R5-T — Construire un plan adapté

**I. Les frontières peuvent limiter et sélectionner les échanges.** Le contrôle, les interdictions et les tensions politiques peuvent réduire les circulations ; la frontière intercoréenne fournit un exemple de fermeture particulièrement forte, dans un contexte d’armistice.

**II. Les frontières peuvent aussi organiser des échanges et des interfaces.** Dans certains espaces rhénans européens, les accords et les infrastructures rendent possibles des mobilités transfrontalières. L’existence d’une frontière ne signifie donc pas l’absence d’échanges ; les effets varient selon les flux, les acteurs, la date et le régime de contrôle.

Les titres « histoire / géographie / géopolitique » désignent des approches, mais n’apportent pas à eux seuls une réponse progressive à la question. Un autre plan est recevable si ses parties démontrent des conditions ou des mécanismes distincts, sans effacer le rôle des choix politiques.

## R6-T — Contrôler l’achèvement

Ce test évalue un processus, pas une réponse unique. Vérifiez que les 25 minutes ont produit un plan utile, une introduction avec question directrice, un paragraphe contenant argument et exemple, puis une conclusion et une relecture. Notez ce qui manque réellement : exemple non situé, lien logique absent, réponse finale omise. Une phrase de conclusion n’efface pas l’absence du développement ; inversement, recopier tout le cours au brouillon n’est pas un progrès si la copie demeure vide.

Pour la tentative suivante, conservez une seule priorité mesurable : par exemple, terminer le paragraphe avec son exemple dans les quinze minutes. Ajustez ensuite la durée avant de passer à l’épreuve entière. Les repères 5 / 15 / 5 sont un entraînement pédagogique, non un découpage réglementaire de l’examen.
