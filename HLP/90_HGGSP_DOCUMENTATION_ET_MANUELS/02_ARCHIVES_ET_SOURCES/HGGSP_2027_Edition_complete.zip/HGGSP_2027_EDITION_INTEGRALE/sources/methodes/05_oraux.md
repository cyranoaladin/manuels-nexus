# Préparer le Grand oral et l’oral de contrôle {#oraux}

## Deux épreuves différentes

Le Grand oral valorise une question préparée et son argumentation. L’oral de contrôle HGGSP porte sur une question de cours tirée au sort parmi deux propositions. Ils ne partagent ni la même préparation sur l’année ni le même statut. Pour 2027, le Grand oral est affecté du coefficient 8 dans la voie générale ; il concerne les spécialités conservées, et non automatiquement la spécialité abandonnée. [S08 ; S09]

Au Grand oral, les deux questions présentées doivent, prises ensemble, porter sur les deux spécialités conservées. Elles peuvent les mobiliser séparément ou de manière transversale. Le jury choisit une question ; vingt minutes de préparation précèdent dix minutes de présentation et dix minutes d’échange. Le support préparé sert au candidat : il peut être montré mais n’est ni remis ni évalué. Les candidats individuels constituent eux-mêmes le document présentant leurs questions. Vérifier les consignes matérielles de la convocation, sans inventer une validation d’établissement exigée pour tous. [S08]

## Construire une question qui permette de démontrer

Un thème comme « le patrimoine » est trop large. « Comment la reconversion d’un héritage industriel peut-elle préserver une mémoire du travail sans figer un territoire ? » ouvre une enquête plus précise : des acteurs, une tension et des exemples. Écrire d’abord la réponse provisoire, puis chercher ce qui pourrait la contredire. Une question n’a pas besoin de promettre une solution définitive pour être pertinente.

Constituer un dossier de deux pages : question, rattachement aux programmes, cinq notions maîtrisées, deux ou trois exemples documentés, trois sources dont on connaît la nature, une objection et une réponse. Une question transversale doit réellement utiliser les concepts de l’autre spécialité ; une statistique isolée ne suffit pas à rendre une question HGGSP « mathématique ». Ne fabriquez pas la seconde spécialité d’un candidat inconnu.

## Simulation guidée : la connaissance et le cyberespace

**Question de travail, à personnaliser.** « Pourquoi l’interconnexion des universités crée-t-elle à la fois une ressource scientifique et une vulnérabilité ? » Rattachement : T06. Cette proposition ne remplace pas les deux questions personnelles conformes au parcours du candidat.

**Préparation sur l’année.** Relire le cours, distinguer données et connaissances, puis décrire une coopération réelle sans révéler de données sensibles. Construire une carte d’acteurs : laboratoire, université, fournisseur, autorité de sécurité, partenaire étranger. Utiliser la situation fictive T06-Doc2 pour tester le raisonnement, sans la raconter comme un incident historique.

**Trame de dix minutes.** Une minute pour définir le problème ; trois minutes sur le partage des données, des outils et des compétences ; trois minutes sur les dépendances et la sécurité ; deux minutes sur les conditions d’une coopération maîtrisée ; une minute de conclusion. Ce découpage est un outil d’entraînement, non un minutage imposé par les textes. Un exemple expliqué vaut mieux qu’une liste de cyberattaques mal connues.

**Relances possibles.** Une adresse IP suffit-elle à attribuer une attaque ? Faut-il garder toute connaissance secrète ? Qui décide du partage ? Quels coûts comporte une protection ? Qu’est-ce qui ferait évoluer votre réponse ? Le candidat doit savoir dire qu’un fait n’est pas établi, puis expliquer quel élément permettrait de l’établir.

## Évaluer une prestation sans la réduire à l’éloquence

Après l’enregistrement, écouter une première fois sans s’arrêter : la question et la réponse sont-elles compréhensibles ? Écouter ensuite pour compter les affirmations non justifiées et les mots non définis. Vérifier cinq dimensions : solidité des connaissances, progression de l’argumentation, précision de la langue, intelligibilité de la voix et qualité de l’interaction. La vitesse et l’assurance ne compensent pas une erreur factuelle. Une hésitation suivie d’une distinction rigoureuse peut être préférable à une réponse immédiate inventée.

Réaliser trois essais espacés. Premier essai avec notes ; deuxième avec une trame réduite ; troisième avec un interlocuteur qui interrompt uniquement pendant la phase d’échange. Après chaque essai, corriger un défaut prioritaire, pas dix à la fois. Préparer des réponses flexibles plutôt qu’un dialogue récité.

## Oral de contrôle HGGSP : une simulation complète {#controle}

**Cadre 2027.** Préparation : vingt minutes. Présentation construite : dix minutes. Échange : dix minutes. Le sujet comporte deux questions problématisées au choix portant sur des parties différentes ; le périmètre est celui de l’écrit, donc T02, T04, T05 et T06 pour 2027. [S04]

**Sujet pédagogique OC1.** Choisissez l’une des deux questions : A. « Pourquoi une victoire militaire ne suffit-elle pas à construire la paix ? » — T02. B. « Comment protéger un patrimoine tout en maintenant ses usages ? » — T04. Ce sujet est original, non issu d’une banque officielle.

Pendant les vingt minutes, consacrer cinq minutes à délimiter, dix minutes à organiser deux ou trois arguments avec exemples et cinq minutes à préparer l’entrée et la conclusion. Ne recopier ni tout le cours ni une dissertation complète. Sur la feuille, indiquer surtout les relations à expliquer.

**Repères de réponse OC1-A.** Distinguer arrêt des combats, accord politique, sécurité et reconstruction ; comparer 1991 et 2003 ; évoquer normes, acteurs locaux et institutions ; ne pas présenter toutes les opérations de l’ONU comme identiques. **Relances :** qu’apporte une victoire ? Quelles conditions permettent un compromis ? Le veto suffit-il à expliquer toute difficulté ?

**Repères de réponse OC1-B.** Définir patrimonialisation et usages ; montrer la nécessité d’empêcher des destructions ; expliquer la reconversion du bassin minier ; intégrer habitants et risques à Venise ; discuter la transmission immatérielle. **Relances :** un label protège-t-il seul ? Qui paie ? Une reconstruction est-elle toujours une falsification ?

**Autoévaluation.** Une réponse maîtrisée définit les termes, répond à la question, explique au moins deux exemples précisément situés et résiste à une relance en reconnaissant une limite. Après un essai, reprendre R1 si les repères sont confondus, R3 si les exemples sont racontés sans lien ou R5 si le plan ne répond pas au sujet.
