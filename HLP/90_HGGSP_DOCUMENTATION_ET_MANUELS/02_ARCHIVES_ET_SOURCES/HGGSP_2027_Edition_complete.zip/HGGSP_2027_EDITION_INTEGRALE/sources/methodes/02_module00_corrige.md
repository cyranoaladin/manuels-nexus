# Entrer en HGGSP — Autocorrection du module 00

Module fondateur conservé ; identifiants préfixés « 00- » pour éviter les collisions avec ceux du manuel.

## Autocorrection — Module 00

**Entrer en HGGSP — compagnon du candidat**

**À OUVRIR APRÈS AVOIR ÉCRIT**

Une correction sert à comprendre la différence entre votre raisonnement et une réponse recevable. Lire un modèle ne suffit pas : reprenez ensuite une tâche, sans regarder ce modèle.

### Comment utiliser ce compagnon

Comparez la demande avec votre réponse. Repérez ce qui est exact avant de chercher ce qui manque. Choisissez une erreur prioritaire : datation, nature de source, causalité, proportion ou argumentation. Reprenez la fiche correspondante et répondez à une question nouvelle.

Les formulations proposées ne sont pas toutes exclusives. Une réponse différente est recevable si elle respecte les documents, explique les liens et ne prétend pas en savoir plus que les sources. Les mini-grilles sont des outils pédagogiques, pas des barèmes ministériels.

| Erreur dominante | Reprise |
| --- | --- |
| Date de consultation prise pour date du texte | 00-R1 et lecture guidée du document A. |
| Succession présentée comme cause certaine | 00-R2 et 00-E6. |
| Pourcentage appliqué à la mauvaise population | 00-R3 et 00-E7. |
| Règle assimilée à une application effective | 00-R4 et 00-E4–00-E5. |
| Opinion non appuyée ou juxtaposition de pièces | 00-M08 et 00-E8–00-E10. |

Nexus Réussite • 8 septembre 2026. Les exercices sont originaux. Les réponses portant sur des cas fictifs ne décrivent aucun territoire réel.

## Diagnostic — réponses et orientation

| Item | Réponse expliquée | Reprise |
| --- | --- | --- |
| 00-D1 | 1648, puis 1789, puis 1992. L’ordre se détermine ici directement par les années. | 00-R1 |
| 00-D2 | 1789 contextualise la production du texte. Légifrance en diffuse une transcription consultée en 2026. Il faut distinguer auteur et support de diffusion. | 00-R1 |
| 00-D3 | Non. La succession temporelle ne suffit pas à démontrer une cause ; il faut un mécanisme et des éléments complémentaires. | 00-R2 |
| 00-D4 | Non. 80 % des réponses sont favorables. Sans méthode garantissant la représentativité, la proportion ne décrit pas tous les habitants. | 00-R3 |
| 00-D5 | Non. Le règlement exprime une norme. Son application demande d’autres sources, par exemple des décisions ou observations. | 00-R4 |
| 00-D6 | Non. Vérifier origine, date, contexte ou recoupement. Le nombre de partages mesure une circulation, pas l’exactitude. | 00-R4 |
| 00-D7 | Commune, État, monde. Une question peut articuler plusieurs de ces échelles. | 00-R3 |
| 00-D8 | Il s’agit d’un jugement. Il faut préciser des critères, apporter des informations et expliquer le lien entre celles-ci et l’appréciation. | 00-R2 |

Une réponse brève mais justifiée vaut mieux qu’une affirmation longue sans contrôle. Pour les items 00-D3 à 00-D6, un simple « non » repère la direction mais ne prouve pas encore la compréhension de la limite.

**NOUVEL ESSAI**

Sans relire le tableau, expliquez la différence entre une source et sa publication numérique, puis entre une proportion de répondants et une proportion de population. Si vous hésitez, reprenez seulement les lignes utiles avant de retenter.

## 00-E1 à 00-E3 — Identifier et articuler les approches

### 00-E1 — Les quatre questions

**a : histoire.** La question porte principalement sur l’évolution de la fonction du port dans le temps.
**b : géographie.** Elle demande une localisation et une relation entre espaces.
**c : géopolitique.** Elle examine une négociation et une rivalité d’acteurs autour d’un contrôle.
**d : sciences politiques.** Elle porte sur l’autorité de décision et la participation.

Il ne s’agit pas de frontières étanches : la négociation peut aussi être éclairée par les institutions, et l’organisation spatiale par son histoire. Pour réussir, il faut identifier ce qui domine dans chaque question, puis expliquer une articulation utile.

### 00-E2 — Une question possible

« Comment les intérêts territoriaux des deux communes influencent-ils les modalités de la décision sur le port ? » La question combine une analyse des acteurs et des territoires avec celle de la décision. Elle est plus précise qu’un avis personnel sur le projet.

Autre réponse possible : « Comment l’évolution historique des activités du port a-t-elle modifié l’organisation des quartiers voisins ? » Elle articule histoire et géographie. Aucun fait supplémentaire ne doit être inventé : ce sont des questions de recherche.

### 00-E3 — Deux phrases recevables

« Les communes et l’association sont des acteurs, mais leurs objectifs ne sont pas identiques. »
« La décision s’analyse à l’échelle locale, tandis que l’étude des flux peut conduire à examiner des espaces plus larges. »

**ERREUR FRÉQUENTE**

Associer « géopolitique » seulement à la guerre ou « histoire » seulement à une date. Une approche se reconnaît par la question et le raisonnement, non par un mot isolé.

## 00-E4 et 00-E5 — Le document de 1789

### 00-E4 — Présenter, expliquer, limiter

**1.** Il s’agit de l’article 16 de la Déclaration des droits de l’homme et du citoyen, adoptée en août 1789 par l’Assemblée nationale, ici consultée dans une transcription diffusée par Légifrance. [S10]

**2.** Le texte exige la protection des droits et une organisation distinguant les pouvoirs. La réponse doit retrouver les deux exigences, sans remplacer l’une d’elles par la seule présence d’élections.

**3.** Le document énonce un principe permettant de définir ce qu’une constitution doit garantir. Il ne présente pas un compte rendu d’application ni une enquête.

**4.** La conclusion du candidat est excessive. On peut établir ce que le texte affirme ; on ne peut pas déduire de cette affirmation que les pratiques de toute une société s’y conforment aussitôt.

**5.** Des décisions, des archives de mise en œuvre, des pratiques institutionnelles documentées ou des travaux d’historiens reposant sur ces pièces peuvent éclairer l’application. Il faut préciser quelle exigence l’on souhaite examiner.

### 00-E5 — Trois fonctions distinctes

| Fonction | Exemple de formulation |
| --- | --- |
| Information | Le texte associe la constitution à deux exigences concernant droits et pouvoirs. |
| Explication | Il fixe un critère normatif d’organisation politique plutôt qu’un simple nom donné à un régime. |
| Limite | Cet article ne permet pas, seul, de décrire l’application des principes dans toutes les situations de l’époque. |

L’exercice demande une analyse du document, pas un récit intégral de la Révolution française. Une connaissance extérieure exacte peut éclairer le texte ; elle ne doit pas remplacer son étude.

Document réel : S10. Le module ne tire de cet article aucun diagnostic juridique sur une situation actuelle.

## 00-E6 à 00-E9 — Argumenter sur le dossier Rivage

### 00-E6 — Réparer les deux généralisations

Deux sauts : consulter ne suffit pas à qualifier toute la décision de démocratique ; pouvoir répondre ne signifie pas approuver. **Réécriture possible en quatre phrases :** Une consultation permet aux personnes qui y ont accès d’exprimer un avis. Elle ne prouve pas, à elle seule, l’accord de tous les habitants. Il faudrait connaître les conditions d’accès, les réponses et leur traitement. Pour apprécier la décision, il faudrait aussi examiner la pluralité de l’information, les droits et la prise en compte des avis.

### 00-E7 — Réponses précises

**1.** F1 est un communiqué favorable au projet ; F2 une note décrivant un recueil de réponses ; F3 un compte rendu d’association exprimant des réserves.
**2.** Les emplois sont annoncés comme une possibilité, non comme des emplois déjà créés.
**3.** 156 ÷ 200 = 0,78 : **78 % des réponses enregistrées** sont favorables.
**4.** La représentativité, l’absence de réponses multiples et le profil des répondants ne sont pas établis ; on ne connaît pas non plus la population totale.

### 00-E8 — Une réponse possible

Les pièces montrent un soutien important parmi les réponses enregistrées, mais elles n’établissent pas l’adhésion de tous les habitants. La note F2 compte 156 réponses favorables sur 200, soit 78 %. Le caractère volontaire du questionnaire et l’absence d’informations sur les doublons limitent cependant la portée de ce résultat. Le communiqué F1 utilise ce soutien pour défendre l’extension et évoque des emplois possibles : il ne démontre pas leur création. Enfin, F3 rend visibles des enjeux environnementaux et demande une comparaison des solutions. Ce compte rendu ne constitue pas, à lui seul, une étude d’impact. Ainsi, les documents permettent d’identifier des positions et un résultat de consultation, mais pas de trancher tous les effets du projet. Des pièces sur le recueil des réponses, les emplois et l’environnement seraient nécessaires.

### 00-E9 — Discuter les statuts

L’origine municipale n’implique pas la neutralité : F1 défend une position. L’origine associative ne rend pas F3 inutilisable : la pièce renseigne sur une demande et des réserves, dont l’expertise reste à examiner. Une enquête correctement documentée et un rapport technique d’impact apporteraient des informations de nature différente.

Une position identifiée n’est pas une preuve de mensonge. Ne pas attribuer d’intention dissimulée sans élément.

## 00-E10, 00-E11 et fiches de reprise

### 00-E10 — Problématique et plan possibles

**Problématique.** À quelles conditions la participation à une consultation éclaire-t-elle le caractère démocratique d’une décision, et quelles informations supplémentaires sont nécessaires ?

**I.** Une consultation peut ouvrir une possibilité d’expression et renseigner sur les avis recueillis.
**II.** Sa portée dépend des conditions d’accès, de la pluralité de l’information et du traitement des réponses.
**III, si utile.** L’évaluation de la décision exige aussi d’examiner les institutions, les droits et la manière dont les résultats sont pris en compte.

Un plan en deux parties regroupant les limites est recevable. En revanche, « I. La mairie ; II. L’association » juxtapose des acteurs sans nécessairement répondre à la question.

### 00-E11 — Fiche de document

Origine : Déclaration adoptée par l’Assemblée nationale. Date : 1789. Apport : critère normatif associant droits et organisation des pouvoirs. Limite : ne décrit pas à lui seul les pratiques. Question de rappel : « Pourquoi ce texte ne suffit-il pas à prouver son application ? » [S10]

### 00-R1 et 00-R2

**00-R1.** 1950 est la date des propos ; 1951 et 2020 décrivent leur publication et leur transmission. **00-R2.** Examiner notamment l’évolution du commerce, d’autres équipements, les tarifs ou la période de mesure ; chercher un mécanisme précis reliant la route à la hausse. Pour la réforme, remplacer « bonne » et « moderne » par un objectif défini, par exemple une réduction d’un délai, et demander des mesures comparables.

### 00-R3 et 00-R4

**00-R3.** 45 ÷ 60 = 75 % des réponses. « 75 % de tous les habitants » serait abusif sans information supplémentaire. **00-R4.** Ni la charte ni les dates de réunions ne prouvent un accès effectif pour tous. Un registre d’accès, des modalités publiées ou une observation documentée apporteraient des éléments utiles.

Les exemples de sources complémentaires doivent être évalués selon leur pertinence : proposer « un autre site » sans dire quelle information on cherche ne suffit pas.

## Bilan A — Correction et grille de travail

**A1.** La charte pose une règle. Le communiqué affirme une transparence totale. La note donne un décompte de comptes rendus publiés. **A2.** 24 ÷ 30 = 80 % des comptes rendus prévus ont été publiés.

**A3.** La note établit une publication partielle selon son décompte. Elle ne renseigne pas sur la complétude des comptes rendus, la facilité d’accès ou les autres formes de transparence ; elle ne permet pas non plus d’inventer les raisons des six absences.

### A4 — Un paragraphe possible

Les pièces ne suffisent pas à établir une transparence totale. La charte énonce une obligation de publicité, mais cette règle doit être distinguée de sa mise en œuvre. La note indique que 24 comptes rendus sur 30 prévus ont été publiés, soit 80 % : la publication n’est donc pas exhaustive selon le périmètre annoncé. De plus, la note ne décrit ni la qualité des informations ni leur accessibilité. Le communiqué présente une appréciation favorable que les pièces disponibles ne démontrent pas. Il faudrait examiner les comptes rendus, les modalités d’accès et les motifs des absences pour préciser l’analyse.

**A5.** Un registre de publication documenté ou les pièces elles-mêmes seraient utiles. Question de sciences politiques possible : « Quels mécanismes permettent aux habitants de demander des comptes sur la mise en œuvre de la règle ? »

| Critère pédagogique | À vérifier dans la copie |
| --- | --- |
| Nature des informations | La règle, l’affirmation et la donnée sont distinguées. |
| Donnée | Le pourcentage et son dénominateur sont corrects. |
| Raisonnement | Une pièce précise soutient chaque idée importante. |
| Limites | La conclusion ne dépasse pas le dossier. |
| Vérification | Le document supplémentaire répond à une lacune identifiée. |

Pour un suivi chiffré local, on peut attribuer 0, 1 ou 2 par critère. Ce score /10 est une proposition de diagnostic, non un barème national ni une conversion automatique en note de baccalauréat.

## Bilan B — Correction et revalidation

**B1.** Le règlement établit une règle ; le service municipal formule une affirmation ; le registre fournit un nombre de dossiers disponibles. **B2.** 21 ÷ 28 = 75 % des dossiers ont été disponibles avant la réunion.

**B3.** Sur le périmètre fourni, sept dossiers ne l’étaient pas. Les données ne soutiennent donc pas l’affirmation d’une disponibilité toujours intégrale. Elles n’expliquent ni les causes des absences ni la bonne ou mauvaise foi du service.

### B4 — Un paragraphe possible

L’information n’apparaît pas toujours intégralement disponible au regard du registre fourni. Celui-ci recense 21 dossiers disponibles avant réunion sur 28 examinés, soit 75 %. Le règlement décrit une exigence, mais le décompte montre qu’elle n’a pas été remplie pour tous les dossiers de cette série. Il existe donc un écart avec l’affirmation générale du service. En revanche, le registre n’indique ni les raisons des manques ni le nombre de personnes ayant consulté les pièces. Pour préciser l’analyse, il faudrait examiner les dates et conditions de publication ainsi que les dossiers concernés.

**B5.** Vérification : contrôler les dates de mise à disposition de chaque dossier. Question de géographie possible : « Les lieux et les moyens d’accès à ces informations sont-ils également disponibles dans les différents quartiers ? »

### Quand considérer la méthode comme acquise ?

Vous pouvez expliquer spontanément la différence entre règle et pratique, utiliser une donnée avec son dénominateur, formuler une conclusion limitée et choisir un complément pertinent. Il faut pouvoir le refaire sur un document différent, pas seulement retrouver les phrases de ce compagnon.

**RETOUR À L’APPRENTISSAGE**

Si l’un de ces gestes reste fragile, reprenez la fiche ciblée et écrivez un nouvel exemple. Si le bilan B est réussi sans aide, passez au premier thème ; gardez toutefois une réactivation de 00-M04 et 00-M08 dans les semaines suivantes.

Sources du document réel et des épreuves : registre du module élève. Tous les dossiers de ces bilans sont fictifs et conçus pour un apprentissage méthodologique.

