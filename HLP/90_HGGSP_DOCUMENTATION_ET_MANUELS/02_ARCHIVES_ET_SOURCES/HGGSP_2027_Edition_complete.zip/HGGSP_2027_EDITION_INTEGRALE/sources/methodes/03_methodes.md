# Douze méthodes pour travailler et réussir les épreuves {#methodes}

## M1 — Comprendre un sujet avant de réciter le cours {#M1}

Un sujet n’est pas le nom d’un chapitre. Commencer par identifier les termes, la relation demandée, les limites spatiales et les bornes chronologiques. Puis reformuler la tâche en une phrase : « Je dois expliquer pourquoi… », « comparer selon… » ou « montrer comment… ». Une question contenant « et » n’appelle pas nécessairement une partie sur chaque terme : elle demande souvent d’étudier leur relation.

**Exemple.** « Patrimoine et tourisme : des intérêts toujours convergents ? » invite à examiner les conditions d’une convergence et ses limites. Une copie qui raconte successivement l’histoire de Versailles et celle de Venise sans les relier au tourisme ne répond pas. Le mot « toujours » demande une mise à l’épreuve : financements, fréquentation, pression sur l’habitat, conservation et choix publics.

Au brouillon, dessiner trois colonnes : **ce que le sujet demande ; ce que je sais utiliser ; ce que je dois laisser de côté**. Écarter une connaissance exacte n’est pas un échec lorsqu’elle n’éclaire pas le problème. Définir les mots par leurs usages dans le sujet, et non par une longue succession de définitions de dictionnaire.

**Micro-entraînement.** Pour « Faire la paix par la sécurité collective », garder la Charte de l’ONU, les mandats, la coopération et leurs limites ; ne pas transformer la réponse en histoire de toutes les batailles du XXe siècle. Une problématique possible est : comment des États souverains peuvent-ils organiser une sécurité commune malgré leurs intérêts divergents ? **Critère de réussite :** chaque partie annoncée répond à un aspect de cette question.

## M2 — Construire des repères utiles {#M2}

Un repère associe **date, acteur, espace, événement et signification**. « 1648 » seul est fragile ; « traités de Westphalie, règlement de conflits européens par la négociation, sans fin de toutes les guerres » est utilisable. Mémoriser un nombre de dates très élevé sans savoir les mobiliser crée une illusion de maîtrise.

Construire une chronologie à deux niveaux : cinq repères structurants par thème, puis quelques dates permettant de préciser un exemple. Relier les événements par des mots prudents : « permet », « fragilise », « contribue à », « dans un contexte de ». La succession ne prouve pas la causalité. L’élection d’Allende en 1970 précède le coup d’État de 1973 ; elle ne suffit pas, isolément, à l’expliquer.

**Exemple comparatif.** Portugal : rupture militaire du 25 avril 1974, phase de transition, Constitution de 1976. Espagne : mort de Franco en 1975, réformes et élections de 1977, Constitution de 1978, alternance de 1982. Le tableau ne doit pas faire croire que ces trajectoires ont le même point de départ ou le même rôle de l’armée.

Pour apprendre, fermer le cours et restituer le repère avec sa signification. Vérifier, corriger, puis rappeler après deux jours et une semaine. **Micro-entraînement corrigé :** 1896 renvoie à Becquerel, 1934 à la radioactivité artificielle, 1945 aux bombardements atomiques ; leur lien est une histoire de recherches et d’applications, non une découverte unique en trois dates. **Critère :** expliquer le rôle de la date dans l’argument, pas seulement la placer.

## M3 — Présenter et critiquer une source {#M3}

Présenter une source exige son auteur ou producteur, sa nature, sa date, son contexte, ses destinataires et son objectif lorsque ces éléments sont connus. Ne pas inventer ce que la notice ne donne pas. Distinguer date des faits, date de production et date de publication ou de republication.

La critique ne consiste pas à déclarer une source « subjective donc inutile ». Elle examine ce que sa position permet de voir et ce qu’elle ne permet pas d’établir. Un discours officiel renseigne sur une stratégie de présentation, même lorsqu’il ne prouve pas l’efficacité de la politique annoncée. Un témoignage fournit une expérience située, non une vision exhaustive de tout un conflit.

**Exemple.** L’article 10 du traité sur l’Union européenne est un texte juridique normatif. Il décrit des circuits de représentation. Il peut étayer l’analyse institutionnelle ; il ne mesure ni la satisfaction ni la participation effective des citoyens. Pour ces questions, il faut d’autres matériaux : enquêtes, résultats électoraux, études et comparaisons datées.

Procédure : relever un élément exact ; l’expliquer grâce au cours ; préciser sa portée ; confronter, lorsque nécessaire, une autre source. **Micro-entraînement corrigé :** une brochure vantant un site patrimonial permet d’étudier sa promotion et les publics visés ; elle ne constitue pas seule une preuve de bénéfices équitablement distribués. **Critère :** une limite formulée porte sur une question précise, sans disqualifier automatiquement toutes les informations du document.

## M4 — Lire un tableau, un graphique ou une carte {#M4}

Avant de commenter, vérifier titre, producteur, date, unité, champ, échelle et légende. Pour un taux, identifier le numérateur et le dénominateur. Pour une carte, distinguer ce qui est localisé, représenté par une surface ou figuré par un flux. Un schéma de principe n’a pas nécessairement une échelle métrique.

**Calcul.** Un taux passant de 60 % à 75 % augmente de **15 points de pourcentage**. Son augmentation relative est de 15/60, soit **25 %**. Ces deux formulations sont différentes et toutes deux recevables si l’on précise ce qui est mesuré. « Deux tiers des personnes non alphabétisées sont des femmes » n’équivaut pas à « deux tiers des femmes ne sont pas alphabétisées » : le dénominateur change.

Pour un graphique, commenter une tendance et une rupture avec des valeurs exactes, puis proposer une explication située. Ne pas inventer une évolution entre deux observations trop espacées. Une corrélation invite à enquêter sur un mécanisme ; elle ne le démontre pas seule.

Pour une carte de réseaux, étudier nœuds, axes, interfaces, hiérarchies et absences. **Exemple maritime :** une zone de 200 milles marins mesurée depuis les lignes de base ne doit pas être présentée comme 200 milles supplémentaires au-delà de la mer territoriale. Les chevauchements demandent des délimitations. **Critère :** chaque commentaire chiffré conserve son unité, son espace et sa période ; chaque interprétation se distingue de la simple lecture.

## M5 — Rédiger un paragraphe argumenté {#M5}

Un paragraphe défend une idée en répondant au problème. Il articule une affirmation, une explication, un exemple précis et une phrase qui établit la portée de l’exemple. Cet ordre peut varier ; ce n’est pas une formule à recopier mécaniquement. L’exemple doit être **analysé**, pas ajouté comme décoration.

**Phrase pauvre :** « La connaissance est importante. Marie Curie a découvert le radium. » **Réécriture :** « La production des connaissances repose sur l’articulation d’initiatives individuelles et de ressources collectives. Les travaux de Marie et Pierre Curie sur le radium en 1898 mobilisent des instruments, des opérations chimiques et des échanges savants. La reconnaissance de leur contribution ne doit donc pas masquer les conditions matérielles et institutionnelles qui rendent la recherche possible. »

Employer des connecteurs qui correspondent au raisonnement : « parce que » pour une explication ; « cependant » pour une limite ; « tandis que » pour une comparaison. Remplacer « cela montre que » lorsque le lien reste implicite par une phrase qui précise **ce qui est montré et pourquoi**.

**Micro-entraînement.** Expliquer en cinq phrases pourquoi une frontière peut faciliter certains échanges tout en les contrôlant. La correction doit contenir une interface, des règles, des acteurs et un exemple comme le Rhin supérieur. **Critère :** un lecteur peut identifier l’idée du paragraphe sans deviner le sujet ; la dernière phrase n’annonce pas simplement qu’on a donné un exemple.

## M6 — Construire un plan qui répond {#M6}

Un plan est la structure d’une démonstration, pas un rangement de souvenirs. Les parties doivent être distinctes, équilibrées et reliées. Deux parties solides peuvent être préférables à trois parties dont la dernière répète les précédentes. Il n’existe pas de plan universel « causes, conséquences, solutions » ni de plan obligé « oui, non, peut-être ».

Pour choisir, partir des relations établies au brouillon. Une progression chronologique convient lorsqu’elle explique une transformation et respecte les bornes ; une comparaison doit utiliser les mêmes critères ; un plan thématique doit répondre à une tension, non juxtaposer des dossiers.

**Exemple.** « La connaissance, une ressource de puissance » : I. La produire et y accéder élargit les capacités d’action ; II. La contrôler et organiser sa circulation crée des dépendances mais impose aussi des coopérations. Dans I, alphabétisation et recherche ; dans II, renseignement, Inde et cyberespace. Ce plan est recevable si les exemples sont analysés et si la dimension d’émancipation ne disparaît pas.

Tester chaque titre en ajoutant mentalement « car… ». Si aucune proposition explicative ne suit, la partie est probablement descriptive. Puis vérifier que chaque exemple sert le titre. **Micro-entraînement corrigé :** « I. Versailles ; II. Venise ; III. Mali » ne constitue pas encore une démonstration sur les conflits patrimoniaux. On peut préférer « des usages concurrents », puis « des dispositifs de protection et leurs arbitrages », en croisant les exemples. **Critère :** le plan devient inadapté lorsqu’on change le sujet ; s’il fonctionne pour presque tout, il est trop vague.

## M7 — Introduire, conclure, relire {#M7}

L’introduction situe l’objet, définit les termes utiles, construit le problème et annonce une démarche. Une accroche n’est pas obligatoire si elle est artificielle. Éviter « depuis la nuit des temps », les citations mal connues et les définitions interminables. Pour l’étude critique, présenter les documents et leur intérêt dans le problème, sans réciter une fiche d’identité séparée de l’analyse.

**Exemple d’ouverture.** « La reconnaissance d’un site comme patrimoine peut favoriser sa protection, mais elle attire aussi des usages concurrents. Le tourisme apporte des ressources tout en accentuant parfois les pressions sur les lieux et les habitants. Il faut donc examiner à quelles conditions la valorisation soutient la transmission plutôt qu’elle ne la compromet. » La suite annonce les deux mouvements réellement suivis.

La conclusion répond à la question et hiérarchise les résultats. Elle ne répète pas intégralement les titres et n’ajoute pas un exemple essentiel oublié. L’ouverture est facultative : une conclusion exacte vaut mieux qu’une question vague sur « l’avenir du monde ».

Relire en trois passages rapides : réponse au sujet ; exactitude des noms, dates et notions ; lisibilité de l’expression. Vérifier les pronoms sans antécédent et les phrases excessivement longues. **Micro-entraînement corrigé :** « En conclusion, le patrimoine est important » doit devenir une réponse, par exemple « sa valorisation protège sous conditions de régulation, de financement durable et de prise en compte des habitants ». **Critère :** la conclusion ne pourrait pas être écrite avant d’avoir établi les arguments.

## M8 — Réussir la composition du niveau 1 {#M8}

La composition N1 est une réponse organisée en **deux heures** à un sujet relevant d’un axe ou d’un objet conclusif de Première. Elle ne demande pas une étude critique séparée. Les connaissances doivent être sélectionnées, expliquées et reliées au sujet. Le volume de pages n’est pas un barème national. [S05]

Répartition indicative : 10 minutes pour analyser ; 20 minutes pour élaborer le plan et les exemples ; 80 minutes pour rédiger ; 10 minutes pour relire. Adapter après deux simulations. Ne pas rédiger tout le devoir au brouillon. Préparer surtout la problématique, l’ordre des idées et les faits qui soutiendront chaque paragraphe.

**Exemple.** Pour « Avancées et reculs des démocraties : des processus réversibles », le cœur est l’axe 2 de P01 : inquiétudes de Tocqueville, Chili, Portugal et Espagne. Athènes ne doit pas prendre la moitié de la copie. Montrer comment des institutions démocratiques peuvent être fragilisées, puis comment des transitions les construisent sans garantir leur irréversibilité, constitue une démarche possible.

**Grille pédagogique, non officielle :** compréhension et problématisation 4 points ; connaissances précises 6 ; argumentation et organisation 6 ; expression et achèvement 4. La note sert à localiser les besoins, pas à faire croire qu’un jury appliquerait obligatoirement cette décomposition. **Critère :** réponse complète, délimitée, nourrie de plusieurs exemples de l’axe ou de l’OTC, avec des relations explicitées et une conclusion.

## M9 — Réussir l’écrit terminal : deux exercices à mener jusqu’au bout {#M9}

L’écrit dure **quatre heures**. La dissertation et l’étude critique sont chacune notées sur 10. Deux dissertations sont proposées ; une seule doit être traitée. Les deux options relèvent de thèmes différents, et le dossier critique d’un troisième. Pour 2027, préparer T02, T04, T05 et T06 sans miser sur un sujet prédit. [S04]

Lire les trois propositions avant de choisir. Retenir la dissertation dont on comprend le problème et pour laquelle on dispose d’exemples précis, pas simplement celle dont un mot semble familier. Une proposition peut être plus connue en apparence mais exiger une relation mal maîtrisée.

Répartition indicative : 10 minutes de lecture et choix ; 110 minutes pour la dissertation ; 110 minutes pour l’étude critique ; 10 minutes de relecture finale. Une autre répartition est possible, mais laisser l’un des exercices inachevé coûte une part importante de l’évaluation. Inscrire des heures de bascule au brouillon et s’y tenir.

La dissertation mobilise le cours sans documents supports imposés. L’étude critique part des documents et les confronte au cours. Passer de l’une à l’autre exige donc un changement de démarche. **Exercice de préparation :** avant chaque blanc, écrire ce qui constituera la preuve d’achèvement : introduction, développement structuré et conclusion pour chacun des deux exercices. **Critère :** aucun exercice n’est sacrifié ; les exemples de dissertation répondent au sujet et les documents restent centraux dans l’étude critique.

## M10 — Organiser une étude critique de document(s) {#M10}

L’étude critique répond à une consigne en analysant un ou deux documents. Elle ne consiste ni à paraphraser, ni à réciter un cours qui oublie les documents. Commencer par lire la consigne, présenter les sources, repérer leurs idées et relever les éléments qui permettront une démonstration.

Au brouillon, utiliser quatre colonnes : **élément du document ; sens dans son contexte ; connaissance qui l’éclaire ; portée ou limite**. Une courte citation exacte peut être utile ; une reformulation fidèle suffit souvent. Toujours expliquer l’élément retenu. Avec deux documents, chercher convergences, compléments, contradictions et différences de nature ; éviter une partie entière par document lorsque la consigne demande de les confronter.

**Exemple.** Un texte de l’UNESCO affirme des objectifs de conservation ; un jugement de la CPI établit une responsabilité pour des destructions. Le premier renseigne sur une norme et une coopération ; le second sur une procédure et des faits jugés. Les rapprocher montre des instruments complémentaires, sans prétendre que l’UNESCO condamne pénalement ni que la CPI gère les restaurations.

L’introduction situe les documents et construit le problème ; le développement analyse des ensembles d’idées ; la conclusion répond et précise ce que le dossier permet d’établir. **Grille pédagogique sur 10 :** compréhension de la consigne 2 ; analyse et confrontation 3 ; contextualisation 2 ; critique de portée 2 ; organisation et expression 1. **Critère :** une limite est argumentée et liée au document, non ajoutée sous la formule « l’auteur est subjectif ».

## M11 — Préparer l’oral sans apprendre un texte immobile {#M11}

Le Grand oral n’est pas la récitation d’un exposé encyclopédique. Une question précise doit permettre un raisonnement, des exemples et une discussion. Préparer les deux questions avec les deux spécialités conservées ; vérifier leur conformité aux indications officielles. En 2027, la présentation dure dix minutes, suivie de dix minutes d’échange, après vingt minutes de préparation. [S08]

Construire une fiche d’appui : question, réponse directrice, deux ou trois mouvements, exemples, limites et sources. Répéter à partir de cette fiche plutôt que d’un texte appris mot à mot. Enregistrer une simulation, mesurer la durée et vérifier si les transitions sont audibles. Un support éventuel doit aider à raisonner, pas contenir tout le discours.

**Exemple HGGSP à adapter à l’autre spécialité :** « Les réseaux de connaissances peuvent-ils réduire la dépendance technologique d’un État ? » La question autorise Inde, recherche et cyberespace. Une question transversale avec NSI pourrait préciser les infrastructures et les conditions de maîtrise ; avec SES, formation et innovation. Ces exemples ne constituent pas des couples obligatoires.

Lors de l’échange, reformuler une question ambiguë, distinguer ce que l’on sait de ce que l’on suppose et reconnaître une limite précise. « Je ne dispose pas de ce chiffre, mais le mécanisme étudié est… » est préférable à une valeur inventée. Pour l’oral de contrôle HGGSP, préparer en vingt minutes une réponse au sujet remis, puis organiser dix minutes de présentation et dix minutes d’échange. **Critère :** répondre à une objection en mobilisant un exemple, sans quitter la question.

## M12 — Rechercher, vérifier, utiliser une actualité {#M12}

Une actualité illustre une connaissance ; elle ne doit pas remplacer le programme ni devenir une suite d’événements non expliqués. Commencer par définir la question et la date d’arrêt de l’enquête. Rechercher un document original, identifier son producteur, puis confronter des sources de nature différente lorsque les faits ou les interprétations sont disputés.

Distinguer annonce, décision, notification, entrée en vigueur et application. **Exemple :** le second retrait américain de l’accord de Paris est notifié en janvier 2025 et devient effectif le 27 janvier 2026. Confondre ces étapes produit une erreur même si le nom de l’accord est exact. Le dépôt d’une requête devant une juridiction n’équivaut pas à une condamnation ; une mesure provisoire n’est pas un jugement définitif sur tous les faits. [D10]

Tenir une fiche : fait établi ; source et date ; contexte ; interprétations ; incertitudes ; lien avec un jalon. Ne pas intégrer une statistique dont on ignore l’unité ou la population. Une image doit être vérifiée dans son contexte : source originale, date, lieu et éventuelle réutilisation.

Une réponse d’intelligence artificielle peut aider à organiser une recherche, mais elle n’est pas une preuve historique. Vérifier les références, les citations et les chiffres dans les documents originaux. Ne pas transmettre de données personnelles inutiles. **Critère :** pouvoir expliquer pourquoi une source est pertinente pour une affirmation précise et quelles limites subsistent. Une bonne actualisation peut être courte ; sa valeur vient de sa traçabilité et de son rôle dans l’argument.
