# N1-3 — Composition de Première

**Durée : 2 heures. Note : sur 20.** Épreuve blanche originale ; aucun document ni accès au cours pendant la simulation. Rédigez une introduction, un développement organisé et une conclusion.

## Sujet

**Pourquoi l’ouverture des frontières européennes ne signifie-t-elle pas leur disparition ?**

Périmètre de préparation : P03, objet conclusif — Les frontières internes et externes de l’Union européenne. Ce sujet porte sur cette seule partie du programme de Première.
