# N1-5 — Composition de Première

**Durée : 2 heures. Note : sur 20.** Épreuve blanche originale ; aucun document ni accès au cours pendant la simulation. Rédigez une introduction, un développement organisé et une conclusion.

## Sujet

**Comment l’État indien peut-il organiser le pluralisme religieux dans une société traversée par des tensions ?**

Périmètre de préparation : P05, objet conclusif — État et religions en Inde. Ce sujet porte sur cette seule partie du programme de Première.
