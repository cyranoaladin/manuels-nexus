# Correction N1-1 — Pourquoi le passage à la démocratie est-il un processus incertain ?

## Analyser et problématiser

« Passage » désigne une transformation, pas seulement une première élection. « Incertain » invite à examiner des fragilités et des bifurcations, sans affirmer que toute transition échoue. Les jalons du Chili, du Portugal et de l’Espagne permettent de comparer rupture antidémocratique, mobilisations et compromis. Problématique possible : comment des acteurs peuvent-ils construire des garanties démocratiques lorsque les rapports de force et l’héritage autoritaire restent ouverts ?

## Une organisation recevable

I. Des rapports de force peuvent interrompre ou fragiliser la démocratie : polarisation, armée, acteurs extérieurs ; Chili. II. La sortie d’un régime autoritaire exige la construction disputée de règles et de garanties : Portugal et Espagne. III. La stabilisation dépend de compromis et de contre-pouvoirs qui ne suppriment pas tous les conflits. Deux parties sont également possibles en regroupant les deux dernières.

## Proposition rédigée

En avril 1974, la chute de la dictature portugaise ouvre une période de transformation sans fixer immédiatement toutes les institutions du nouveau régime. L’événement rappelle qu’une rupture ne suffit pas à assurer la démocratie. Celle-ci suppose non seulement des élections, mais des libertés, des droits et la possibilité d’une alternance dans un cadre accepté. Pourquoi son établissement demeure-t-il incertain ? Les exemples chilien, portugais et espagnol montrent que les rapports de force peuvent renverser un régime, tandis que sa démocratisation exige des garanties dont la construction reste conflictuelle.

D’abord, les procédures électorales ne mettent pas une démocratie à l’abri d’une crise. Au Chili, Salvador Allende accède à la présidence en 1970 dans un cadre constitutionnel. Son projet de transformation, les oppositions qu’il rencontre, la polarisation et les tensions économiques s’inscrivent dans un contexte de guerre froide. L’hostilité américaine intervient dans ce contexte, sans dispenser d’étudier les acteurs chiliens et leurs décisions. Le coup d’État du 11 septembre 1973, conduit par les militaires, détruit les garanties démocratiques et ouvre une dictature. Cet exemple interdit de considérer la démocratie comme un acquis irréversible produit par une seule élection.

La sortie de l’autoritarisme est elle-même une période d’incertitude. Au Portugal, le Mouvement des forces armées joue un rôle décisif le 25 avril 1974. La fin du régime ouvre des libertés, mais les orientations économiques, sociales et institutionnelles font l’objet de conflits. Les mobilisations populaires et les divisions entre forces politiques montrent que tous les adversaires de la dictature ne partagent pas exactement le même projet. Les élections et la Constitution de 1976 participent à la construction d’un cadre démocratique. La transition doit donc être comprise comme une succession de décisions, non comme la simple conséquence automatique du jour de la révolution.

L’Espagne offre un autre chemin. Après la mort de Franco en 1975, la transformation s’effectue à partir d’institutions héritées, sous l’action du roi Juan Carlos, de responsables réformateurs, de forces d’opposition et de mobilisations sociales. Les élections de 1977 et la Constitution de 1978 organisent un nouveau cadre. Les compromis rendent possible un changement sans reproduire exactement la rupture portugaise ; ils suscitent aussi des débats sur les héritages de la dictature et les conditions de la transition. La tentative de coup d’État de février 1981 rappelle que l’établissement des institutions n’a pas immédiatement fait disparaître toutes les menaces.

Enfin, la consolidation exige que les acteurs acceptent les règles même lorsqu’ils perdent. Des élections pluralistes ne suffisent pas si l’armée peut intervenir contre le pouvoir civil ou si les droits de l’opposition ne sont pas protégés. Les libertés publiques, les contre-pouvoirs et les pratiques d’alternance donnent de la durée au changement. Ces garanties ne font pas disparaître les désaccords : elles permettent de les traiter sans supprimer la compétition politique. Il serait donc erroné de définir la stabilité démocratique par l’absence de conflit.

Le passage à la démocratie est ainsi incertain parce qu’il transforme des intérêts, des institutions et des usages du pouvoir. Il dépend des décisions prises pendant les crises autant que des règles progressivement établies. Les cas étudiés ne fournissent pas une recette unique, mais un même principe d’analyse : distinguer chute d’un régime, ouverture politique et consolidation démocratique, sans faire de l’une la garantie automatique des autres.

## Évaluer et reprendre

**Erreurs à corriger.** Présenter le coup d’État chilien comme une transition démocratique ; confondre Portugal et Espagne ; expliquer toutes les décisions par un seul acteur extérieur ; définir démocratie par absence de conflit.

**Autre démarche recevable.** Comparer les trois situations selon les acteurs, les modes de transformation puis les garanties, plutôt que suivre trois récits nationaux séparés.

**Barème pédagogique proposé, non ministériel.** Compréhension et problématique : 4 points ; connaissances exactes et situées : 6 ; raisonnement et organisation : 6 ; expression et achèvement : 4. Ne pas sanctionner deux fois la même faiblesse. Une organisation différente peut obtenir tous les points si elle répond au sujet.

**Après correction.** Relever deux écarts entre votre copie et les critères, non entre votre copie et les formulations de ce modèle. Réécrire un paragraphe sans consulter le texte. À J+7, traiter une question voisine pendant 30 minutes.
