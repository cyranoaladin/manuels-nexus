# Correction N1-4 — Pourquoi la liberté de l’information dépend-elle de rapports de force politiques et sociaux ?

## Analyser et problématiser

Il faut dépasser la seule existence d’un média. Le sujet appelle garanties juridiques, acteurs de l’information, pouvoirs et opinion, à travers Dreyfus, les agences et la guerre du Vietnam. Une composition sur Internet seulement sortirait du périmètre choisi.

## Une organisation recevable

I. Les règles et les institutions peuvent garantir ou restreindre l’expression. II. Journalistes, agences et publics agissent dans des rapports de dépendance et de concurrence. III. Les conflits et controverses rendent visibles des limites mais aussi des capacités de contestation.

## Proposition rédigée

Une information publiée n’est pas nécessairement indépendante, et une garantie juridique ne met pas toujours son producteur à l’abri des pressions. La liberté de l’information désigne la possibilité de rechercher, de produire et de diffuser des faits et des analyses dans un cadre protégeant cette activité. Pourquoi dépend-elle de rapports de force ? Les règles résultent de choix politiques, tandis que les conditions de production et les conflits déterminent la capacité réelle des acteurs à informer.

La liberté possède d’abord une dimension institutionnelle. En France, la loi du 29 juillet 1881 constitue un repère majeur de la liberté de la presse, tout en organisant des responsabilités et des limites. Elle n’abolit pas toutes les pressions ni toutes les infractions. Le droit définit des possibilités, mais l’accès aux moyens de publication, aux sources et aux protections professionnelles conditionne leur exercice. Une censure officielle peut empêcher la diffusion ; des contraintes économiques ou une menace contre un journaliste peuvent également réduire l’indépendance sans prendre la forme d’une interdiction générale.

L’affaire Dreyfus révèle la place de la presse dans une lutte politique et sociale. Des journaux défendent des interprétations opposées, mobilisent des publics et contribuent à structurer l’opinion. L’intervention de Zola avec J’accuse…! en 1898 donne une visibilité considérable à une contestation de la version officielle. Mais la presse véhicule aussi des préjugés, des accusations et des campagnes antisémites. La pluralité des titres permet une confrontation ; elle ne garantit pas que chaque publication recherche la vérité avec la même rigueur. Liberté et qualité de l’information sont donc liées sans être identiques.

Les agences de presse montrent un autre enjeu : l’organisation matérielle de la production. En collectant et diffusant des informations à de nombreux clients, elles rendent possible une couverture étendue. Elles peuvent fournir des procédures de vérification et une ressource commune aux rédactions. Cependant, la reprise d’une même dépêche par plusieurs médias ne constitue pas plusieurs enquêtes indépendantes. Le statut, les financements et les relations avec les pouvoirs doivent être examinés pour comprendre les conditions de l’autonomie. L’histoire de l’AFP permet de poser ces questions sans attribuer à toute agence une dépendance identique.

La guerre du Vietnam met enfin à l’épreuve les relations entre autorités, journalistes et opinion. Les images, reportages et enquêtes peuvent contredire un récit officiel ou rendre visibles des conséquences de la guerre. La publication des Pentagon Papers en 1971 montre l’importance de documents révélant des écarts entre certaines présentations publiques et les processus de décision. Il serait pourtant excessif d’affirmer que les médias auraient, seuls, déterminé l’issue de la guerre. Les mobilisations sociales, les choix politiques, les opérations militaires et les informations circulent dans une relation complexe.

La liberté de l’information se construit ainsi dans la confrontation entre acteurs disposant de ressources inégales. Les pouvoirs cherchent parfois à contrôler, les journalistes à enquêter, les entreprises à préserver leur activité et les publics à interpréter. Aucun de ces groupes n’est parfaitement homogène. Comprendre ces rapports permet d’éviter une opposition simpliste entre un pouvoir toujours manipulateur et des médias toujours indépendants.

La liberté dépend donc à la fois de garanties juridiques et de conditions concrètes de production, de protection et de réception. Les cas étudiés montrent qu’elle peut être défendue et élargie, mais aussi fragilisée. Elle ne constitue pas un état acquis une fois pour toutes : son effectivité doit être examinée à travers les institutions, les pratiques et les conflits.

## Évaluer et reprendre

**Erreurs à corriger.** Assimiler pluralité et vérité ; attribuer seul aux médias la fin de la guerre ; confondre agence et journal ; remplacer les exemples par une opinion générale sur la manipulation.

**Autre démarche recevable.** Construire une comparaison thématique entre garantie juridique, autonomie économique et contestation du récit officiel.

**Barème pédagogique proposé, non ministériel.** Compréhension et problématique : 4 points ; connaissances exactes et situées : 6 ; raisonnement et organisation : 6 ; expression et achèvement : 4. Ne pas sanctionner deux fois la même faiblesse. Une organisation différente peut obtenir tous les points si elle répond au sujet.

**Après correction.** Relever deux écarts entre votre copie et les critères, non entre votre copie et les formulations de ce modèle. Réécrire un paragraphe sans consulter le texte. À J+7, traiter une question voisine pendant 30 minutes.
