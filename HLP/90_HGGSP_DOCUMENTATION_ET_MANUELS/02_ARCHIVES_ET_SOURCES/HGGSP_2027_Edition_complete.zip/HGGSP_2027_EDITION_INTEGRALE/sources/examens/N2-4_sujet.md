# N2-4 — Écrit terminal HGGSP

**Durée : 4 heures. Note : sur 20.** Épreuve blanche originale, session de préparation 2027. Aucun accès au cours ni aux corrigés pendant la simulation.

## Première partie — Dissertation, sur 10

Choisissez **un seul** des deux sujets.

**Sujet 1 — Pourquoi les tentatives de paix au Moyen-Orient rencontrent-elles des difficultés ?**

**Sujet 2 — Le partage des connaissances est-il compatible avec leur protection ?**

Rédigez une introduction, un développement organisé et une conclusion. Une illustration pertinente est possible mais non obligatoire.

## Seconde partie — Étude critique, sur 10

**Patrimonialiser et transmettre : une responsabilité à plusieurs échelles**

En confrontant les documents, montrez comment la reconnaissance patrimoniale articule responsabilité publique et transmission. Vous discuterez les limites d’une protection réduite au seul label.

### Document 1 — Responsabilité nationale et coopération internationale

**Adaptation pédagogique**, non verbatim, des articles 4 et 6 de la convention de l’UNESCO concernant la protection du patrimoine mondial culturel et naturel, adoptée le 16 novembre 1972 [D11].

Chaque État partie reconnaît que l’identification, la protection, la conservation, la mise en valeur et la transmission aux générations futures du patrimoine situé sur son territoire lui incombent en premier lieu. Il agit selon ses ressources et peut mobiliser l’assistance et la coopération internationales. La reconnaissance d’un intérêt pour l’humanité s’articule au respect de la souveraineté des États et des droits de propriété prévus par les législations nationales. La convention organise donc une coopération ; elle ne transfère pas la propriété des biens à l’UNESCO.

### Document 2 — Trois héritages, des opérations différentes

**Tableau comparatif éditorial**, réalisé pour ce sujet à partir des notices institutionnelles des biens et pratiques. Sources : [B49 ; B53 ; B54 ; D12]. Les dates sont celles des inscriptions indiquées.

| Héritage | Reconnaissance | Une question de transmission |
|---|---|---|
| Paris, rives de la Seine | Patrimoine mondial, 1991 | Conserver un ensemble urbain tout en maintenant les fonctions d’une ville habitée. |
| Bassin minier du Nord-Pas-de-Calais | Patrimoine mondial, 2012 | Transmettre des traces et des mémoires du travail dans un territoire en reconversion. |
| Repas gastronomique des Français | Patrimoine culturel immatériel, 2010 | Transmettre une pratique sociale et des savoir-faire, non figer un menu obligatoire. |

**Note.** La dernière ligne relève du dispositif de la convention de 2003 sur le patrimoine culturel immatériel, et non d’une inscription au titre de la convention de 1972.

**Fin du sujet N2-4.** Les références servent à identifier les documents ; aucune consultation extérieure n’est nécessaire pendant l’épreuve. Les adaptations sont signalées et ne sont jamais présentées comme des citations littérales.
