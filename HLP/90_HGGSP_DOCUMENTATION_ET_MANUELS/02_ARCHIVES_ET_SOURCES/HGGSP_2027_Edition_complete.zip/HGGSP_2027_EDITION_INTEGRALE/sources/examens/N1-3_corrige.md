# Correction N1-3 — Pourquoi l’ouverture des frontières européennes ne signifie-t-elle pas leur disparition ?

## Analyser et problématiser

Le sujet porte sur l’Union et ses frontières, en distinguant espace Schengen et UE. Il faut examiner ouverture interne, coopération et contrôle externe, puis les différenciations. « Disparition » serait l’abolition de la limite politique et de ses fonctions, ce que la facilitation des circulations ne démontre pas.

## Une organisation recevable

I. Des dispositifs facilitent les circulations et organisent des interfaces. II. Les limites territoriales et certaines fonctions de contrôle subsistent. III. Les frontières externes et les régimes différenciés montrent une reconfiguration plutôt qu’un effacement.

## Proposition rédigée

Traverser certaines frontières européennes sans contrôle systématique peut donner l’impression que la limite a disparu. Pourtant, le passage continue de relier des territoires régis par des institutions et des droits distincts. L’intégration européenne a transformé les fonctions des frontières davantage qu’elle ne les a abolies. Pourquoi ouverture et disparition ne sont-elles pas équivalentes ? Les facilités de circulation reposent sur des règles communes qui maintiennent des limites politiques, tandis que les frontières externes et les régimes différenciés rendent leur rôle toujours visible.

L’ouverture interne est d’abord une construction juridique et matérielle. L’espace Schengen permet, entre ses membres, la suppression habituelle des contrôles aux frontières intérieures pour les personnes. L’Union organise également des libertés de circulation et un marché intérieur selon ses propres règles. Ces dispositifs ne se confondent pas : tous les États de l’Union ne sont pas dans la même situation au regard de Schengen, et des États non membres de l’Union y participent. Il faut donc préciser de quelle circulation et de quel périmètre on parle.

Dans les régions frontalières, cette ouverture peut soutenir de véritables interfaces. Des travailleurs résident d’un côté et travaillent de l’autre ; des collectivités coopèrent pour les transports et des services. L’espace du Rhin supérieur, notamment autour de Strasbourg et de Kehl, permet d’observer une frontière qui devient un lieu d’articulation plutôt qu’un simple obstacle. La continuité des mobilités n’efface cependant pas les écarts de réglementation, de fiscalité ou de salaire. Ces différences peuvent même motiver certains déplacements.

Les frontières internes restent donc des limites de compétence. Le franchissement peut être facile sans que les administrations nationales, les systèmes scolaires ou les droits applicables deviennent identiques. Des contrôles temporaires peuvent être réintroduits dans un cadre juridique déterminé. Leur existence montre que la fonction de filtrage peut être réactivée ; elle n’autorise pas à décrire toute l’ouverture comme une fiction. Il faut raisonner sur les fonctions variables de la frontière selon les périodes, les personnes et les flux.

L’ouverture interne s’accompagne par ailleurs d’une organisation des frontières externes. Le contrôle des entrées, les visas, l’asile et la coopération entre autorités posent des questions de souveraineté et de droits. Les États et les institutions européennes cherchent à articuler des responsabilités qui ne sont pas toujours perçues de la même manière. Les espaces méditerranéens révèlent des tensions entre contrôle, circulation, protection des personnes et relations avec les pays voisins. Une frontière n’est pas vécue de façon identique par un touriste muni de documents, un travailleur transfrontalier et une personne demandant protection.

Enfin, les périmètres européens évoluent. Le Brexit rappelle qu’un processus d’intégration peut être reconfiguré par une décision politique, avec des conséquences sur les règles et les contrôles. À l’inverse, l’élargissement d’un dispositif d’ouverture ne signifie pas l’abolition des États concernés. La carte doit donc être datée ; au lieu de mémoriser une Europe uniforme, le candidat doit distinguer les cercles institutionnels et leurs effets.

L’ouverture européenne ne supprime ainsi ni les territoires ni toutes les fonctions frontalières. Elle redistribue les contrôles, organise des coopérations et crée des interfaces, avec des effets différenciés selon les flux. Parler de reconfiguration permet de rendre compte de cette réalité : la frontière peut rester politiquement décisive tout en étant moins visible dans certaines pratiques quotidiennes.

## Évaluer et reprendre

**Erreurs à corriger.** Assimiler UE et Schengen ; dire que toute frontière interne est supprimée ; oublier les droits et les situations des personnes ; décrire une carte sans date.

**Autre démarche recevable.** Comparer trois fonctions — limite de compétence, interface, filtre — en montrant pour chacune les effets de l’intégration.

**Barème pédagogique proposé, non ministériel.** Compréhension et problématique : 4 points ; connaissances exactes et situées : 6 ; raisonnement et organisation : 6 ; expression et achèvement : 4. Ne pas sanctionner deux fois la même faiblesse. Une organisation différente peut obtenir tous les points si elle répond au sujet.

**Après correction.** Relever deux écarts entre votre copie et les critères, non entre votre copie et les formulations de ce modèle. Réécrire un paragraphe sans consulter le texte. À J+7, traiter une question voisine pendant 30 minutes.
