# Correction N1-5 — Comment l’État indien peut-il organiser le pluralisme religieux dans une société traversée par des tensions ?

## Analyser et problématiser

La question demande d’articuler cadre constitutionnel, diversité sociale et mobilisations politiques. Elle n’invite ni à juger les religions ni à décrire une majorité comme un bloc. Les relations avec le Pakistan peuvent éclairer les tensions, sans absorber toute la composition.

## Une organisation recevable

I. Un cadre constitutionnel cherche à protéger la diversité. II. La pluralité réelle et les rapports majoritaires/minoritaires rendent son application conflictuelle. III. Les mobilisations politiques et les tensions régionales imposent de distinguer principes et pratiques.

## Proposition rédigée

L’Inde réunit une grande diversité de traditions, de pratiques et d’appartenances religieuses. Son État doit organiser des droits communs sans supposer que la société serait homogène. Le cadre constitutionnel entré en vigueur en 1950 constitue une réponse à cette pluralité, mais son application reste traversée par des tensions. Comment articuler protection des libertés, représentation politique et coexistence ? Le projet de pluralisme repose sur des garanties institutionnelles dont les effets dépendent des rapports entre groupes, des mobilisations et du contexte régional.

La Constitution organise d’abord des libertés et une égalité de principe. La liberté de conscience et la pratique religieuse s’inscrivent dans un cadre de droits qui n’attribue pas la citoyenneté à une seule appartenance. Le terme secular est ajouté au préambule en 1976, mais les garanties de liberté et le projet pluraliste ne naissent pas entièrement à cette date. La laïcité indienne ne doit pas être confondue automatiquement avec un modèle français : l’État peut intervenir dans certains domaines liés aux religions et chercher à réguler des situations différentes.

Cette organisation répond à une diversité qui dépasse une simple opposition entre deux communautés. La majorité hindoue n’est pas un groupe politique ou social uniforme ; les musulmans, chrétiens, sikhs et autres minorités connaissent eux-mêmes des situations variées. Les appartenances se croisent avec les langues, les régions, les classes et d’autres hiérarchies sociales. Une politique publique ne peut donc être analysée en supposant que chaque religion produit une volonté unique. Le pluralisme demande des garanties pour les individus et les groupes, notamment lorsqu’une majorité dispose d’une force électorale importante.

Les tensions apparaissent lorsque des mobilisations présentent l’identité nationale comme indissociable d’une appartenance religieuse majoritaire. Elles peuvent contester l’interprétation du cadre constitutionnel, transformer des lieux en symboles et peser sur le statut des minorités. L’enjeu politique ne se réduit pas à une religiosité plus ou moins forte : il concerne la définition de la nation, l’égalité des droits et l’usage public du passé. Il faut identifier les acteurs et leurs décisions, plutôt qu’attribuer automatiquement une politique à tous les croyants.

L’histoire de la partition de 1947 et les relations avec le Pakistan contribuent également aux tensions. Les déplacements de populations, les violences et le différend autour du Cachemire participent à des mémoires et à des enjeux de sécurité. Mais la politique intérieure indienne ne peut être expliquée entièrement par un conflit extérieur. Inversement, les relations entre les deux États ne sont pas seulement religieuses : elles comportent des dimensions territoriales, stratégiques et diplomatiques. Une analyse HGGSP croise ces approches sans effacer leur distinction.

Organiser le pluralisme suppose donc plus que proclamer une neutralité abstraite. Les institutions doivent protéger les droits, traiter des situations concrètes et permettre la contestation des décisions. Les tribunaux, les élections, les associations et les débats publics constituent des lieux d’arbitrage ; ils ne rendent pas les tensions inexistantes. L’écart entre principe constitutionnel et pratique doit être étudié à partir de faits datés, non d’un jugement définitif sur une société entière.

L’État indien peut ainsi organiser la pluralité par des garanties et des dispositifs qui reconnaissent la diversité, mais leur effectivité dépend des rapports de force. Le cas indien montre que le pluralisme est une construction politique continue. La question essentielle n’est pas de mesurer une supposée homogénéité religieuse, mais d’examiner comment sont protégés les droits lorsque les appartenances deviennent des ressources de mobilisation.

## Évaluer et reprendre

**Erreurs à corriger.** Présenter secular comme une absence de religion ; faire naître toutes les libertés en 1976 ; confondre hindouisme et programme politique unique ; réduire le Cachemire à une seule cause.

**Autre démarche recevable.** Partir de la tension entre citoyenneté commune et appartenances, puis montrer les arbitrages institutionnels et régionaux.

**Barème pédagogique proposé, non ministériel.** Compréhension et problématique : 4 points ; connaissances exactes et situées : 6 ; raisonnement et organisation : 6 ; expression et achèvement : 4. Ne pas sanctionner deux fois la même faiblesse. Une organisation différente peut obtenir tous les points si elle répond au sujet.

**Après correction.** Relever deux écarts entre votre copie et les critères, non entre votre copie et les formulations de ce modèle. Réécrire un paragraphe sans consulter le texte. À J+7, traiter une question voisine pendant 30 minutes.
