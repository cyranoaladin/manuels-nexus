# N2-2 — Écrit terminal HGGSP

**Durée : 4 heures. Note : sur 20.** Épreuve blanche originale, session de préparation 2027. Aucun accès au cours ni aux corrigés pendant la simulation.

## Première partie — Dissertation, sur 10

Choisissez **un seul** des deux sujets.

**Sujet 1 — Les sociétés peuvent-elles protéger l’environnement tout en l’exploitant ?**

**Sujet 2 — Pourquoi la production et la diffusion des connaissances sont-elles des enjeux de puissance ?**

Rédigez une introduction, un développement organisé et une conclusion. Une illustration pertinente est possible mais non obligatoire.

## Seconde partie — Étude critique, sur 10

**Sécurité collective et usage de la force : des règles à leur application**

En confrontant les documents, analysez les principes de la sécurité collective et les difficultés de leur application. Vous distinguerez cadre juridique, décision politique et effets des interventions.

### Document 1 — Les principes de la Charte des Nations unies

**Adaptation pédagogique**, non verbatim, des articles 2, 24, 39, 42 et 51 de la Charte signée le 26 juin 1945. Source : Nations unies [D09]. La sélection simplifie le dispositif pour l’exercice ; elle ne remplace pas le texte intégral.

Les membres s’engagent à régler pacifiquement leurs différends et à s’abstenir de la menace ou de l’emploi de la force contre l’intégrité territoriale ou l’indépendance politique d’un État. Le Conseil de sécurité reçoit la responsabilité principale du maintien de la paix et de la sécurité internationales. Il peut constater une menace contre la paix, une rupture de la paix ou un acte d’agression, et décider des mesures appropriées, y compris, dans les conditions prévues, une action armée. La Charte reconnaît également un droit de légitime défense en cas d’agression armée, dans le cadre défini par son article 51.

### Document 2 — Deux situations irakiennes à distinguer

**Tableau de synthèse historique éditorial**, réalisé à partir des résolutions du Conseil de sécurité et de son répertoire des pratiques. Sources : [B39 ; B39a]. Il ne prétend pas résumer toutes les dimensions des conflits.

| Situation | Décision et cadre international | Question posée après l’action militaire |
|---|---|---|
| 1990–1991 | Après l’invasion du Koweït, des résolutions condamnent l’Irak ; la résolution 678 autorise les États coopérant avec le Koweït à employer les moyens nécessaires dans les conditions fixées. | Comment articuler libération du Koweït, cessez-le-feu, contrôles et ordre régional ? |
| 2003 | L’invasion menée par les États-Unis et leurs alliés intervient sans nouvelle résolution autorisant explicitement cette invasion ; la portée d’autorisations antérieures est contestée. | Comment transformer la chute du régime en un ordre politique stable et accepté ? |

**Note.** La légalité invoquée par les intervenants et sa contestation doivent être attribuées ; une victoire militaire n’est pas un jugement juridique.

**Fin du sujet N2-2.** Les références servent à identifier les documents ; aucune consultation extérieure n’est nécessaire pendant l’épreuve. Les adaptations sont signalées et ne sont jamais présentées comme des citations littérales.
