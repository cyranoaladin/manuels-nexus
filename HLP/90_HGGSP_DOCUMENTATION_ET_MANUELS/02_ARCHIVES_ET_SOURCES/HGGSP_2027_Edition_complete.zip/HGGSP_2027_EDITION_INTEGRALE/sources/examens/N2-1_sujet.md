# N2-1 — Écrit terminal HGGSP

**Durée : 4 heures. Note : sur 20.** Épreuve blanche originale, session de préparation 2027. Aucun accès au cours ni aux corrigés pendant la simulation.

## Première partie — Dissertation, sur 10

Choisissez **un seul** des deux sujets.

**Sujet 1 — La guerre demeure-t-elle un instrument politique malgré la transformation des conflits ?**

**Sujet 2 — Pourquoi le patrimoine peut-il devenir un objet de conflit ?**

Rédigez une introduction, un développement organisé et une conclusion. Une illustration pertinente est possible mais non obligatoire.

## Seconde partie — Étude critique, sur 10

**La coopération environnementale : construire un cadre, obtenir des résultats**

En confrontant les documents et en mobilisant vos connaissances, montrez comment se construit une coopération environnementale et pourquoi l’existence d’un cadre ne suffit pas à démontrer son efficacité.

### Document 1 — Une architecture de coopération climatique

**Adaptation pédagogique**, rédigée pour ce manuel, des articles 2, 4 et 13 de l’accord de Paris adopté le 12 décembre 2015. Ce texte reformule des dispositions ; ce n’est pas une citation littérale. Source institutionnelle : CCNUCC [D10 ; B58a].

L’accord poursuit notamment un objectif collectif de limitation de l’élévation de la température mondiale nettement sous 2 °C et de poursuite des efforts vers 1,5 °C, par rapport aux niveaux préindustriels. Chaque partie prépare, communique et actualise une contribution déterminée au niveau national. Les contributions successives doivent progresser et traduire une ambition tenant compte des responsabilités et des capacités différentes. Un cadre de transparence organise la communication d’informations sur les actions et leurs résultats. Ces mécanismes articulent une direction collective et des décisions nationales ; ils ne constituent pas une administration mondiale unique de l’énergie.

### Document 2 — Des étapes et des instruments distincts

**Tableau chronologique éditorial**, construit pour ce sujet à partir des ressources institutionnelles de l’ONU et de la CCNUCC. Il sélectionne quatre étapes ; il ne mesure pas les résultats environnementaux. [B58 ; D10]

| Repère | Instrument ou événement | Niveau principal et opération |
|---|---|---|
| 1972 | Conférence de Stockholm | Mise à l’agenda international de questions environnementales. |
| 1992 | Sommet de Rio et Convention-cadre sur le climat | Cadre multilatéral de coopération, avec des responsabilités différenciées. |
| 1997 | Protocole de Kyoto | Engagements de réduction pour des pays industrialisés selon le dispositif du protocole. |
| 2015 | Accord de Paris | Objectif collectif, contributions nationales et révision. |

**Note.** Les dates sont celles des événements ou de l’adoption, non nécessairement de l’entrée en vigueur des instruments.

**Fin du sujet N2-1.** Les références servent à identifier les documents ; aucune consultation extérieure n’est nécessaire pendant l’épreuve. Les adaptations sont signalées et ne sont jamais présentées comme des citations littérales.
