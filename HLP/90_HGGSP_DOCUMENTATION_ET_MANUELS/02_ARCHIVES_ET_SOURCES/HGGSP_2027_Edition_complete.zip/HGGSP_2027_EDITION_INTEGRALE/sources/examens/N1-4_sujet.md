# N1-4 — Composition de Première

**Durée : 2 heures. Note : sur 20.** Épreuve blanche originale ; aucun document ni accès au cours pendant la simulation. Rédigez une introduction, un développement organisé et une conclusion.

## Sujet

**Pourquoi la liberté de l’information dépend-elle de rapports de force politiques et sociaux ?**

Périmètre de préparation : P04, axe 2 — Liberté ou contrôle de l’information. Ce sujet porte sur cette seule partie du programme de Première.
