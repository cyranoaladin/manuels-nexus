# N2-3 — Écrit terminal HGGSP

**Durée : 4 heures. Note : sur 20.** Épreuve blanche originale, session de préparation 2027. Aucun accès au cours ni aux corrigés pendant la simulation.

## Première partie — Dissertation, sur 10

Choisissez **un seul** des deux sujets.

**Sujet 1 — Comment construire une paix durable après un conflit armé ?**

**Sujet 2 — Pourquoi les politiques environnementales des États-Unis sont-elles traversées par des tensions ?**

Rédigez une introduction, un développement organisé et une conclusion. Une illustration pertinente est possible mais non obligatoire.

## Seconde partie — Étude critique, sur 10

**Coopérer pour produire des connaissances : possibilités et asymétries**

En confrontant les documents et en mobilisant vos connaissances, analysez les apports de la circulation des chercheurs et de la coopération scientifique. Vous montrerez aussi ce que les documents ne permettent pas de conclure sur l’égalité entre partenaires.

### Document 1 — Faciliter des projets scientifiques entre les États-Unis et l’Inde

**Synthèse adaptée d’une communication institutionnelle**, non verbatim. National Science Foundation, annonce du 1er février 2023 relative à un arrangement de mise en œuvre entre la NSF et les organismes indiens partenaires [B65a]. Texte reformulé pour l’exercice.

Le dispositif annoncé vise à faciliter la préparation, l’évaluation et le financement de propositions de recherche collaboratives entre chercheurs américains et indiens. Il cherche à réduire certains obstacles administratifs liés à des procédures séparées. L’annonce associe cette démarche à la circulation d’idées, de ressources et de pratiques, dans plusieurs domaines scientifiques, dont l’informatique, les géosciences et les sciences physiques. Cette annonce présente un instrument destiné à soutenir des collaborations. Elle ne fournit pas, à elle seule, un bilan complet des projets réalisés, de leurs résultats ou de la répartition des bénéfices.

### Document 2 — Trois configurations de circulation des compétences

**Tableau conceptuel éditorial**, construit pour ce sujet à partir du cours T06. Il décrit des mécanismes possibles, non des proportions statistiques sur les migrations. [R-T06 ; B65]

| Configuration | Possibilité ouverte | Question à vérifier dans un cas réel |
|---|---|---|
| Installation durable à l’étranger | Accès à un laboratoire, des équipements et des réseaux. | Quelles capacités sont renforcées ou fragilisées dans les différents pays ? |
| Retour après formation ou emploi | Transfert de compétences et développement d’activités. | Les institutions locales permettent-elles leur réemploi ? |
| Collaboration à distance ou mobilité répétée | Projets communs, circulation d’informations et accès à des partenaires. | Qui finance, fixe les priorités et peut accéder aux résultats ? |

**Note.** Ces configurations peuvent se succéder ou se combiner dans un même parcours.

**Fin du sujet N2-3.** Les références servent à identifier les documents ; aucune consultation extérieure n’est nécessaire pendant l’épreuve. Les adaptations sont signalées et ne sont jamais présentées comme des citations littérales.
