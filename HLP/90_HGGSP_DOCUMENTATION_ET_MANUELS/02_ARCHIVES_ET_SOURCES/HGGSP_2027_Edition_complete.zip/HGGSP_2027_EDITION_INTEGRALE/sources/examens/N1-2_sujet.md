# N1-2 — Composition de Première

**Durée : 2 heures. Note : sur 20.** Épreuve blanche originale ; aucun document ni accès au cours pendant la simulation. Rédigez une introduction, un développement organisé et une conclusion.

## Sujet

**Comment les formes indirectes de la puissance permettent-elles d’agir sur les autres acteurs ?**

Périmètre de préparation : P02, axe 2 — Formes indirectes de la puissance. Ce sujet porte sur cette seule partie du programme de Première.
