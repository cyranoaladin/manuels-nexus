# N1-1 — Composition de Première

**Durée : 2 heures. Note : sur 20.** Épreuve blanche originale ; aucun document ni accès au cours pendant la simulation. Rédigez une introduction, un développement organisé et une conclusion.

## Sujet

**Pourquoi le passage à la démocratie est-il un processus incertain ?**

Périmètre de préparation : P01, axe 2 — Avancées et reculs des démocraties. Ce sujet porte sur cette seule partie du programme de Première.
