# Correction N1-2 — Comment les formes indirectes de la puissance permettent-elles d’agir sur les autres acteurs ?

## Analyser et problématiser

Il faut expliquer des mécanismes : attraction, dépendance, standardisation, accès et contrôle des réseaux. « Indirect » n’est pas synonyme de bienveillant ni de culturel. Le sujet appelle les langues, les nouvelles technologies et les routes de la soie. Une réponse centrée sur l’armée américaine manquerait le périmètre.

## Une organisation recevable

I. La diffusion linguistique et culturelle crée de l’attraction et des réseaux. II. Les infrastructures et les technologies structurent des dépendances et des règles. III. Leurs effets demeurent conditionnels, négociés et contestés.

## Proposition rédigée

La capacité d’un acteur à influencer un choix ne repose pas toujours sur une menace militaire explicite. Une langue de travail, un service numérique ou une infrastructure commerciale peuvent orienter les possibilités des autres. Ces formes indirectes de puissance agissent par l’attraction, l’organisation des échanges ou la dépendance. Comment deviennent-elles des instruments d’action ? Elles ouvrent des réseaux et structurent des choix, mais leur efficacité dépend de conditions qui empêchent de confondre diffusion et domination automatique.

La langue constitue d’abord une ressource de circulation. Lorsqu’elle est employée dans l’enseignement, la recherche, les affaires ou la diplomatie, elle facilite l’accès à certains réseaux. Les institutions culturelles et éducatives peuvent soutenir sa diffusion et maintenir des liens entre sociétés. La francophonie illustre l’existence d’un espace linguistique partagé qui dépasse un seul État. Il ne faut pourtant pas en faire une zone d’obéissance à la France : les acteurs qui utilisent le français ont leurs propres intérêts et peuvent s’approprier la langue de manière autonome.

Les productions culturelles peuvent également rendre un pays ou un mode de vie attractif. Le soft power désigne cette capacité d’attraction, distincte de la contrainte et du paiement. Une œuvre appréciée peut familiariser un public avec des références ; une université reconnue peut attirer des étudiants et soutenir des échanges durables. L’effet politique n’est toutefois pas immédiat. On peut aimer des films sans soutenir le gouvernement de leur pays d’origine. Une copie doit donc expliquer la conversion éventuelle de la ressource en influence, plutôt que présenter la popularité comme une preuve suffisante de puissance.

Les nouvelles technologies interviennent selon d’autres mécanismes. Les entreprises qui organisent des services numériques disposent d’infrastructures, de données et de capacités à définir des conditions d’accès. Des effets de réseau peuvent rendre une plateforme difficile à remplacer : son intérêt augmente avec ses utilisateurs, tandis que la migration vers une autre solution comporte des coûts. Les États cherchent à encadrer ces acteurs par le droit, la concurrence et la protection des données. La puissance se joue alors dans la capacité à imposer ou négocier des normes, pas seulement dans la possession d’une entreprise connue.

Les routes de la soie, promues par la Chine à partir de 2013, montrent enfin l’importance des infrastructures et de la connectivité. Des ports, voies ferrées ou corridors peuvent améliorer les échanges et renforcer la position des acteurs qui les financent, les construisent ou les gèrent. Mais leurs effets dépendent de la rentabilité, des contrats, des choix des États partenaires et des usages effectifs. Une infrastructure peut créer une dépendance sans devenir une annexion ; un financement ne suffit pas à prouver une intention unique ni un résultat identique dans tous les pays.

Ces exemples montrent que l’action indirecte est souvent relationnelle. Elle suppose des partenaires, des publics et des institutions qui peuvent accepter, détourner ou contester l’influence. Les langues produisent des appropriations multiples ; les normes numériques suscitent des régulations ; les infrastructures font l’objet de négociations. La capacité de fixer les conditions d’une relation peut donc être puissante sans être absolue.

Les formes indirectes permettent ainsi d’agir en rendant certains choix plus attractifs, plus accessibles ou plus coûteux à remplacer. Elles complètent d’autres instruments de puissance, mais ne les reproduisent pas simplement sous une apparence pacifique. Pour les analyser, il faut toujours distinguer la ressource détenue, le mécanisme d’influence et l’effet effectivement obtenu.

## Évaluer et reprendre

**Erreurs à corriger.** Confondre sanction et attraction ; attribuer toute action d’une entreprise à son État ; présenter tous les projets chinois comme identiques ; citer des classements non datés.

**Autre démarche recevable.** Organiser la composition autour d’attirer, connecter et fixer les règles, en intégrant une limite dans chaque partie.

**Barème pédagogique proposé, non ministériel.** Compréhension et problématique : 4 points ; connaissances exactes et situées : 6 ; raisonnement et organisation : 6 ; expression et achèvement : 4. Ne pas sanctionner deux fois la même faiblesse. Une organisation différente peut obtenir tous les points si elle répond au sujet.

**Après correction.** Relever deux écarts entre votre copie et les critères, non entre votre copie et les formulations de ce modèle. Réécrire un paragraphe sans consulter le texte. À J+7, traiter une question voisine pendant 30 minutes.
