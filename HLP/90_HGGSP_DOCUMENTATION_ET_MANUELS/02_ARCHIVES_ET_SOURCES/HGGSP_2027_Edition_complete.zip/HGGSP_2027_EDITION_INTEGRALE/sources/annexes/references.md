# Références et provenance documentaire {#references}

Les codes sont des repères locaux, non des identifiants ministériels. **S** désigne le cadre officiel ; **R** les ressources d’accompagnement ; **D** des documents de référence ; **B** une source spécifique ou un renvoi thématique à une ressource, selon la qualification indiquée. Un renvoi à une ressource pédagogique ne signifie pas que les ouvrages originaux qu’elle cite ont tous été lus intégralement.

Les documents du cours sont des synthèses éditoriales sauf indication expresse contraire. Les adaptations ne sont pas des citations verbatim. Les jeux fictifs ne sont pas des statistiques historiques. Les liens permettent une vérification complémentaire ; aucun exercice ne suppose qu’un document absent soit téléchargé pour être résolu.

**Actualisation : 8 septembre 2026.** Les règles de session et les faits contemporains demandent une nouvelle veille avant l’examen. Ce manuel ne vaut ni homologation ministérielle ni conseil individuel d’inscription.

## Cadre officiel

**[S01] Éduscol — Programmes et ressources HGGSP** — Texte ou information officielle. [Consulter la source](https://eduscol.education.gouv.fr/5802/programmes-et-ressources-en-histoire-geographie-geopolitique-et-sciences-politiques-voie-g).

**[S02] Programme de Première — BO spécial du 22 janvier 2019** — Texte ou information officielle. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/spe576annexe1062925pdf-83244.pdf).

**[S03] Programme de Terminale — BO spécial du 25 juillet 2019** — Texte ou information officielle. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/spe254annexe1159180pdf-83247.pdf).

**[S04] Note du 27 août 2025, NOR MENE2521923N — Épreuve HGGSP à compter de 2026** — Texte ou information officielle. [Consulter la source](https://www.education.gouv.fr/bo/2025/Hebdo33/MENE2521923N).

**[S05] Évaluation ponctuelle de la spécialité non poursuivie — version consolidée juin 2025, HGGSP pages 3–4** — Texte ou information officielle. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ndsevaluations-ponctuelleseds-non-poursuivivoie-gjuin-2025pdf-100575.pdf).

**[S06] Éduscol — Candidats individuels au baccalauréat** — Texte ou information officielle. [Consulter la source](https://eduscol.education.gouv.fr/5694/candidats-individuels-au-baccalaureat-general-et-au-baccalaureat-technologique).

**[S07] Note du 25 août 2025 — Modalités d’évaluation à compter de 2026** — Texte ou information officielle. [Consulter la source](https://www.education.gouv.fr/bo/2025/Hebdo32/MENE2523743N).

**[S08] Éduscol — Grand oral, présentation actualisée en février 2026** — Texte ou information officielle. [Consulter la source](https://eduscol.education.gouv.fr/5661/presentation-du-grand-oral).

**[S09] Éduscol — Épreuves terminales et coefficients du baccalauréat général** — Texte ou information officielle. [Consulter la source](https://eduscol.education.gouv.fr/5706/les-epreuves-terminales-du-baccalaureat-general).

**[S10] Déclaration des droits de l’homme et du citoyen de 1789 — Légifrance** — Texte ou information officielle. [Consulter la source](https://www.legifrance.gouv.fr/loda/id/JORFTEXT000000697056).

## Accompagnement par thème

**[R-P01] Éduscol — Ressource d’accompagnement : Comprendre un régime politique : la démocratie** — Accompagnement disciplinaire officiel. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra19lyceegspe1hggsptheme1democratie1169458pdf-83250.pdf). Source d’appui aux jalons et à leur problématisation ; ne vaut pas validation du présent manuel.

**[R-P02] Éduscol — Ressource d’accompagnement : Analyser les dynamiques des puissances internationales** — Accompagnement disciplinaire officiel. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra19lyceegspe1hggsptheme2puissancesinter1169460pdf-83253.pdf). Source d’appui aux jalons et à leur problématisation ; ne vaut pas validation du présent manuel.

**[R-P03] Éduscol — Ressource d’accompagnement : Étudier les divisions politiques du monde : les frontières** — Accompagnement disciplinaire officiel. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra19lyceegspe1hggsptheme3frontieres1206062pdf-83256.pdf). Source d’appui aux jalons et à leur problématisation ; ne vaut pas validation du présent manuel.

**[R-P04] Éduscol — Ressource d’accompagnement : S’informer : un regard critique sur les sources et modes de communication** — Accompagnement disciplinaire officiel. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra20lyceeg1histgeogeopolitique-sciencespotheme4-sinformer-regard-critique1293847pdf-83259.pdf). Source d’appui aux jalons et à leur problématisation ; ne vaut pas validation du présent manuel.

**[R-P05] Éduscol — Ressource d’accompagnement : Analyser les relations entre États et religions** — Accompagnement disciplinaire officiel. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra20lyceeg1histgeogeopolitique-sciencespoanalyser-relations-etats-religions1293914pdf-83262.pdf). Source d’appui aux jalons et à leur problématisation ; ne vaut pas validation du présent manuel.

**[R-T01] Éduscol — Ressource d’accompagnement : De nouveaux espaces de conquête** — Accompagnement disciplinaire officiel. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra20lyceegtspehgeotheme1espacesconquetes0021329089pdf-83265.pdf). Source d’appui aux jalons et à leur problématisation ; ne vaut pas validation du présent manuel.

**[R-T02] Éduscol — Ressource d’accompagnement : Faire la guerre, faire la paix : formes de conflits et modes de résolution** — Accompagnement disciplinaire officiel. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra22lycee-gthggsptheme-2faire-la-guerre-et-faire-la-paix-93786.pdf). Source d’appui aux jalons et à leur problématisation ; ne vaut pas validation du présent manuel.

**[R-T03] Éduscol — Ressource d’accompagnement : Histoire et mémoires** — Accompagnement disciplinaire officiel. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra22lycee-gthggsphistoire-et-memoires-93783.pdf). Source d’appui aux jalons et à leur problématisation ; ne vaut pas validation du présent manuel.

**[R-T04] Éduscol — Ressource d’accompagnement : Identifier, protéger et valoriser le patrimoine : enjeux géopolitiques** — Accompagnement disciplinaire officiel. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra25lyceegthggspidentifierprotegervaloriserpatrimoine-enjeuxgeopolitiques0pdf-121241.pdf). Source d’appui aux jalons et à leur problématisation ; ne vaut pas validation du présent manuel.

**[R-T05] Éduscol — Ressource d’accompagnement : L’environnement, entre exploitation et protection : un enjeu planétaire** — Accompagnement disciplinaire officiel. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra23lyceegthggspenvironnementexploitationprotectionenjeupdf-102786.pdf). Source d’appui aux jalons et à leur problématisation ; ne vaut pas validation du présent manuel.

**[R-T06] Éduscol — Ressource d’accompagnement : L’enjeu de la connaissance** — Accompagnement disciplinaire officiel. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra24lyceegthggspenjeuxconnaissancepdf-104487.pdf). Source d’appui aux jalons et à leur problématisation ; ne vaut pas validation du présent manuel.

## Documents de référence

**[D01] Traité sur l’Union européenne, article 10** — Document institutionnel de référence. [Consulter la source](https://eur-lex.europa.eu/legal-content/FR/TXT/?uri=CELEX:12012M010).

**[D02] Convention des Nations unies sur le droit de la mer, 1982** — Document institutionnel de référence. [Consulter la source](https://www.un.org/depts/los/convention_agreements/texts/unclos/unclos_f.pdf).

**[D03] Accord BBNJ — Dépositaire ONU : entrée en vigueur le 17 janvier 2026** — Document institutionnel de référence. [Consulter la source](https://treaties.un.org/Pages/ViewDetails.aspx?src=TREATY&mtdsg_no=XXI-10&chapter=21&clang=_en).

**[D04] Conseil de l’UE — Espace Schengen** — Document institutionnel de référence. [Consulter la source](https://www.consilium.europa.eu/en/policies/schengen-area/).

**[D06] Archives nationales américaines — Bill of Rights, premier amendement** — Document institutionnel de référence. [Consulter la source](https://www.archives.gov/founding-docs/bill-of-rights-transcript).

**[D07] OTAN — Pays membres et dates d’adhésion** — Document institutionnel de référence. [Consulter la source](https://www.nato.int/en/about-us/organization/nato-member-countries).

**[D08] UNOOSA — Traité de l’espace de 1967** — Document institutionnel de référence. [Consulter la source](https://www.unoosa.org/oosa/en/ourwork/spacelaw/treaties/introouterspacetreaty.html).

**[D09] Nations unies — Charte de 1945** — Document institutionnel de référence. [Consulter la source](https://treaties.un.org/doc/source/docs/charter-all-lang.pdf).

**[D10] CCNUCC — Accord de Paris** — Document institutionnel de référence. [Consulter la source](https://unfccc.int/process-and-meetings/the-paris-agreement).

**[D10a] Dépositaire ONU — Retrait américain de la CCNUCC, notification du 27 février 2026, effet prévu le 27 février 2027** — Document institutionnel de référence. [Consulter la source](https://treaties.un.org/doc/Publication/CN/2026/CN.102.2026-Eng.pdf).

**[D11] UNESCO — Convention du patrimoine mondial de 1972** — Document institutionnel de référence. [Consulter la source](https://whc.unesco.org/fr/conventiontexte/).

**[D12] UNESCO — Convention pour la sauvegarde du patrimoine culturel immatériel, 2003** — Document institutionnel de référence. [Consulter la source](https://ich.unesco.org/fr/convention). Le dispositif de 2003 est distinct de la convention de 1972. Aucun passage présenté comme transcription littérale.

**[D13] GIEC — AR6, rapport de synthèse 2023, résumé pour décideurs** — Document institutionnel de référence. [Consulter la source](https://www.ipcc.ch/report/ar6/syr/summary-for-policymakers/).

**[D14] Banque mondiale / UNESCO-UIS — Indicateur d’alphabétisation des femmes adultes** — Document institutionnel de référence. [Consulter la source](https://data.worldbank.org/indicator/SE.ADT.LITR.FE.ZS). Aucune valeur illisible de l’ancienne banque n’est reconstituée à partir de cette page ; T06-E3 est un jeu fictif explicitement nouveau.

**[D15] Décret n° 2009-834 du 7 juillet 2009 créant l’ANSSI** — Document institutionnel de référence. [Consulter la source](https://www.legifrance.gouv.fr/loda/id/JORFTEXT000020828212).

**[D16] ENISA — Directive NIS 2 et coopération européenne** — Document institutionnel de référence. [Consulter la source](https://www.enisa.europa.eu/topics/state-of-cybersecurity-in-the-eu/cybersecurity-policies/nis-directive-2).

**[D17] ONU — Convention de 1948 pour la prévention et la répression du crime de génocide** — Document institutionnel de référence. [Consulter la source](https://www.ohchr.org/en/instruments-mechanisms/instruments/convention-prevention-and-punishment-crime-genocide).

## Appuis documentaires et approfondissements

**[B01] Citoyenneté athénienne — appui dans la ressource P01** — Renvoi thématique à un accompagnement officiel. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra19lyceegspe1hggsptheme1democratie1169458pdf-83250.pdf). Le code désigne un point d’appui de la ressource Éduscol, pas une édition intégrale d’un ouvrage original. Voir le jalon correspondant.

**[B02] Benjamin Constant : libertés des Anciens et des Modernes — appui dans la ressource P01** — Renvoi thématique à un accompagnement officiel. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra19lyceegspe1hggsptheme1democratie1169458pdf-83250.pdf). Le code désigne un point d’appui de la ressource Éduscol, pas une édition intégrale d’un ouvrage original. Voir le jalon correspondant.

**[B03] Tocqueville et les tensions de la démocratie — appui dans la ressource P01** — Renvoi thématique à un accompagnement officiel. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra19lyceegspe1hggsptheme1democratie1169458pdf-83250.pdf). Le code désigne un point d’appui de la ressource Éduscol, pas une édition intégrale d’un ouvrage original. Voir le jalon correspondant.

**[B04] Sénat américain — Covert Action in Chile, 1963–1973, rapport de 1975** — Source institutionnelle. [Consulter la source](https://www.intelligence.senate.gov/wp-content/uploads/2024/08/sites-default-files-94chile.pdf).

**[B05] Assemblée de la République portugaise — Construção da democracia, 1974–1976** — Source institutionnelle. [Consulter la source](https://www.parlamento.pt/Parlamento/Paginas/construcao-democracia_1974-1976.aspx).

**[B06] Transition et Constitution espagnoles — appui dans la ressource P01** — Renvoi thématique à un accompagnement officiel. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra19lyceegspe1hggsptheme1democratie1169458pdf-83250.pdf). Le code désigne un point d’appui de la ressource Éduscol, pas une édition intégrale d’un ouvrage original. Voir le jalon correspondant.

**[B07] Empire ottoman : essor et déclin — appui dans la ressource P02** — Renvoi thématique à un accompagnement officiel. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra19lyceegspe1hggsptheme2puissancesinter1169460pdf-83253.pdf). Le code désigne un point d’appui de la ressource Éduscol, pas une édition intégrale d’un ouvrage original. Voir le jalon correspondant.

**[B08] ONU — Agression contre l’Ukraine, résolution ES-11/1 du 2 mars 2022** — Source institutionnelle. [Consulter la source](https://docs.un.org/fr/A/RES/ES-11/1).

**[B09] Langues, attraction et soft power — appui dans la ressource P02** — Renvoi thématique à un accompagnement officiel. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra19lyceegspe1hggsptheme2puissancesinter1169460pdf-83253.pdf). Le code désigne un point d’appui de la ressource Éduscol, pas une édition intégrale d’un ouvrage original. Voir le jalon correspondant.

**[B10] Conseil de l’UE — Paquet sur les services et marchés numériques** — Source institutionnelle. [Consulter la source](https://www.consilium.europa.eu/en/policies/digital-services-package/).

**[B11] Routes de la soie et connectivité — appui dans la ressource P02** — Renvoi thématique à un accompagnement officiel. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra19lyceegspe1hggsptheme2puissancesinter1169460pdf-83253.pdf). Le code désigne un point d’appui de la ressource Éduscol, pas une édition intégrale d’un ouvrage original. Voir le jalon correspondant.

**[B12] Lieux et instruments de la puissance américaine — appui dans la ressource P02** — Renvoi thématique à un accompagnement officiel. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra19lyceegspe1hggsptheme2puissancesinter1169460pdf-83253.pdf). Le code désigne un point d’appui de la ressource Éduscol, pas une édition intégrale d’un ouvrage original. Voir le jalon correspondant.

**[B13] UNESCO — Frontières de l’Empire romain : limes de Germanie inférieure** — Source institutionnelle. [Consulter la source](https://whc.unesco.org/en/list/1631/).

**[B14] Conférence et acte de Berlin de 1885 — appui dans la ressource P03** — Renvoi thématique à un accompagnement officiel. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra19lyceegspe1hggsptheme3frontieres1206062pdf-83256.pdf). Le code désigne un point d’appui de la ressource Éduscol, pas une édition intégrale d’un ouvrage original. Voir le jalon correspondant.

**[B15] Commandement des Nations unies — Négociations de l’armistice coréen, 1951–1953** — Source institutionnelle. [Consulter la source](https://www.unc.mil/History/1951-1953-Armistice-Negotiations/).

**[B16] Frontière germano-polonaise et traités — appui dans la ressource P03** — Renvoi thématique à un accompagnement officiel. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra19lyceegspe1hggsptheme3frontieres1206062pdf-83256.pdf). Le code désigne un point d’appui de la ressource Éduscol, pas une édition intégrale d’un ouvrage original. Voir le jalon correspondant.

**[B17] Coopération dans le Rhin supérieur — appui dans la ressource P03** — Renvoi thématique à un accompagnement officiel. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra19lyceegspe1hggsptheme3frontieres1206062pdf-83256.pdf). Le code désigne un point d’appui de la ressource Éduscol, pas une édition intégrale d’un ouvrage original. Voir le jalon correspondant.

**[B18] Histoire des médias de masse — appui dans la ressource P04** — Renvoi thématique à un accompagnement officiel. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra20lyceeg1histgeogeopolitique-sciencespotheme4-sinformer-regard-critique1293847pdf-83259.pdf). Le code désigne un point d’appui de la ressource Éduscol, pas une édition intégrale d’un ouvrage original. Voir le jalon correspondant.

**[B19] Presse et affaire Dreyfus — appui dans la ressource P04** — Renvoi thématique à un accompagnement officiel. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra20lyceeg1histgeogeopolitique-sciencespotheme4-sinformer-regard-critique1293847pdf-83259.pdf). Le code désigne un point d’appui de la ressource Éduscol, pas une édition intégrale d’un ouvrage original. Voir le jalon correspondant.

**[B20] Agences de presse, Havas et AFP — appui dans la ressource P04** — Renvoi thématique à un accompagnement officiel. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra20lyceeg1histgeogeopolitique-sciencespotheme4-sinformer-regard-critique1293847pdf-83259.pdf). Le code désigne un point d’appui de la ressource Éduscol, pas une édition intégrale d’un ouvrage original. Voir le jalon correspondant.

**[B20a] Loi du 29 juillet 1881, article 1 — Légifrance** — Source institutionnelle. [Consulter la source](https://www.legifrance.gouv.fr/loda/article_lc/LEGIARTI000006419657).

**[B21a] DARPA — Histoire d’ARPANET** — Source institutionnelle. [Consulter la source](https://www.darpa.mil/news/features/arpanet).

**[B21b] CERN — Naissance du Web** — Source institutionnelle. [Consulter la source](https://home.cern/science/computing/the-birth-of-the-web/).

**[B22] Archives nationales américaines — Pentagon Papers** — Source institutionnelle. [Consulter la source](https://www.archives.gov/research/pentagon-papers).

**[B23] Information numérique, vérification et lanceurs d’alerte — appui dans la ressource P04** — Renvoi thématique à un accompagnement officiel. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra20lyceeg1histgeogeopolitique-sciencespotheme4-sinformer-regard-critique1293847pdf-83259.pdf). Le code désigne un point d’appui de la ressource Éduscol, pas une édition intégrale d’un ouvrage original. Voir le jalon correspondant.

**[B24] Charlemagne et pouvoirs religieux — appui dans la ressource P05** — Renvoi thématique à un accompagnement officiel. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra20lyceeg1histgeogeopolitique-sciencespoanalyser-relations-etats-religions1293914pdf-83262.pdf). Le code désigne un point d’appui de la ressource Éduscol, pas une édition intégrale d’un ouvrage original. Voir le jalon correspondant.

**[B25] Empereurs byzantins et califes abbassides — appui dans la ressource P05** — Renvoi thématique à un accompagnement officiel. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra20lyceeg1histgeogeopolitique-sciencespoanalyser-relations-etats-religions1293914pdf-83262.pdf). Le code désigne un point d’appui de la ressource Éduscol, pas une édition intégrale d’un ouvrage original. Voir le jalon correspondant.

**[B26] Turquie : laïcisation et Diyanet — appui dans la ressource P05** — Renvoi thématique à un accompagnement officiel. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra20lyceeg1histgeogeopolitique-sciencespoanalyser-relations-etats-religions1293914pdf-83262.pdf). Le code désigne un point d’appui de la ressource Éduscol, pas une édition intégrale d’un ouvrage original. Voir le jalon correspondant.

**[B27] Religion et politique aux États-Unis — appui dans la ressource P05** — Renvoi thématique à un accompagnement officiel. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra20lyceeg1histgeogeopolitique-sciencespoanalyser-relations-etats-religions1293914pdf-83262.pdf). Le code désigne un point d’appui de la ressource Éduscol, pas une édition intégrale d’un ouvrage original. Voir le jalon correspondant.

**[B28] Constitution et pluralisme en Inde — appui dans la ressource P05** — Renvoi thématique à un accompagnement officiel. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra20lyceeg1histgeogeopolitique-sciencespoanalyser-relations-etats-religions1293914pdf-83262.pdf). Le code désigne un point d’appui de la ressource Éduscol, pas une édition intégrale d’un ouvrage original. Voir le jalon correspondant.

**[B29] Inde, Pakistan et Cachemire — appui dans la ressource P05** — Renvoi thématique à un accompagnement officiel. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra20lyceeg1histgeogeopolitique-sciencespoanalyser-relations-etats-religions1293914pdf-83262.pdf). Le code désigne un point d’appui de la ressource Éduscol, pas une édition intégrale d’un ouvrage original. Voir le jalon correspondant.

**[B30] Jalons de la conquête spatiale — appui dans la ressource T01** — Renvoi thématique à un accompagnement officiel. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra20lyceegtspehgeotheme1espacesconquetes0021329089pdf-83265.pdf). Le code désigne un point d’appui de la ressource Éduscol, pas une édition intégrale d’un ouvrage original. Voir le jalon correspondant.

**[B31] Dissuasion et projection navale — appui dans la ressource T01** — Renvoi thématique à un accompagnement officiel. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra20lyceegtspehgeotheme1espacesconquetes0021329089pdf-83265.pdf). Le code désigne un point d’appui de la ressource Éduscol, pas une édition intégrale d’un ouvrage original. Voir le jalon correspondant.

**[B32] NASA — International Space Station, facts and figures** — Source institutionnelle. [Consulter la source](https://www.nasa.gov/international-space-station/space-station-facts-and-figures/).

**[B33] CNSA — Retour d’échantillons de Chang’e 6, juin 2024** — Source institutionnelle. [Consulter la source](https://www.cnsa.gov.cn/english/n6465652/n6465653/c10573102/content.html).

**[B34] Chine et enjeux maritimes — appui dans la ressource T01** — Renvoi thématique à un accompagnement officiel. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra20lyceegtspehgeotheme1espacesconquetes0021329089pdf-83265.pdf). Le code désigne un point d’appui de la ressource Éduscol, pas une édition intégrale d’un ouvrage original. Voir le jalon correspondant.

**[B35] Clausewitz — On War, livre I, traduction historique anglophone** — Source institutionnelle. [Consulter la source](https://clausewitzstudies.org/readings/OnWar1873/BK1ch01.html).

**[B35a] Guerre de Sept Ans et guerres napoléoniennes — appui dans la ressource T02** — Renvoi thématique à un accompagnement officiel. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra22lycee-gthggsptheme-2faire-la-guerre-et-faire-la-paix-93786.pdf). Le code désigne un point d’appui de la ressource Éduscol, pas une édition intégrale d’un ouvrage original. Voir le jalon correspondant.

**[B36] Yale, Avalon Project — Traité de Westphalie, 1648** — Source institutionnelle. [Consulter la source](https://avalon.law.yale.edu/17th_century/westphal.asp).

**[B36a] Al-Qaïda et Daech : formes et objectifs de la violence — appui dans la ressource T02** — Renvoi thématique à un accompagnement officiel. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra22lycee-gthggsptheme-2faire-la-guerre-et-faire-la-paix-93786.pdf). Le code désigne un point d’appui de la ressource Éduscol, pas une édition intégrale d’un ouvrage original. Voir le jalon correspondant.

**[B37] ONU et construction de la paix sous Kofi Annan — appui dans la ressource T02** — Renvoi thématique à un accompagnement officiel. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra22lycee-gthggsptheme-2faire-la-guerre-et-faire-la-paix-93786.pdf). Le code désigne un point d’appui de la ressource Éduscol, pas une édition intégrale d’un ouvrage original. Voir le jalon correspondant.

**[B37a] ONU — Responsabilité de protéger** — Source institutionnelle. [Consulter la source](https://www.un.org/en/genocide-prevention/responsibility-protect/about).

**[B38] Conflits et tentatives de paix au Moyen-Orient — appui dans la ressource T02** — Renvoi thématique à un accompagnement officiel. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra22lycee-gthggsptheme-2faire-la-guerre-et-faire-la-paix-93786.pdf). Le code désigne un point d’appui de la ressource Éduscol, pas une édition intégrale d’un ouvrage original. Voir le jalon correspondant.

**[B38a] Résolution 242 et diplomatie régionale — appui dans la ressource T02** — Renvoi thématique à un accompagnement officiel. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra22lycee-gthggsptheme-2faire-la-guerre-et-faire-la-paix-93786.pdf). Le code désigne un point d’appui de la ressource Éduscol, pas une édition intégrale d’un ouvrage original. Voir le jalon correspondant.

**[B38b] ONU — Situation à Gaza et processus politique, point daté du 26 août 2026** — Actualisation institutionnelle. [Consulter la source](https://www.un.org/unispal/document/gazas-recovery-and-reconstruction-and-the-broader-political-process-are-mutually-dependent-un-acting-special-coordinator-for-the-middle-east-peace-process-briefs-the-security-council/). Le code désigne un point d’appui de la ressource Éduscol, pas une édition intégrale d’un ouvrage original. Voir le jalon correspondant.

**[B38c] Cour internationale de justice — Avis consultatif du 19 juillet 2024, affaire 186** — Source institutionnelle. [Consulter la source](https://www.icj-cij.org/case/186).

**[B38d] ONU — Briefing du coordinateur spécial par intérim au Conseil de sécurité, 26 août 2026** — Source institutionnelle. [Consulter la source](https://www.un.org/unispal/document/gazas-recovery-and-reconstruction-and-the-broader-political-process-are-mutually-dependent-un-acting-special-coordinator-for-the-middle-east-peace-process-briefs-the-security-council/).

**[B39] Résolutions 678 et 687, guerre de 1991 — appui dans la ressource T02** — Renvoi thématique à un accompagnement officiel. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra22lycee-gthggsptheme-2faire-la-guerre-et-faire-la-paix-93786.pdf). Le code désigne un point d’appui de la ressource Éduscol, pas une édition intégrale d’un ouvrage original. Voir le jalon correspondant.

**[B39a] Conseil de sécurité — Répertoire des pratiques, 2000–2003, chapitre XII** — Source institutionnelle. [Consulter la source](https://www.un.org/fr/sc/repertoire/00-03/00-03_12.pdf).

**[B40] Controverse sur les responsabilités de 1914 : Fischer et Clark — appui dans la ressource T03** — Renvoi thématique à un accompagnement officiel. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra22lycee-gthggsphistoire-et-memoires-93783.pdf). Le code désigne un point d’appui de la ressource Éduscol, pas une édition intégrale d’un ouvrage original. Voir le jalon correspondant.

**[B40a] Traité de Versailles et responsabilité — appui dans la ressource T03** — Renvoi thématique à un accompagnement officiel. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra22lycee-gthggsphistoire-et-memoires-93783.pdf). Le code désigne un point d’appui de la ressource Éduscol, pas une édition intégrale d’un ouvrage original. Voir le jalon correspondant.

**[B41] Histoire et mémoires de la guerre d’Algérie — appui dans la ressource T03** — Renvoi thématique à un accompagnement officiel. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra22lycee-gthggsphistoire-et-memoires-93783.pdf). Le code désigne un point d’appui de la ressource Éduscol, pas une édition intégrale d’un ouvrage original. Voir le jalon correspondant.

**[B41a] Loi du 18 octobre 1999 — Reconnaissance de la guerre d’Algérie** — Source institutionnelle. [Consulter la source](https://www.legifrance.gouv.fr/loda/id/JORFTEXT000000578132).

**[B42] Rwanda : gacaca et justice après le génocide — appui dans la ressource T03** — Renvoi thématique à un accompagnement officiel. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra22lycee-gthggsphistoire-et-memoires-93783.pdf). Le code désigne un point d’appui de la ressource Éduscol, pas une édition intégrale d’un ouvrage original. Voir le jalon correspondant.

**[B43] TPIY : justice internationale et responsabilités — appui dans la ressource T03** — Renvoi thématique à un accompagnement officiel. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra22lycee-gthggsphistoire-et-memoires-93783.pdf). Le code désigne un point d’appui de la ressource Éduscol, pas une édition intégrale d’un ouvrage original. Voir le jalon correspondant.

**[B44] United States Holocaust Memorial Museum — Génocide des Roms européens, 1939–1945** — Source institutionnelle. [Consulter la source](https://encyclopedia.ushmm.org/content/en/article/genocide-of-european-roma-gypsies-1939-1945).

**[B44a] Lieux de mémoire des génocides — appui dans la ressource T03** — Renvoi thématique à un accompagnement officiel. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra22lycee-gthggsphistoire-et-memoires-93783.pdf). Le code désigne un point d’appui de la ressource Éduscol, pas une édition intégrale d’un ouvrage original. Voir le jalon correspondant.

**[B45] Procès après Nuremberg — appui dans la ressource T03** — Renvoi thématique à un accompagnement officiel. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra22lycee-gthggsphistoire-et-memoires-93783.pdf). Le code désigne un point d’appui de la ressource Éduscol, pas une édition intégrale d’un ouvrage original. Voir le jalon correspondant.

**[B46] Littérature, cinéma et transmission — appui dans la ressource T03** — Renvoi thématique à un accompagnement officiel. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra22lycee-gthggsphistoire-et-memoires-93783.pdf). Le code désigne un point d’appui de la ressource Éduscol, pas une édition intégrale d’un ouvrage original. Voir le jalon correspondant.

**[B47] Château de Versailles — Inauguration des galeries historiques** — Source institutionnelle. [Consulter la source](https://www.chateauversailles.fr/decouvrir/histoire/les-grandes-dates/inauguration-galeries-historiques).

**[B47a] Versailles, 1871, 1919 et usages républicains — appui dans la ressource T04** — Renvoi thématique à un accompagnement officiel. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra25lyceegthggspidentifierprotegervaloriserpatrimoine-enjeuxgeopolitiques0pdf-121241.pdf). Le code désigne un point d’appui de la ressource Éduscol, pas une édition intégrale d’un ouvrage original. Voir le jalon correspondant.

**[B48] British Museum — Position institutionnelle sur les sculptures du Parthénon** — Source institutionnelle. [Consulter la source](https://www.britishmuseum.org/about-us/british-museum-story/contested-objects-collection/parthenon-sculptures). Position d’une partie à la controverse ; ne vaut pas arbitrage neutre de la propriété.

**[B48a] Musée de l’Acropole — Galerie du Parthénon** — Source institutionnelle. [Consulter la source](https://www.theacropolismuseum.gr/en/exhibit-halls/parthenon-gallery). Présentation institutionnelle de la muséographie ; pour la revendication, déclaration de réunification du 24 mars 2023.

**[B49] UNESCO — Paris, rives de la Seine** — Source institutionnelle. [Consulter la source](https://whc.unesco.org/en/list/600/).

**[B50] UNESCO — Sauvegarde du patrimoine de Tombouctou** — Source institutionnelle. [Consulter la source](https://whc.unesco.org/en/canopy/timbuktu/).

**[B50a] CPI — Affaire Al Mahdi** — Source institutionnelle. [Consulter la source](https://www.icc-cpi.int/mali/al-mahdi).

**[B51] UNESCO — Venise et sa lagune** — Source institutionnelle. [Consulter la source](https://whc.unesco.org/en/list/394/).

**[B52] Ministère de la Culture — Grandes dates des monuments historiques** — Source institutionnelle. [Consulter la source](https://www.culture.gouv.fr/thematiques/monuments-sites/monuments-historiques-sites-patrimoniaux/un-peu-d-histoire/les-grandes-dates-des-monuments-historiques).

**[B53] UNESCO — Bassin minier du Nord-Pas-de-Calais** — Source institutionnelle. [Consulter la source](https://whc.unesco.org/en/list/1360/).

**[B54] UNESCO — Repas gastronomique des Français, inscription 2010** — Source institutionnelle. [Consulter la source](https://ich.unesco.org/en/RL/gastronomic-meal-of-the-french-00437).

**[B55] ONF — Ordonnance de Colbert de 1669 et forêt de Tronçais** — Source institutionnelle. [Consulter la source](https://www.onf.fr/onf/%2B/ff6%3A%3Ala-grande-histoire-des-forets-episode-ordonnance-de-colbert-en-1669-la-gestion-forestiere-en-foret-de-troncais.html).

**[B55a] ONF — Histoire des forêts** — Source institutionnelle. [Consulter la source](https://www.onf.fr/vivre-la-foret/fonctionnement-gestion-foret/histoire-des-forets).

**[B56] Inrap — Le Néolithique** — Source institutionnelle. [Consulter la source](https://www.inrap.fr/periodes/neolithique).

**[B56a] Industrialisation, énergie et transformations des milieux — appui dans la ressource T05** — Renvoi thématique à un accompagnement officiel. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra23lyceegthggspenvironnementexploitationprotectionenjeupdf-102786.pdf). Le code désigne un point d’appui de la ressource Éduscol, pas une édition intégrale d’un ouvrage original. Voir le jalon correspondant.

**[B57] Collège de France — Petit Âge glaciaire et passage à la modernité** — Source institutionnelle. [Consulter la source](https://www.college-de-france.fr/fr/agenda/cours/histoire-societe-climat-entre-fragilite-et-resilience/le-petit-age-glaciaire-et-le-passage-la-modernite).

**[B58] Stockholm, Rio et Kyoto — appui dans la ressource T05** — Renvoi thématique à un accompagnement officiel. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra23lyceegthggspenvironnementexploitationprotectionenjeupdf-102786.pdf). Le code désigne un point d’appui de la ressource Éduscol, pas une édition intégrale d’un ouvrage original. Voir le jalon correspondant.

**[B58a] CCNUCC — Contributions déterminées au niveau national** — Source institutionnelle. [Consulter la source](https://unfccc.int/process-and-meetings/the-paris-agreement/nationally-determined-contributions-ndcs).

**[B59] National Park Service — Histoire et interprétation des parcs** — Source institutionnelle. [Consulter la source](https://www.nps.gov/articles/history-under-construction.htm).

**[B59a] USDA — Conservation versus preservation** — Source institutionnelle. [Consulter la source](https://www.usda.gov/about-usda/news/blog/conservation-versus-preservation).

**[B59b] L’action fédérale américaine et l’EPA — appui dans la ressource T05** — Renvoi thématique à un accompagnement officiel. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra23lyceegthggspenvironnementexploitationprotectionenjeupdf-102786.pdf). Le code désigne un point d’appui de la ressource Éduscol, pas une édition intégrale d’un ouvrage original. Voir le jalon correspondant.

**[B60] Pluralité des acteurs environnementaux américains — appui dans la ressource T05** — Renvoi thématique à un accompagnement officiel. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra23lyceegthggspenvironnementexploitationprotectionenjeupdf-102786.pdf). Le code désigne un point d’appui de la ressource Éduscol, pas une édition intégrale d’un ouvrage original. Voir le jalon correspondant.

**[B61] Société de la connaissance : définition et enjeux — appui dans la ressource T06** — Renvoi thématique à un accompagnement officiel. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra24lyceegthggspenjeuxconnaissancepdf-104487.pdf). Le code désigne un point d’appui de la ressource Éduscol, pas une édition intégrale d’un ouvrage original. Voir le jalon correspondant.

**[B62] Histoire de l’alphabétisation des femmes — appui dans la ressource T06** — Renvoi thématique à un accompagnement officiel. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra24lyceegthggspenjeuxconnaissancepdf-104487.pdf). Le code désigne un point d’appui de la ressource Éduscol, pas une édition intégrale d’un ouvrage original. Voir le jalon correspondant.

**[B62a] Sénat — Loi du 21 décembre 1880 sur l’enseignement secondaire des jeunes filles** — Source institutionnelle. [Consulter la source](https://www.senat.fr/connaitre-le-senat/lhistoire-du-senat/dossiers-dhistoire/les-lois-scolaires-de-jules-ferry/les-lois-scolaires-de-jules-ferry-la-loi-du-21-decembre-1880-sur-lenseignement-secondaire-des-jeunes-filles.html).

**[B63] Musée Curie — Chronologie de Pierre et Marie Curie** — Source institutionnelle. [Consulter la source](https://musee.curie.fr/decouvrir/la-famille-curie/pierre-et-marie-curie-chronologie).

**[B63a] Communautés scientifiques et découvertes — appui dans la ressource T06** — Renvoi thématique à un accompagnement officiel. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra24lyceegthggspenjeuxconnaissancepdf-104487.pdf). Le code désigne un point d’appui de la ressource Éduscol, pas une édition intégrale d’un ouvrage original. Voir le jalon correspondant.

**[B63b] Fission nucléaire et applications stratégiques — appui dans la ressource T06** — Renvoi thématique à un accompagnement officiel. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra24lyceegthggspenjeuxconnaissancepdf-104487.pdf). Le code désigne un point d’appui de la ressource Éduscol, pas une édition intégrale d’un ouvrage original. Voir le jalon correspondant.

**[B64] Office of the Historian — Crise des missiles de Cuba, 1962** — Source institutionnelle. [Consulter la source](https://history.state.gov/milestones/1961-1968/cuban-missile-crisis).

**[B65] NSF/NCSES — Immigration and the science and engineering workforce, 2019** — Source institutionnelle. [Consulter la source](https://ncses.nsf.gov/pubs/nsb20198/immigration-and-the-s-e-workforce).

**[B65a] NSF — Arrangement de coopération États-Unis–Inde, annonce du 1er février 2023** — Source institutionnelle. [Consulter la source](https://www.nsf.gov/news/nsf-signs-us-india-implementation-arrangement-streamline). Page archivée : exemple historique de 2023, non affirmation de la politique actuelle. Date corrigée après réouverture de la source.

**[B66] Cyberespace : couches, acteurs et dépendances — appui dans la ressource T06** — Renvoi thématique à un accompagnement officiel. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra24lyceegthggspenjeuxconnaissancepdf-104487.pdf). Le code désigne un point d’appui de la ressource Éduscol, pas une édition intégrale d’un ouvrage original. Voir le jalon correspondant.

## Droits, adaptations et limites

Les textes historiques du domaine public et les actes officiels sont identifiés ; les autres ressources ne sont pas reproduites intégralement. Les synthèses, tableaux, exercices et schémas nouveaux sont des créations éditoriales de cette édition. Aucun fichier de police n’est livré. Les textes du kit et les fragments récupérés restent conservés séparément avec leurs empreintes ; les nouveaux développements ne sont pas présentés comme le manuscrit ancien retrouvé.

Les vérifications effectuées portent sur la couverture, les correspondances, les points réglementaires, les données explicites et la fabrication. Elles ne constituent pas une relecture disciplinaire indépendante de l’ensemble de l’ouvrage. Le registre JSON précise les accès protégés et les renvois documentaires indirects.
