# Carnet cartographique et schémas de raisonnement {#atlas}

Les cartes suivantes servent à localiser ; elles ne sont ni une carte des régimes politiques actuels ni une représentation exhaustive des frontières. Elles montrent les traits de côte, sans tracé des frontières d’État. Projection cylindrique équidistante ; coordonnées des villes arrondies. Fonds issus des données côtières distribuées avec Basemap/GSHHG ; réalisation éditoriale nouvelle. Les schémas A02 et A06–A09 représentent des relations, non des quantités mesurées. Les neuf figures sont disponibles séparément dans les sources.

## A01 — Démocratie : changer d’échelle {#A01}

![Carte A01 — Localisation des études de démocratie.](illustrations/A01.png){width=80%}

**Repères :** 1 Lisbonne ; 2 Madrid ; 3 Athènes ; 4 Bruxelles ; 5 Santiago du Chili ; 6 Washington. Situer un exemple ne signifie pas attribuer à l’ensemble du pays ou de la période un régime immuable. Athènes renvoie à la cité antique étudiée ; Bruxelles à une dimension institutionnelle de l’Union. La comparaison Portugal/Espagne/Chili doit conserver les temporalités différentes. [P01 ; S02]

\clearpage

## A02 — Espaces maritimes : distinguer les droits {#A02}

![Schéma A02 — Régimes maritimes simplifiés.](illustrations/A02.png){width=100%}

Une mer territoriale n’est pas une ZEE. Les 200 milles se mesurent depuis les lignes de base : on ne leur ajoute pas les 12 milles de la mer territoriale. Le schéma laisse de côté plusieurs zones et le régime détaillé du fond marin ; cette simplification ne doit pas être transformée en règle exhaustive. Source de référence : convention de Montego Bay, 1982. [D02 ; P03 ; T01]

\clearpage

## A03 — États-Unis : des lieux complémentaires {#A03}

![Carte A03 — Lieux de puissance aux États-Unis continentaux.](illustrations/A03.png){width=95%}

**Repères :** 1 Los Angeles/Hollywood ; 2 New York ; 3 Boston/Cambridge ; 4 Washington ; 5 San Francisco et aire de la Silicon Valley ; 6 Seattle. Les points désignent des lieux ou des aires, non des limites d’agglomération. Hollywood est un quartier de Los Angeles ; Cambridge appartient à l’aire de Boston. Les fonctions culturelles, financières, politiques, scientifiques et numériques se combinent ; aucun lieu ne représente à lui seul toute la puissance. L’exercice P02-E8 demande d’expliquer ces complémentarités. [R-P02]

\clearpage

## A04 — Europe : limites, interfaces et patrimoines {#A04}

![Carte A04 — Repères européens.](illustrations/A04.png){width=95%}

**Repères :** 1 Strasbourg, face à Kehl sur l’autre rive du Rhin ; 2 Luxembourg ; 3 Berlin ; 4 Varsovie ; 5 Bruxelles ; 6 Venise ; 7 Paris. Le fond ne représente pas l’espace Schengen. Pour parler de frontières, ajouter une légende correspondant à la date et au dispositif étudiés, sans déduire une compétence juridique du seul emplacement d’une ville. [P03 ; T04 ; D04]

\clearpage

## A05 — Moyen-Orient : localiser sans simplifier les conflits {#A05}

![Carte A05 — Repères au Moyen-Orient.](illustrations/A05.png){width=95%}

**Repères :** 1 Jérusalem ; 2 Le Caire ; 3 Damas ; 4 Bagdad ; 5 Koweït ; 6 Téhéran ; 7 Amman ; 8 Istanbul. Les points sont des repères de localisation, non une attribution de souveraineté ou une prise de position sur un statut territorial contesté. Ne pas confondre la capitale d’un État, un lieu de négociation et l’ensemble des acteurs qui y interviennent. [T02 ; R-T02]

\clearpage

## A06 — Information : identifier la chaîne de production {#A06}

![Schéma A06 — Production et réception d’une information.](illustrations/A06.png){width=100%}

Chaque flèche représente une opération, pas une garantie. La vérification peut échouer ; la mise en forme peut modifier un cadrage ; la réception n’est pas une adhésion automatique. Pour une dépêche reprise dans plusieurs journaux, distinguer la source initiale et les choix des rédactions. [P04 ; M3]

\clearpage

## A07 — Patrimoine : une chaîne d’opérations et d’arbitrages {#A07}

![Schéma A07 — Patrimonialisation et transmission.](illustrations/A07.png){width=100%}

La sélection précède une reconnaissance qui ne garantit pas toute la conservation. Le dernier bloc n’est pas une fin définitive : une pratique doit être transmise et un site entretenu. Revenir sur une décision peut être nécessaire lorsque les usages et les risques changent. [T04 ; D11 ; D12]

\clearpage

## A08 — Climat : raisonner sur les mécanismes {#A08}

![Schéma A08 — Causes, effets et réponses climatiques.](illustrations/A08.png){width=100%}

L’atténuation et l’adaptation sont différentes mais complémentaires. Les effets ne sont pas uniformes, parce que les espaces et les sociétés n’ont pas les mêmes expositions ni les mêmes moyens. Le schéma ne remplace pas un modèle climatique ou une série de mesures ; il organise des distinctions du cours. [T05 ; D13]

\clearpage

## A09 — Cyberespace : articuler matériel, logique et droits {#A09}

![Schéma A09 — Trajet plausible d’une consultation.](illustrations/A09.png){width=100%}

Un service peut distribuer ses données entre plusieurs centres et emprunter plusieurs réseaux. Le schéma ne prouve donc pas le trajet réel d’une consultation donnée. Il rappelle que des câbles, des logiciels, des identités et des règles sont nécessaires pour accéder à un document. Distinguer ce que l’on observe, ce que l’on suppose et ce qu’une enquête technique devrait établir. [T06 ; D15 ; D16]
