# Lexique raisonné et index thématique {#lexique}

Ces définitions de travail renvoient aux chapitres où les notions sont contextualisées. Une définition ne remplace pas l’exemple ni l’analyse des limites. Plusieurs mots changent de portée selon l’époque et l’auteur ; préciser l’usage retenu dans la copie.

**Adaptation** — Réduction de la vulnérabilité aux effets d’un changement climatique ; à distinguer de l’atténuation. T05.

**Alphabétisation** — Apprentissage et maîtrise de compétences de lecture et d’écriture, mesurées selon des conventions qu’il faut préciser. Un taux exige une population de référence. T06.

**Alternance** — Remplacement des gouvernants ou de la majorité dans le respect de règles permettant la compétition politique. P01.

**Armistice** — Accord suspendant des opérations militaires ; il ne se confond pas avec un traité de paix réglant l’ensemble du conflit. P03, T02.

**Atténuation** — Action sur les causes du changement climatique, notamment les émissions et les puits de gaz à effet de serre. T05.

**Attribution** — Démarche cherchant à établir la responsabilité d’une action ; dans le cyberespace, elle ne se déduit pas de la seule localisation d’un serveur. T06.

**Autoritarisme** — Forme d’exercice du pouvoir limitant fortement la compétition politique et les libertés ; à contextualiser plutôt qu’à utiliser comme synonyme de toute décision contraignante. P01.

**Censure** — Contrôle qui empêche ou limite une expression ou une diffusion. Distinguer censure préalable, sanctions juridiques et autres pressions. P04.

**Citoyenneté** — Statut organisant l’appartenance politique, des droits et des obligations. Ses conditions varient : les habitants d’Athènes ne sont pas tous citoyens. P01.

**Connaissance** — Savoir construit par la mise en relation, l’interprétation et la validation d’informations ou d’expériences. T06.

**Conservation** — Maintien d’éléments, de ressources ou de conditions de renouvellement ; sa finalité peut être productive, scientifique ou patrimoniale selon le contexte. T04, T05.

**Contre-pouvoir** — Institution ou capacité organisée qui limite, contrôle ou conteste l’exercice d’un pouvoir. P01.

**Coopération** — Action coordonnée entre acteurs conservant des intérêts et des compétences propres. Elle n’implique pas l’absence de rivalité ou l’égalité de leurs moyens. P02, T01, T02, T05, T06.

**Cyberespace** — Ensemble de réseaux, d’infrastructures, de logiciels, d’informations et d’acteurs permettant des interactions numériques. Il ne se réduit ni à une carte des câbles ni à un espace immatériel. T06.

**Démocratie directe** — Participation des citoyens eux-mêmes à certaines décisions ; elle ne prouve pas que tous les habitants possèdent la citoyenneté. P01.

**Démocratie représentative** — Régime dans lequel des représentants exercent des fonctions politiques selon un mandat et des règles de responsabilité. Ses garanties dépassent la seule élection. P01.

**Désinformation** — Production ou diffusion intentionnelle d’informations trompeuses. Distinguer intention, erreur involontaire, satire et désaccord d’interprétation. P04.

**Dissuasion** — Action cherchant à empêcher un adversaire d’agir en lui faisant anticiper un coût jugé inacceptable. La dissuasion nucléaire est un cas spécifique. T01, T02.

**Donnée** — Élément enregistré ou mesuré qui demande un contexte, une définition et un traitement avant de soutenir une conclusion. T05, T06.

**État de droit** — Organisation dans laquelle l’exercice du pouvoir est soumis à des règles et à des garanties juridictionnelles ; ne se réduit pas à l’existence de textes. P01.

**Frontière** — Limite construite de souveraineté ou de compétence, qui peut aussi être un espace de contact, de filtrage et de coopération. P03.

**Génocide** — Crime défini par des actes et une intention de détruire, en tout ou en partie, un groupe national, ethnique, racial ou religieux comme tel. La qualification exige d’examiner les critères de la convention de 1948. T03, D17.

**Géopolitique** — Analyse de rivalités et de coopérations entre acteurs pour des territoires, ressources ou positions, intégrant leurs représentations. Module 00.

**Gouvernance** — Organisation d’une action entre plusieurs acteurs et niveaux, sans supposer un gouvernement unique qui décide de tout. T05.

**Guerre** — Affrontement armé organisé entre acteurs ; sa qualification et ses formes doivent être examinées, sans appeler guerre toute concurrence. T02.

**Histoire** — Construction critique de connaissances sur le passé à partir de sources interrogées et confrontées. T03.

**Information** — Contenu porté à la connaissance d’un destinataire ; sa vérité, son contexte et ses conditions de production doivent être établis. P04, T06.

**Interface** — Espace de contact et d’échanges entre ensembles différenciés. Une frontière peut devenir une interface sans perdre toute fonction de limite. P03.

**Jalon** — Entrée d’étude explicitement prévue dans une rubrique du programme. Les codes P01-AXE1-J01 du manuel sont locaux, non ministériels. S02, S03.

**Laïcité** — Mode d’organisation des rapports entre État et religions, dont les formes institutionnelles varient. À distinguer de la sécularisation des sociétés. P05.

**Légitimité** — Reconnaissance du droit ou de la justification d’un pouvoir ou d’une action. Elle peut être contestée et ne se confond pas avec la seule capacité matérielle. P01, T02.

**Mémoire** — Rapport situé au passé, individuel ou collectif, qui sélectionne et transmet des expériences et des significations. Ce n’est ni un mensonge par définition ni une histoire exhaustive. T03.

**Multilatéralisme** — Organisation de relations et de décisions entre plusieurs États, souvent dans un cadre institutionnel. Il n’abolit pas leurs rapports de force. T02, T05.

**Patrimonialisation** — Processus par lequel des acteurs reconnaissent, sélectionnent et organisent la transmission d’un héritage. T04.

**Patrimoine immatériel** — Pratiques, expressions, connaissances et savoir-faire reconnus par des communautés, dont la sauvegarde repose sur la transmission vivante. T04, D12.

**Pluralisme** — Reconnaissance et possibilité d’expression d’une diversité de positions, d’organisations ou d’appartenances. P01, P04, P05.

**Problématique** — Question construite qui organise la démonstration à partir de la tension du sujet ; elle ne se réduit pas à ajouter un point d’interrogation au titre. M1, M6.

**Projection de puissance** — Capacité à intervenir et à soutenir une action au-delà de son territoire, par des moyens et des relais précis. T01.

**Puissance** — Capacité d’un acteur à agir, à faire agir, à empêcher ou à peser sur une relation. Une ressource n’a pas automatiquement l’effet recherché. P02.

**Renseignement** — Informations recherchées, traitées et analysées pour éclairer une décision, notamment dans un contexte stratégique. T06.

**Représentation** — Selon le contexte, exercice d’un mandat politique ou manière de percevoir et de construire le sens d’une situation ; préciser le sens utilisé. P01, P02.

**Restauration** — Intervention sur un héritage dégradé, fondée sur des choix d’état, de matériaux et de méthode. Elle n’est pas une restitution magique d’un passé intact. T04.

**Sécularisation** — Transformation de la place du religieux dans les pratiques, les institutions et les représentations sociales ; processus distinct d’une décision juridique de séparation. P05.

**Sécurité collective** — Dispositif dans lequel des membres cherchent à répondre collectivement aux menaces contre la paix, selon des règles et des organes. T02.

**Soft power** — Capacité d’influence par l’attraction ; une sanction économique relève de la contrainte, même sans recours à l’armée. P02.

**Souveraineté** — Autorité suprême exercée dans un ordre politique et sur un territoire, soumise dans les relations internationales à des règles et des engagements. Ne pas confondre souveraineté et capacité d’action illimitée. P03, T01.

**Source** — Trace, document ou témoignage interrogé pour construire une connaissance. Identifier auteur, date, nature, contexte et conditions d’accès. M3.

**Terrorisme** — Usage de violences visant notamment à terroriser des populations ou à contraindre des autorités ; qualifier les pratiques et leurs auteurs sans en faire une explication unique. T02.

**Transition démocratique** — Processus de transformation d’un régime autoritaire vers des institutions et des pratiques démocratiques, dont la consolidation n’est pas garantie. P01.

**Valorisation** — Mise en visibilité, en usage ou en intelligibilité d’un héritage ; elle peut comporter des dimensions éducatives, sociales et économiques à évaluer. T04.

**Vulnérabilité** — Propension à subir les effets d’un aléa, liée notamment à l’exposition, aux ressources et aux capacités de protection. T05.

**ZEE** — Zone économique exclusive, pouvant s’étendre jusqu’à 200 milles depuis les lignes de base, où l’État côtier possède des droits souverains et des compétences déterminés, sans souveraineté intégrale comparable à celle de la mer territoriale. P03, T01, D02.
