# HGGSP — Cycle terminal — Édition pédagogique 1.0

**Session 2027. Actualisation documentaire : 8 septembre 2026.**

## Ouvrir et utiliser le dossier

Ouvrir `index.html` après extraction de l’archive. Les cinq volumes PDF se trouvent dans `pdf/`. Les versions HTML, consultables hors connexion, sont dans `html/` ; conserver leur dossier avec `illustrations/` et le fichier CSS. Les liens bibliographiques externes demandent évidemment une connexion.

Le **manuel du cycle terminal** comporte les cinq thèmes de Première et les six thèmes de Terminale, avec diagnostics, cours, documents, exemples commentés, exercices, QCM et nouveaux tests. Les méthodes, remédiations, oraux, cartes et lexique complètent ce parcours.

Le **volume Première** est une extraction N1 des mêmes sources. Ses pages de présentation situent aussi N2 afin d’éviter les confusions, mais les cours de Terminale n’y sont pas repris. Il s’utilise avec les sections P01 à P05 du compagnon commun.

Le **compagnon d’autocorrection** doit être consulté après une première tentative. Les identifiants permettent de retrouver les réponses, critères, explications des distracteurs et propositions de reprise. Les exemples résolus intégrés au cours peuvent être lus immédiatement.

Les **épreuves avec corrigés** comprennent cinq compositions N1 et quatre écrits N2. Chaque écrit N2 propose deux dissertations au choix et une étude critique portant sur un troisième thème. Les deux dissertations sont corrigées. Le volume **Sujets seuls** permet une première passation sans réponses.

## Cadre de cette édition

N1 et N2 sont des parcours éditoriaux, non des degrés de difficulté. Une préparation intensive en une année ne vaut pas autorisation administrative de regrouper les épreuves. Les documents officiels et la situation personnelle du candidat restent déterminants. Le manuel prépare HGGSP, pas toutes les disciplines du bac.

Les 78 jalons locaux sont rapprochés des programmes dans `verification/MATRICE_COUVERTURE.csv`, `.json` et `.md`. Le registre `sources/referentiel/registre_sources.json` distingue sources officielles, ressources d’accompagnement, sources spécifiques et renvois thématiques. Un renvoi bibliographique ne signifie pas que tous les ouvrages originaux ont été intégralement lus.

## Provenance et conservation

Le dossier de reprise ne contenait pas le manuscrit historique complet ni ses anciens corrigés. Sept fichiers de fondation ou de transcription utilisés sont conservés **inchangés** dans `sources/originaux/`, avec leurs empreintes dans `verification/ORIGINAUX.json`. Les archives complètes du précédent checkpoint restent des témoins distincts ; elles ne sont pas prétendument remplacées ou intégralement recopiées dans cette édition.

Les fragments d’énoncés récupérés, les adaptations et les textes nouvellement rédigés sont distingués dans la banque JSON et les pages de provenance. Tous les corrigés avancés sont nouveaux. Les neuf figures sont des réalisations éditoriales nouvelles ; elles ne sont pas les quatre images historiques. Aucun fichier de police n’est fourni.

## Modifier puis reconstruire

Les sources canoniques sont sous `sources/`. Les assemblages sous `production/assemblages/` sont générés : **ne pas les modifier directement**, car ils seraient remplacés au prochain assemblage. La banque JSON et les dix-huit fichiers de sujets/corrigés sont les entrées de leurs volumes respectifs.

Dépendances de construction : Python 3.10 ou ultérieur, Pandoc, LuaLaTeX, paquets LaTeX usuels (`fontspec`, `unicode-math`, `babel`, `sectsty`, `fancyhdr`, `caption`, `float`, `needspace`, `microtype`, `hyperref`, `bookmark`) et polices installées **Noto Serif, Lato, DejaVu Sans Mono**. Elles sont utilisées via leur nom système, sans être redistribuées.

Depuis la racine extraite :

```bash
python production/build.py --jobs 2
python production/verifier.py
```

Le second script utilise aussi PyMuPDF (`pymupdf`) pour ouvrir les PDF et contrôler leurs liens et polices. Le script de fabrication reconstruit cinq volumes ; l’option `--volumes manuel_cycle` limite la fabrication à un volume. Les chemins sont calculés relativement au script : aucun ancien chemin temporaire n’est requis.

Les illustrations déjà fournies suffisent à la fabrication. Pour les régénérer, les dépendances supplémentaires sont Matplotlib et Basemap ; exécuter `python production/atlas.py`. Les cartes utilisent les données côtières distribuées avec Basemap/GSHHG, sans frontières étatiques ; la projection et les limites sont expliquées dans l’atlas.

Les scripts n’effectuent aucun téléchargement, aucune publication, aucune modification d’un dépôt distant. La fabrication écrit seulement les assemblages, les exports et ses journaux locaux. Après une modification de contenu, refaire les contrôles et la revue des rendus ; un ancien rapport ne valide pas automatiquement une nouvelle édition.

## Portée des vérifications

Le rapport détaille les contrôles réellement exécutés et les pages inspectées. Il distingue couverture rédactionnelle, vérification des formats d’épreuve, contrôles techniques et revue visuelle ciblée. Il ne prétend pas à une relecture disciplinaire indépendante, à une homologation ministérielle, à une certification PDF/UA ou à la prévision des futurs sujets officiels.
