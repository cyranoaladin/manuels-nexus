#!/usr/bin/env python3
"""Schémas éditoriaux et cartes de localisation. Aucun service externe nécessaire."""
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch, Rectangle
from mpl_toolkits.basemap import Basemap
R=Path(__file__).resolve().parents[1];OUT=R/'illustrations';OUT.mkdir(exist_ok=True)
NAVY='#16324A';TEAL='#167C80';LIGHT='#EDF4F6';GOLD='#B67F28'
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':10,'axes.titleweight':'bold'})
def save(fig,id):
 fig.savefig(OUT/(id+'.png'),dpi=200,bbox_inches='tight',facecolor='white');fig.savefig(OUT/(id+'.pdf'),bbox_inches='tight',facecolor='white');plt.close(fig)
def mapfig(id,title,bounds,points):
 fig,ax=plt.subplots(figsize=(9.2,5.5));lo,la,hi,ha=bounds
 m=Basemap(projection='cyl',llcrnrlon=lo,llcrnrlat=la,urcrnrlon=hi,urcrnrlat=ha,resolution='c',ax=ax)
 m.drawmapboundary(fill_color='white');m.fillcontinents(color=LIGHT,lake_color='white');m.drawcoastlines(linewidth=.6,color=NAVY)
 # Only coastlines: no claim regarding current disputed state borders.
 import numpy as np
 step=10 if hi-lo<90 else 30
 m.drawmeridians(np.arange(-180,181,step),labels=[0,0,0,1],linewidth=.3,color='#CBD6DD',fontsize=8)
 m.drawparallels(np.arange(-90,91,step),labels=[1,0,0,0],linewidth=.3,color='#CBD6DD',fontsize=8)
 for n,name,x,y,dx,dy in points:
  ax.scatter([x],[y],s=28,color=TEAL,zorder=5)
  ax.annotate(str(n),(x,y),xytext=(dx,dy),textcoords='offset points',color=NAVY,fontweight='bold',fontsize=10,
   arrowprops=dict(arrowstyle='-',color=NAVY,lw=.45) if abs(dx)+abs(dy)>18 else None)
 ax.set_title(title,color=NAVY,pad=16)
 save(fig,id)
mapfig('A01','Situer les études de la démocratie',(-90,-45,40,65),[
 (1,'Lisbonne',-9.14,38.72,-18,-5),(2,'Madrid',-3.70,40.42,8,5),(3,'Athènes',23.73,37.98,8,4),
 (4,'Bruxelles',4.35,50.85,8,4),(5,'Santiago',-70.67,-33.45,8,3),(6,'Washington',-77.04,38.91,8,4)])
mapfig('A03','Des lieux de la puissance américaine',(-128,23,-65,51),[
 (1,'Los Angeles / Hollywood',-118.24,34.05,-4,-18),(2,'New York',-74.01,40.71,9,-14),
 (3,'Boston / Cambridge',-71.06,42.36,15,9),(4,'Washington',-77.04,38.91,-35,-7),
 (5,'San Francisco / Silicon Valley',-122.42,37.77,8,6),(6,'Seattle',-122.33,47.61,8,4)])
mapfig('A04','Europe : villes-repères, frontières et patrimoines',(-13,35,30,59),[
 (1,'Strasbourg',7.75,48.58,13,-13),(2,'Luxembourg',6.13,49.61,18,5),(3,'Berlin',13.41,52.52,8,3),
 (4,'Varsovie',21.01,52.23,8,3),(5,'Bruxelles',4.35,50.85,-14,8),(6,'Venise',12.32,45.44,8,4),(7,'Paris',2.35,48.86,-19,-6)])
mapfig('A05','Moyen-Orient : repères des conflits et négociations',(25,23,61,43),[
 (1,'Jérusalem',35.21,31.77,-23,8),(2,'Le Caire',31.24,30.04,-14,-14),(3,'Damas',36.29,33.51,8,5),
 (4,'Bagdad',44.37,33.32,8,5),(5,'Koweït',47.98,29.38,8,5),(6,'Téhéran',51.39,35.69,8,5),
 (7,'Amman',35.93,31.95,15,-12),(8,'Istanbul',28.98,41.01,8,-4)])
def canvas(title):
 fig,ax=plt.subplots(figsize=(9.2,4.7));ax.set_xlim(0,10);ax.set_ylim(0,5);ax.axis('off');ax.set_title(title,color=NAVY,pad=16);return fig,ax
def box(ax,x,y,w,h,text):
 ax.add_patch(FancyBboxPatch((x,y),w,h,boxstyle='round,pad=0.08',facecolor=LIGHT,edgecolor=TEAL,lw=1))
 ax.text(x+w/2,y+h/2,text,ha='center',va='center',color=NAVY,fontsize=10,linespacing=1.5)
def arrow(ax,a,b):ax.add_patch(FancyArrowPatch(a,b,arrowstyle='-|>',mutation_scale=12,color=TEAL,lw=1.3))
fig,ax=canvas('A02 — Mer : territoire, ressources et libertés')
box(ax,.15,2.2,1.6,1.5,'Mer territoriale\nJusqu’à 12 milles\nSouveraineté\nencadrée')
box(ax,2.4,2.2,3.45,1.5,'ZEE : jusqu’à 200 milles\nDroits souverains sur les ressources\nCompétences définies\nPas une souveraineté intégrale')
box(ax,6.5,2.2,3.2,1.5,'Haute mer\nLibertés et obligations\nPas d’appropriation\npar un État')
arrow(ax,(1.85,2.95),(2.3,2.95));arrow(ax,(5.95,2.95),(6.4,2.95))
ax.text(5,1.4,'Distances mesurées depuis les lignes de base, et non depuis la limite des 12 milles.',ha='center',fontsize=10,color=NAVY)
ax.text(5,.85,'Le fond marin relève aussi du régime du plateau continental ; ce schéma ne le représente pas.',ha='center',fontsize=9)
ax.text(5,.35,'Schéma de notions, non proportionnel. Délimitations et droits dépendent de la convention et des accords.',ha='center',fontsize=9)
save(fig,'A02')
fig,ax=canvas('A06 — De l’événement au public : une information construite')
for x,t in [(.2,'Événement\net traces'),(2.7,'Collecte\net vérification'),(5.2,'Sélection\net mise en forme'),(7.7,'Diffusion\net réception')]:box(ax,x,2.2,2.0,1.3,t)
for x in [2.3,4.8,7.3]:arrow(ax,(x,2.85),(x+.3,2.85))
box(ax,1,.3,8,1,'À chaque étape : acteurs, moyens, règles et choix\nUne reprise n’est pas une enquête indépendante.')
save(fig,'A06')
fig,ax=canvas('A07 — Patrimonialiser, protéger, transmettre')
for x,t in [(.2,'Identifier\nDocumenter'),(2.7,'Reconnaître\nProtéger'),(5.2,'Conserver\nRestaurer'),(7.7,'Transmettre\nFaire vivre')]:box(ax,x,2.5,2.0,1.15,t)
for x in [2.3,4.8,7.3]:arrow(ax,(x,3.05),(x+.3,3.05))
box(ax,.2,.4,9.5,1.2,'Acteurs : habitants, praticiens, experts, collectivités, États, organisations\nArbitrages : traces / usages ; fréquentation / vie locale ; mémoire / transformation')
save(fig,'A07')
fig,ax=canvas('A08 — Climat : distinguer causes, effets et réponses')
box(ax,.25,2.45,2.5,1.15,'Activités et émissions\nAccumulation de gaz\nà effet de serre')
box(ax,3.7,2.45,2.5,1.15,'Changement climatique\nEffets variables\nselon les espaces')
box(ax,7.05,2.45,2.5,1.15,'Exposition et\nvulnérabilités\nConséquences sociales')
arrow(ax,(2.9,3),(3.55,3));arrow(ax,(6.35,3),(6.9,3))
box(ax,.4,.35,3.8,1.1,'Atténuation\nAgir sur les causes et les émissions')
box(ax,5.4,.35,3.8,1.1,'Adaptation\nRéduire la vulnérabilité aux effets')
arrow(ax,(2.2,1.6),(1.5,2.3));arrow(ax,(7.3,1.6),(8.3,2.3));save(fig,'A08')
fig,ax=canvas('A09 — Consulter un document dans le cyberespace')
for x,t in [(.15,'Terminal\nUtilisateur'),(2.65,'Réseaux\nOpérateurs'),(5.15,'Centre de données\nHébergement'),(7.65,'Service\nDocument')]:box(ax,x,2.55,2.1,1.15,t)
for x in [2.3,4.8,7.3]:arrow(ax,(x,3.1),(x+.3,3.1))
box(ax,.2,.4,9.5,1.25,'Couche transversale : logiciels, identités, droits d’accès et sécurité\nLe trajet représenté est plausible, non une enquête sur un service réel.\nLocaliser un serveur ne suffit pas à attribuer une attaque.')
save(fig,'A09')
print('Atlas : 9 figures PNG + 9 PDF')
