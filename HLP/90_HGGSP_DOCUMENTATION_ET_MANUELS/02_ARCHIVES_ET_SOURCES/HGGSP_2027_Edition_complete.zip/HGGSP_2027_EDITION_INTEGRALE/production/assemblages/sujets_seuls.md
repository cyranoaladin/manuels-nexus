---
title: "HGGSP — Sujets seuls"
subtitle: "Cinq compositions N1 et quatre écrits N2 · Sans corrigés"
author: "Nexus Réussite — Collection Manuels scolaires"
date: "Session 2027 · Édition pédagogique 1.0 · 8 septembre 2026"
lang: "fr-FR"
---

# Consignes de passation

Ces neuf sujets originaux d’entraînement ne sont pas des sujets officiels de la session 2027. Aucun corrigé n’est inclus dans ce volume. Écrivez sur une copie séparée et conservez votre brouillon pour analyser votre démarche après l’épreuve.

**N1 :** composition de deux heures, sur 20 ; traiter le sujet indiqué. **N2 :** quatre heures ; choisir une dissertation parmi les deux proposées, puis traiter l’étude critique ; chaque exercice est noté sur 10. La répartition du temps entre exercices relève de votre méthode.

Les documents nécessaires aux études critiques sont intégrés et leur nature est précisée. Les tableaux éditoriaux ne sont pas des données statistiques authentiques sauf mention expresse. Les durées et le format sont fondés sur les textes applicables ; les corrigés et barèmes pédagogiques sont dans le volume séparé. ([S04](#ref-S04) ; [S05](#ref-S05))

# N1-1 — Composition de Première

**Durée : 2 heures. Note : sur 20.** Épreuve blanche originale ; aucun document ni accès au cours pendant la simulation. Rédigez une introduction, un développement organisé et une conclusion.

## Sujet

**Pourquoi le passage à la démocratie est-il un processus incertain ?**

Périmètre de préparation : P01, axe 2 — Avancées et reculs des démocraties. Ce sujet porte sur cette seule partie du programme de Première.

# N1-2 — Composition de Première

**Durée : 2 heures. Note : sur 20.** Épreuve blanche originale ; aucun document ni accès au cours pendant la simulation. Rédigez une introduction, un développement organisé et une conclusion.

## Sujet

**Comment les formes indirectes de la puissance permettent-elles d’agir sur les autres acteurs ?**

Périmètre de préparation : P02, axe 2 — Formes indirectes de la puissance. Ce sujet porte sur cette seule partie du programme de Première.

# N1-3 — Composition de Première

**Durée : 2 heures. Note : sur 20.** Épreuve blanche originale ; aucun document ni accès au cours pendant la simulation. Rédigez une introduction, un développement organisé et une conclusion.

## Sujet

**Pourquoi l’ouverture des frontières européennes ne signifie-t-elle pas leur disparition ?**

Périmètre de préparation : P03, objet conclusif — Les frontières internes et externes de l’Union européenne. Ce sujet porte sur cette seule partie du programme de Première.

# N1-4 — Composition de Première

**Durée : 2 heures. Note : sur 20.** Épreuve blanche originale ; aucun document ni accès au cours pendant la simulation. Rédigez une introduction, un développement organisé et une conclusion.

## Sujet

**Pourquoi la liberté de l’information dépend-elle de rapports de force politiques et sociaux ?**

Périmètre de préparation : P04, axe 2 — Liberté ou contrôle de l’information. Ce sujet porte sur cette seule partie du programme de Première.

# N1-5 — Composition de Première

**Durée : 2 heures. Note : sur 20.** Épreuve blanche originale ; aucun document ni accès au cours pendant la simulation. Rédigez une introduction, un développement organisé et une conclusion.

## Sujet

**Comment l’État indien peut-il organiser le pluralisme religieux dans une société traversée par des tensions ?**

Périmètre de préparation : P05, objet conclusif — État et religions en Inde. Ce sujet porte sur cette seule partie du programme de Première.

# N2-1 — Écrit terminal HGGSP

**Durée : 4 heures. Note : sur 20.** Épreuve blanche originale, session de préparation 2027. Aucun accès au cours ni aux corrigés pendant la simulation.

## Première partie — Dissertation, sur 10

Choisissez **un seul** des deux sujets.

**Sujet 1 — La guerre demeure-t-elle un instrument politique malgré la transformation des conflits ?**

**Sujet 2 — Pourquoi le patrimoine peut-il devenir un objet de conflit ?**

Rédigez une introduction, un développement organisé et une conclusion. Une illustration pertinente est possible mais non obligatoire.

## Seconde partie — Étude critique, sur 10

**La coopération environnementale : construire un cadre, obtenir des résultats**

En confrontant les documents et en mobilisant vos connaissances, montrez comment se construit une coopération environnementale et pourquoi l’existence d’un cadre ne suffit pas à démontrer son efficacité.

### Document 1 — Une architecture de coopération climatique

**Adaptation pédagogique**, rédigée pour ce manuel, des articles 2, 4 et 13 de l’accord de Paris adopté le 12 décembre 2015. Ce texte reformule des dispositions ; ce n’est pas une citation littérale. Source institutionnelle : CCNUCC ([D10](#ref-D10) ; [B58a](#ref-B58a)).

L’accord poursuit notamment un objectif collectif de limitation de l’élévation de la température mondiale nettement sous 2 °C et de poursuite des efforts vers 1,5 °C, par rapport aux niveaux préindustriels. Chaque partie prépare, communique et actualise une contribution déterminée au niveau national. Les contributions successives doivent progresser et traduire une ambition tenant compte des responsabilités et des capacités différentes. Un cadre de transparence organise la communication d’informations sur les actions et leurs résultats. Ces mécanismes articulent une direction collective et des décisions nationales ; ils ne constituent pas une administration mondiale unique de l’énergie.

### Document 2 — Des étapes et des instruments distincts

**Tableau chronologique éditorial**, construit pour ce sujet à partir des ressources institutionnelles de l’ONU et de la CCNUCC. Il sélectionne quatre étapes ; il ne mesure pas les résultats environnementaux. ([B58](#ref-B58) ; [D10](#ref-D10))

| Repère | Instrument ou événement | Niveau principal et opération |
|---|---|---|
| 1972 | Conférence de Stockholm | Mise à l’agenda international de questions environnementales. |
| 1992 | Sommet de Rio et Convention-cadre sur le climat | Cadre multilatéral de coopération, avec des responsabilités différenciées. |
| 1997 | Protocole de Kyoto | Engagements de réduction pour des pays industrialisés selon le dispositif du protocole. |
| 2015 | Accord de Paris | Objectif collectif, contributions nationales et révision. |

**Note.** Les dates sont celles des événements ou de l’adoption, non nécessairement de l’entrée en vigueur des instruments.

**Fin du sujet N2-1.** Les références servent à identifier les documents ; aucune consultation extérieure n’est nécessaire pendant l’épreuve. Les adaptations sont signalées et ne sont jamais présentées comme des citations littérales.

# N2-2 — Écrit terminal HGGSP

**Durée : 4 heures. Note : sur 20.** Épreuve blanche originale, session de préparation 2027. Aucun accès au cours ni aux corrigés pendant la simulation.

## Première partie — Dissertation, sur 10

Choisissez **un seul** des deux sujets.

**Sujet 1 — Les sociétés peuvent-elles protéger l’environnement tout en l’exploitant ?**

**Sujet 2 — Pourquoi la production et la diffusion des connaissances sont-elles des enjeux de puissance ?**

Rédigez une introduction, un développement organisé et une conclusion. Une illustration pertinente est possible mais non obligatoire.

## Seconde partie — Étude critique, sur 10

**Sécurité collective et usage de la force : des règles à leur application**

En confrontant les documents, analysez les principes de la sécurité collective et les difficultés de leur application. Vous distinguerez cadre juridique, décision politique et effets des interventions.

### Document 1 — Les principes de la Charte des Nations unies

**Adaptation pédagogique**, non verbatim, des articles 2, 24, 39, 42 et 51 de la Charte signée le 26 juin 1945. Source : Nations unies ([D09](#ref-D09)). La sélection simplifie le dispositif pour l’exercice ; elle ne remplace pas le texte intégral.

Les membres s’engagent à régler pacifiquement leurs différends et à s’abstenir de la menace ou de l’emploi de la force contre l’intégrité territoriale ou l’indépendance politique d’un État. Le Conseil de sécurité reçoit la responsabilité principale du maintien de la paix et de la sécurité internationales. Il peut constater une menace contre la paix, une rupture de la paix ou un acte d’agression, et décider des mesures appropriées, y compris, dans les conditions prévues, une action armée. La Charte reconnaît également un droit de légitime défense en cas d’agression armée, dans le cadre défini par son article 51.

### Document 2 — Deux situations irakiennes à distinguer

**Tableau de synthèse historique éditorial**, réalisé à partir des résolutions du Conseil de sécurité et de son répertoire des pratiques. Sources : ([B39](#ref-B39) ; [B39a](#ref-B39a)). Il ne prétend pas résumer toutes les dimensions des conflits.

| Situation | Décision et cadre international | Question posée après l’action militaire |
|---|---|---|
| 1990–1991 | Après l’invasion du Koweït, des résolutions condamnent l’Irak ; la résolution 678 autorise les États coopérant avec le Koweït à employer les moyens nécessaires dans les conditions fixées. | Comment articuler libération du Koweït, cessez-le-feu, contrôles et ordre régional ? |
| 2003 | L’invasion menée par les États-Unis et leurs alliés intervient sans nouvelle résolution autorisant explicitement cette invasion ; la portée d’autorisations antérieures est contestée. | Comment transformer la chute du régime en un ordre politique stable et accepté ? |

**Note.** La légalité invoquée par les intervenants et sa contestation doivent être attribuées ; une victoire militaire n’est pas un jugement juridique.

**Fin du sujet N2-2.** Les références servent à identifier les documents ; aucune consultation extérieure n’est nécessaire pendant l’épreuve. Les adaptations sont signalées et ne sont jamais présentées comme des citations littérales.

# N2-3 — Écrit terminal HGGSP

**Durée : 4 heures. Note : sur 20.** Épreuve blanche originale, session de préparation 2027. Aucun accès au cours ni aux corrigés pendant la simulation.

## Première partie — Dissertation, sur 10

Choisissez **un seul** des deux sujets.

**Sujet 1 — Comment construire une paix durable après un conflit armé ?**

**Sujet 2 — Pourquoi les politiques environnementales des États-Unis sont-elles traversées par des tensions ?**

Rédigez une introduction, un développement organisé et une conclusion. Une illustration pertinente est possible mais non obligatoire.

## Seconde partie — Étude critique, sur 10

**Coopérer pour produire des connaissances : possibilités et asymétries**

En confrontant les documents et en mobilisant vos connaissances, analysez les apports de la circulation des chercheurs et de la coopération scientifique. Vous montrerez aussi ce que les documents ne permettent pas de conclure sur l’égalité entre partenaires.

### Document 1 — Faciliter des projets scientifiques entre les États-Unis et l’Inde

**Synthèse adaptée d’une communication institutionnelle**, non verbatim. National Science Foundation, annonce du 1er février 2023 relative à un arrangement de mise en œuvre entre la NSF et les organismes indiens partenaires ([B65a](#ref-B65a)). Texte reformulé pour l’exercice.

Le dispositif annoncé vise à faciliter la préparation, l’évaluation et le financement de propositions de recherche collaboratives entre chercheurs américains et indiens. Il cherche à réduire certains obstacles administratifs liés à des procédures séparées. L’annonce associe cette démarche à la circulation d’idées, de ressources et de pratiques, dans plusieurs domaines scientifiques, dont l’informatique, les géosciences et les sciences physiques. Cette annonce présente un instrument destiné à soutenir des collaborations. Elle ne fournit pas, à elle seule, un bilan complet des projets réalisés, de leurs résultats ou de la répartition des bénéfices.

### Document 2 — Trois configurations de circulation des compétences

**Tableau conceptuel éditorial**, construit pour ce sujet à partir du cours T06. Il décrit des mécanismes possibles, non des proportions statistiques sur les migrations. ([R-T06](#ref-R-T06) ; [B65](#ref-B65))

| Configuration | Possibilité ouverte | Question à vérifier dans un cas réel |
|---|---|---|
| Installation durable à l’étranger | Accès à un laboratoire, des équipements et des réseaux. | Quelles capacités sont renforcées ou fragilisées dans les différents pays ? |
| Retour après formation ou emploi | Transfert de compétences et développement d’activités. | Les institutions locales permettent-elles leur réemploi ? |
| Collaboration à distance ou mobilité répétée | Projets communs, circulation d’informations et accès à des partenaires. | Qui finance, fixe les priorités et peut accéder aux résultats ? |

**Note.** Ces configurations peuvent se succéder ou se combiner dans un même parcours.

**Fin du sujet N2-3.** Les références servent à identifier les documents ; aucune consultation extérieure n’est nécessaire pendant l’épreuve. Les adaptations sont signalées et ne sont jamais présentées comme des citations littérales.

# N2-4 — Écrit terminal HGGSP

**Durée : 4 heures. Note : sur 20.** Épreuve blanche originale, session de préparation 2027. Aucun accès au cours ni aux corrigés pendant la simulation.

## Première partie — Dissertation, sur 10

Choisissez **un seul** des deux sujets.

**Sujet 1 — Pourquoi les tentatives de paix au Moyen-Orient rencontrent-elles des difficultés ?**

**Sujet 2 — Le partage des connaissances est-il compatible avec leur protection ?**

Rédigez une introduction, un développement organisé et une conclusion. Une illustration pertinente est possible mais non obligatoire.

## Seconde partie — Étude critique, sur 10

**Patrimonialiser et transmettre : une responsabilité à plusieurs échelles**

En confrontant les documents, montrez comment la reconnaissance patrimoniale articule responsabilité publique et transmission. Vous discuterez les limites d’une protection réduite au seul label.

### Document 1 — Responsabilité nationale et coopération internationale

**Adaptation pédagogique**, non verbatim, des articles 4 et 6 de la convention de l’UNESCO concernant la protection du patrimoine mondial culturel et naturel, adoptée le 16 novembre 1972 ([D11](#ref-D11)).

Chaque État partie reconnaît que l’identification, la protection, la conservation, la mise en valeur et la transmission aux générations futures du patrimoine situé sur son territoire lui incombent en premier lieu. Il agit selon ses ressources et peut mobiliser l’assistance et la coopération internationales. La reconnaissance d’un intérêt pour l’humanité s’articule au respect de la souveraineté des États et des droits de propriété prévus par les législations nationales. La convention organise donc une coopération ; elle ne transfère pas la propriété des biens à l’UNESCO.

### Document 2 — Trois héritages, des opérations différentes

**Tableau comparatif éditorial**, réalisé pour ce sujet à partir des notices institutionnelles des biens et pratiques. Sources : ([B49](#ref-B49) ; [B53](#ref-B53) ; [B54](#ref-B54) ; [D12](#ref-D12)). Les dates sont celles des inscriptions indiquées.

| Héritage | Reconnaissance | Une question de transmission |
|---|---|---|
| Paris, rives de la Seine | Patrimoine mondial, 1991 | Conserver un ensemble urbain tout en maintenant les fonctions d’une ville habitée. |
| Bassin minier du Nord-Pas-de-Calais | Patrimoine mondial, 2012 | Transmettre des traces et des mémoires du travail dans un territoire en reconversion. |
| Repas gastronomique des Français | Patrimoine culturel immatériel, 2010 | Transmettre une pratique sociale et des savoir-faire, non figer un menu obligatoire. |

**Note.** La dernière ligne relève du dispositif de la convention de 2003 sur le patrimoine culturel immatériel, et non d’une inscription au titre de la convention de 1972.

**Fin du sujet N2-4.** Les références servent à identifier les documents ; aucune consultation extérieure n’est nécessaire pendant l’épreuve. Les adaptations sont signalées et ne sont jamais présentées comme des citations littérales.

# Références et provenance documentaire {#references}

Les codes sont des repères locaux, non des identifiants ministériels. **S** désigne le cadre officiel ; **R** les ressources d’accompagnement ; **D** des documents de référence ; **B** une source spécifique ou un renvoi thématique à une ressource, selon la qualification indiquée. Un renvoi à une ressource pédagogique ne signifie pas que les ouvrages originaux qu’elle cite ont tous été lus intégralement.

Les documents du cours sont des synthèses éditoriales sauf indication expresse contraire. Les adaptations ne sont pas des citations verbatim. Les jeux fictifs ne sont pas des statistiques historiques. Les liens permettent une vérification complémentaire ; aucun exercice ne suppose qu’un document absent soit téléchargé pour être résolu.

**Actualisation : 8 septembre 2026.** Les règles de session et les faits contemporains demandent une nouvelle veille avant l’examen. Ce manuel ne vaut ni homologation ministérielle ni conseil individuel d’inscription.

## Cadre officiel

[**([S02](#ref-S02)) Programme de Première — BO spécial du 22 janvier 2019**]{#ref-S02} — Texte ou information officielle. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/spe576annexe1062925pdf-83244.pdf).

[**([S03](#ref-S03)) Programme de Terminale — BO spécial du 25 juillet 2019**]{#ref-S03} — Texte ou information officielle. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/spe254annexe1159180pdf-83247.pdf).

[**([S04](#ref-S04)) Note du 27 août 2025, NOR MENE2521923N — Épreuve HGGSP à compter de 2026**]{#ref-S04} — Texte ou information officielle. [Consulter la source](https://www.education.gouv.fr/bo/2025/Hebdo33/MENE2521923N).

[**([S05](#ref-S05)) Évaluation ponctuelle de la spécialité non poursuivie — version consolidée juin 2025, HGGSP pages 3–4**]{#ref-S05} — Texte ou information officielle. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ndsevaluations-ponctuelleseds-non-poursuivivoie-gjuin-2025pdf-100575.pdf).

## Accompagnement par thème

[**([R-T06](#ref-R-T06)) Éduscol — Ressource d’accompagnement : L’enjeu de la connaissance**]{#ref-R-T06} — Accompagnement disciplinaire officiel. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra24lyceegthggspenjeuxconnaissancepdf-104487.pdf). Source d’appui aux jalons et à leur problématisation ; ne vaut pas validation du présent manuel.

## Documents de référence

[**([D09](#ref-D09)) Nations unies — Charte de 1945**]{#ref-D09} — Document institutionnel de référence. [Consulter la source](https://treaties.un.org/doc/source/docs/charter-all-lang.pdf).

[**([D10](#ref-D10)) CCNUCC — Accord de Paris**]{#ref-D10} — Document institutionnel de référence. [Consulter la source](https://unfccc.int/process-and-meetings/the-paris-agreement).

[**([D11](#ref-D11)) UNESCO — Convention du patrimoine mondial de 1972**]{#ref-D11} — Document institutionnel de référence. [Consulter la source](https://whc.unesco.org/fr/conventiontexte/).

[**([D12](#ref-D12)) UNESCO — Convention pour la sauvegarde du patrimoine culturel immatériel, 2003**]{#ref-D12} — Document institutionnel de référence. [Consulter la source](https://ich.unesco.org/fr/convention). Le dispositif de 2003 est distinct de la convention de 1972. Aucun passage présenté comme transcription littérale.

## Appuis documentaires et approfondissements

[**([B39](#ref-B39)) Résolutions 678 et 687, guerre de 1991 — appui dans la ressource T02**]{#ref-B39} — Renvoi thématique à un accompagnement officiel. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra22lycee-gthggsptheme-2faire-la-guerre-et-faire-la-paix-93786.pdf). Le code désigne un point d’appui de la ressource Éduscol, pas une édition intégrale d’un ouvrage original. Voir le jalon correspondant.

[**([B39a](#ref-B39a)) Conseil de sécurité — Répertoire des pratiques, 2000–2003, chapitre XII**]{#ref-B39a} — Source institutionnelle. [Consulter la source](https://www.un.org/fr/sc/repertoire/00-03/00-03_12.pdf).

[**([B49](#ref-B49)) UNESCO — Paris, rives de la Seine**]{#ref-B49} — Source institutionnelle. [Consulter la source](https://whc.unesco.org/en/list/600/).

[**([B53](#ref-B53)) UNESCO — Bassin minier du Nord-Pas-de-Calais**]{#ref-B53} — Source institutionnelle. [Consulter la source](https://whc.unesco.org/en/list/1360/).

[**([B54](#ref-B54)) UNESCO — Repas gastronomique des Français, inscription 2010**]{#ref-B54} — Source institutionnelle. [Consulter la source](https://ich.unesco.org/en/RL/gastronomic-meal-of-the-french-00437).

[**([B58](#ref-B58)) Stockholm, Rio et Kyoto — appui dans la ressource T05**]{#ref-B58} — Renvoi thématique à un accompagnement officiel. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra23lyceegthggspenvironnementexploitationprotectionenjeupdf-102786.pdf). Le code désigne un point d’appui de la ressource Éduscol, pas une édition intégrale d’un ouvrage original. Voir le jalon correspondant.

[**([B58a](#ref-B58a)) CCNUCC — Contributions déterminées au niveau national**]{#ref-B58a} — Source institutionnelle. [Consulter la source](https://unfccc.int/process-and-meetings/the-paris-agreement/nationally-determined-contributions-ndcs).

[**([B65](#ref-B65)) NSF/NCSES — Immigration and the science and engineering workforce, 2019**]{#ref-B65} — Source institutionnelle. [Consulter la source](https://ncses.nsf.gov/pubs/nsb20198/immigration-and-the-s-e-workforce).

[**([B65a](#ref-B65a)) NSF — Arrangement de coopération États-Unis–Inde, annonce du 1er février 2023**]{#ref-B65a} — Source institutionnelle. [Consulter la source](https://www.nsf.gov/news/nsf-signs-us-india-implementation-arrangement-streamline). Page archivée : exemple historique de 2023, non affirmation de la politique actuelle. Date corrigée après réouverture de la source.

## Droits, adaptations et limites

Les textes historiques du domaine public et les actes officiels sont identifiés ; les autres ressources ne sont pas reproduites intégralement. Les synthèses, tableaux, exercices et schémas nouveaux sont des créations éditoriales de cette édition. Aucun fichier de police n’est livré. Les textes du kit et les fragments récupérés restent conservés séparément avec leurs empreintes ; les nouveaux développements ne sont pas présentés comme le manuscrit ancien retrouvé.

Les vérifications effectuées portent sur la couverture, les correspondances, les points réglementaires, les données explicites et la fabrication. Elles ne constituent pas une relecture disciplinaire indépendante de l’ensemble de l’ouvrage. Le registre JSON précise les accès protégés et les renvois documentaires indirects.
