---
title: "HGGSP — Épreuves blanches"
subtitle: "Cinq compositions N1 et quatre écrits N2 · Sujets et corrigés"
author: "Nexus Réussite — Collection Manuels scolaires"
date: "Session 2027 · Édition pédagogique 1.0 · 8 septembre 2026"
lang: "fr-FR"
---

# Passer une épreuve, puis l’analyser

Ce volume contient neuf sujets originaux d’entraînement et leurs corrections : cinq compositions N1, puis quatre écrits N2. Ce ne sont pas des sujets officiels annoncés pour 2027. Les barèmes détaillés et les répartitions temporelles sont pédagogiques, sauf les durées et notes prescrites indiquées comme telles.

Pour un premier essai en temps limité, utilisez le volume « Sujets seuls ». Dans chaque N2, choisissez une seule des deux dissertations ; traitez aussi l’étude critique. Les deux dissertations proposées sont corrigées pour permettre une reprise ultérieure. Lire les deux corrigés avant la première tentative enlève au sujet sa fonction diagnostique.

Les documents adaptés et les tableaux éditoriaux sont identifiés dans chaque dossier. Ils sont fournis intégralement dans le sujet. Les corrigés sont des propositions argumentées, non une grille officielle exclusive. ([S04](#ref-S04) ; [S05](#ref-S05))

# N1-1 — Composition de Première

**Durée : 2 heures. Note : sur 20.** Épreuve blanche originale ; aucun document ni accès au cours pendant la simulation. Rédigez une introduction, un développement organisé et une conclusion.

## Sujet

**Pourquoi le passage à la démocratie est-il un processus incertain ?**

Périmètre de préparation : P01, axe 2 — Avancées et reculs des démocraties. Ce sujet porte sur cette seule partie du programme de Première.

# Correction N1-1 — Pourquoi le passage à la démocratie est-il un processus incertain ?

## Analyser et problématiser

« Passage » désigne une transformation, pas seulement une première élection. « Incertain » invite à examiner des fragilités et des bifurcations, sans affirmer que toute transition échoue. Les jalons du Chili, du Portugal et de l’Espagne permettent de comparer rupture antidémocratique, mobilisations et compromis. Problématique possible : comment des acteurs peuvent-ils construire des garanties démocratiques lorsque les rapports de force et l’héritage autoritaire restent ouverts ?

## Une organisation recevable

I. Des rapports de force peuvent interrompre ou fragiliser la démocratie : polarisation, armée, acteurs extérieurs ; Chili. II. La sortie d’un régime autoritaire exige la construction disputée de règles et de garanties : Portugal et Espagne. III. La stabilisation dépend de compromis et de contre-pouvoirs qui ne suppriment pas tous les conflits. Deux parties sont également possibles en regroupant les deux dernières.

## Proposition rédigée

En avril 1974, la chute de la dictature portugaise ouvre une période de transformation sans fixer immédiatement toutes les institutions du nouveau régime. L’événement rappelle qu’une rupture ne suffit pas à assurer la démocratie. Celle-ci suppose non seulement des élections, mais des libertés, des droits et la possibilité d’une alternance dans un cadre accepté. Pourquoi son établissement demeure-t-il incertain ? Les exemples chilien, portugais et espagnol montrent que les rapports de force peuvent renverser un régime, tandis que sa démocratisation exige des garanties dont la construction reste conflictuelle.

D’abord, les procédures électorales ne mettent pas une démocratie à l’abri d’une crise. Au Chili, Salvador Allende accède à la présidence en 1970 dans un cadre constitutionnel. Son projet de transformation, les oppositions qu’il rencontre, la polarisation et les tensions économiques s’inscrivent dans un contexte de guerre froide. L’hostilité américaine intervient dans ce contexte, sans dispenser d’étudier les acteurs chiliens et leurs décisions. Le coup d’État du 11 septembre 1973, conduit par les militaires, détruit les garanties démocratiques et ouvre une dictature. Cet exemple interdit de considérer la démocratie comme un acquis irréversible produit par une seule élection.

La sortie de l’autoritarisme est elle-même une période d’incertitude. Au Portugal, le Mouvement des forces armées joue un rôle décisif le 25 avril 1974. La fin du régime ouvre des libertés, mais les orientations économiques, sociales et institutionnelles font l’objet de conflits. Les mobilisations populaires et les divisions entre forces politiques montrent que tous les adversaires de la dictature ne partagent pas exactement le même projet. Les élections et la Constitution de 1976 participent à la construction d’un cadre démocratique. La transition doit donc être comprise comme une succession de décisions, non comme la simple conséquence automatique du jour de la révolution.

L’Espagne offre un autre chemin. Après la mort de Franco en 1975, la transformation s’effectue à partir d’institutions héritées, sous l’action du roi Juan Carlos, de responsables réformateurs, de forces d’opposition et de mobilisations sociales. Les élections de 1977 et la Constitution de 1978 organisent un nouveau cadre. Les compromis rendent possible un changement sans reproduire exactement la rupture portugaise ; ils suscitent aussi des débats sur les héritages de la dictature et les conditions de la transition. La tentative de coup d’État de février 1981 rappelle que l’établissement des institutions n’a pas immédiatement fait disparaître toutes les menaces.

Enfin, la consolidation exige que les acteurs acceptent les règles même lorsqu’ils perdent. Des élections pluralistes ne suffisent pas si l’armée peut intervenir contre le pouvoir civil ou si les droits de l’opposition ne sont pas protégés. Les libertés publiques, les contre-pouvoirs et les pratiques d’alternance donnent de la durée au changement. Ces garanties ne font pas disparaître les désaccords : elles permettent de les traiter sans supprimer la compétition politique. Il serait donc erroné de définir la stabilité démocratique par l’absence de conflit.

Le passage à la démocratie est ainsi incertain parce qu’il transforme des intérêts, des institutions et des usages du pouvoir. Il dépend des décisions prises pendant les crises autant que des règles progressivement établies. Les cas étudiés ne fournissent pas une recette unique, mais un même principe d’analyse : distinguer chute d’un régime, ouverture politique et consolidation démocratique, sans faire de l’une la garantie automatique des autres.

## Évaluer et reprendre

**Erreurs à corriger.** Présenter le coup d’État chilien comme une transition démocratique ; confondre Portugal et Espagne ; expliquer toutes les décisions par un seul acteur extérieur ; définir démocratie par absence de conflit.

**Autre démarche recevable.** Comparer les trois situations selon les acteurs, les modes de transformation puis les garanties, plutôt que suivre trois récits nationaux séparés.

**Barème pédagogique proposé, non ministériel.** Compréhension et problématique : 4 points ; connaissances exactes et situées : 6 ; raisonnement et organisation : 6 ; expression et achèvement : 4. Ne pas sanctionner deux fois la même faiblesse. Une organisation différente peut obtenir tous les points si elle répond au sujet.

**Après correction.** Relever deux écarts entre votre copie et les critères, non entre votre copie et les formulations de ce modèle. Réécrire un paragraphe sans consulter le texte. À J+7, traiter une question voisine pendant 30 minutes.

# N1-2 — Composition de Première

**Durée : 2 heures. Note : sur 20.** Épreuve blanche originale ; aucun document ni accès au cours pendant la simulation. Rédigez une introduction, un développement organisé et une conclusion.

## Sujet

**Comment les formes indirectes de la puissance permettent-elles d’agir sur les autres acteurs ?**

Périmètre de préparation : P02, axe 2 — Formes indirectes de la puissance. Ce sujet porte sur cette seule partie du programme de Première.

# Correction N1-2 — Comment les formes indirectes de la puissance permettent-elles d’agir sur les autres acteurs ?

## Analyser et problématiser

Il faut expliquer des mécanismes : attraction, dépendance, standardisation, accès et contrôle des réseaux. « Indirect » n’est pas synonyme de bienveillant ni de culturel. Le sujet appelle les langues, les nouvelles technologies et les routes de la soie. Une réponse centrée sur l’armée américaine manquerait le périmètre.

## Une organisation recevable

I. La diffusion linguistique et culturelle crée de l’attraction et des réseaux. II. Les infrastructures et les technologies structurent des dépendances et des règles. III. Leurs effets demeurent conditionnels, négociés et contestés.

## Proposition rédigée

La capacité d’un acteur à influencer un choix ne repose pas toujours sur une menace militaire explicite. Une langue de travail, un service numérique ou une infrastructure commerciale peuvent orienter les possibilités des autres. Ces formes indirectes de puissance agissent par l’attraction, l’organisation des échanges ou la dépendance. Comment deviennent-elles des instruments d’action ? Elles ouvrent des réseaux et structurent des choix, mais leur efficacité dépend de conditions qui empêchent de confondre diffusion et domination automatique.

La langue constitue d’abord une ressource de circulation. Lorsqu’elle est employée dans l’enseignement, la recherche, les affaires ou la diplomatie, elle facilite l’accès à certains réseaux. Les institutions culturelles et éducatives peuvent soutenir sa diffusion et maintenir des liens entre sociétés. La francophonie illustre l’existence d’un espace linguistique partagé qui dépasse un seul État. Il ne faut pourtant pas en faire une zone d’obéissance à la France : les acteurs qui utilisent le français ont leurs propres intérêts et peuvent s’approprier la langue de manière autonome.

Les productions culturelles peuvent également rendre un pays ou un mode de vie attractif. Le soft power désigne cette capacité d’attraction, distincte de la contrainte et du paiement. Une œuvre appréciée peut familiariser un public avec des références ; une université reconnue peut attirer des étudiants et soutenir des échanges durables. L’effet politique n’est toutefois pas immédiat. On peut aimer des films sans soutenir le gouvernement de leur pays d’origine. Une copie doit donc expliquer la conversion éventuelle de la ressource en influence, plutôt que présenter la popularité comme une preuve suffisante de puissance.

Les nouvelles technologies interviennent selon d’autres mécanismes. Les entreprises qui organisent des services numériques disposent d’infrastructures, de données et de capacités à définir des conditions d’accès. Des effets de réseau peuvent rendre une plateforme difficile à remplacer : son intérêt augmente avec ses utilisateurs, tandis que la migration vers une autre solution comporte des coûts. Les États cherchent à encadrer ces acteurs par le droit, la concurrence et la protection des données. La puissance se joue alors dans la capacité à imposer ou négocier des normes, pas seulement dans la possession d’une entreprise connue.

Les routes de la soie, promues par la Chine à partir de 2013, montrent enfin l’importance des infrastructures et de la connectivité. Des ports, voies ferrées ou corridors peuvent améliorer les échanges et renforcer la position des acteurs qui les financent, les construisent ou les gèrent. Mais leurs effets dépendent de la rentabilité, des contrats, des choix des États partenaires et des usages effectifs. Une infrastructure peut créer une dépendance sans devenir une annexion ; un financement ne suffit pas à prouver une intention unique ni un résultat identique dans tous les pays.

Ces exemples montrent que l’action indirecte est souvent relationnelle. Elle suppose des partenaires, des publics et des institutions qui peuvent accepter, détourner ou contester l’influence. Les langues produisent des appropriations multiples ; les normes numériques suscitent des régulations ; les infrastructures font l’objet de négociations. La capacité de fixer les conditions d’une relation peut donc être puissante sans être absolue.

Les formes indirectes permettent ainsi d’agir en rendant certains choix plus attractifs, plus accessibles ou plus coûteux à remplacer. Elles complètent d’autres instruments de puissance, mais ne les reproduisent pas simplement sous une apparence pacifique. Pour les analyser, il faut toujours distinguer la ressource détenue, le mécanisme d’influence et l’effet effectivement obtenu.

## Évaluer et reprendre

**Erreurs à corriger.** Confondre sanction et attraction ; attribuer toute action d’une entreprise à son État ; présenter tous les projets chinois comme identiques ; citer des classements non datés.

**Autre démarche recevable.** Organiser la composition autour d’attirer, connecter et fixer les règles, en intégrant une limite dans chaque partie.

**Barème pédagogique proposé, non ministériel.** Compréhension et problématique : 4 points ; connaissances exactes et situées : 6 ; raisonnement et organisation : 6 ; expression et achèvement : 4. Ne pas sanctionner deux fois la même faiblesse. Une organisation différente peut obtenir tous les points si elle répond au sujet.

**Après correction.** Relever deux écarts entre votre copie et les critères, non entre votre copie et les formulations de ce modèle. Réécrire un paragraphe sans consulter le texte. À J+7, traiter une question voisine pendant 30 minutes.

# N1-3 — Composition de Première

**Durée : 2 heures. Note : sur 20.** Épreuve blanche originale ; aucun document ni accès au cours pendant la simulation. Rédigez une introduction, un développement organisé et une conclusion.

## Sujet

**Pourquoi l’ouverture des frontières européennes ne signifie-t-elle pas leur disparition ?**

Périmètre de préparation : P03, objet conclusif — Les frontières internes et externes de l’Union européenne. Ce sujet porte sur cette seule partie du programme de Première.

# Correction N1-3 — Pourquoi l’ouverture des frontières européennes ne signifie-t-elle pas leur disparition ?

## Analyser et problématiser

Le sujet porte sur l’Union et ses frontières, en distinguant espace Schengen et UE. Il faut examiner ouverture interne, coopération et contrôle externe, puis les différenciations. « Disparition » serait l’abolition de la limite politique et de ses fonctions, ce que la facilitation des circulations ne démontre pas.

## Une organisation recevable

I. Des dispositifs facilitent les circulations et organisent des interfaces. II. Les limites territoriales et certaines fonctions de contrôle subsistent. III. Les frontières externes et les régimes différenciés montrent une reconfiguration plutôt qu’un effacement.

## Proposition rédigée

Traverser certaines frontières européennes sans contrôle systématique peut donner l’impression que la limite a disparu. Pourtant, le passage continue de relier des territoires régis par des institutions et des droits distincts. L’intégration européenne a transformé les fonctions des frontières davantage qu’elle ne les a abolies. Pourquoi ouverture et disparition ne sont-elles pas équivalentes ? Les facilités de circulation reposent sur des règles communes qui maintiennent des limites politiques, tandis que les frontières externes et les régimes différenciés rendent leur rôle toujours visible.

L’ouverture interne est d’abord une construction juridique et matérielle. L’espace Schengen permet, entre ses membres, la suppression habituelle des contrôles aux frontières intérieures pour les personnes. L’Union organise également des libertés de circulation et un marché intérieur selon ses propres règles. Ces dispositifs ne se confondent pas : tous les États de l’Union ne sont pas dans la même situation au regard de Schengen, et des États non membres de l’Union y participent. Il faut donc préciser de quelle circulation et de quel périmètre on parle.

Dans les régions frontalières, cette ouverture peut soutenir de véritables interfaces. Des travailleurs résident d’un côté et travaillent de l’autre ; des collectivités coopèrent pour les transports et des services. L’espace du Rhin supérieur, notamment autour de Strasbourg et de Kehl, permet d’observer une frontière qui devient un lieu d’articulation plutôt qu’un simple obstacle. La continuité des mobilités n’efface cependant pas les écarts de réglementation, de fiscalité ou de salaire. Ces différences peuvent même motiver certains déplacements.

Les frontières internes restent donc des limites de compétence. Le franchissement peut être facile sans que les administrations nationales, les systèmes scolaires ou les droits applicables deviennent identiques. Des contrôles temporaires peuvent être réintroduits dans un cadre juridique déterminé. Leur existence montre que la fonction de filtrage peut être réactivée ; elle n’autorise pas à décrire toute l’ouverture comme une fiction. Il faut raisonner sur les fonctions variables de la frontière selon les périodes, les personnes et les flux.

L’ouverture interne s’accompagne par ailleurs d’une organisation des frontières externes. Le contrôle des entrées, les visas, l’asile et la coopération entre autorités posent des questions de souveraineté et de droits. Les États et les institutions européennes cherchent à articuler des responsabilités qui ne sont pas toujours perçues de la même manière. Les espaces méditerranéens révèlent des tensions entre contrôle, circulation, protection des personnes et relations avec les pays voisins. Une frontière n’est pas vécue de façon identique par un touriste muni de documents, un travailleur transfrontalier et une personne demandant protection.

Enfin, les périmètres européens évoluent. Le Brexit rappelle qu’un processus d’intégration peut être reconfiguré par une décision politique, avec des conséquences sur les règles et les contrôles. À l’inverse, l’élargissement d’un dispositif d’ouverture ne signifie pas l’abolition des États concernés. La carte doit donc être datée ; au lieu de mémoriser une Europe uniforme, le candidat doit distinguer les cercles institutionnels et leurs effets.

L’ouverture européenne ne supprime ainsi ni les territoires ni toutes les fonctions frontalières. Elle redistribue les contrôles, organise des coopérations et crée des interfaces, avec des effets différenciés selon les flux. Parler de reconfiguration permet de rendre compte de cette réalité : la frontière peut rester politiquement décisive tout en étant moins visible dans certaines pratiques quotidiennes.

## Évaluer et reprendre

**Erreurs à corriger.** Assimiler UE et Schengen ; dire que toute frontière interne est supprimée ; oublier les droits et les situations des personnes ; décrire une carte sans date.

**Autre démarche recevable.** Comparer trois fonctions — limite de compétence, interface, filtre — en montrant pour chacune les effets de l’intégration.

**Barème pédagogique proposé, non ministériel.** Compréhension et problématique : 4 points ; connaissances exactes et situées : 6 ; raisonnement et organisation : 6 ; expression et achèvement : 4. Ne pas sanctionner deux fois la même faiblesse. Une organisation différente peut obtenir tous les points si elle répond au sujet.

**Après correction.** Relever deux écarts entre votre copie et les critères, non entre votre copie et les formulations de ce modèle. Réécrire un paragraphe sans consulter le texte. À J+7, traiter une question voisine pendant 30 minutes.

# N1-4 — Composition de Première

**Durée : 2 heures. Note : sur 20.** Épreuve blanche originale ; aucun document ni accès au cours pendant la simulation. Rédigez une introduction, un développement organisé et une conclusion.

## Sujet

**Pourquoi la liberté de l’information dépend-elle de rapports de force politiques et sociaux ?**

Périmètre de préparation : P04, axe 2 — Liberté ou contrôle de l’information. Ce sujet porte sur cette seule partie du programme de Première.

# Correction N1-4 — Pourquoi la liberté de l’information dépend-elle de rapports de force politiques et sociaux ?

## Analyser et problématiser

Il faut dépasser la seule existence d’un média. Le sujet appelle garanties juridiques, acteurs de l’information, pouvoirs et opinion, à travers Dreyfus, les agences et la guerre du Vietnam. Une composition sur Internet seulement sortirait du périmètre choisi.

## Une organisation recevable

I. Les règles et les institutions peuvent garantir ou restreindre l’expression. II. Journalistes, agences et publics agissent dans des rapports de dépendance et de concurrence. III. Les conflits et controverses rendent visibles des limites mais aussi des capacités de contestation.

## Proposition rédigée

Une information publiée n’est pas nécessairement indépendante, et une garantie juridique ne met pas toujours son producteur à l’abri des pressions. La liberté de l’information désigne la possibilité de rechercher, de produire et de diffuser des faits et des analyses dans un cadre protégeant cette activité. Pourquoi dépend-elle de rapports de force ? Les règles résultent de choix politiques, tandis que les conditions de production et les conflits déterminent la capacité réelle des acteurs à informer.

La liberté possède d’abord une dimension institutionnelle. En France, la loi du 29 juillet 1881 constitue un repère majeur de la liberté de la presse, tout en organisant des responsabilités et des limites. Elle n’abolit pas toutes les pressions ni toutes les infractions. Le droit définit des possibilités, mais l’accès aux moyens de publication, aux sources et aux protections professionnelles conditionne leur exercice. Une censure officielle peut empêcher la diffusion ; des contraintes économiques ou une menace contre un journaliste peuvent également réduire l’indépendance sans prendre la forme d’une interdiction générale.

L’affaire Dreyfus révèle la place de la presse dans une lutte politique et sociale. Des journaux défendent des interprétations opposées, mobilisent des publics et contribuent à structurer l’opinion. L’intervention de Zola avec J’accuse…! en 1898 donne une visibilité considérable à une contestation de la version officielle. Mais la presse véhicule aussi des préjugés, des accusations et des campagnes antisémites. La pluralité des titres permet une confrontation ; elle ne garantit pas que chaque publication recherche la vérité avec la même rigueur. Liberté et qualité de l’information sont donc liées sans être identiques.

Les agences de presse montrent un autre enjeu : l’organisation matérielle de la production. En collectant et diffusant des informations à de nombreux clients, elles rendent possible une couverture étendue. Elles peuvent fournir des procédures de vérification et une ressource commune aux rédactions. Cependant, la reprise d’une même dépêche par plusieurs médias ne constitue pas plusieurs enquêtes indépendantes. Le statut, les financements et les relations avec les pouvoirs doivent être examinés pour comprendre les conditions de l’autonomie. L’histoire de l’AFP permet de poser ces questions sans attribuer à toute agence une dépendance identique.

La guerre du Vietnam met enfin à l’épreuve les relations entre autorités, journalistes et opinion. Les images, reportages et enquêtes peuvent contredire un récit officiel ou rendre visibles des conséquences de la guerre. La publication des Pentagon Papers en 1971 montre l’importance de documents révélant des écarts entre certaines présentations publiques et les processus de décision. Il serait pourtant excessif d’affirmer que les médias auraient, seuls, déterminé l’issue de la guerre. Les mobilisations sociales, les choix politiques, les opérations militaires et les informations circulent dans une relation complexe.

La liberté de l’information se construit ainsi dans la confrontation entre acteurs disposant de ressources inégales. Les pouvoirs cherchent parfois à contrôler, les journalistes à enquêter, les entreprises à préserver leur activité et les publics à interpréter. Aucun de ces groupes n’est parfaitement homogène. Comprendre ces rapports permet d’éviter une opposition simpliste entre un pouvoir toujours manipulateur et des médias toujours indépendants.

La liberté dépend donc à la fois de garanties juridiques et de conditions concrètes de production, de protection et de réception. Les cas étudiés montrent qu’elle peut être défendue et élargie, mais aussi fragilisée. Elle ne constitue pas un état acquis une fois pour toutes : son effectivité doit être examinée à travers les institutions, les pratiques et les conflits.

## Évaluer et reprendre

**Erreurs à corriger.** Assimiler pluralité et vérité ; attribuer seul aux médias la fin de la guerre ; confondre agence et journal ; remplacer les exemples par une opinion générale sur la manipulation.

**Autre démarche recevable.** Construire une comparaison thématique entre garantie juridique, autonomie économique et contestation du récit officiel.

**Barème pédagogique proposé, non ministériel.** Compréhension et problématique : 4 points ; connaissances exactes et situées : 6 ; raisonnement et organisation : 6 ; expression et achèvement : 4. Ne pas sanctionner deux fois la même faiblesse. Une organisation différente peut obtenir tous les points si elle répond au sujet.

**Après correction.** Relever deux écarts entre votre copie et les critères, non entre votre copie et les formulations de ce modèle. Réécrire un paragraphe sans consulter le texte. À J+7, traiter une question voisine pendant 30 minutes.

# N1-5 — Composition de Première

**Durée : 2 heures. Note : sur 20.** Épreuve blanche originale ; aucun document ni accès au cours pendant la simulation. Rédigez une introduction, un développement organisé et une conclusion.

## Sujet

**Comment l’État indien peut-il organiser le pluralisme religieux dans une société traversée par des tensions ?**

Périmètre de préparation : P05, objet conclusif — État et religions en Inde. Ce sujet porte sur cette seule partie du programme de Première.

# Correction N1-5 — Comment l’État indien peut-il organiser le pluralisme religieux dans une société traversée par des tensions ?

## Analyser et problématiser

La question demande d’articuler cadre constitutionnel, diversité sociale et mobilisations politiques. Elle n’invite ni à juger les religions ni à décrire une majorité comme un bloc. Les relations avec le Pakistan peuvent éclairer les tensions, sans absorber toute la composition.

## Une organisation recevable

I. Un cadre constitutionnel cherche à protéger la diversité. II. La pluralité réelle et les rapports majoritaires/minoritaires rendent son application conflictuelle. III. Les mobilisations politiques et les tensions régionales imposent de distinguer principes et pratiques.

## Proposition rédigée

L’Inde réunit une grande diversité de traditions, de pratiques et d’appartenances religieuses. Son État doit organiser des droits communs sans supposer que la société serait homogène. Le cadre constitutionnel entré en vigueur en 1950 constitue une réponse à cette pluralité, mais son application reste traversée par des tensions. Comment articuler protection des libertés, représentation politique et coexistence ? Le projet de pluralisme repose sur des garanties institutionnelles dont les effets dépendent des rapports entre groupes, des mobilisations et du contexte régional.

La Constitution organise d’abord des libertés et une égalité de principe. La liberté de conscience et la pratique religieuse s’inscrivent dans un cadre de droits qui n’attribue pas la citoyenneté à une seule appartenance. Le terme secular est ajouté au préambule en 1976, mais les garanties de liberté et le projet pluraliste ne naissent pas entièrement à cette date. La laïcité indienne ne doit pas être confondue automatiquement avec un modèle français : l’État peut intervenir dans certains domaines liés aux religions et chercher à réguler des situations différentes.

Cette organisation répond à une diversité qui dépasse une simple opposition entre deux communautés. La majorité hindoue n’est pas un groupe politique ou social uniforme ; les musulmans, chrétiens, sikhs et autres minorités connaissent eux-mêmes des situations variées. Les appartenances se croisent avec les langues, les régions, les classes et d’autres hiérarchies sociales. Une politique publique ne peut donc être analysée en supposant que chaque religion produit une volonté unique. Le pluralisme demande des garanties pour les individus et les groupes, notamment lorsqu’une majorité dispose d’une force électorale importante.

Les tensions apparaissent lorsque des mobilisations présentent l’identité nationale comme indissociable d’une appartenance religieuse majoritaire. Elles peuvent contester l’interprétation du cadre constitutionnel, transformer des lieux en symboles et peser sur le statut des minorités. L’enjeu politique ne se réduit pas à une religiosité plus ou moins forte : il concerne la définition de la nation, l’égalité des droits et l’usage public du passé. Il faut identifier les acteurs et leurs décisions, plutôt qu’attribuer automatiquement une politique à tous les croyants.

L’histoire de la partition de 1947 et les relations avec le Pakistan contribuent également aux tensions. Les déplacements de populations, les violences et le différend autour du Cachemire participent à des mémoires et à des enjeux de sécurité. Mais la politique intérieure indienne ne peut être expliquée entièrement par un conflit extérieur. Inversement, les relations entre les deux États ne sont pas seulement religieuses : elles comportent des dimensions territoriales, stratégiques et diplomatiques. Une analyse HGGSP croise ces approches sans effacer leur distinction.

Organiser le pluralisme suppose donc plus que proclamer une neutralité abstraite. Les institutions doivent protéger les droits, traiter des situations concrètes et permettre la contestation des décisions. Les tribunaux, les élections, les associations et les débats publics constituent des lieux d’arbitrage ; ils ne rendent pas les tensions inexistantes. L’écart entre principe constitutionnel et pratique doit être étudié à partir de faits datés, non d’un jugement définitif sur une société entière.

L’État indien peut ainsi organiser la pluralité par des garanties et des dispositifs qui reconnaissent la diversité, mais leur effectivité dépend des rapports de force. Le cas indien montre que le pluralisme est une construction politique continue. La question essentielle n’est pas de mesurer une supposée homogénéité religieuse, mais d’examiner comment sont protégés les droits lorsque les appartenances deviennent des ressources de mobilisation.

## Évaluer et reprendre

**Erreurs à corriger.** Présenter secular comme une absence de religion ; faire naître toutes les libertés en 1976 ; confondre hindouisme et programme politique unique ; réduire le Cachemire à une seule cause.

**Autre démarche recevable.** Partir de la tension entre citoyenneté commune et appartenances, puis montrer les arbitrages institutionnels et régionaux.

**Barème pédagogique proposé, non ministériel.** Compréhension et problématique : 4 points ; connaissances exactes et situées : 6 ; raisonnement et organisation : 6 ; expression et achèvement : 4. Ne pas sanctionner deux fois la même faiblesse. Une organisation différente peut obtenir tous les points si elle répond au sujet.

**Après correction.** Relever deux écarts entre votre copie et les critères, non entre votre copie et les formulations de ce modèle. Réécrire un paragraphe sans consulter le texte. À J+7, traiter une question voisine pendant 30 minutes.

# N2-1 — Écrit terminal HGGSP

**Durée : 4 heures. Note : sur 20.** Épreuve blanche originale, session de préparation 2027. Aucun accès au cours ni aux corrigés pendant la simulation.

## Première partie — Dissertation, sur 10

Choisissez **un seul** des deux sujets.

**Sujet 1 — La guerre demeure-t-elle un instrument politique malgré la transformation des conflits ?**

**Sujet 2 — Pourquoi le patrimoine peut-il devenir un objet de conflit ?**

Rédigez une introduction, un développement organisé et une conclusion. Une illustration pertinente est possible mais non obligatoire.

## Seconde partie — Étude critique, sur 10

**La coopération environnementale : construire un cadre, obtenir des résultats**

En confrontant les documents et en mobilisant vos connaissances, montrez comment se construit une coopération environnementale et pourquoi l’existence d’un cadre ne suffit pas à démontrer son efficacité.

### Document 1 — Une architecture de coopération climatique

**Adaptation pédagogique**, rédigée pour ce manuel, des articles 2, 4 et 13 de l’accord de Paris adopté le 12 décembre 2015. Ce texte reformule des dispositions ; ce n’est pas une citation littérale. Source institutionnelle : CCNUCC ([D10](#ref-D10) ; [B58a](#ref-B58a)).

L’accord poursuit notamment un objectif collectif de limitation de l’élévation de la température mondiale nettement sous 2 °C et de poursuite des efforts vers 1,5 °C, par rapport aux niveaux préindustriels. Chaque partie prépare, communique et actualise une contribution déterminée au niveau national. Les contributions successives doivent progresser et traduire une ambition tenant compte des responsabilités et des capacités différentes. Un cadre de transparence organise la communication d’informations sur les actions et leurs résultats. Ces mécanismes articulent une direction collective et des décisions nationales ; ils ne constituent pas une administration mondiale unique de l’énergie.

### Document 2 — Des étapes et des instruments distincts

**Tableau chronologique éditorial**, construit pour ce sujet à partir des ressources institutionnelles de l’ONU et de la CCNUCC. Il sélectionne quatre étapes ; il ne mesure pas les résultats environnementaux. ([B58](#ref-B58) ; [D10](#ref-D10))

| Repère | Instrument ou événement | Niveau principal et opération |
|---|---|---|
| 1972 | Conférence de Stockholm | Mise à l’agenda international de questions environnementales. |
| 1992 | Sommet de Rio et Convention-cadre sur le climat | Cadre multilatéral de coopération, avec des responsabilités différenciées. |
| 1997 | Protocole de Kyoto | Engagements de réduction pour des pays industrialisés selon le dispositif du protocole. |
| 2015 | Accord de Paris | Objectif collectif, contributions nationales et révision. |

**Note.** Les dates sont celles des événements ou de l’adoption, non nécessairement de l’entrée en vigueur des instruments.

**Fin du sujet N2-1.** Les références servent à identifier les documents ; aucune consultation extérieure n’est nécessaire pendant l’épreuve. Les adaptations sont signalées et ne sont jamais présentées comme des citations littérales.

# Correction N2-1

Les deux dissertations sont corrigées ci-dessous pour permettre de travailler ensuite l’option non choisie. Une copie d’examen ne traite qu’une dissertation et l’étude critique. Les propositions n’imposent ni un nombre universel de parties ni des formulations à reproduire.

## Dissertation 1 — La guerre demeure-t-elle un instrument politique malgré la transformation des conflits ?

**Comprendre le sujet.** Il faut discuter la portée du modèle politique de la guerre, non réciter toutes les catégories de conflits. « Demeure » appelle une comparaison dans le temps ; « malgré » invite à examiner ce que les transformations changent réellement. Un plan recevable distingue persistance des finalités politiques, diversification des acteurs et limites d’une transposition mécanique du modèle.

**Proposition rédigée.** La guerre de Sept Ans et les violences d’organisations transnationales ne mobilisent ni les mêmes acteurs ni les mêmes moyens. Elles posent pourtant toutes deux la question des objectifs poursuivis par l’usage de la violence. La guerre peut être définie comme un affrontement armé organisé ; son lien au politique renvoie aux rapports de pouvoir et aux buts que cherchent à atteindre les belligérants. La transformation des conflits rend-elle ce lien caduc ? Elle oblige surtout à l’analyser de manière plus différenciée, sans présumer que les formes nouvelles seraient dépourvues de rationalité politique.

La pensée de Clausewitz fournit une première clé. La guerre n’est pas isolée des objectifs politiques ; l’emploi des moyens militaires doit être replacé dans une confrontation de volontés. La guerre de Sept Ans illustre des rivalités entre puissances pour des territoires, des positions et des équilibres. Les objectifs et les alliances contribuent à déterminer l’extension du conflit. Il ne suffit donc pas d’énumérer des batailles : il faut montrer ce que les acteurs cherchent à obtenir et pourquoi ils choisissent ou subissent l’affrontement.

Les guerres révolutionnaires et napoléoniennes transforment les mobilisations et l’ampleur des moyens engagés. L’implication des populations, les changements de régime et la recherche d’une décision militaire peuvent rapprocher certaines pratiques d’une montée aux extrêmes. Cela ne supprime pas les finalités politiques ; cela modifie l’articulation entre sociétés, armées et pouvoirs. Il faut néanmoins distinguer le concept de guerre absolue et les guerres réelles, soumises à des contraintes et à des circonstances. Un modèle aide à poser des questions ; il ne décrit pas identiquement chaque conflit.

Les acteurs non étatiques conduisent à élargir l’analyse. Al-Qaïda et Daech utilisent la violence et la terreur pour poursuivre des projets de pouvoir, mobiliser des soutiens et atteindre des adversaires. Leur organisation et leur rapport au territoire diffèrent. Qualifier certaines pratiques de terroristes n’autorise pas à conclure à l’absence de but politique ; il faut examiner ce qu’elles cherchent à imposer. Inversement, identifier un objectif ne justifie pas moralement les moyens employés ni ne rend tous les comportements parfaitement calculés.

Les conflits contemporains associent aussi des dynamiques économiques, sociales, identitaires et internationales. Des combattants peuvent poursuivre des objectifs distincts au sein d’une même coalition ; les moyens utilisés peuvent produire des conséquences contraires au but annoncé. La guerre en Irak de 2003 rappelle que la capacité de vaincre militairement ne garantit pas la maîtrise de l’ordre politique qui suit. La relation entre guerre et politique existe, mais elle ne doit pas être transformée en promesse de contrôle rationnel et complet.

Enfin, les frontières entre guerre, compétition et violence organisée peuvent faire l’objet de débats. Il convient de qualifier les situations à partir d’acteurs, d’intensités et de pratiques, plutôt que d’appeler guerre toute rivalité. Les nouveaux domaines d’action ou les formes irrégulières ne rendent pas inutile l’étude des finalités ; ils exigent de distinguer la coercition, la démonstration, la mobilisation et la conquête.

La guerre demeure donc liée au politique, mais ses formes variables interdisent une application automatique d’un modèle unique. L’enjeu est de comprendre comment des acteurs convertissent des objectifs en violence organisée, et pourquoi les effets peuvent leur échapper. Cette lecture maintient la force de l’approche clausewitzienne tout en reconnaissant les limites de sa transposition à des configurations différentes.

**Autre démarche recevable.** Organiser le devoir autour des buts, des acteurs et de l’écart entre moyens et résultats. **Vigilance :** ne pas opposer des guerres anciennes supposées rationnelles à des guerres actuelles supposées dépourvues de politique.

## Dissertation 2 — Pourquoi le patrimoine peut-il devenir un objet de conflit ?

**Comprendre le sujet.** Un patrimoine est sélectionné et transmis par des acteurs ; il ne constitue pas seulement un stock de monuments. Le conflit peut porter sur la propriété, le récit, les usages ou la destruction. Il faut expliquer pourquoi la valeur accordée à l’héritage produit des intérêts parfois incompatibles.

**Proposition rédigée.** Les sculptures du Parthénon peuvent être présentées comme les éléments dispersés d’un monument ou comme les pièces d’un musée à vocation universelle. Cette différence de cadrage montre qu’un même héritage n’a pas le même sens pour tous. Le patrimoine désigne des biens et des pratiques reconnus comme dignes de transmission. Pourquoi devient-il un objet de conflit ? Parce que sa sélection et sa protection engagent des identités, des droits et des usages dont les acteurs ne partagent pas toujours les priorités.

Les conflits portent d’abord sur l’appropriation et le pouvoir de raconter. La controverse sur les sculptures du Parthénon confronte la demande grecque de réunification et les arguments du British Museum sur son acquisition et la comparaison des civilisations. L’analyse doit attribuer ces positions, examiner leur contexte et distinguer revendication juridique et argument éthique. Le déplacement d’objets pendant une période de domination peut nourrir une contestation durable, même lorsque leur conservation matérielle n’est pas seule en jeu.

Les usages politiques d’un lieu peuvent également superposer des mémoires antagonistes. Versailles est investi par la monarchie, réorganisé comme musée national sous Louis-Philippe, puis utilisé pour la proclamation de l’Empire allemand en 1871 et la signature du traité de 1919. La continuité du bâtiment ne produit donc pas un récit unique. Elle peut offrir aux pouvoirs un support de légitimation ou une scène symbolique dont le sens change selon la cérémonie. Le conflit est ici autant interprétatif que matériel.

Dans d’autres situations, la destruction d’un héritage devient un moyen d’atteindre une société. À Tombouctou, les attaques contre des mausolées en 2012 visent des lieux investis de pratiques et de significations religieuses. Elles contribuent à imposer un ordre et à rompre des transmissions. La condamnation d’Al Mahdi par la CPI en 2016 montre qu’une telle attaque peut relever d’une responsabilité pénale internationale. La reconstruction mobilise d’autres acteurs et fonctions : habitants, artisans et partenaires patrimoniaux. Juger et restaurer ne sont pas deux noms de la même opération.

Les tensions existent aussi sans guerre. À Paris ou à Venise, conserver un paysage urbain doit être articulé au logement, aux transports, à l’activité économique et aux besoins des habitants. Une valorisation touristique peut financer des travaux et rendre un site visible, mais elle peut également intensifier des pressions sur les usages résidentiels. Les acteurs n’évaluent pas tous la réussite selon le même indicateur. Une hausse de visiteurs ne démontre donc pas, à elle seule, la qualité d’une politique patrimoniale.

Enfin, la patrimonialisation sélectionne ce qui mérite d’être transmis. La reconnaissance du bassin minier révèle un changement de regard sur des héritages du travail longtemps associés à la crise industrielle. Des habitants, associations et institutions peuvent se mobiliser pour faire reconnaître leur valeur. Le patrimoine immatériel, comme le repas gastronomique, pose encore d’autres questions : qui représente une pratique, comment la transmettre sans l’immobiliser et comment éviter sa réduction à un produit commercial ?

Le patrimoine devient ainsi conflictuel parce qu’il concentre des valeurs et des droits que ses acteurs interprètent différemment. Ces tensions ne rendent pas toute protection impossible ; elles imposent de documenter les choix, de négocier les usages et d’identifier les groupes concernés. La coopération ne supprime pas nécessairement les désaccords, mais elle peut organiser leur traitement sans réduire le patrimoine à une propriété matérielle ou à une attraction touristique.

**Autre démarche recevable.** Classer les conflits par échelle — locale, nationale, internationale — en évitant de répéter les mêmes arguments. **Vigilance :** ne pas faire de l’UNESCO le propriétaire des sites et ne pas transformer toute tension en conflit armé.

## Étude critique — La coopération environnementale : construire un cadre, obtenir des résultats

**Présentation et problématique.** Le premier document est une adaptation d’un texte conventionnel adopté en 2015 ; il expose une architecture normative. Le second est un tableau éditorial sélectionnant des étapes historiques. Ce ne sont ni une déclaration originale reproduite mot à mot ni une série mesurant les émissions. Comment ces documents éclairent-ils la construction d’une coopération et les limites de ce qu’ils permettent de conclure sur son efficacité ?

Le tableau montre d’abord une mise à l’agenda progressive. Stockholm en 1972 traite d’environnement à l’échelle internationale ; Rio et la Convention-cadre de 1992 établissent un cadre dans lequel les responsabilités sont différenciées. La distinction est importante : tous les problèmes environnementaux ne se réduisent pas au climat, et tous les États n’ont pas les mêmes responsabilités historiques ni les mêmes capacités. Les dates d’adoption doivent être distinguées de celles de l’entrée en vigueur, comme le rappelle la note du document.

L’accord de Paris, présenté dans les deux documents, articule ensuite une direction commune et des actions nationales. Le premier document indique un objectif de température, puis la préparation et l’actualisation de contributions. Cette articulation répond à une difficulté : le problème est mondial, mais les décisions énergétiques, économiques et sociales relèvent de nombreux acteurs. La coopération ne supprime pas les souverainetés ; elle organise des engagements et leur discussion. La progression annoncée et le cadre de transparence cherchent à éviter que le texte demeure une simple déclaration sans suivi.

La confrontation avec Kyoto souligne une évolution des instruments. Le tableau indique des engagements portant sur des pays industrialisés dans le dispositif du protocole, tandis que Paris repose sur une architecture de contributions nationales plus largement partagée. Il ne faut pas déduire de ce changement une supériorité automatiquement prouvée : les documents décrivent des formes institutionnelles. Ils permettent de comprendre une recherche de participation et de flexibilité, mais ne donnent pas à eux seuls un bilan comparé des résultats.

Leurs limites découlent précisément de leur nature. Le document 1 prescrit et organise ; il ne prouve pas que les contributions suffisent ni qu’elles sont toutes réalisées. Le document 2 sélectionne des jalons et peut donner visuellement une impression de progrès continu, alors que les négociations comportent des conflits et que l’application dépend de financements, de politiques et de rapports de force. Aucun des deux ne fournit une courbe d’émissions, une mesure des investissements ni une évaluation des effets sociaux.

Les connaissances du cours permettent de compléter cette analyse. Les coûts de transition, les dépendances aux ressources et les inégalités de développement rendent les engagements difficiles à répartir. L’alternance politique américaine montre aussi que la participation à un cadre peut varier dans le temps. Cela ne démontre pas l’inutilité de la coopération : ses objectifs, ses procédures et ses informations communes peuvent orienter des décisions. Mais l’efficacité doit être étudiée à partir d’indicateurs et de séries datés, en distinguant annonce, mise en œuvre et effet.

Les documents mettent donc en évidence une construction institutionnelle réelle, sans autoriser à conclure que le problème serait résolu. Leur apport est d’expliquer comment s’articulent objectifs collectifs et engagements différenciés. Leur limite appelle une enquête sur les résultats, non une condamnation abstraite de tous les accords. Une étude critique réussie tient ensemble ces deux dimensions.

## Barème et reprise

**Répartition officielle :** dissertation sur 10 et étude critique sur 10. **Décomposition pédagogique proposée :** dissertation — compréhension et problématique 2, connaissances 3, démonstration 3, expression et achèvement 2 ; étude — présentation et problématique 2, exploitation et confrontation 3, contextualisation et recul critique 3, organisation et expression 2. Cette décomposition n’est pas une grille ministérielle imposée.

**Points d’attention propres à ce sujet.** Dans l’étude, exploiter les deux documents et distinguer la norme du résultat. Dans les dissertations, éviter l’énumération des jalons sans réponse au problème ; les exemples n’ont pas tous besoin de la même longueur.

**Reprise espacée.** À J+2, réécrire le passage le plus faible sans modèle. À J+7, élaborer en 30 minutes le plan de l’autre dissertation ; à J+21, reprendre l’étude en expliquant oralement deux apports et deux limites des documents.

# N2-2 — Écrit terminal HGGSP

**Durée : 4 heures. Note : sur 20.** Épreuve blanche originale, session de préparation 2027. Aucun accès au cours ni aux corrigés pendant la simulation.

## Première partie — Dissertation, sur 10

Choisissez **un seul** des deux sujets.

**Sujet 1 — Les sociétés peuvent-elles protéger l’environnement tout en l’exploitant ?**

**Sujet 2 — Pourquoi la production et la diffusion des connaissances sont-elles des enjeux de puissance ?**

Rédigez une introduction, un développement organisé et une conclusion. Une illustration pertinente est possible mais non obligatoire.

## Seconde partie — Étude critique, sur 10

**Sécurité collective et usage de la force : des règles à leur application**

En confrontant les documents, analysez les principes de la sécurité collective et les difficultés de leur application. Vous distinguerez cadre juridique, décision politique et effets des interventions.

### Document 1 — Les principes de la Charte des Nations unies

**Adaptation pédagogique**, non verbatim, des articles 2, 24, 39, 42 et 51 de la Charte signée le 26 juin 1945. Source : Nations unies ([D09](#ref-D09)). La sélection simplifie le dispositif pour l’exercice ; elle ne remplace pas le texte intégral.

Les membres s’engagent à régler pacifiquement leurs différends et à s’abstenir de la menace ou de l’emploi de la force contre l’intégrité territoriale ou l’indépendance politique d’un État. Le Conseil de sécurité reçoit la responsabilité principale du maintien de la paix et de la sécurité internationales. Il peut constater une menace contre la paix, une rupture de la paix ou un acte d’agression, et décider des mesures appropriées, y compris, dans les conditions prévues, une action armée. La Charte reconnaît également un droit de légitime défense en cas d’agression armée, dans le cadre défini par son article 51.

### Document 2 — Deux situations irakiennes à distinguer

**Tableau de synthèse historique éditorial**, réalisé à partir des résolutions du Conseil de sécurité et de son répertoire des pratiques. Sources : ([B39](#ref-B39) ; [B39a](#ref-B39a)). Il ne prétend pas résumer toutes les dimensions des conflits.

| Situation | Décision et cadre international | Question posée après l’action militaire |
|---|---|---|
| 1990–1991 | Après l’invasion du Koweït, des résolutions condamnent l’Irak ; la résolution 678 autorise les États coopérant avec le Koweït à employer les moyens nécessaires dans les conditions fixées. | Comment articuler libération du Koweït, cessez-le-feu, contrôles et ordre régional ? |
| 2003 | L’invasion menée par les États-Unis et leurs alliés intervient sans nouvelle résolution autorisant explicitement cette invasion ; la portée d’autorisations antérieures est contestée. | Comment transformer la chute du régime en un ordre politique stable et accepté ? |

**Note.** La légalité invoquée par les intervenants et sa contestation doivent être attribuées ; une victoire militaire n’est pas un jugement juridique.

**Fin du sujet N2-2.** Les références servent à identifier les documents ; aucune consultation extérieure n’est nécessaire pendant l’épreuve. Les adaptations sont signalées et ne sont jamais présentées comme des citations littérales.

# Correction N2-2

Les deux dissertations sont corrigées ci-dessous pour permettre de travailler ensuite l’option non choisie. Une copie d’examen ne traite qu’une dissertation et l’étude critique. Les propositions n’imposent ni un nombre universel de parties ni des formulations à reproduire.

## Dissertation 1 — Les sociétés peuvent-elles protéger l’environnement tout en l’exploitant ?

**Comprendre le sujet.** L’exploitation est un usage des ressources ; elle ne signifie pas par définition destruction. La protection a des finalités historiques variables. Le sujet demande d’étudier conditions et contradictions, non d’opposer une nature sans humains à toute activité sociale.

**Proposition rédigée.** Une forêt peut être réglementée afin de garantir du bois à long terme ; un territoire peut être protégé tout en restant habité. L’exploitation et la protection de l’environnement ne sont donc pas toujours incompatibles. Mais leurs objectifs peuvent entrer en conflit lorsque les prélèvements ou les transformations compromettent les milieux et les ressources. Dans quelles conditions leur articulation est-elle possible ? Elle suppose des règles, des connaissances et des arbitrages, dont les limites varient selon les échelles et les intérêts.

L’histoire forestière française montre d’abord que la protection peut servir une finalité productive. L’ordonnance de 1669 sous Colbert vise à encadrer une ressource importante pour l’économie et la puissance. Il serait anachronique d’y voir exactement une politique contemporaine de biodiversité ou de climat. Limiter certaines pratiques peut néanmoins contribuer à assurer la continuité d’un usage. La protection n’est pas nécessairement un retrait de toute activité ; elle peut organiser son renouvellement et répartir des droits.

Les transformations des sociétés changent cependant l’ampleur des pressions. La néolithisation modifie des paysages et des relations aux ressources selon des temporalités régionales longues. L’industrialisation accroît les échelles de production, d’extraction et de circulation, avec un rôle déterminant des énergies fossiles. Reconnaître une action humaine ancienne ne permet pas de rendre tous ces processus identiques. Les moyens techniques et les volumes mobilisés créent des effets nouveaux, dont la protection doit tenir compte.

L’articulation entre usage et protection appelle donc une connaissance des milieux et de leurs limites. Une exploitation déclarée durable doit être évaluée selon ses effets, pas seulement selon l’intention de son gestionnaire. Les sols, les écosystèmes, les cycles de renouvellement et les conséquences pour les habitants constituent des dimensions différentes. Des mesures peuvent déplacer une pression plutôt que la réduire : protéger ici tout en important une ressource extraite ailleurs pose une question d’échelle. Une politique nationale ne peut donc être isolée des échanges.

Le cas américain illustre des conceptions et des intérêts concurrents. La préservation associée à certaines conceptions des parcs et la conservation orientée vers un usage régulé ne proposent pas exactement le même rapport aux milieux. Les territoires protégés ont aussi une histoire sociale, notamment au regard des populations autochtones ; ils ne doivent pas être décrits comme des espaces simplement vides. États, agences, entreprises et associations négocient ou contestent les règles, tandis que les niveaux fédéral et fédérés n’agissent pas toujours dans la même direction.

À l’échelle climatique, la difficulté devient plus forte encore. Les bénéfices d’une production peuvent être localisés alors que les effets de l’accumulation des gaz à effet de serre sont globaux. La coopération cherche à rendre compatibles des besoins de développement et une réduction des pressions. L’accord de Paris organise un objectif commun et des contributions différenciées ; son efficacité dépend des politiques, des financements et des trajectoires effectivement observées. L’existence d’un accord ne démontre pas que tous les usages soient déjà compatibles avec cet objectif.

Les sociétés peuvent donc protéger tout en exploitant, mais cette compatibilité n’est ni automatique ni illimitée. Elle dépend de la nature des usages, des rythmes de prélèvement, de la répartition des coûts et de la capacité à contrôler les effets. L’analyse doit éviter aussi bien l’idée que toute activité détruit nécessairement que celle selon laquelle une simple étiquette de protection suffirait à rendre tout usage acceptable.

**Autre démarche recevable.** Comparer finalités historiques, instruments de régulation et limites planétaires. **Vigilance :** distinguer environnement et climat, puis conservation annoncée et résultat mesuré.

## Dissertation 2 — Pourquoi la production et la diffusion des connaissances sont-elles des enjeux de puissance ?

**Comprendre le sujet.** La connaissance ne se réduit pas à des données ni à une marchandise. La puissance concerne ici capacité d’innover, de décider, de contrôler des réseaux et d’attirer des personnes. Production et diffusion doivent toutes deux être traitées, avec leurs tensions.

**Proposition rédigée.** Une découverte scientifique peut naître d’échanges internationaux tout en donnant à un État ou à une entreprise un avantage stratégique. Cette tension révèle que la connaissance n’est pas seulement un ensemble de savoirs abstraits : ses conditions de production et de circulation ont des effets politiques. Pourquoi constitue-t-elle un enjeu de puissance ? Parce qu’elle soutient des capacités d’action, tandis que son accès, ses infrastructures et ses protections répartissent inégalement ces capacités.

Produire des connaissances suppose d’abord des ressources collectives. L’histoire des recherches sur la radioactivité montre l’importance de chercheurs, d’instruments, de laboratoires et de communications scientifiques. Les découvertes ne sont pas réductibles à un génie isolé ; elles s’appuient sur des acquis, des méthodes et des institutions. La capacité à financer et organiser ces milieux peut soutenir l’innovation, la formation et le prestige. Elle devient une ressource de puissance lorsqu’elle permet de développer des techniques ou d’éclairer des décisions.

Les applications stratégiques rendent cette relation particulièrement visible. Les savoirs nucléaires peuvent être associés à des usages médicaux, énergétiques ou militaires. Les États cherchent alors à maîtriser des compétences et à protéger certaines informations. La distinction entre recherche fondamentale et application n’empêche pas les interactions ; elle évite de considérer que tout chercheur poursuivrait dès l’origine le même objectif politique. Le pouvoir ne possède pas seul la connaissance, mais peut chercher à orienter ses institutions et ses usages.

La diffusion est tout aussi décisive. L’alphabétisation et l’accès à l’enseignement élargissent les possibilités d’apprendre, de participer et de produire. Le retard imposé à certains groupes, notamment aux femmes selon les sociétés et les périodes, limite ces capacités. La circulation d’étudiants, de chercheurs et de publications permet des transferts et des coopérations. Les relations entre l’Inde et les États-Unis montrent qu’il faut dépasser l’image d’une fuite unilatérale des cerveaux : des mobilités peuvent former des réseaux, soutenir des collaborations ou favoriser des retours, sans abolir les asymétries.

Les infrastructures numériques modifient enfin les conditions de circulation. Un accès à un service ou à un centre de données dépend de réseaux, d’entreprises, de règles et de compétences techniques. Le cyberespace possède donc une matérialité et des acteurs ; il n’est pas un domaine sans territoire ni pouvoir. Contrôler un point d’accès, fixer un standard ou assurer une protection peut procurer un avantage. Les attaques et les dépendances révèlent la vulnérabilité d’une société qui utilise des connaissances sans maîtriser toutes les infrastructures nécessaires.

Cette dimension stratégique ne rend pas toute coopération contradictoire. La production de savoirs demande souvent la confrontation de résultats et le partage d’outils. Un secret intégral peut limiter la validation et l’innovation ; une ouverture sans précautions peut exposer des données sensibles. Les acteurs doivent donc arbitrer entre circulation, protection et confiance. L’attribution d’une cyberattaque rappelle en outre que posséder des traces n’équivaut pas à connaître avec certitude son responsable : la puissance d’analyse dépend d’une méthode et de sources fiables.

La connaissance est ainsi un enjeu de puissance par ses effets sur les techniques, les décisions et les réseaux. Sa production et sa diffusion peuvent élargir des capacités collectives tout en reproduisant des inégalités. Une analyse rigoureuse distingue les ressources disponibles, les dispositifs qui les organisent et les effets obtenus. Elle ne réduit ni la science à une rivalité permanente ni la coopération à une disparition des intérêts.

**Autre démarche recevable.** Organiser autour de produire, attirer et sécuriser, avec une limite pour chaque capacité. **Vigilance :** ne pas confondre savoir, information, donnée et renseignement.

## Étude critique — Sécurité collective et usage de la force : des règles à leur application

**Présentation.** Le document 1 adapte une sélection d’articles de la Charte de 1945. Il expose des principes et un mécanisme institutionnel, sans reproduire toutes les conditions juridiques. Le tableau éditorial rapproche deux situations irakiennes, en sélectionnant leur cadre international et la question de l’après-guerre. Comment la sécurité collective peut-elle encadrer la force alors que sa mise en œuvre dépend de décisions et de rapports de puissance ?

La Charte affirme d’abord une limitation de l’usage unilatéral de la force. Le règlement pacifique et le respect de l’intégrité territoriale visent à établir un ordre qui ne repose pas seulement sur la capacité militaire de chaque État. Le Conseil de sécurité reçoit une responsabilité principale et peut décider des mesures dans les situations prévues. Le droit de légitime défense demeure, mais dans un cadre : le document ne permet pas de qualifier librement toute intervention de défense légitime.

Le cas de 1990–1991 montre comment ce dispositif peut soutenir une réponse collective. L’invasion du Koweït par l’Irak constitue le contexte des résolutions ; le tableau cite la résolution 678 et son autorisation conditionnée. Les connaissances permettent de comprendre qu’une coalition d’États mène les opérations : il ne s’agit pas d’une armée mondiale permanente agissant indépendamment des membres. L’autorisation internationale et la capacité militaire sont deux composantes distinctes de l’action.

La situation de 2003 révèle une autre configuration. Le tableau précise l’absence de nouvelle résolution autorisant explicitement l’invasion et la contestation de la portée d’autorisations antérieures. Une étude rigoureuse doit attribuer les interprétations au lieu de présenter la version des intervenants comme un consensus. Le Conseil de sécurité peut être un lieu de débat et de blocage parce que les grandes puissances ne partagent pas toujours l’analyse et les objectifs. La force disponible ne vaut donc pas à elle seule légitimité internationale.

Les deux situations posent ensuite la question des résultats. Le document 2 distingue la libération d’un territoire, les dispositifs de contrôle et la construction d’un ordre stable. La chute d’un régime en 2003 ne résout pas automatiquement les conflits politiques et sociaux. Cette différence permet d’articuler faire la guerre et faire la paix : une opération militaire peut atteindre un objectif immédiat sans assurer la sécurité durable ni l’acceptation d’institutions nouvelles.

Les limites documentaires sont importantes. La Charte est normative : elle énonce un cadre, pas le récit de sa réalisation. L’adaptation omet des articles et des détails ; elle ne suffit pas pour trancher toutes les controverses juridiques. Le tableau est une synthèse construite qui rapproche deux dates au prix d’une forte sélection. Il ne donne ni le texte intégral des résolutions, ni les débats, ni les expériences des populations. La critique consiste à identifier ces limites utiles, non à déclarer les documents sans valeur.

La confrontation montre ainsi que la sécurité collective organise une possibilité d’action, dont l’effectivité dépend des États, de leurs accords et de leurs moyens. Elle ne garantit pas mécaniquement la paix ; son absence de toute-puissance ne démontre pas non plus son inutilité. Pour l’évaluer, il faut distinguer principe, autorisation, opération et ordre politique produit. C’est cette chaîne que les deux documents permettent de commencer à analyser.

## Barème et reprise

**Répartition officielle :** dissertation sur 10 et étude critique sur 10. **Décomposition pédagogique proposée :** dissertation — compréhension et problématique 2, connaissances 3, démonstration 3, expression et achèvement 2 ; étude — présentation et problématique 2, exploitation et confrontation 3, contextualisation et recul critique 3, organisation et expression 2. Cette décomposition n’est pas une grille ministérielle imposée.

**Points d’attention propres à ce sujet.** Ne pas confondre 1991 et 2003 ; ne pas faire du Conseil de sécurité un gouvernement indépendant des États ; ne pas déduire la légalité de la seule victoire. Une critique précise vaut mieux que la formule générale « ces documents sont subjectifs ».

**Reprise espacée.** À J+2, réécrire le passage le plus faible sans modèle. À J+7, élaborer en 30 minutes le plan de l’autre dissertation ; à J+21, reprendre l’étude en expliquant oralement deux apports et deux limites des documents.

# N2-3 — Écrit terminal HGGSP

**Durée : 4 heures. Note : sur 20.** Épreuve blanche originale, session de préparation 2027. Aucun accès au cours ni aux corrigés pendant la simulation.

## Première partie — Dissertation, sur 10

Choisissez **un seul** des deux sujets.

**Sujet 1 — Comment construire une paix durable après un conflit armé ?**

**Sujet 2 — Pourquoi les politiques environnementales des États-Unis sont-elles traversées par des tensions ?**

Rédigez une introduction, un développement organisé et une conclusion. Une illustration pertinente est possible mais non obligatoire.

## Seconde partie — Étude critique, sur 10

**Coopérer pour produire des connaissances : possibilités et asymétries**

En confrontant les documents et en mobilisant vos connaissances, analysez les apports de la circulation des chercheurs et de la coopération scientifique. Vous montrerez aussi ce que les documents ne permettent pas de conclure sur l’égalité entre partenaires.

### Document 1 — Faciliter des projets scientifiques entre les États-Unis et l’Inde

**Synthèse adaptée d’une communication institutionnelle**, non verbatim. National Science Foundation, annonce du 1er février 2023 relative à un arrangement de mise en œuvre entre la NSF et les organismes indiens partenaires ([B65a](#ref-B65a)). Texte reformulé pour l’exercice.

Le dispositif annoncé vise à faciliter la préparation, l’évaluation et le financement de propositions de recherche collaboratives entre chercheurs américains et indiens. Il cherche à réduire certains obstacles administratifs liés à des procédures séparées. L’annonce associe cette démarche à la circulation d’idées, de ressources et de pratiques, dans plusieurs domaines scientifiques, dont l’informatique, les géosciences et les sciences physiques. Cette annonce présente un instrument destiné à soutenir des collaborations. Elle ne fournit pas, à elle seule, un bilan complet des projets réalisés, de leurs résultats ou de la répartition des bénéfices.

### Document 2 — Trois configurations de circulation des compétences

**Tableau conceptuel éditorial**, construit pour ce sujet à partir du cours T06. Il décrit des mécanismes possibles, non des proportions statistiques sur les migrations. ([R-T06](#ref-R-T06) ; [B65](#ref-B65))

| Configuration | Possibilité ouverte | Question à vérifier dans un cas réel |
|---|---|---|
| Installation durable à l’étranger | Accès à un laboratoire, des équipements et des réseaux. | Quelles capacités sont renforcées ou fragilisées dans les différents pays ? |
| Retour après formation ou emploi | Transfert de compétences et développement d’activités. | Les institutions locales permettent-elles leur réemploi ? |
| Collaboration à distance ou mobilité répétée | Projets communs, circulation d’informations et accès à des partenaires. | Qui finance, fixe les priorités et peut accéder aux résultats ? |

**Note.** Ces configurations peuvent se succéder ou se combiner dans un même parcours.

**Fin du sujet N2-3.** Les références servent à identifier les documents ; aucune consultation extérieure n’est nécessaire pendant l’épreuve. Les adaptations sont signalées et ne sont jamais présentées comme des citations littérales.

# Correction N2-3

Les deux dissertations sont corrigées ci-dessous pour permettre de travailler ensuite l’option non choisie. Une copie d’examen ne traite qu’une dissertation et l’étude critique. Les propositions n’imposent ni un nombre universel de parties ni des formulations à reproduire.

## Dissertation 1 — Comment construire une paix durable après un conflit armé ?

**Comprendre le sujet.** Il faut distinguer cessation des combats, règlement politique et conditions de durée. Le sujet autorise Westphalie, ONU et Moyen-Orient, sans imposer une recette valable pour tous les conflits. Une paix durable ne signifie pas disparition de tout désaccord.

**Proposition rédigée.** Un cessez-le-feu peut faire taire les armes sans résoudre le conflit qui les a mobilisées. À l’inverse, un compromis peut laisser subsister des oppositions tout en leur donnant des formes non militaires. Construire la paix consiste donc à transformer les conditions de confrontation afin de rendre la reprise de la guerre moins probable. Comment cette construction peut-elle durer ? Elle exige un règlement reconnu, des garanties et des institutions, mais dépend de rapports de force et de conditions sociales qui échappent à une solution universelle.

La première exigence est de produire un accord sur les conditions de sortie du conflit. Les traités de Westphalie de 1648 illustrent la place de négociations longues entre acteurs dont les intérêts ne sont pas identiques. Ils organisent des compromis territoriaux, politiques et confessionnels dans un contexte déterminé. Il ne faut pas les présenter comme l’invention instantanée de tous les principes de l’État moderne ni comme la fin de toutes les guerres européennes. Leur intérêt est de montrer qu’un règlement peut rendre possible une coexistence sans abolir les divergences.

Un accord doit ensuite pouvoir être garanti. Les engagements sont fragiles si une partie pense obtenir davantage par une reprise des combats ou si elle doute de l’application des clauses. Des mécanismes de contrôle, des garanties extérieures et une capacité à traiter les différends peuvent réduire cette incertitude. La création de l’ONU en 1945 inscrit cette ambition dans un cadre multilatéral de sécurité collective. Le Conseil de sécurité peut adopter des décisions et autoriser des mesures ; les opérations et les médiations mobilisent des moyens et des acteurs différents selon les situations.

Cette architecture reste cependant dépendante de la coopération des États. Les désaccords entre grandes puissances, les ressources limitées, la définition des mandats et les comportements des acteurs locaux conditionnent les résultats. Sous Kofi Annan, les réflexions et les actions de l’ONU sur la construction de la paix montrent la nécessité d’articuler sécurité, institutions et société. Une opération internationale ne peut être évaluée uniquement à partir de sa présence : il faut examiner son mandat, ses moyens et le processus politique qu’elle accompagne.

Le Moyen-Orient révèle également la différence entre décision militaire et ordre durable. En 1991, la coalition obtient la libération du Koweït dans un cadre de résolutions internationales ; les questions de contrôle et d’équilibre régional persistent. En 2003, la chute du régime irakien ne produit pas automatiquement un ordre stable et accepté. L’exemple ne prouve pas qu’aucune intervention ne puisse avoir d’effet ; il montre que les capacités militaires et la construction d’institutions légitimes relèvent d’opérations distinctes.

La durée de la paix dépend enfin des conditions de vie et de reconnaissance. Le retour des déplacés, l’accès aux ressources, la reconstruction et le traitement des responsabilités peuvent peser sur la confiance. Mais imposer de l’extérieur un modèle abstrait sans tenir compte des rapports sociaux peut fragiliser les institutions nouvelles. La participation des populations, les compromis entre acteurs et la possibilité de résoudre les désaccords sans violence deviennent déterminants. Une paix qui paraît stable pour une puissance extérieure peut rester profondément contestée pour ceux qui la vivent.

Construire une paix durable suppose donc d’articuler un règlement, des garanties et un ordre politique susceptible d’être reconnu. Ni la victoire, ni le traité, ni l’organisation internationale ne suffisent isolément. La comparaison des situations permet d’identifier ces conditions sans promettre une recette. La paix n’est pas l’absence de politique après la guerre : elle est une autre manière d’organiser les conflits et les coexistences.

**Autre démarche recevable.** Étudier successivement négocier, garantir et reconstruire, en intégrant à chaque étape des limites. **Vigilance :** ne pas transformer Westphalie en origine incontestée d’un système achevé ni l’ONU en acteur tout-puissant.

## Dissertation 2 — Pourquoi les politiques environnementales des États-Unis sont-elles traversées par des tensions ?

**Comprendre le sujet.** Les États-Unis ne sont ni un gouvernement inchangé ni un acteur social homogène. Il faut articuler conceptions de la nature, système fédéral, intérêts économiques et place internationale. La chronologie contemporaine doit être datée.

**Proposition rédigée.** Les États-Unis associent une histoire ancienne de protection de certains espaces et un modèle économique fortement consommateur de ressources. Cette coexistence rend insuffisant un jugement uniforme sur leur politique environnementale. Au pluriel, ces politiques désignent des décisions prises par des institutions et des groupes dont les objectifs peuvent diverger. Pourquoi sont-elles traversées de tensions ? Elles résultent de conceptions concurrentes des milieux, d’un partage des compétences et d’arbitrages économiques dont les effets se prolongent dans les relations internationales.

L’histoire oppose d’abord différentes manières de protéger. La préservation met l’accent sur des espaces soustraits à certaines transformations ; la conservation peut chercher à organiser un usage durable des ressources. Les figures de John Muir et de Gifford Pinchot permettent de comprendre ces orientations sans réduire chaque acteur à une formule. Les parcs nationaux témoignent d’une volonté de protection et de mise en valeur, mais leur histoire doit aussi intégrer les populations autochtones et les conflits d’usage. Un territoire présenté comme sauvage n’est pas nécessairement un espace sans histoire humaine.

Le développement économique renforce les arbitrages. L’exploitation des ressources, les infrastructures et les activités industrielles produisent des emplois et des revenus, mais aussi des pollutions et des transformations des milieux. Les décisions environnementales répartissent donc des coûts et des avantages. Une réglementation peut être soutenue par des habitants exposés à un risque et contestée par des acteurs dépendant d’une activité. L’opposition ne se réduit pas toujours à un choix abstrait entre aimer ou détester la nature ; elle concerne des intérêts, des temporalités et des capacités de reconversion.

Le système fédéral ajoute une pluralité institutionnelle. L’État fédéral dispose de lois, d’agences et d’une capacité diplomatique ; les États fédérés et les villes exercent d’autres compétences. Les entreprises, associations et tribunaux participent également à l’élaboration et à la contestation des mesures. Une décision présidentielle ne décrit donc pas la totalité de l’action américaine. Des niveaux peuvent se renforcer, se freiner ou poursuivre des orientations différentes, ce qui impose de nommer l’acteur précis avant d’écrire « les États-Unis veulent ».

La scène internationale rend visibles les alternances. La participation aux cadres climatiques dépend des choix fédéraux et de la manière dont sont appréciés les coûts, les contraintes et les responsabilités. Les retraits et retours dans l’accord de Paris montrent cette instabilité. Au 8 septembre 2026, le second retrait américain de cet accord est effectif depuis le 27 janvier 2026. Une procédure distincte concerne la Convention-cadre : sa notification de février 2026 prévoit une prise d’effet en février 2027. Ces dates doivent être séparées, sans présenter une échéance future comme déjà réalisée.

Les choix internationaux ne suppriment cependant pas toute politique intérieure ni toute coopération d’autres acteurs. Des États fédérés, des villes, des universités ou des entreprises peuvent maintenir des initiatives selon leurs compétences et leurs intérêts. Inversement, leur action ne remplace pas automatiquement toutes les capacités du niveau fédéral. L’analyse doit donc évaluer les instruments et les résultats au lieu de déduire d’une annonce un bilan total.

Les tensions américaines tiennent ainsi à la combinaison d’une histoire de protection, de puissants intérêts d’exploitation et d’un système politique pluraliste. Elles traversent les échelles et les périodes. Les comprendre suppose de distinguer les acteurs, leurs instruments et les effets observés, plutôt que d’opposer deux images figées d’un pays entièrement protecteur ou entièrement hostile à l’environnement.

**Autre démarche recevable.** Un plan historique est recevable s’il explique les transformations et les permanences. **Vigilance :** ne pas confondre niveaux fédéral/fédéré, ni accord de Paris et Convention-cadre.

## Étude critique — Coopérer pour produire des connaissances : possibilités et asymétries

**Présentation.** Le premier document est une synthèse adaptée d’une annonce de la NSF en 2023 ; son origine institutionnelle et son objet doivent être identifiés. Il présente un dispositif de coopération, non une évaluation indépendante de ses résultats. Le second est un tableau conceptuel construit pour l’exercice : ses configurations ne sont pas des données statistiques. Comment la circulation et les dispositifs institutionnels peuvent-ils produire des connaissances sans garantir une relation égalitaire ?

Les documents montrent d’abord que la coopération repose sur des personnes et des organisations. Le tableau indique l’accès à des laboratoires, à des équipements et à des réseaux. L’annonce présente un arrangement entre organismes destiné à faciliter la sélection et le financement de projets. La connaissance ne circule donc pas par une simple ouverture abstraite des frontières : elle exige des financements, des procédures, des compétences et des relations de confiance.

Le premier document met l’accent sur un obstacle particulier, la séparation des procédures. Un arrangement peut réduire les coûts administratifs d’une collaboration et rendre plus facile la coordination de projets. Ce mécanisme éclaire le rôle des États et des agences dans la production scientifique. Il ne signifie pas que les autorités produisent seules chaque découverte ; elles organisent une partie des conditions dans lesquelles les chercheurs travaillent. Le cours sur les laboratoires et les réseaux scientifiques permet de relier cette dimension à une histoire plus longue de la production collective.

Le tableau invite ensuite à dépasser une lecture uniquement en termes de fuite. Une installation durable peut renforcer un pôle d’accueil, mais un retour ou une mobilité répétée peut transmettre des compétences et créer des liens. Les configurations peuvent se combiner dans une trajectoire ; le document le précise. La relation entre l’Inde et les États-Unis ne peut donc être réduite, sans enquête, à un départ définitif où l’un gagnerait exactement ce que l’autre perd. Des réseaux transnationaux peuvent produire des effets différents selon les institutions et les secteurs.

Cependant, les documents ne démontrent pas l’égalité des partenaires. La colonne des questions du tableau demande qui finance, fixe les priorités et accède aux résultats. La possibilité formelle de coopérer ne garantit pas des équipements comparables, une même capacité de négociation ou un partage identique des bénéfices. L’adaptation du document 1 ne donne pas de bilan de ce nouvel arrangement, des équipes retenues ou des droits sur les résultats. Une analyse de puissance doit donc examiner les asymétries plutôt que les supposer abolies par la coopération.

Le recul critique porte également sur la nature des pièces. Une annonce institutionnelle présente un instrument sous un jour favorable et selon son objectif ; cela ne la rend pas fausse, mais limite les conclusions. Le tableau conceptualise des mécanismes possibles et ne fournit aucune fréquence. Il serait incorrect d’en tirer un pourcentage de retours ou de déclarer que tous les chercheurs suivent la même trajectoire. Il faudrait des données datées sur les mobilités, les financements, les publications et les usages pour évaluer les effets.

La confrontation permet ainsi de comprendre comment circulation des compétences et dispositifs de coordination soutiennent la connaissance. Elle révèle aussi les questions qui demeurent ouvertes sur les priorités et la répartition des capacités. La coopération peut être une ressource de puissance et un moyen de production collective à la fois ; ces deux dimensions ne s’annulent pas. Une étude réussie les articule sans transformer un projet annoncé en résultat déjà acquis.

## Barème et reprise

**Répartition officielle :** dissertation sur 10 et étude critique sur 10. **Décomposition pédagogique proposée :** dissertation — compréhension et problématique 2, connaissances 3, démonstration 3, expression et achèvement 2 ; étude — présentation et problématique 2, exploitation et confrontation 3, contextualisation et recul critique 3, organisation et expression 2. Cette décomposition n’est pas une grille ministérielle imposée.

**Points d’attention propres à ce sujet.** Le tableau n’est pas une statistique ; l’annonce ne constitue pas une preuve de succès. Distinguer départ, retour et réseau, puis coopération et symétrie. Dans la dissertation américaine, dater les procédures internationales.

**Reprise espacée.** À J+2, réécrire le passage le plus faible sans modèle. À J+7, élaborer en 30 minutes le plan de l’autre dissertation ; à J+21, reprendre l’étude en expliquant oralement deux apports et deux limites des documents.

# N2-4 — Écrit terminal HGGSP

**Durée : 4 heures. Note : sur 20.** Épreuve blanche originale, session de préparation 2027. Aucun accès au cours ni aux corrigés pendant la simulation.

## Première partie — Dissertation, sur 10

Choisissez **un seul** des deux sujets.

**Sujet 1 — Pourquoi les tentatives de paix au Moyen-Orient rencontrent-elles des difficultés ?**

**Sujet 2 — Le partage des connaissances est-il compatible avec leur protection ?**

Rédigez une introduction, un développement organisé et une conclusion. Une illustration pertinente est possible mais non obligatoire.

## Seconde partie — Étude critique, sur 10

**Patrimonialiser et transmettre : une responsabilité à plusieurs échelles**

En confrontant les documents, montrez comment la reconnaissance patrimoniale articule responsabilité publique et transmission. Vous discuterez les limites d’une protection réduite au seul label.

### Document 1 — Responsabilité nationale et coopération internationale

**Adaptation pédagogique**, non verbatim, des articles 4 et 6 de la convention de l’UNESCO concernant la protection du patrimoine mondial culturel et naturel, adoptée le 16 novembre 1972 ([D11](#ref-D11)).

Chaque État partie reconnaît que l’identification, la protection, la conservation, la mise en valeur et la transmission aux générations futures du patrimoine situé sur son territoire lui incombent en premier lieu. Il agit selon ses ressources et peut mobiliser l’assistance et la coopération internationales. La reconnaissance d’un intérêt pour l’humanité s’articule au respect de la souveraineté des États et des droits de propriété prévus par les législations nationales. La convention organise donc une coopération ; elle ne transfère pas la propriété des biens à l’UNESCO.

### Document 2 — Trois héritages, des opérations différentes

**Tableau comparatif éditorial**, réalisé pour ce sujet à partir des notices institutionnelles des biens et pratiques. Sources : ([B49](#ref-B49) ; [B53](#ref-B53) ; [B54](#ref-B54) ; [D12](#ref-D12)). Les dates sont celles des inscriptions indiquées.

| Héritage | Reconnaissance | Une question de transmission |
|---|---|---|
| Paris, rives de la Seine | Patrimoine mondial, 1991 | Conserver un ensemble urbain tout en maintenant les fonctions d’une ville habitée. |
| Bassin minier du Nord-Pas-de-Calais | Patrimoine mondial, 2012 | Transmettre des traces et des mémoires du travail dans un territoire en reconversion. |
| Repas gastronomique des Français | Patrimoine culturel immatériel, 2010 | Transmettre une pratique sociale et des savoir-faire, non figer un menu obligatoire. |

**Note.** La dernière ligne relève du dispositif de la convention de 2003 sur le patrimoine culturel immatériel, et non d’une inscription au titre de la convention de 1972.

**Fin du sujet N2-4.** Les références servent à identifier les documents ; aucune consultation extérieure n’est nécessaire pendant l’épreuve. Les adaptations sont signalées et ne sont jamais présentées comme des citations littérales.

# Correction N2-4

Les deux dissertations sont corrigées ci-dessous pour permettre de travailler ensuite l’option non choisie. Une copie d’examen ne traite qu’une dissertation et l’étude critique. Les propositions n’imposent ni un nombre universel de parties ni des formulations à reproduire.

## Dissertation 1 — Pourquoi les tentatives de paix au Moyen-Orient rencontrent-elles des difficultés ?

**Comprendre le sujet.** Le Moyen-Orient n’est pas un conflit unique. Il faut distinguer conflits interétatiques, enjeux israélo-palestiniens, guerres du Golfe et acteurs internes ou extérieurs. Le sujet demande des mécanismes expliquant les difficultés, sans conclure à une violence prétendument naturelle de la région.

**Proposition rédigée.** Des traités, médiations et résolutions ont tenté d’organiser la paix au Moyen-Orient, sans produire partout un règlement durable. Cette difficulté ne peut être expliquée par une identité régionale supposée vouée à la guerre. Elle résulte de conflits différents qui articulent territoires, pouvoirs, sécurité et interventions. Pourquoi les tentatives de paix rencontrent-elles de tels obstacles ? Elles doivent traiter des objectifs concurrents et des asymétries, tandis que les acteurs et les conditions d’application changent au cours du temps.

Les conflits impliquent d’abord des revendications dont la conciliation est difficile. La question israélo-palestinienne engage le territoire, la sécurité, les droits nationaux et les conditions de vie. Les guerres et les déplacements ont produit des mémoires et des situations matérielles qui pèsent sur les négociations. Les principes formulés dans des résolutions, comme la résolution 242 après 1967, constituent des références diplomatiques ; leur existence ne résout pas automatiquement les divergences d’interprétation et d’application. Le texte et les rapports de force doivent être étudiés ensemble.

Les négociations supposent ensuite des acteurs capables de s’engager et de faire appliquer un accord. Un gouvernement ne contrôle pas nécessairement toutes les forces présentes ; des groupes peuvent refuser un compromis ou chercher à le faire échouer. Les sociétés sont traversées par des oppositions, et les expériences de violence peuvent fragiliser la confiance. Les accords d’Oslo en 1993 montrent la possibilité d’une reconnaissance et d’un processus, mais aussi la différence entre ouverture diplomatique et règlement achevé. Il faut examiner les questions laissées en suspens plutôt que présenter une cérémonie comme la fin du conflit.

La région est également un espace d’intervention de puissances extérieures. Ces acteurs peuvent fournir des garanties, des moyens de pression ou des ressources ; ils poursuivent aussi leurs intérêts et ne disposent pas toujours de la même légitimité auprès des populations. Leur soutien peut modifier le rapport de force sans créer les conditions d’un compromis accepté. L’analyse ne doit pourtant pas réduire les acteurs locaux à des exécutants : ils possèdent des objectifs et des capacités propres.

Les guerres du Golfe révèlent les limites d’une solution principalement militaire. En 1991, la libération du Koweït est obtenue dans un cadre international déterminé, mais la question de l’ordre régional demeure. L’invasion de l’Irak en 2003, dont le cadre est contesté, montre que renverser un régime n’équivaut pas à construire une paix stable. Les institutions, les rapports entre groupes et les conséquences sociales de la guerre conditionnent la suite. Une victoire répond à un objectif militaire immédiat ; elle ne suffit pas à assurer la légitimité du pouvoir.

Les violences récentes doivent enfin être abordées avec des sources datées et des qualifications précises. Les attaques du 7 octobre 2023, la guerre à Gaza et leurs conséquences rendent plus visibles encore les enjeux de protection des civils, de sécurité, de droit et de perspectives politiques. Une copie ne doit pas remplacer l’analyse par des chiffres non datés ni confondre des procédures judiciaires distinctes. Les faits contemporains éclairent les mécanismes du cours, mais exigent une vigilance supérieure sur leur actualisation.

Les difficultés de paix proviennent ainsi de la combinaison de questions non réglées, de rapports de force asymétriques et de capacités d’application fragiles. Cela n’implique pas que toute paix serait impossible. Les accords et les médiations peuvent produire des effets partiels ; leur durée exige des garanties, des droits et un ordre politique reconnu. Comprendre ces conditions permet d’éviter aussi bien le fatalisme régional que la promesse d’une solution unique imposée de l’extérieur.

**Autre démarche recevable.** Comparer les conflits à partir du règlement territorial, de la représentation des acteurs et des garanties. **Vigilance :** ne pas confondre paix israélo-arabe, règlement israélo-palestinien et guerres irakiennes ; ne pas essentialiser les religions ou les peuples.

## Dissertation 2 — Le partage des connaissances est-il compatible avec leur protection ?

**Comprendre le sujet.** « Protection » peut concerner sécurité, droits, confidentialité ou souveraineté ; elle n’est pas synonyme de secret absolu. Le partage peut produire des connaissances mais aussi exposer des vulnérabilités. Le sujet appelle des conditions, non une réponse binaire immédiate.

**Proposition rédigée.** La science progresse par la publication et la confrontation des résultats, tandis que certaines connaissances ou données sont soumises à des restrictions. Cette coexistence semble contradictoire si l’on assimile tout partage à une ouverture intégrale et toute protection à un secret. Le partage des connaissances peut-il être compatible avec leur protection ? Il le peut, à condition de distinguer les objets, les finalités et les dispositifs, tout en reconnaissant des tensions qui ne disparaissent pas complètement.

Le partage constitue d’abord une condition majeure de la production de savoirs. L’histoire des recherches sur la radioactivité montre des circulations entre personnes, laboratoires et publications. Les résultats deviennent discutables et réutilisables lorsqu’ils peuvent être examinés. Les infrastructures, les méthodes et les compétences collectives rendent insuffisante l’image d’une découverte produite sans échanges. Une restriction générale peut donc limiter la vérification et ralentir l’innovation, même lorsqu’elle est justifiée par la volonté de conserver un avantage.

La diffusion élargit aussi les capacités des sociétés. L’alphabétisation, l’enseignement et les mobilités étudiantes permettent à davantage de personnes de comprendre et de produire. Les réseaux entre l’Inde et les États-Unis montrent que la circulation ne consiste pas seulement à déplacer un stock fini de savoirs : des collaborations peuvent créer des connaissances nouvelles. Les dispositifs qui facilitent des projets communs doivent toutefois être évalués selon leur accès et leurs résultats. Un partage annoncé ne garantit ni une participation égale ni une répartition équitable des bénéfices.

Certaines protections restent nécessaires. Une information personnelle, une donnée sensible et un résultat scientifique publié ne soulèvent pas les mêmes questions. Les recherches associées à des applications stratégiques, notamment nucléaires, montrent que les États peuvent limiter la circulation. Le renseignement répond à des besoins de décision dans un contexte de rivalité ; sa protection ne doit pas être confondue avec celle d’un savoir destiné à l’enseignement. Il faut donc préciser l’objet protégé et le risque identifié avant de défendre ou de condamner une restriction.

Le cyberespace renforce cette exigence de distinction. Une université peut vouloir partager des résultats tout en protégeant les données personnelles, les accès et les systèmes qui les hébergent. Des droits différenciés, une authentification, des sauvegardes et une coopération entre autorités peuvent soutenir les deux objectifs. La sécurité ne consiste pas nécessairement à couper toute connexion ; elle cherche à rendre les usages possibles dans des conditions maîtrisées. Mais les dépendances aux infrastructures et aux fournisseurs peuvent créer des asymétries qu’un simple engagement de partage ne règle pas.

L’arbitrage doit enfin rester explicite et révisable. Qui décide de la restriction ? Pour quelle durée ? Avec quel contrôle ? Un secret invoqué sans limite peut protéger des abus ou empêcher une enquête ; une ouverture sans précaution peut exposer des personnes ou des capacités sensibles. La connaissance exige aussi de reconnaître l’incertitude : disposer d’un indice technique n’autorise pas à attribuer une attaque avec certitude. Une coopération responsable partage des informations dont le statut et la fiabilité sont compris.

Le partage et la protection sont donc compatibles lorsqu’ils sont définis par des finalités précises et des règles adaptées aux objets. Ils demeurent en tension parce que la connaissance est à la fois une ressource collective et un enjeu de puissance. L’enjeu n’est pas de choisir abstraitement entre tout ouvrir et tout fermer, mais de construire des dispositifs qui permettent la production, la validation et l’accès tout en limitant des risques identifiés.

**Autre démarche recevable.** Distinguer les niveaux individuel, institutionnel et étatique, à condition de comparer les mécanismes. **Vigilance :** ne pas assimiler données et connaissances ni présenter tout secret comme légitime par définition.

## Étude critique — Patrimonialiser et transmettre : une responsabilité à plusieurs échelles

**Présentation.** Le premier document adapte des dispositions de la convention de 1972 : il expose des responsabilités et un principe de coopération. Le second compare trois héritages inscrits dans deux dispositifs différents. Sa note distingue expressément patrimoine mondial et patrimoine immatériel. Comment ces documents permettent-ils de comprendre une protection à plusieurs échelles, sans réduire la transmission à l’obtention d’un label ?

Le document 1 affirme d’abord une responsabilité publique située. L’identification, la conservation et la transmission incombent en premier lieu à l’État concerné. La dimension mondiale ne supprime donc pas le territoire, la souveraineté ni les droits de propriété. Cette précision corrige une erreur fréquente : l’UNESCO ne devient pas propriétaire des sites qu’elle reconnaît. La coopération peut apporter des ressources, des expertises et une visibilité, mais elle ne se substitue pas automatiquement aux décisions et aux moyens nationaux.

Le tableau montre ensuite que les opérations de transmission varient selon les héritages. Les rives de la Seine constituent un ensemble urbain dans une ville habitée : conserver doit être articulé à des fonctions résidentielles, économiques et de transport. Le bassin minier associe des traces matérielles et une mémoire du travail dans un territoire qui change d’activité. Le repas gastronomique relève d’une pratique sociale : sa protection ne consiste pas à conserver un objet immobile ni à imposer le même menu. Les trois lignes permettent donc de comparer, pas de ramener toutes les situations à une recette.

Cette diversité éclaire la patrimonialisation comme processus. Des acteurs identifient une valeur, construisent un dossier et organisent une reconnaissance ; la valeur n’est pas automatiquement produite par l’ancienneté. L’inscription du bassin minier en 2012 révèle un regard sur des héritages industriels et sociaux. La transmission suppose alors habitants, associations, professionnels et institutions, au-delà de la seule autorité qui délivre le label. Le patrimoine n’est pas seulement ce que l’on montre à des visiteurs ; il peut être un support de mémoire et d’usage quotidien.

Les documents invitent aussi à distinguer les instruments juridiques. La convention de 1972 concerne le patrimoine mondial culturel et naturel, tandis que la ligne sur le repas renvoie à celle de 2003. On ne peut donc pas appliquer directement toutes les dispositions du document 1 à cette pratique comme si elle appartenait au même régime d’inscription. Cette limite est explicitement signalée, ce qui permet une comparaison raisonnée des finalités de transmission sans confusion des dispositifs.

Enfin, ni le texte normatif ni le tableau ne démontrent l’efficacité de la protection. Le premier décrit des devoirs ; le second mentionne des reconnaissances et des questions. Ils ne donnent pas de bilan des travaux, des financements, de la participation des habitants ou de la transmission des pratiques. Le cours sur Venise ou Tombouctou permet de rappeler que fréquentation, sécurité, usages et conservation peuvent entrer en tension. Un label peut soutenir une action, mais il ne suffit pas à prévenir une destruction ou à garantir une vie sociale durable.

La confrontation montre donc une responsabilité articulée entre États, coopération internationale et acteurs de terrain. Elle révèle également que transmettre demande des opérations adaptées à la nature des héritages. La réussite ne se mesure pas seulement à une inscription ou à une visibilité touristique : elle exige des moyens, une médiation et des usages qui donnent une continuité à ce que la société a choisi de conserver.

## Barème et reprise

**Répartition officielle :** dissertation sur 10 et étude critique sur 10. **Décomposition pédagogique proposée :** dissertation — compréhension et problématique 2, connaissances 3, démonstration 3, expression et achèvement 2 ; étude — présentation et problématique 2, exploitation et confrontation 3, contextualisation et recul critique 3, organisation et expression 2. Cette décomposition n’est pas une grille ministérielle imposée.

**Points d’attention propres à ce sujet.** Ne pas assimiler les conventions de 1972 et de 2003. Exploiter les trois exemples du tableau sans raconter tout T04. La critique doit porter sur l’absence de bilan et sur les périmètres, non sur une prétendue inutilité de toute reconnaissance.

**Reprise espacée.** À J+2, réécrire le passage le plus faible sans modèle. À J+7, élaborer en 30 minutes le plan de l’autre dissertation ; à J+21, reprendre l’étude en expliquant oralement deux apports et deux limites des documents.

# Références et provenance documentaire {#references}

Les codes sont des repères locaux, non des identifiants ministériels. **S** désigne le cadre officiel ; **R** les ressources d’accompagnement ; **D** des documents de référence ; **B** une source spécifique ou un renvoi thématique à une ressource, selon la qualification indiquée. Un renvoi à une ressource pédagogique ne signifie pas que les ouvrages originaux qu’elle cite ont tous été lus intégralement.

Les documents du cours sont des synthèses éditoriales sauf indication expresse contraire. Les adaptations ne sont pas des citations verbatim. Les jeux fictifs ne sont pas des statistiques historiques. Les liens permettent une vérification complémentaire ; aucun exercice ne suppose qu’un document absent soit téléchargé pour être résolu.

**Actualisation : 8 septembre 2026.** Les règles de session et les faits contemporains demandent une nouvelle veille avant l’examen. Ce manuel ne vaut ni homologation ministérielle ni conseil individuel d’inscription.

## Cadre officiel

[**([S02](#ref-S02)) Programme de Première — BO spécial du 22 janvier 2019**]{#ref-S02} — Texte ou information officielle. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/spe576annexe1062925pdf-83244.pdf).

[**([S03](#ref-S03)) Programme de Terminale — BO spécial du 25 juillet 2019**]{#ref-S03} — Texte ou information officielle. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/spe254annexe1159180pdf-83247.pdf).

[**([S04](#ref-S04)) Note du 27 août 2025, NOR MENE2521923N — Épreuve HGGSP à compter de 2026**]{#ref-S04} — Texte ou information officielle. [Consulter la source](https://www.education.gouv.fr/bo/2025/Hebdo33/MENE2521923N).

[**([S05](#ref-S05)) Évaluation ponctuelle de la spécialité non poursuivie — version consolidée juin 2025, HGGSP pages 3–4**]{#ref-S05} — Texte ou information officielle. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ndsevaluations-ponctuelleseds-non-poursuivivoie-gjuin-2025pdf-100575.pdf).

## Accompagnement par thème

[**([R-T06](#ref-R-T06)) Éduscol — Ressource d’accompagnement : L’enjeu de la connaissance**]{#ref-R-T06} — Accompagnement disciplinaire officiel. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra24lyceegthggspenjeuxconnaissancepdf-104487.pdf). Source d’appui aux jalons et à leur problématisation ; ne vaut pas validation du présent manuel.

## Documents de référence

[**([D09](#ref-D09)) Nations unies — Charte de 1945**]{#ref-D09} — Document institutionnel de référence. [Consulter la source](https://treaties.un.org/doc/source/docs/charter-all-lang.pdf).

[**([D10](#ref-D10)) CCNUCC — Accord de Paris**]{#ref-D10} — Document institutionnel de référence. [Consulter la source](https://unfccc.int/process-and-meetings/the-paris-agreement).

[**([D11](#ref-D11)) UNESCO — Convention du patrimoine mondial de 1972**]{#ref-D11} — Document institutionnel de référence. [Consulter la source](https://whc.unesco.org/fr/conventiontexte/).

[**([D12](#ref-D12)) UNESCO — Convention pour la sauvegarde du patrimoine culturel immatériel, 2003**]{#ref-D12} — Document institutionnel de référence. [Consulter la source](https://ich.unesco.org/fr/convention). Le dispositif de 2003 est distinct de la convention de 1972. Aucun passage présenté comme transcription littérale.

## Appuis documentaires et approfondissements

[**([B39](#ref-B39)) Résolutions 678 et 687, guerre de 1991 — appui dans la ressource T02**]{#ref-B39} — Renvoi thématique à un accompagnement officiel. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra22lycee-gthggsptheme-2faire-la-guerre-et-faire-la-paix-93786.pdf). Le code désigne un point d’appui de la ressource Éduscol, pas une édition intégrale d’un ouvrage original. Voir le jalon correspondant.

[**([B39a](#ref-B39a)) Conseil de sécurité — Répertoire des pratiques, 2000–2003, chapitre XII**]{#ref-B39a} — Source institutionnelle. [Consulter la source](https://www.un.org/fr/sc/repertoire/00-03/00-03_12.pdf).

[**([B49](#ref-B49)) UNESCO — Paris, rives de la Seine**]{#ref-B49} — Source institutionnelle. [Consulter la source](https://whc.unesco.org/en/list/600/).

[**([B53](#ref-B53)) UNESCO — Bassin minier du Nord-Pas-de-Calais**]{#ref-B53} — Source institutionnelle. [Consulter la source](https://whc.unesco.org/en/list/1360/).

[**([B54](#ref-B54)) UNESCO — Repas gastronomique des Français, inscription 2010**]{#ref-B54} — Source institutionnelle. [Consulter la source](https://ich.unesco.org/en/RL/gastronomic-meal-of-the-french-00437).

[**([B58](#ref-B58)) Stockholm, Rio et Kyoto — appui dans la ressource T05**]{#ref-B58} — Renvoi thématique à un accompagnement officiel. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra23lyceegthggspenvironnementexploitationprotectionenjeupdf-102786.pdf). Le code désigne un point d’appui de la ressource Éduscol, pas une édition intégrale d’un ouvrage original. Voir le jalon correspondant.

[**([B58a](#ref-B58a)) CCNUCC — Contributions déterminées au niveau national**]{#ref-B58a} — Source institutionnelle. [Consulter la source](https://unfccc.int/process-and-meetings/the-paris-agreement/nationally-determined-contributions-ndcs).

[**([B65](#ref-B65)) NSF/NCSES — Immigration and the science and engineering workforce, 2019**]{#ref-B65} — Source institutionnelle. [Consulter la source](https://ncses.nsf.gov/pubs/nsb20198/immigration-and-the-s-e-workforce).

[**([B65a](#ref-B65a)) NSF — Arrangement de coopération États-Unis–Inde, annonce du 1er février 2023**]{#ref-B65a} — Source institutionnelle. [Consulter la source](https://www.nsf.gov/news/nsf-signs-us-india-implementation-arrangement-streamline). Page archivée : exemple historique de 2023, non affirmation de la politique actuelle. Date corrigée après réouverture de la source.

## Droits, adaptations et limites

Les textes historiques du domaine public et les actes officiels sont identifiés ; les autres ressources ne sont pas reproduites intégralement. Les synthèses, tableaux, exercices et schémas nouveaux sont des créations éditoriales de cette édition. Aucun fichier de police n’est livré. Les textes du kit et les fragments récupérés restent conservés séparément avec leurs empreintes ; les nouveaux développements ne sont pas présentés comme le manuscrit ancien retrouvé.

Les vérifications effectuées portent sur la couverture, les correspondances, les points réglementaires, les données explicites et la fabrication. Elles ne constituent pas une relecture disciplinaire indépendante de l’ensemble de l’ouvrage. Le registre JSON précise les accès protégés et les renvois documentaires indirects.
