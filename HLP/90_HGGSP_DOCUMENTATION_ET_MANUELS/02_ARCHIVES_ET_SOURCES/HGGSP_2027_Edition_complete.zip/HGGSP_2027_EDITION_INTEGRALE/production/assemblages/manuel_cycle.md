---
title: "HGGSP — Cycle terminal"
subtitle: "Manuel du candidat individuel · Parcours N1 et N2"
author: "Nexus Réussite — Collection Manuels scolaires"
date: "Session 2027 · Édition pédagogique 1.0 · 8 septembre 2026"
lang: "fr-FR"
---

# Commencer : choisir son parcours et organiser son travail {#mode-emploi}

## Ce que contient cette édition

Ce manuel prépare la spécialité **histoire-géographie, géopolitique et sciences politiques** du baccalauréat général. Il couvre les cinq thèmes de Première et les six thèmes de Terminale. Il ne prépare pas, à lui seul, toutes les disciplines du baccalauréat et ne vaut pas autorisation administrative d’inscription.

Deux parcours éditoriaux sont proposés. **N1** concerne la spécialité non poursuivie après la Première. **N2** concerne la spécialité conservée en Terminale, avec une progression intensive possible en une année. Ces parcours ne sont pas des degrés de difficulté : les exercices possèdent séparément trois degrés, **consolidation, maîtrise, approfondissement**. Un candidat préparant le bac en un an mais ne conservant pas HGGSP relève de N1 pour cette spécialité.

Le manuel et son compagnon sont complémentaires. Tenter une activité avant d’ouvrir sa correction permet d’identifier un besoin réel. Les corrigés ne sont pas réservés à un enseignant : ils expliquent les démarches et les limites. Les exemples commentés intégrés au cours peuvent, eux, être lus immédiatement. Les neuf épreuves blanches sont également fournies dans un volume sans réponses, utilisable en temps limité.

**Provenance de l’édition.** Le module 00 et les fragments explicitement identifiés proviennent du dossier fondateur ou des transcriptions récupérées. Les développements nécessaires, les méthodes, les compléments d’exercices et tous les corrigés du corpus avancé ont été nouvellement rédigés. Ils ne sont pas présentés comme les anciens fichiers retrouvés. Les originaux restent séparés dans les sources modifiables. Cette édition est autonome : elle n’a pas été déclarée charte canonique du dépôt de la collection.

## Les règles d’examen à connaître — vérification du 8 septembre 2026

| Situation | Épreuve HGGSP | Format et coefficient |
|---|---|---|
| N1 : spécialité non poursuivie | Évaluation ponctuelle écrite | Composition, 2 heures, note sur 20, coefficient 8. |
| N2 : spécialité conservée | Épreuve terminale écrite | 4 heures, coefficient 16 ; dissertation sur 10 et étude critique de document(s) sur 10. |
| Grand oral, voie générale, session 2027 | Épreuve distincte | Préparation 20 minutes ; présentation 10 minutes puis échange 10 minutes ; coefficient 8. |

Pour **N1**, le sujet porte sur l’un des axes ou sur l’objet de travail conclusif d’un thème de Première. L’entraînement doit donc apprendre à délimiter un objet, non à réciter les cinq thèmes. La passation pendant la première année et le choix d’une évaluation à la fin du cycle dépendent de la modalité d’inscription du candidat individuel ; l’année d’apprentissage, l’année de passation et la session du diplôme ne sont pas synonymes. Le choix de modalité est encadré par les textes et l’inscription : il ne se décide pas librement matière par matière dans ce manuel. ([S05](#ref-S05) ; [S06](#ref-S06) ; [S07](#ref-S07))

Pour **N2**, deux sujets de dissertation au choix portent sur deux thèmes différents ; l’étude critique porte sur un troisième thème. Le candidat rédige **une** dissertation et réalise **l’étude critique**. Pour l’écrit de **2027**, année impaire, les thèmes concernés sont **T02 : guerre et paix ; T04 : patrimoine ; T05 : environnement ; T06 : connaissance**. T01 et T03 demeurent dans le programme enseigné et dans ce livre ; ils ne sont pas à supprimer. Le manuel ne prédit aucun sujet officiel. ([S03](#ref-S03) ; [S04](#ref-S04))

Le **Grand oral** mobilise les deux spécialités conservées. Les deux questions préparées doivent, prises ensemble, concerner ces deux enseignements ; elles peuvent être disciplinaires ou transversales selon les conditions officielles. Le jury choisit une question. Le support préparé pendant les vingt minutes peut servir à la présentation, mais n’est pas une production évaluée en tant que telle. Les modalités particulières des candidats individuels et les documents attendus sont à vérifier auprès du service organisateur. ([S08](#ref-S08))

L’**oral de contrôle HGGSP**, lorsqu’un candidat y est admis et choisit cette discipline, dure 20 minutes après 20 minutes de préparation ; la présentation est suivie d’un échange. Le programme d’évaluation suit le périmètre de l’écrit. Ce n’est ni le Grand oral ni une composition réduite. Voir la méthode M11 et la simulation proposée dans les annexes. ([S04](#ref-S04))

**Préparer en un an n’autorise pas automatiquement à regrouper toutes les épreuves.** Les conditions permettant de passer les épreuves anticipées la même année que les épreuves terminales sont encadrées : l’âge de vingt ans atteint au 31 décembre de l’année de l’examen constitue notamment un cas, à côté de situations réglementaires particulières. Ne pas transformer ces cas en conditions cumulatives ni présumer que le lecteur en bénéficie. Les dispenses, notes conservées, aménagements et modalités locales relèvent du dossier personnel et du service des examens. Aucun calendrier tunisien n’est fabriqué ici. ([S06](#ref-S06))

## Parcours N1 — 24 semaines indicatives

Cette proposition représente **un cadre pédagogique**, pas un horaire officiel obligatoire. Prévoir généralement cinq à six heures de travail personnel par semaine, à ajuster après le diagnostic. Un lecteur ayant des lacunes importantes en expression ou en repères doit allonger les phases concernées.

| Semaines | Travail principal | Production à conserver |
|---|---|---|
| 1–2 | Module 00 ; M1 à M5 ; repères chronologiques et géographiques. | Diagnostic et première rédaction corrigée. |
| 3–6 | P01 : démocratie. | Paragraphe, plan, composition N1-1. |
| 7–10 | P02 : puissances. | Tableau comparatif, composition N1-2. |
| 11–14 | P03 : frontières. | Lecture de schéma, composition N1-3. |
| 15–18 | P04 : information. | Critique de source, composition N1-4. |
| 19–22 | P05 : États et religions. | Comparaison argumentée, composition N1-5. |
| 23–24 | Reprises espacées et nouvelle rédaction des points faibles. | Une composition complète sans aide et son bilan. |

À chaque thème : lire l’introduction, faire le diagnostic, travailler un axe à la fois, répondre aux exercices correspondants, puis traiter l’objet conclusif. Les QCM vérifient des distinctions ; ils ne suffisent pas à prouver la capacité à rédiger. Faire le nouveau test après un délai d’au moins deux jours, et non immédiatement après avoir copié le corrigé.

## Parcours N2 intensif — 32 semaines indicatives

Prévoir environ dix à douze heures hebdomadaires pour cette spécialité lorsque les fondations sont à construire, puis adapter ce volume aux résultats. Cette charge doit être articulée aux autres matières ; ce n’est pas une garantie de réussite ni une prescription officielle.

| Semaines | Priorité | Validation |
|---|---|---|
| 1–2 | Module 00 ; diagnostic ; méthodes M1–M7. | Présenter une source et rédiger un paragraphe. |
| 3–7 | Fondations P01–P05, un thème par semaine. | Notions, repères, E1–E5 et nouveau test de chaque thème. |
| 8–10 | T02 : guerre et paix. | Dissertation et étude critique guidées. |
| 11–13 | T04 : patrimoine. | Plan problématisé et dossier à deux documents. |
| 14–16 | T05 : environnement. | Indicateur exact et argumentation à plusieurs échelles. |
| 17–19 | T06 : connaissance. | Attribution prudente, rédaction et oral explicatif. |
| 20–21 | T01 : espaces de conquête. | Comparaison coopération/rivalité et transfert vers T02/T06. |
| 22–23 | T03 : histoire et mémoires. | Distinction histoire/mémoire/justice ; transfert vers T04. |
| 24–27 | Quatre blancs N2, un par semaine avec correction approfondie. | Deux exercices achevés en quatre heures. |
| 28–30 | Grand oral avec l’autre spécialité ; remédiations ciblées. | Deux questions conformes et simulations chronométrées. |
| 31–32 | Réactivation, nouvelle étude critique, écrit de synthèse. | Bilan des critères et reprise des erreurs persistantes. |

**Fondations à ne pas sauter.** P01 éclaire les institutions et les libertés ; P02 les mécanismes de puissance ; P03 les territoires et le droit maritime ; P04 la critique de l’information ; P05 les relations entre pouvoir et croyances. Le parcours accéléré réduit certains entraînements redondants, pas les notions nécessaires. Les E7–E8 de Première restent disponibles lorsque le diagnostic révèle un besoin.

## Une séance de travail et une preuve observable

Pour une séance de 90 minutes : 10 minutes de rappel sans cours ; 25 minutes de lecture active d’une unité ; 25 minutes de production ; 20 minutes de correction argumentée ; 10 minutes de réécriture d’un point faible. Les durées sont adaptables. La lecture active consiste à reformuler un mécanisme, repérer les acteurs et dater un exemple, pas à surligner chaque ligne.

Trois preuves sont à distinguer : **restituer**, sans notes, une notion et un repère ; **expliquer**, par une relation causale ou une comparaison ; **mobiliser**, dans une question différente de celle du cours. Une connaissance n’est pas durablement acquise au seul motif que sa correction paraît compréhensible.

| Date / objet | Restituer | Expliquer | Mobiliser ailleurs | Erreur précise | Reprise prévue |
|---|---|---|---|---|---|
| À compléter dans le cahier | Sans aide / avec aide | Relation établie / absente | Exemple pertinent / plaqué | Une phrase descriptive | J+2, J+7, J+21 |

**Orientation.** Si les dates et acteurs sont confondus, R1 ; si les mots restent vagues, R2 ; si la réponse raconte, R3 ; si elle répète le document, R4 ; si le plan est interchangeable, R5 ; si elle reste inachevée, R6. Le retour au cours vise la section concernée. Refaire tout le thème sans identifier l’erreur produit souvent moins de progrès qu’une reprise courte et ciblée.

## Lire les références et les documents

Les codes **S** désignent les textes officiels, **R** les ressources d’accompagnement, **B** les appuis historiques et institutionnels, **D** les documents de référence. Leur registre figure en annexe et dans les sources modifiables. Les identifiants P01/T01 et ceux des jalons sont locaux, non ministériels. Les liens numériques ne remplacent pas les documents nécessaires : les activités évaluées disposent de leurs matériaux dans le livre ou dans leur dossier de sujet.

Une **citation authentique** reproduit les mots d’une source ; une **adaptation** modifie sa présentation ou sa longueur et le signale ; une **synthèse éditoriale** expose des informations avec les mots du manuel ; une **fiction pédagogique** sert à une tâche méthodologique sans prétendre décrire un fait réel. Ne pas transformer une synthèse ou une fiction en témoignage historique dans une copie.

Cette édition a fait l’objet de contrôles de structure, de correspondance, d’assemblage et de rendu, décrits dans le rapport joint. Ces contrôles ne constituent pas une relecture disciplinaire indépendante ni une approbation ministérielle. Les faits contemporains sont arrêtés à la date de vérification indiquée ; leur évolution doit être distinguée des connaissances historiques stabilisées.

# Entrer en HGGSP — Module 00 du candidat individuel

Module fondateur conservé ; identifiants préfixés « 00- » pour éviter les collisions avec ceux du manuel.

## Entrer en HGGSP

**Comprendre • analyser • argumenter**
Module 00 — Première et entrée en Terminale

**POUR LE CANDIDAT INDIVIDUEL**

Un premier parcours autonome, avant les onze thèmes du cycle. Ce livret apprend à travailler un document, à distinguer un principe d’une pratique, à utiliser une donnée et à construire une réponse argumentée.

### À la fin du module, vous saurez…

Identifier les quatre approches de la spécialité ; poser une question précise ; présenter une source ; limiter vos conclusions à ce que les pièces permettent ; organiser un paragraphe et vérifier votre travail.

| Parcours conseillé | Durée de travail indicative |
| --- | --- |
| Se situer, découvrir la discipline, apprendre à lire une source | Deux heures, avec prise de notes et premiers exercices. |
| Argumenter, traiter un dossier, se tester et reprendre | Deux heures, puis une courte réactivation à distance. |

Le livret d’autocorrection est séparé : écrivez une première réponse avant de l’ouvrir. Vous pourrez ensuite identifier votre erreur, reprendre une méthode et tenter un nouvel exercice. Les espaces prévus servent à prendre des notes ; rédigez les productions longues sur une feuille ou dans votre cahier.

Nexus Réussite • Module fondateur adapté dans l’édition 1.0 • 8 septembre 2026. Les cas « Rivage » et les situations de test sont fictifs ; le document de 1789 est réel et référencé. Ce module n’est pas le cours complet du thème « Démocratie ».

## Mon itinéraire vers le baccalauréat

| Mon cas | Ce que je dois préparer en HGGSP |
| --- | --- |
| J’arrête HGGSP après la Première. | Les cinq thèmes de Première et la composition de deux heures de l’évaluation ponctuelle : coefficient 8. |
| Je conserve HGGSP en Terminale. | Les six thèmes de Terminale et leurs liens avec la Première. Pour l’écrit, une dissertation et une étude critique, en quatre heures : coefficient 16. |
| Je prépare le Grand oral. | Deux questions couvrant mes deux spécialités conservées ; 20 min de préparation, puis 10 min de présentation et 10 min d’échange. Coefficient 8 en voie générale à partir de 2027. |

Pour la Terminale, les thèmes de l’écrit varient selon la session : **2027 : 2, 4, 5 et 6 ; 2028 : 1, 2, 3 et 5.** Cette sélection de révision ne supprime pas les deux autres thèmes du cours. ([S04](#ref-S04) ; [S05](#ref-S05) ; [S06](#ref-S06) ; [S07](#ref-S07) ; [S08](#ref-S08) ; [S09](#ref-S09))

**À NE PAS CONFONDRE**

HGGSP ne remplace pas l’histoire-géographie du tronc commun. Le Grand oral n’est pas l’oral de contrôle. Une préparation à une épreuve ne vaut pas inscription au baccalauréat.

### Mon carnet de bord

| Information | À compléter |
| --- | --- |
| Session du diplôme |  |
| Spécialité conservée ou non poursuivie |  |
| Autre spécialité conservée, le cas échéant |  |
| Service des examens / notice consultée |  |
| Créneaux réguliers de travail personnel |  |

Sources S04–S09. Vérifiez vos choix et dates sur votre confirmation d’inscription et les documents du service des examens. Les calendriers locaux ne sont pas fixés par ce livret.

## Diagnostic : ce que je sais déjà faire

**15 minutes, sans recherche.** Répondez en quelques mots, sauf indication contraire. Un doute est une information utile : ne devinez pas uniquement pour remplir la page.

**00-D1.** Rangez ces dates de la plus ancienne à la plus récente : 1992, 1648, 1789.

*Répondez dans votre cahier.*

**00-D2.** Un texte rédigé en 1789 est reproduit sur Légifrance en 2026. Quelle date utilisez-vous pour le contexte de production ? Quel rôle joue le site ?

*Répondez dans votre cahier.*

**00-D3.** « L’événement B a suivi l’événement A ; donc A est la cause de B. » La conclusion est-elle certaine ? Justifiez.

*Répondez dans votre cahier.*

**00-D4.** Une consultation en ligne reçoit 100 réponses volontaires, dont 80 favorables. Peut-on affirmer que 80 % de tous les habitants sont favorables ?

*Répondez dans votre cahier.*

**00-D5.** Un règlement proclame l’égalité de tous. Ce document prouve-t-il que tous sont effectivement traités de façon égale ?

*Répondez dans votre cahier.*

**00-D6.** Un message très partagé est-il nécessairement exact ? Indiquez une vérification à faire.

*Répondez dans votre cahier.*

**00-D7.** Classez du plus local au plus large : commune, monde, État.

*Répondez dans votre cahier.*

**00-D8.** « Ce projet est excellent. » Est-ce une donnée mesurée ou un jugement ? Que faudrait-il ajouter pour construire une argumentation ?

*Répondez dans votre cahier.*

Orientation : 00-D1–00-D2 fragiles → 00-R1 ; 00-D3 et 00-D8 → 00-R2 ; 00-D4 et 00-D7 → 00-R3 ; 00-D5–00-D6 → 00-R4. Les fiches de reprise figurent dans ce livret ; le corrigé détaillé est dans le compagnon.

## Quatre regards sur une même question

HGGSP associe quatre approches. Elles ne sont pas quatre cours indépendants et l’on ne doit pas les confondre. ([S02](#ref-S02) ; [S03](#ref-S03))

| Approche | Questions caractéristiques |
| --- | --- |
| Histoire | Comment une situation s’est-elle construite ? Quelles ruptures, continuités et temporalités permettent de la comprendre ? |
| Géographie | Comment les sociétés organisent-elles les espaces ? Où se répartissent activités, populations et ressources ? À quelles échelles ? |
| Géopolitique | Quels acteurs rivalisent ou coopèrent pour des territoires, des ressources et des positions ? Quels sont leurs moyens et leurs représentations ? |
| Sciences politiques | Comment le pouvoir est-il organisé, exercé et contesté ? Comment fonctionnent institutions, participation et décision collective ? |

**CAS D’ENTRAÎNEMENT FICTIF**

Deux communes discutent de l’extension d’un port commun. Des entreprises espèrent de nouveaux débouchés ; une association souhaite préserver une zone humide ; des habitants réclament une consultation. Aucune commune réelle n’est désignée.

### Exercice 00-E1 — Reconnaître une approche

Associez chaque question à l’approche dominante, puis justifiez une association. Plusieurs approches peuvent ensuite être articulées.

a. Comment la fonction du port a-t-elle changé en trente ans ?
b. Où se trouvent la zone humide et les quartiers exposés aux flux ?
c. Comment les deux communes négocient-elles le contrôle des revenus ?
d. Qui est habilité à décider et comment les habitants participent-ils ?

*Répondez dans votre cahier.*

### Exercice 00-E2 — Construire sa question

À partir de ce cas, écrivez une question qui articule deux approches. Évitez « Que pensez-vous du port ? », qui appelle une opinion sans préciser ce qu’il faut expliquer.

*Répondez dans votre cahier.*

## Des mots pour penser précisément

| Notion de travail | Définition et vigilance |
| --- | --- |
| Acteur | Individu, groupe, institution ou organisation qui intervient dans une situation. Préciser ses objectifs, moyens et contraintes. |
| Territoire | Espace approprié et organisé par des acteurs. Ne pas le réduire à une surface sur une carte. |
| Échelle | Niveau spatial de l’analyse : local, national, régional ou mondial. Une explication peut changer quand on change d’échelle. |
| Institution | Organisation ou ensemble de règles qui stabilise l’exercice d’une activité ou d’un pouvoir. |
| Puissance | Capacité d’un acteur à agir, influencer ou imposer dans une relation donnée. Identifier ses moyens et ses limites. |
| Démocratie | Régime fondé sur la souveraineté du peuple ; son étude examine participation, représentation, libertés, institutions et pratiques. |
| Source | Trace ou document à partir duquel on construit une connaissance. Sa valeur dépend notamment de la question posée. |
| Preuve / élément de preuve | Information qui permet d’étayer une proposition dans un raisonnement explicite. Une source doit être interrogée, non invoquée seulement par son titre. |
| Interprétation | Explication argumentée de faits et de sources. Elle peut être discutée à partir d’éléments vérifiables. |
| Contexte | Ensemble des circonstances pertinentes pour comprendre la production d’un document ou une situation. |
| Problématique | Question directrice qui identifie un problème à expliquer et organise la réponse. |
| Document normatif | Texte qui énonce une règle, un droit ou un principe. Il ne décrit pas automatiquement les pratiques effectives. |

Ces formulations sont des définitions de travail pour débuter. Elles seront précisées dans les thèmes. Les notions et approches sont rattachées aux programmes S02–S03 et aux ressources R-P01 à R-P05.

### Exercice 00-E3

Choisissez deux notions et formulez une phrase qui les emploie à propos du port fictif. La phrase doit montrer leur sens, pas seulement juxtaposer les mots.

*Répondez dans votre cahier.*

## Lire une source : un texte de 1789

**DOCUMENT A — SOURCE RÉELLE**

Déclaration du 26 août 1789 des droits de l’homme et du citoyen, article 16 :
« Toute société dans laquelle la garantie des droits n’est pas assurée, ni la séparation des pouvoirs déterminée, n’a point de constitution. »

**Identification.** Le texte est adopté par les représentants constitués en Assemblée nationale. Il énonce des principes. La transcription consultée est diffusée par Légifrance. La date de consultation du site, le 8 septembre 2026, n’est pas la date de rédaction du document. ([S10](#ref-S10))

**Vocabulaire.** Garantir signifie ici assurer la protection ; les pouvoirs renvoient à l’organisation de l’autorité politique. Pour analyser cette phrase, recherchez les deux conditions associées à l’existence d’une constitution au sens du texte.

### Exercice 00-E4 — Lecture guidée

1. Présentez la nature, l’origine et la date du document en une phrase.

*Répondez dans votre cahier.*

2. Quelles sont les deux exigences énoncées ? Reformulez-les sans recopier toute la phrase.

*Répondez dans votre cahier.*

3. Expliquez pourquoi il s’agit d’un texte normatif.

*Répondez dans votre cahier.*

4. Un candidat écrit : « Ce texte prouve que ces deux exigences sont partout respectées en France dès 1789. » Peut-on conclure cela à partir du document ?

*Répondez dans votre cahier.*

5. Quel autre type de source permettrait d’étudier l’application d’un de ces principes ?

*Répondez dans votre cahier.*

Source S10, article 16 ; transcription typographique, sans coupe dans la phrase citée. Le texte intégral est accessible par le lien donné en fin de livret. Ce document de méthode ne remplace pas les jalons officiels de P01.

## 00-M04 — Faire une étude critique

**Critiquer un document ne signifie pas le dénigrer.** Il s’agit d’en comprendre l’apport et les limites en fonction de la question posée.

| Étape | Action à effectuer |
| --- | --- |
| 1. Situer | Identifier auteur, date, nature, destinataire et circonstances pertinentes. Un site de publication n’est pas nécessairement l’auteur. |
| 2. Comprendre | Déterminer le sujet et l’idée principale. Repérer les mots qui commandent le sens. |
| 3. Prélever | Sélectionner un passage court ou une donnée utile pour répondre à la question. |
| 4. Expliquer | Reformuler et relier à une connaissance précise ; éviter la simple répétition. |
| 5. Examiner les limites | Demander ce que le document montre, ce qu’il laisse de côté et ce qu’il ne peut pas prouver. |
| 6. Conclure | Répondre à la question avec une portée proportionnée aux informations disponibles. |

**DU MAUVAIS AU MEILLEUR**

Insuffisant : « L’auteur parle des droits. »
Plus précis : « L’article associe l’existence d’une constitution à des garanties concernant les droits et l’organisation des pouvoirs. Il établit donc un critère normatif, sans fournir une observation de son application. »

### Exercice 00-E5 — Distinguer trois opérations

Pour le document A, écrivez : une information tirée du texte ; une explication de cette information ; une limite du document. Trois phrases suffisent, mais elles doivent remplir trois fonctions différentes.

*Répondez dans votre cahier.*

L’étude critique de l’écrit de Terminale exige des documents et des connaissances, une organisation et une réponse à la problématique. Le présent exercice en isole une étape, sans reproduire tout le format de l’épreuve. ([S04](#ref-S04))

## 00-M08 — Passer de l’idée à l’argument

Un argument n’est ni un slogan, ni une suite de noms propres. Pour commencer, utilisez quatre opérations : **affirmer une idée, apporter un élément précis, expliquer son intérêt, limiter la conclusion**.

**QUESTION DE MÉTHODE**

Un texte proclamant des principes suffit-il à démontrer leur application ?

**Idée.** Un texte normatif ne suffit pas, à lui seul, à établir les pratiques.
**Élément précis.** Le document A formule deux conditions relatives aux droits et à l’organisation des pouvoirs.
**Explication.** Il définit ce qui devrait caractériser un ordre constitutionnel, mais ne décrit ni des décisions ni leur exécution.
**Limite et conclusion.** Il renseigne donc sur un idéal formulé dans le texte ; l’étude de son application demande d’autres sources.

### Exercice 00-E6 — Un raisonnement à réparer

« Il y a une consultation, donc le projet est démocratique. Les gens peuvent répondre. Cela prouve que tout le monde est d’accord. »

Identifiez deux sauts de raisonnement. Réécrivez le passage en quatre phrases, en signalant les informations qu’il faudrait connaître pour conclure davantage.

*Répondez dans votre cahier.*

### Se relire

Ma première phrase répond-elle à la question ? Mon exemple est-il précis ? Ai-je expliqué le lien ? Ai-je généralisé sans preuve ? Une phrase de nuance est utile lorsqu’elle corrige réellement la portée d’une affirmation.

Cette grille est une aide pédagogique. Elle n’impose pas quatre phrases par paragraphe ni un plan unique pour les compositions.

## Dossier Rivage : les pièces

**Tout le dossier ci-dessous est fictif et créé pour cet exercice.** Il sert à apprendre la lecture critique ; ce n’est ni une étude de cas historique, ni une annale du baccalauréat.

**F1 — COMMUNIQUÉ DE L’EXÉCUTIF MUNICIPAL**

« L’extension du port représente une chance pour Rivage. Elle pourrait créer 200 emplois. Notre consultation montre un soutien massif. Nous invitons le conseil municipal à approuver le projet le mois prochain. »
Document d’exercice daté du 12 avril, année fictive.

**F2 — NOTE SUR LA CONSULTATION**

Le questionnaire a été publié sur le site municipal du 1er au 10 avril. Répondre était volontaire. Deux cents réponses ont été enregistrées : 156 favorables et 44 défavorables. La note ne décrit ni la représentativité des répondants, ni un contrôle empêchant une même personne de répondre plusieurs fois.

**F3 — COMPTE RENDU D’UNE ASSOCIATION LOCALE**

L’association signale que le projet concerne aussi une zone humide et demande une étude sur les effets de l’extension. Elle estime que les documents techniques disponibles ne permettent pas encore de comparer le projet avec des solutions alternatives. Sa méthode d’expertise n’est pas précisée dans l’extrait.

### Informations de contexte fournies pour le cas

Le communiqué défend le projet ; la note décrit le recueil des réponses ; l’association formule des réserves. Aucun résultat d’étude d’impact, aucun décompte de la population et aucune décision finale ne sont fournis. Vous ne devez pas les inventer.

Les trois pièces ont été rédigées pour le présent module. Il serait incorrect de les citer comme documents d’une collectivité réelle. Vous pouvez résoudre les exercices suivants sans recherche sur Internet.

## Exploiter les pièces sans les surinterpréter

### Exercice 00-E7 — Consolidation (degré 1)

1. Présentez la nature et la fonction des trois pièces.
2. Dans F1, les 200 emplois sont-ils observés ou annoncés comme une possibilité ?
3. Calculez la part des réponses favorables parmi les réponses enregistrées. Écrivez une phrase avec le bon dénominateur.
4. Donnez deux informations manquantes qui empêchent de conclure sur l’opinion de tous les habitants.

*Répondez dans votre cahier.*

### Exercice 00-E8 — Maîtrise (degré 2)

Rédigez 120 à 150 mots répondant à la question : **Que permettent d’affirmer ces documents sur le soutien et les enjeux du projet ?** Mobilisez au moins deux pièces et distinguez constat, promesse et réserve.

*Répondez dans votre cahier.*

### Exercice 00-E9 — Approfondissement (degré 3)

Une personne affirme : « F1 vient de la mairie, donc il est neutre ; F3 vient d’une association, donc il est inutilisable. » Discutez cette affirmation. Proposez deux documents supplémentaires de nature différente et expliquez leur utilité.

*Répondez dans votre cahier.*

Aides graduées, à utiliser après une tentative : 1. Cherchez les verbes et le dénominateur. 2. Séparez ce qui est compté et ce qui est promis. 3. Organisez une réponse en deux idées : soutien recueilli ; limites et enjeux restant à examiner.

## 00-M09 — Construire un plan qui répond au sujet

En HGGSP, le plan organise une réponse. Il n’est pas une récitation automatique de trois chapitres. À l’écrit de Terminale, le texte officiel demande une introduction, plusieurs parties structurées et une conclusion ; il ne fixe pas un modèle « trois fois trois ». ([S04](#ref-S04))

### Une méthode en cinq étapes

**1. Délimiter.** Souligner les notions, les acteurs, l’espace et la période.
**2. Comprendre.** Reformuler ce que le sujet demande d’expliquer.
**3. Chercher.** Sélectionner les connaissances et exemples pertinents, sans tout conserver.
**4. Organiser.** Regrouper les idées en parties qui répondent à la même question.
**5. Vérifier.** S’assurer que la conclusion répondra au sujet et que les exemples prouvent réellement les idées.

**EXERCICE 00-E10 — UN PLAN DE TRAVAIL**

Question d’entraînement : « La consultation des habitants suffit-elle à établir le caractère démocratique d’une décision ? »
À partir du module, proposez une problématique et deux ou trois grandes idées. Ce n’est pas un sujet officiel de composition et il ne demande pas une dissertation de quatre heures.

*Répondez dans votre cahier.*

Pour l’introduction, définir le problème est plus important qu’ajouter une citation décorative. Une citation incertaine ou un chiffre inventé affaiblit le travail. Pour la conclusion, répondre précisément vaut mieux qu’une ouverture sans lien.

La méthode complète sera reprise avec des connaissances historiques et géopolitiques de chaque thème. Les cas fictifs de ce module ne sont pas des exemples à réutiliser comme faits réels dans une copie de bac.

## 00-M03 — Construire une fiche utile

Une fiche de jalon doit permettre de **retrouver un raisonnement**, pas seulement de réduire le cours en petites lettres. Voici une structure de travail à réutiliser quand vous étudierez un véritable jalon du programme.

| Rubrique | Votre question de contrôle |
| --- | --- |
| Titre et rattachement | Quel thème et quel axe ce jalon éclaire-t-il ? |
| Période, espace, acteurs | Puis-je expliquer chaque repère choisi ? |
| Trois à cinq idées essentielles | Ai-je distingué idée générale et fait précis ? |
| Un exemple analysé | Quel mécanisme ou quelle évolution montre-t-il ? |
| Une source | Est-elle identifiée et l’ai-je effectivement consultée ? |
| Une limite ou une nuance | Que dois-je éviter de généraliser ? |
| Deux questions de rappel | Puis-je y répondre sans regarder la fiche ? |

### Exercice 00-E11 — Une fiche de document, pas encore de jalon

Complétez pour le document A : son origine ; sa date ; son apport ; sa limite ; une question de rappel. Ne présentez pas cet article comme l’un des jalons officiels du thème démocratie.

*Répondez dans votre cahier.*

### La banque personnelle d’exemples

Plus tard, chaque exemple historique devra être daté, situé, sourcé et associé à un argument. Une mention comme « l’Union européenne » est trop générale : il faut choisir un cas et expliquer son utilité dans la réponse.

Les fiches n’effacent pas le cours. Si vous ne comprenez plus les liens entre les rubriques, reprenez l’explication rédigée puis refaites la fiche sans la recopier.

## 00-R1 et 00-R2 — Reprendre les bases du raisonnement

### 00-R1 — Dater et contextualiser

Distinguez la date d’un événement, celle de rédaction d’un document et celle de publication de sa copie numérique. Elles peuvent être différentes. Avant de comparer deux situations, précisez la période et l’espace.

**ENTRAÎNEMENT 00-R1**

Un discours prononcé en 1950 est publié dans une revue en 1951, puis numérisé en 2020. Quelle date sert à contextualiser les propos ? Quelles autres dates indiquez-vous pour décrire la transmission du document ?

*Répondez dans votre cahier.*

### 00-R2 — Ne pas transformer une succession en cause

Constater qu’un fait survient après un autre permet de décrire un ordre, pas d’établir à lui seul une causalité. Il faut chercher un mécanisme et examiner d’autres explications possibles.

**ENTRAÎNEMENT 00-R2**

Cas fictif : après l’ouverture d’une nouvelle route, la fréquentation du port augmente. Une entreprise conclut que la route explique à elle seule toute la hausse. Quelles informations faudrait-il examiner avant d’accepter cette conclusion ?

*Répondez dans votre cahier.*

### Une phrase à améliorer

« Cette réforme est bonne car elle est moderne. » Identifiez les termes imprécis. Proposez une question d’analyse et un critère vérifiable à la place du jugement général.

*Répondez dans votre cahier.*

Les corrigés indiquent des réponses possibles. Une proposition différente peut être recevable si elle identifie réellement une date, un mécanisme ou un critère pertinent.

## 00-R3 et 00-R4 — Limiter correctement ses conclusions

### 00-R3 — Vérifier l’échelle et le dénominateur

Une commune relève de l’échelle locale ; l’État, de l’échelle nationale ; le monde, de l’échelle mondiale. Un constat local ne décrit pas automatiquement l’ensemble du pays. Reprenez le lexique « Échelle » et les questions de l’exercice 00-E1.

Une proportion doit dire **parmi qui ou parmi quoi** elle est calculée. L’opinion des personnes qui répondent volontairement à une enquête ne décrit pas automatiquement celle d’une population entière.

**ENTRAÎNEMENT 00-R3**

Cas fictif : une association recueille 60 réponses, dont 45 favorables à un projet. Calculez la proportion de réponses favorables. Rédigez une phrase exacte, puis une phrase qui serait abusive.

*Répondez dans votre cahier.*

### 00-R4 — Examiner la nature d’une source

Un texte normatif renseigne sur des règles ou des principes. Un discours renseigne aussi sur les objectifs et la présentation d’un acteur. Une statistique dépend de sa méthode. Aucune de ces natures ne dispense d’examiner le document.

**ENTRAÎNEMENT 00-R4**

Cas fictif : une charte affirme que toutes les réunions sont ouvertes. Un extrait de calendrier donne les dates de trois réunions mais ne décrit pas l’accès. Peut-on affirmer que tous les habitants ont pu assister à chaque réunion ? Quel complément demander ?

*Répondez dans votre cahier.*

### Avant de consulter la correction

Soulignez le mot qui limite votre conclusion : « parmi les réponses », « dans cet extrait », « à cette date », « selon cet acteur ». Vérifiez ensuite que cette limitation correspond réellement à votre source.

Une formulation prudente ne doit pas devenir une esquive. Quand une donnée est établie, affirmez-la précisément ; limitez seulement ce que la preuve ne permet pas de généraliser.

## Bilan A — Analyser un petit dossier

**30 minutes. Travail individuel.** Ce bilan est formatif et original ; il n’imite pas toutes les exigences d’une épreuve officielle.

**NOUVEAU CAS FICTIF : CLAIRVAL**

Une charte municipale de l’année 2000 affirme que les décisions budgétaires doivent être rendues publiques. En 2025, un communiqué annonce : « Notre ville garantit désormais une transparence totale. » Une note jointe indique que 24 comptes rendus sur les 30 prévus pour l’année ont été publiés ; elle ne précise ni leur contenu ni les conditions d’accès. Ces informations sont inventées pour l’entraînement.

**A1.** Distinguez une règle, une affirmation d’acteur et une donnée de la note.
**A2.** Calculez la part des comptes rendus publiés, en écrivant le dénominateur.
**A3.** Expliquez ce que la note permet de conclure et ce qu’elle ne permet pas d’affirmer.
**A4.** Rédigez un paragraphe répondant : « Les pièces fournies suffisent-elles à établir une transparence totale ? »
**A5.** Proposez un document supplémentaire utile et une question relevant des sciences politiques.

*Répondez dans votre cahier.*

### Critères de réussite

Je distingue les types d’information ; je calcule et formule correctement ; je relie une pièce à un argument ; je signale une limite pertinente ; je propose une vérification adaptée. La correction donne une grille pédagogique, non une note officielle.

Consultez le compagnon seulement après avoir terminé. Identifiez ensuite une reprise prioritaire avant le bilan B.

## Bilan B — Revalider après la reprise

**30 minutes, à distance du bilan A.** Reprendre un format comparable sur d’autres données permet de vérifier votre méthode, plutôt que de restituer un corrigé mémorisé.

**NOUVEAU CAS FICTIF : BELRIVE**

Un règlement de 2010 prévoit l’accès aux pièces préparatoires avant chaque réunion du conseil. En 2025, le service municipal affirme que « l’information a toujours été intégralement disponible ». Le registre fourni compte 21 dossiers disponibles avant la réunion sur 28 dossiers examinés. Il ne précise pas les raisons des absences ni le nombre d’habitants ayant consulté les pièces.

**B1.** Distinguez une règle, une affirmation d’acteur et une donnée du registre.
**B2.** Calculez la part des dossiers disponibles avant la réunion.
**B3.** Expliquez la tension entre l’affirmation et les données, sans inventer d’intention.
**B4.** Rédigez un paragraphe répondant : « Peut-on parler d’une information toujours intégralement disponible ? »
**B5.** Proposez une vérification complémentaire et une question relevant de la géographie.

*Répondez dans votre cahier.*

Après correction, comparez les **méthodes** utilisées dans A et B : avez-vous réutilisé le bon dénominateur ? Distingué règle et application ? Répondu à la question sans généraliser ?

Ces bilans publiés dans le livret sont des exercices d’autoévaluation. Ils ne conviennent pas à une évaluation surveillée « non connue » après distribution intégrale.

## Organiser la suite de mon apprentissage

### Une séance autonome en cinq gestes

Lire la question de départ ; étudier le cours en cherchant les liens ; fermer le support et restituer ; produire un travail ; comparer à la correction et programmer une reprise. Gardez une trace de ce que vous avez effectivement écrit ou expliqué.

| Acquisition du module | Première tentative | Après reprise | Preuve conservée |
| --- | --- | --- | --- |
| Distinguer les approches HGGSP |  |  |  |
| Présenter une source |  |  |  |
| Séparer règle et pratique |  |  |  |
| Utiliser une proportion à bon escient |  |  |  |
| Construire un argument |  |  |  |
| Identifier une limite et une vérification |  |  |  |

Utilisez les mentions « à reprendre », « en cours » ou « réalisé sans aide », accompagnées d’une date. Ne cochez pas une compétence seulement parce que vous avez lu la correction.

### Réactivation suggérée

**À J+2** : présentez le document A et sa limite sans regarder le livret.
**À J+7** : expliquez pourquoi une consultation volontaire ne décrit pas automatiquement toute une population.
**À J+21** : prenez un document du premier thème étudié et refaites la grille 00-M04.

**PROCHAINE ÉTAPE**

Commencer le thème de Première « Comprendre un régime politique : la démocratie », avec ses deux axes et son objet de travail conclusif sur l’Union européenne. Le module vous donne une méthode de départ ; il ne dispense pas d’étudier les connaissances, les documents et les jalons de ce thème. ([S02](#ref-S02))

Les intervalles de réactivation sont des repères proposés. Adaptez-les à votre progression et à vos dates d’évaluation.

## Sources et usage du livret

Les définitions de travail et les exercices sont des rédactions pédagogiques originales. Le cas du port, Rivage, Clairval, Belrive et les situations de reprise sont explicitement fictifs. Ils ne doivent pas être cités comme des faits historiques ou des enquêtes réelles.

### Le document réel du module

**S10 — Déclaration du 26 août 1789 des droits de l’homme et du citoyen**, article 16. Transcription consultée sur Légifrance. Le site diffuse la source ; il n’en est pas l’auteur historique.

[Consulter le texte sur Légifrance](https://www.legifrance.gouv.fr/loda/id/JORFTEXT000000697056)

### Programme et épreuves

**S01–S03.** Éduscol, programmes de Première et de Terminale HGGSP, BO du 22 janvier et du 25 juillet 2019.

[Éduscol — programmes et ressources HGGSP](https://eduscol.education.gouv.fr/5802/programmes-et-ressources-en-histoire-geographie-geopolitique-et-sciences-politiques-voie-g)

**S04–S05.** Épreuve terminale HGGSP, note du 27 août 2025 ; évaluation ponctuelle de la spécialité non poursuivie, version consolidée de juin 2025.

[BO — épreuve terminale HGGSP à compter de 2026](https://www.education.gouv.fr/bo/2025/Hebdo33/MENE2521923N)

[Éduscol — évaluation ponctuelle, HGGSP pages 3–4](https://eduscol.education.gouv.fr/sites/default/files/document/ndsevaluations-ponctuelleseds-non-poursuivivoie-gjuin-2025pdf-100575.pdf)

**S06–S09.** Éduscol et BO : candidats individuels, Grand oral et coefficients. Les notices locales précisent l’inscription et l’organisation matérielle.

[Éduscol — candidats individuels](https://eduscol.education.gouv.fr/5694/candidats-individuels-au-baccalaureat-general-et-au-baccalaureat-technologique)

[Éduscol — Grand oral](https://eduscol.education.gouv.fr/5661/presentation-du-grand-oral)

Références consultées le 8 septembre 2026. Le registre complet est joint au kit. Les règles peuvent évoluer : consulter les sources pour votre session. Le livret de correction est accessible au candidat, après une première production.

# P01 — Comprendre un régime politique : la démocratie {#p01}

**Première • Parcours N1 ; fondations du parcours N2**

**Question directrice.** Comment faire exercer le pouvoir au peuple sans supprimer les libertés ni réduire la démocratie à un vote ?

**Contrat d’apprentissage.** À la fin du thème, vous devez pouvoir distinguer démocratie directe, représentation et délégation ; expliquer une rupture et une transition démocratiques ; analyser la double représentation des citoyens et des États dans l’Union européenne. Vous devez appuyer chaque réponse sur un cas précisément situé.

**Diagnostic P01-D — 10 minutes sans cours.** Un gouvernement élu peut-il prendre une décision antidémocratique ? Une monarchie est-elle nécessairement une dictature ? Quelle différence faites-vous entre choisir un représentant et voter directement une loi ? Les réponses et l’orientation figurent dans le compagnon sous **P01-D**.

**Parcours de travail.** Étudiez l’introduction et l’axe 1, puis réalisez E1–E2. Après l’axe 2, traitez E4–E5. Réservez E3 et E6–E8 à l’objet conclusif. Le degré 3 approfondit l’argumentation ; il n’est pas réservé au parcours N2. Une première lecture n’est pas une preuve de maîtrise : terminez par le test P01-RT, sans notes.

## Entrer dans le thème : des élections ne suffisent pas

Un régime politique organise l’accès au pouvoir, son exercice et son contrôle. Dans une démocratie, le pouvoir est réputé procéder du peuple. Mais la formule laisse plusieurs questions ouvertes : qui appartient au peuple des citoyens ? Qui décide effectivement ? Quels droits ne peuvent être supprimés par une majorité ? Comment remplacer pacifiquement les gouvernants ? L’existence d’élections ne résout donc pas, à elle seule, la question du caractère démocratique d’un régime. Une élection sans concurrence réelle, sans liberté d’expression ou sans possibilité de contestation n’a pas la même portée qu’un scrutin pluraliste.

La démocratie contemporaine associe généralement la souveraineté populaire, une compétition politique ouverte, des libertés publiques et un État de droit. Celui-ci signifie que l’exercice du pouvoir est soumis à des règles juridiques et à des contrôles, y compris lorsque ses détenteurs disposent d’une majorité. La séparation des pouvoirs ne suppose pas qu’ils soient hermétiquement isolés : elle vise à empêcher leur concentration et à organiser des contre-pouvoirs. La démocratie est ainsi une manière de décider, mais aussi un ensemble de garanties permettant de contester les décisions.

Les régimes autoritaires réduisent le pluralisme et rendent difficile l’alternance. Les régimes totalitaires, catégorie historique plus spécifique, visent une mobilisation et un encadrement de la société au nom d’une idéologie exclusive. Il faut éviter de qualifier indistinctement de « totalitaire » tout gouvernement qui restreint une liberté. Inversement, un régime peut conserver les institutions électorales tout en affaiblissant les médias, les juges ou les droits des opposants. Les transformations doivent donc être examinées concrètement plutôt que classées à partir d’un seul indice.

*Provenance : les trois paragraphes précédents, la question directrice et le contrat sont issus du fragment P01 récupéré. Les développements suivants sont une rédaction nouvelle. Cadre du thème : S02, p. 5 ; accompagnement : R-P01.*

### Comparer à partir de critères, non d’étiquettes

Une république se caractérise par une conception non héréditaire de la fonction souveraine ; cela ne garantit pas le pluralisme. Une monarchie parlementaire peut, au contraire, comporter un gouvernement responsable devant une assemblée élue et des libertés garanties. Il faut donc distinguer **forme de l’État**, **organisation des pouvoirs** et **pratiques politiques**. La démocratie n’est pas davantage synonyme d’unanimité : elle institutionnalise le désaccord et rend possible la révision d’une décision.

Pour comparer deux régimes, examinez la concurrence électorale, les droits de l’opposition, les libertés d’association et d’information, l’indépendance des juges et la possibilité réelle d’une alternance. Une constitution renseigne sur les règles proclamées ; elle doit être confrontée à des pratiques. Les indicateurs de démocratie peuvent aider, à condition de connaître leurs critères et de ne pas transformer un classement en explication. Une institution identique sur le papier peut fonctionner différemment selon la distribution des ressources, les habitudes de gouvernement et les capacités de mobilisation citoyenne.

## Axe 1 — Penser la démocratie : démocratie directe et démocratie représentative

### Être citoyen à Athènes au Ve siècle avant notre ère {#P01-AXE1-J01}

Athènes est une **cité**, communauté politique associant un centre urbain et le territoire de l’Attique. Les réformes de Clisthène, en 508–507 avant notre ère, contribuent à réorganiser le corps civique. Au Ve siècle, les citoyens participent à l’Ecclésia : ils délibèrent et votent notamment les décisions politiques, la guerre et la paix. Il ne s’agit pas d’élire périodiquement une assemblée qui déciderait à leur place. Cette participation directe donne un contenu concret à l’**isonomie**, égalité des citoyens devant la loi, et à l’**iségorie**, égalité de droit dans la prise de parole politique. ([R-P01](#ref-R-P01) ; [B01](#ref-B01))

La démocratie ne se réduit pourtant pas à l’assemblée. La Boulè prépare les affaires ; les magistrats exécutent les décisions ; les tribunaux populaires participent à la vie civique. Le tirage au sort et la rotation des charges limitent la monopolisation des fonctions par un petit groupe. Certaines fonctions, notamment militaires, sont électives : les stratèges sont choisis pour des compétences supposées. Les indemnités attachées à certaines charges facilitent la participation de citoyens modestes, sans faire disparaître les écarts de richesse, de disponibilité ou de maîtrise de la parole. Les orateurs influents et les réseaux sociaux comptent.

Le mot « peuple » désigne ici un corps politique restreint. Les femmes de familles citoyennes, les étrangers résidents appelés métèques et les esclaves ne participent pas à l’Ecclésia. La citoyenneté politique masculine repose sur des conditions de naissance et d’inscription ; la loi de Périclès de 451–450 resserre notamment l’exigence de filiation. Il faut distinguer l’appartenance à la communauté civique, qui concerne aussi les femmes, de l’exercice des droits politiques réservé aux hommes citoyens. **Directe ne signifie donc pas universelle.**

Une autre limite est extérieure : la cité qui développe la participation de ses citoyens exerce une domination sur des alliés au sein de la ligue de Délos. L’égalité interne d’un groupe ne garantit pas l’égalité entre tous les habitants ni entre les cités. L’intérêt du jalon n’est pas de déclarer Athènes « faussement démocratique », mais de comprendre comment un dispositif démocratique fonctionne dans un cadre social et impérial éloigné du nôtre.

**Point de méthode.** Dans une copie, associez toujours une institution à une opération : « l’Ecclésia permet aux citoyens de délibérer et de décider », et non « il y a l’Ecclésia, la Boulè et l’Héliée ». L’énumération ne montre pas le fonctionnement.

### Benjamin Constant : déléguer sans renoncer à la liberté {#P01-AXE1-J02}

En 1819, sous la Restauration, Benjamin Constant prononce *De la liberté des Anciens comparée à celle des Modernes*. Il écrit après les expériences révolutionnaires et napoléoniennes : son problème n’est pas seulement de définir le meilleur scrutin, mais de protéger les individus contre une souveraineté sans limites. Dans son raisonnement, la liberté des Anciens correspond principalement à la participation collective à la souveraineté ; celle des Modernes accorde une place centrale aux droits individuels, à la conscience, à l’expression et à la conduite des affaires privées. ([B02](#ref-B02))

Cette distinction est liée à une transformation des sociétés. Dans de grands États, chacun pèse moins directement sur la décision commune que dans une petite cité. Le commerce, les professions et la diversité des occupations rendent difficile une présence permanente aux assemblées. La représentation permet de confier la décision à des personnes choisies, tout en conservant un espace d’autonomie individuelle. Elle n’est donc pas seulement une solution technique à la distance : elle correspond à une conception du rapport entre personne et pouvoir.

Cependant, Constant ne demande pas aux citoyens d’abandonner les affaires publiques. Une délégation sans surveillance peut laisser les gouvernants affaiblir précisément les droits qu’ils devraient garantir. Les Modernes doivent conserver des moyens de participation, de contrôle et de contestation. L’opposition des deux libertés sert à penser leur articulation, non à justifier une indifférence politique générale. De même, l’Antiquité ne constitue pas un bloc uniforme : Athènes laisse davantage de place à certaines activités et libertés individuelles que l’image d’une communauté absorbant totalement l’individu ne le suggère.

La représentation a elle-même une histoire : au XIXe siècle, elle peut s’accommoder d’un suffrage censitaire qui exclut une grande partie de la population. Elle n’est donc pas automatiquement démocratique. Pour devenir démocratique au sens contemporain, elle doit être associée à l’élargissement du suffrage, au pluralisme et à la responsabilité des représentants. La question contemporaine n’est pas de choisir une fois pour toutes entre participation et représentation, mais de décider quels mécanismes permettent de les combiner sans affaiblir les droits.

**Comparaison utile.** Le tirage au sort recherche une égalité de chances d’accéder à une fonction ; l’élection sélectionne des candidats jugés préférables. Ni l’un ni l’autre ne suffit, isolément, à garantir un régime démocratique. Il faut examiner les pouvoirs confiés, leur durée et les contrôles.

## Axe 2 — Avancées et reculs des démocraties

### Tocqueville : les dangers internes d’une société démocratique {#P01-AXE2-J01}

Alexis de Tocqueville voyage aux États-Unis en 1831 et publie les deux volumes de *De la démocratie en Amérique* en 1835 et 1840. La démocratie désigne chez lui, au-delà des institutions, un état social marqué par l’**égalité des conditions** : les places ne sont plus légitimées exclusivement par une hiérarchie d’ordres héréditaires. Cette évolution ne signifie ni égalité des revenus ni disparition des discriminations. Tocqueville observe notamment une société où l’esclavage et la domination des populations autochtones contredisent l’universalité des principes proclamés. ([B03](#ref-B03))

Le premier danger est la **tyrannie de la majorité**. Une majorité peut utiliser sa puissance politique et sociale pour faire taire les minorités. Le risque n’est pas limité à une loi répressive : l’opinion dominante peut rendre coûteuse l’expression d’un désaccord et produire du conformisme. La règle majoritaire est un moyen de trancher ; elle ne prouve pas que la décision est juste et n’autorise pas la suppression des droits de ceux qui ont perdu le vote.

Un second danger apparaît lorsque des individus absorbés par leur bien-être privé se désintéressent de l’action commune. Un pouvoir central protecteur pourrait alors tout administrer, au prix d’une réduction progressive de l’autonomie. Ce **despotisme tutélaire**, parfois appelé « doux », ne doit pas être confondu avec la terreur des régimes totalitaires du XXe siècle. Tocqueville imagine une dépendance politique qui peut croître à l’intérieur même d’une société égalitaire.

Les libertés locales, les associations, une presse pluraliste et les contre-pouvoirs judiciaires favorisent l’apprentissage de l’action collective. Participer à une association apprend à négocier, à assumer des responsabilités et à ne pas attendre toute initiative de l’État. Tocqueville ne décrit donc pas un effondrement fatal de la démocratie : il identifie des tendances et des moyens de leur résister. Une copie réussie transforme ses notions en mécanismes, au lieu d’en faire des prédictions universelles.

### Chili, 1970–1973 : une démocratie renversée {#P01-AXE2-J02}

En septembre 1970, Salvador Allende, candidat de l’Unité populaire, arrive en tête de l’élection présidentielle sans majorité absolue ; le Congrès confirme son élection. Son projet est une transformation socialiste par les voies institutionnelles. Les nationalisations, la réforme agraire et les politiques de redistribution modifient les rapports économiques et sociaux. La nationalisation du cuivre en 1971 bénéficie d’un soutien parlementaire large, mais cela ne signifie pas un consensus durable sur l’ensemble de la politique gouvernementale. ([B04](#ref-B04) ; [R-P01](#ref-R-P01))

Le contexte de guerre froide internationalise le conflit. Les États-Unis s’opposent au gouvernement Allende et soutiennent des actions de déstabilisation documentées par les enquêtes et archives américaines. Ce rôle extérieur ne dispense pas d’examiner les acteurs chiliens : partis, patronat, syndicats, forces armées, mouvements populaires et fractions rivales de la gauche. Une explication unique par Washington effacerait leurs initiatives ; une explication purement intérieure négligerait des pressions importantes.

Les tensions économiques — inflation, difficultés d’approvisionnement, conflits sur la production — se combinent à une polarisation politique croissante. Le désaccord sur les réformes devient un conflit sur les règles mêmes de l’action collective. Le gouvernement et l’opposition s’affrontent dans les institutions et dans la rue ; l’armée prend une place décisive. Il faut distinguer l’analyse de cette crise de sa justification : expliquer pourquoi un coup d’État devient possible ne rend pas légitime la suppression des libertés.

Le 11 septembre 1973, les forces armées renversent le gouvernement. Allende meurt au palais de la Moneda. Une dictature militaire dominée par Augusto Pinochet s’installe, ferme l’espace politique et mène une répression massive. L’exemple montre qu’une tradition constitutionnelle et une élection régulière ne rendent pas la démocratie irréversible. Pour expliquer une rupture, reliez les tensions structurelles, les choix des acteurs et l’événement déclencheur, sans transformer le dénouement connu en fatalité.

### Portugal et Espagne : deux voies de transition, 1974–1982 {#P01-AXE2-J03}

Au Portugal, l’Estado Novo est un régime autoritaire, installé sous Salazar puis poursuivi par Marcelo Caetano. Les guerres coloniales menées en Afrique pèsent sur la société et l’armée. Le 25 avril 1974, le Mouvement des forces armées renverse le régime ; la mobilisation populaire accompagne cette révolution. La disparition de la dictature ouvre toutefois une période de confrontation sur l’avenir : démocratie pluraliste, transformations socialistes, place des militaires et décolonisation. Une transition est donc un processus, pas une cérémonie instantanée. ([B05](#ref-B05))

L’élection d’une Assemblée constituante en 1975, puis la Constitution de 1976, organisent de nouvelles règles. La stabilisation se poursuit ; la révision constitutionnelle de 1982 réduit la tutelle institutionnelle des militaires en supprimant le Conseil de la Révolution. Les élections, les partis et les garanties constitutionnelles transforment progressivement la rupture initiale en ordre politique durable. L’adhésion européenne, réalisée ensuite en 1986, ne doit pas être présentée comme un événement de la période 1974–1982.

En Espagne, la mort de Franco en novembre 1975 ouvre une succession prévue au sein du régime, mais la monarchie de Juan Carlos et le gouvernement d’Adolfo Suárez engagent une réforme. Les mobilisations sociales, les négociations entre acteurs et la légalisation des partis rendent possible une sortie de l’autoritarisme. Les élections de 1977 puis la Constitution de 1978 fondent une monarchie parlementaire, reconnaissent des libertés et organisent un État des autonomies. La tentative de coup d’État du 23 février 1981 rappelle la fragilité du processus ; l’alternance de 1982, avec la victoire socialiste, marque sa consolidation. ([B06](#ref-B06))

Comparer ne consiste pas à opposer une révolution populaire pure à une réforme venue seulement d’en haut. Dans les deux pays, les mouvements sociaux, les rapports de force et les choix des responsables interviennent. Le Portugal connaît une rupture militaire suivie d’une séquence révolutionnaire ; l’Espagne transforme une partie des institutions par des réformes et des compromis. Les deux trajectoires conduisent à des règles acceptées par des concurrents capables de perdre une élection sans détruire le régime.

## Objet de travail conclusif — L’Union européenne et la démocratie

### Une représentation des citoyens et une représentation des États {#P01-OTC-J01}

L’Union européenne n’est ni un État unitaire ni une simple organisation où les gouvernements décideraient sans intervention des citoyens. Elle combine plusieurs sources de légitimité. Le Parlement européen représente directement les citoyens ; ses membres sont élus au suffrage universel direct depuis 1979. Le Conseil européen réunit les chefs d’État ou de gouvernement et définit les grandes orientations. Le Conseil de l’Union européenne réunit les ministres compétents des États membres et participe, avec le Parlement dans la procédure législative ordinaire, à l’adoption des textes. ([D01](#ref-D01))

La Commission exerce notamment un rôle de proposition et de mise en œuvre ; elle n’est pas élue directement par l’ensemble des citoyens européens. Cela ne signifie pas qu’elle serait extérieure à toute responsabilité démocratique : sa désignation associe les institutions et elle est soumise à un contrôle parlementaire. La Cour de justice garantit le respect du droit de l’Union. Il ne faut confondre ni Conseil européen, ni Conseil de l’Union européenne, ni Conseil de l’Europe, organisation distincte de l’Union.

L’article 10 du traité sur l’Union européenne décrit une double chaîne de représentation. D’un côté, citoyens → Parlement européen ; de l’autre, citoyens → institutions nationales → gouvernements représentés dans les Conseils. La démocratie dite **déléguée** renvoie à ces médiations entre décisions européennes et mandats nationaux. Elles permettent d’associer des États de tailles différentes mais rendent plus difficile l’identification de la responsabilité politique : un gouvernement peut participer à une décision à Bruxelles puis la présenter chez lui comme une contrainte entièrement extérieure.

Il faut aussi distinguer légitimité d’entrée, fondée sur la participation et la représentation, et efficacité des résultats. Une politique efficace n’annule pas la question de son contrôle ; une procédure régulière ne garantit pas que tous les citoyens jugeront ses résultats satisfaisants. L’objet conclusif oblige donc à mobiliser les notions précédentes à plusieurs échelles, plutôt qu’à apprendre un organigramme isolé.

### Depuis 1992 : participation, souveraineté et contestations {#P01-OTC-J02}

Le traité de Maastricht, signé en 1992 et entré en vigueur en 1993, approfondit l’intégration et institue une citoyenneté européenne complémentaire de la citoyenneté nationale. Il contribue aussi à faire de l’Europe un objet plus visible de confrontation politique. Les référendums, les débats sur l’euro et les élargissements révèlent des attentes différentes : protection économique, ouverture, contrôle national ou capacité collective d’action. L’opposition à un traité ne signifie pas nécessairement un rejet de toute coopération européenne. ([D01](#ref-D01) ; [R-P01](#ref-R-P01))

En 2005, les électeurs français et néerlandais rejettent le traité établissant une Constitution pour l’Europe. Le traité de Lisbonne, entré en vigueur en 2009, reprend une partie des réformes institutionnelles sous une autre forme juridique. Ce parcours nourrit une discussion sur la place respective du vote référendaire, de la représentation parlementaire et de la négociation entre États. En 2016, le référendum britannique conduit au Brexit, réalisé en 2020 : l’intégration peut être contestée jusqu’à la sortie d’un État.

La crise de la zone euro, les conflits sur les politiques migratoires et les tensions relatives à l’État de droit mettent au jour des problèmes différents. Dans le premier cas, se pose notamment la question du contrôle de décisions économiques contraignantes ; dans le second, celle du partage de responsabilités ; dans le troisième, celle du respect des principes communs par les États membres. Les confondre sous une formule unique de « déficit démocratique » empêcherait de comprendre les mécanismes.

Les élections européennes, les initiatives citoyennes, les associations et les débats publics sont des voies de participation ; elles n’effacent pas les inégalités de ressources et d’accès. Une démocratie européenne plus lisible suppose de pouvoir attribuer les décisions, discuter leurs justifications et identifier les moyens de les modifier. La contestation peut fragiliser les institutions, mais elle peut aussi manifester une appropriation démocratique lorsque les acteurs acceptent le pluralisme et les règles communes.

## Documents et atelier de raisonnement

### P01-Doc1 — Deux circuits de représentation

**Nature : synthèse éditoriale, rédigée pour cette édition d’après l’article 10 du traité sur l’Union européenne ; ce n’est pas une citation. Source : D01.**

| Représentés | Intermédiaire | Institution européenne |
| --- | --- | --- |
| Citoyens de l’Union | Élection directe | Parlement européen |
| Citoyens dans leur État | Élections et responsabilité nationales | Gouvernement siégeant au Conseil ; dirigeant au Conseil européen |

Le traité énonce une architecture normative. Le tableau n’indique ni les taux de participation ni la confiance des citoyens. Il ne prouve pas que chaque électeur connaît les décisions de son gouvernement au Conseil.

**Exemple résolu.** « Le Parlement est élu, donc toute décision européenne est démocratique » est une conclusion trop large. Une formulation recevable serait : « L’élection du Parlement fournit une source directe de légitimité. Pour apprécier une décision précise, il faut aussi identifier la procédure suivie, les autres institutions impliquées et les contrôles disponibles. » L’amélioration ne consiste pas à remplacer une affirmation favorable par une affirmation défavorable, mais à proportionner la conclusion aux preuves.

### P01-Doc2 — Trois trajectoires politiques

**Nature : chronologie comparative originale ; faits historiques du cours, références B04–B06.**

| Pays | Ouverture ou crise | Issue et consolidation |
| --- | --- | --- |
| Chili | 1970 : élection d’Allende ; crise politique et économique | 1973 : coup d’État et dictature |
| Portugal | 1974 : révolution ; 1975 : Constituante | 1976 : Constitution ; 1982 : recul de la tutelle militaire |
| Espagne | 1975 : mort de Franco ; 1977 : élections | 1978 : Constitution ; 1981 : putsch échoué ; 1982 : alternance |

**À vous — activité guidée P01-A.** En 150 mots, expliquez pourquoi les trois lignes ne décrivent pas la même relation entre armée et démocratie. Utilisez une date par pays et distinguez renversement, ouverture et consolidation. Correction : compagnon P01-A.

## Synthèse à reconstruire sans regarder

Une démocratie associe souveraineté populaire, participation ou représentation et garanties contre l’arbitraire. Athènes fait participer directement un corps civique limité ; Constant défend la représentation sans abandonner la surveillance citoyenne ; Tocqueville explique comment la majorité et le retrait dans la vie privée peuvent fragiliser les libertés. Les trajectoires chilienne, portugaise et espagnole montrent que les régimes résultent de rapports de force et de choix, non d’une évolution automatique. L’Union européenne transpose la question démocratique à plusieurs échelles.

**Cinq repères à connaître :** Ve siècle avant notre ère ; 1819 ; 1835–1840 ; 1970–1982 ; 1992. Pour chacun, associez un acteur, un mécanisme et une limite. **Transfert vers N2 :** T02 pour les institutions de paix ; T06 pour la circulation des connaissances et le contrôle citoyen.

**Références du thème :** S02, R-P01 ; B01 (Aristote), B02 (Constant), B03 (Tocqueville), B04 (archives sur le Chili), B05 (Parlement portugais), B06 (Congrès espagnol), D01 (traité sur l’Union européenne). Les titres, liens et statuts des documents sont détaillés dans le registre commun.

## Entraînements — P01 {#P01-entrainements}

Les degrés 1, 2 et 3 désignent la difficulté, non les parcours N1/N2. Commencez sans aide ; consultez ensuite l’indice si nécessaire. Les corrections, les critères détaillés et les remédiations sont dans le compagnon, sous les mêmes identifiants.

### P01-E1 — Distinguer les régimes {#P01-E1}

**Degré 1 · 15 minutes · Méthode M1**

Classez et justifiez : A. une monarchie avec gouvernement responsable et élections pluralistes ; B. une république à parti unique ; C. une assemblée où tous les citoyens présents votent la décision. Quelles informations supplémentaires faut-il pour juger les garanties démocratiques ?

**Aide, après une première tentative.** Ne confondez pas la forme monarchique ou républicaine et les garanties démocratiques. Pour C, demandez qui possède la citoyenneté.

### P01-E2 — Athènes et les limites du peuple politique {#P01-E2}

**Degré 1 · 20 minutes · Méthode M5**

Rédigez dix lignes répondant à : « La participation athénienne était-elle universelle ? » Utilisez les mots Ecclésia, citoyen, métèque et exclusion. Distinguez participation directe et universalité des droits.

**Aide, après une première tentative.** Séparez deux questions : comment les décisions sont-elles prises et qui a le droit d’y participer ?

### P01-E3 — Lire une règle de représentation {#P01-E3}

**Degré 2 · 30 minutes · Méthode M3**

Dossier documentaire — synthèse éditoriale d’après l’article 10 du traité sur l’Union européenne ([D01](#ref-D01)). Le fonctionnement de l’Union est représentatif. Les citoyens sont directement représentés au Parlement européen. Les États le sont au Conseil européen par leurs dirigeants et au Conseil par leurs gouvernements, eux-mêmes démocratiquement responsables.

1. Identifiez la nature de la source sous-jacente. 2. Expliquez les deux circuits. 3. Le texte permet-il de mesurer la satisfaction des citoyens ? Rédigez 180 à 220 mots.

**Aide, après une première tentative.** La source sous-jacente est juridique. Distinguez représentation directe des citoyens et représentation des États ; séparez règle et pratique.

### P01-E4 — Comparer deux transitions {#P01-E4}

**Degré 2 · 30 minutes · Méthode M2**

Construisez un tableau Portugal/Espagne : situation initiale, rupture ou réforme de départ, rôle des acteurs, jalons de consolidation. Puis expliquez en huit lignes pourquoi « fin du dictateur = démocratie immédiate » est une mauvaise formule.

**Aide, après une première tentative.** Pour chaque pays, relevez une rupture initiale, deux acteurs et deux repères de consolidation. La mort d’un dirigeant n’est pas un système institutionnel.

### P01-E5 — Corriger une copie {#P01-E5}

**Degré 2 · 20 minutes · Méthode M5**

Copie fictive : « Tocqueville dit que la majorité a toujours raison. Constant propose de supprimer toute participation. L’élection d’Allende en 1970 prouve que le régime chilien ne pouvait plus être renversé. » Corrigez les trois erreurs puis formulez l’idée commune du passage.

**Aide, après une première tentative.** Dans les trois phrases, recherchez l’absolu : toujours, toute, ne pouvait plus. Remplacez-le par une relation historiquement justifiée.

### P01-E6 — Passer du thème au problème {#P01-E6}

**Degré 2 · 35 minutes · Méthode M6**

Sujet : « L’Union européenne : une démocratie représentative à plusieurs échelles ». Proposez une problématique, deux ou trois parties et au moins quatre exemples ou mécanismes précis. Ne rédigez pas tout le cours sur la construction européenne.

**Aide, après une première tentative.** Partir de l’article 10, puis distinguer architecture représentative et difficultés de participation ; ne pas dérouler les traités depuis 1951.

### P01-E7 — Composition autonome {#P01-E7}

**Degré 3 · 120 minutes · Méthode M8**

En deux heures : « Avancées et reculs des démocraties : des processus réversibles ». Appuyez-vous sur les cas de l’axe 2. Conservez le brouillon et notez les temps de travail.

**Aide, après une première tentative.** Utilisez l’axe 2 : Tocqueville pour les fragilités, Chili pour la rupture, Portugal et Espagne pour la construction. Comparez les mécanismes plutôt que les seules dates.

### P01-E8 — Expliquer à un non-spécialiste {#P01-E8}

**Degré 3 · 25 minutes · Méthode M11**

Préparez une réponse orale de trois minutes : « Voter suffit-il à faire vivre la démocratie ? » Utilisez un exemple antique et un exemple contemporain du cours. Ajoutez une objection à votre propre réponse.

**Aide, après une première tentative.** Préparez une réponse, deux exemples et une objection. Ne cherchez pas à faire entrer tout P01 dans trois minutes.

### P01 — QCM de vérification {#P01-qcm}

Une seule proposition correcte par question. Notez votre réponse et justifiez-la en une phrase ; la correction explique aussi pourquoi les autres propositions ne conviennent pas.

**P01-Q1.** La démocratie athénienne était directe parce que…

**A.** tous les habitants votaient

**B.** les citoyens participent eux-mêmes à certaines décisions

**C.** elle était sans institutions

**P01-Q2.** Constant justifie principalement la représentation par…

**A.** le changement d’échelle et la place des libertés individuelles

**B.** l’inutilité définitive du contrôle civique

**C.** l’interdiction du débat

**P01-Q3.** Le coup d’État chilien intervient en…

**A.** 1970

**B.** 1974

**C.** 1973

**P01-Q4.** Dans l’Union, le Conseil européen et le Parlement…

**A.** représentent exactement les mêmes acteurs par la même procédure

**B.** correspondent à des circuits de représentation distincts

**C.** n’ont aucun rapport avec les États

**P01-Q5.** Une majorité démocratiquement élue…

**A.** doit respecter les garanties de l’État de droit

**B.** dispose nécessairement d’un pouvoir sans limite

**C.** ne peut jamais être contestée

### P01-RT — Nouveau test et réactivation {#P01-RT}

**20 minutes, sans cours, à distance du premier entraînement.**

Sans notes : 1. Expliquez pourquoi l’exemple athénien associe participation et exclusion. 2. Comparez, avec deux faits précis, le renversement chilien et la transition portugaise. 3. Pourquoi la représentation européenne ne se réduit-elle pas à l’élection du Parlement ?

**Vérifier la maîtrise.** Réussite : trois réponses justifiées, avec notions distinguées et exemples situés. Une erreur de date appelle R1 ; une confusion de notion R2 ; une relation non expliquée R3. Refaire le point faible à J+2.

**Réactivation espacée.** J+7 : Restituer 1970, 1973 et 1974 avec leur pays et leur signification. J+21 : Comparer l’usage démocratique de l’information en P04 et les garanties de P01.

**Trace de progression.** Date : … · Je restitue : oui / à reprendre · J’explique : oui / à reprendre · Je mobilise dans un sujet nouveau : oui / à reprendre · Erreur prioritaire : … · Nouvelle tentative prévue : …

# P02 — Analyser les dynamiques des puissances internationales {#p02}

**Première • Parcours N1 ; passerelle centrale vers T01, T02 et T06**

**Question directrice.** Comment des acteurs acquièrent-ils la capacité d’agir sur le monde, et pourquoi leurs ressources ne suffisent-elles pas toujours à obtenir les résultats recherchés ?

**Objectifs.** Expliquer un essor et un affaiblissement sans récit de fatalité ; distinguer ressources, instruments et effets ; analyser la langue, les plateformes et les infrastructures ; situer les points d’appui de la puissance américaine.

**Diagnostic P02-D — 10 minutes.** Un grand territoire rend-il automatiquement puissant ? Une sanction économique relève-t-elle nécessairement du soft power ? Un film apprécié à l’étranger prouve-t-il un soutien à la politique de son pays d’origine ? Répondez avec une justification par question.

**Itinéraire.** Après l’introduction, réalisez E1. Étudiez les deux trajectoires historiques avant E2 et E5. L’axe 2 prépare E3–E4 ; l’objet conclusif prépare E6–E8. Réactivation : comparer, à J+7, un instrument ottoman et un instrument contemporain sans les assimiler.

## Introduction — La puissance est une relation

Une puissance est un acteur capable de peser sur le comportement d’autres acteurs, de défendre son autonomie et d’influencer les règles. Un État dispose de **ressources** : population, territoire, richesses, armée, institutions, compétences et réseaux. Il emploie des **instruments** : négociation, coopération, coercition, investissements, normes ou production culturelle. Il recherche des **effets** : faire agir, empêcher, faire accepter une règle ou préserver une liberté d’action. Ces trois niveaux ne se confondent pas. [S02, p. 6 ; R-P02]

Une armée puissante peut gagner une bataille sans stabiliser un territoire ; une ressource énergétique abondante peut procurer des revenus tout en créant une dépendance au marché mondial. La puissance doit donc être évaluée relativement à un objectif, à des adversaires et à une période. L’essor d’un autre acteur peut réduire une supériorité relative sans que les capacités du premier diminuent en valeur absolue. « Déclin » et « disparition » ne sont pas synonymes.

Le **hard power** agit par la contrainte ou les incitations matérielles ; il n’est pas exclusivement militaire. Une menace de sanction économique peut en relever. Le **soft power**, notion associée à Joseph Nye, désigne la capacité d’obtenir des effets par l’attraction et la légitimité. Une politique culturelle financée par un État n’a d’influence que si des publics l’acceptent. La combinaison des instruments doit être étudiée concrètement : l’expression « smart power » ne remplace pas l’analyse de leur cohérence. ([B09](#ref-B09) ; [R-P02](#ref-R-P02))

La puissance peut aussi être **structurelle** : fixer une norme, occuper une position centrale dans un réseau de paiement ou fournir un service numérique devenu indispensable modifie les choix possibles des autres. Enfin, les États ne sont pas seuls : firmes, organisations internationales, universités, diasporas et associations participent à ces relations. Leur influence peut servir un État, le concurrencer ou lui résister.

## Axe 1 — Essor et déclin des puissances : un regard historique

### L’Empire ottoman : expansion, adaptation, démantèlement {#P02-AXE1-J01}

Issu d’une principauté d’Anatolie à la fin du XIIIe siècle, le pouvoir ottoman s’étend progressivement dans les Balkans et au Proche-Orient. La prise de Constantinople par Mehmed II en 1453 marque une étape majeure : elle fournit un centre politique prestigieux et renforce le contrôle de passages entre Europe et Asie. Les conquêtes de 1516–1517 étendent la domination vers la Syrie et l’Égypte. Sous Soliman le Magnifique au XVIe siècle, l’Empire constitue une puissance territoriale, militaire et diplomatique de premier ordre. ([B07](#ref-B07) ; [R-P02](#ref-R-P02))

Cet essor ne s’explique pas par une prétendue supériorité intemporelle. L’organisation militaire, l’usage de l’artillerie, la capacité fiscale, l’administration et les alliances rendent les conquêtes possibles. Gouverner un empire exige aussi d’intégrer des populations diverses. Les arrangements avec les élites locales et les communautés religieuses permettent une domination différenciée ; ils ne correspondent ni à l’égalité citoyenne contemporaine ni à une uniformité absolue. Les détroits, les villes et les routes structurent un espace de circulation autant qu’un territoire à défendre.

À partir de la fin du XVIIe siècle, des défaites et des pertes territoriales, notamment consacrées par le traité de Karlowitz de 1699, modifient les rapports de force. Au XIXe siècle, les nationalismes, les interventions des puissances européennes et les dépendances financières accentuent les difficultés. Les réformes des **Tanzimat**, ouvertes en 1839, montrent toutefois que l’Empire cherche à réorganiser son administration, son armée et ses rapports avec les populations. Parler d’un déclin continu depuis le XVIe siècle effacerait ces transformations, les périodes de reprise et la diversité des provinces.

La Première Guerre mondiale précipite le démantèlement de l’Empire. La défaite de 1918, les projets de partage et les luttes nationales débouchent sur un nouvel ordre territorial. Le sultanat est aboli en 1922 ; la République de Turquie est proclamée en 1923. L’abolition du califat en 1924, étudiée en P05, concerne une autre institution. La fin d’un empire ne signifie donc pas l’effacement de tous ses héritages : frontières, populations, réseaux et mémoires continuent de peser sur les espaces qui lui succèdent.

**À retenir comme mécanisme.** Les ressources militaires permettent une expansion seulement si l’appareil fiscal et politique peut la soutenir. Quand les coûts de contrôle augmentent et que les concurrents se renforcent, une puissance doit se transformer ; l’issue de cette transformation n’est pas écrite d’avance.

### La Russie depuis 1991 : reconstruire une capacité d’action {#P02-AXE1-J02}

La disparition de l’URSS en décembre 1991 produit plusieurs États indépendants. La Fédération de Russie hérite d’une grande partie du territoire, de l’arsenal nucléaire soviétique et de la continuité du siège permanent au Conseil de sécurité, mais perd le contrôle direct d’espaces, de populations et de réseaux. Les années 1990 sont marquées par une crise économique et sociale, des privatisations conflictuelles et une forte recomposition des rapports de pouvoir. La taille territoriale ne suffit pas à empêcher cet affaiblissement. ([R-P02](#ref-R-P02) ; [B08](#ref-B08))

À partir des années 2000, le pouvoir russe renforce le contrôle politique central, bénéficie de revenus liés aux hydrocarbures et modernise une partie de ses forces armées. Les exportations énergétiques, les capacités nucléaires, la diplomatie et les réseaux d’information constituent des instruments complémentaires. Les relations avec les États issus de l’URSS sont un enjeu majeur : l’expression russe d’« étranger proche » traduit une représentation d’influence, non un droit de domination sur ces États souverains.

La guerre en Géorgie en 2008, l’annexion de la Crimée en 2014 et l’invasion à grande échelle de l’Ukraine lancée en février 2022 manifestent le recours à la force. L’Assemblée générale des Nations unies a condamné l’agression de 2022 et demandé le retrait des forces russes dans la résolution ES-11/1. Il faut distinguer les justifications avancées par un gouvernement des qualifications adoptées par les institutions internationales. Le vocabulaire de la « reconstruction de puissance » ne constitue pas une approbation des moyens employés. ([B08](#ref-B08))

La coercition peut produire des gains militaires tout en entraînant des coûts économiques, diplomatiques et humains, en suscitant des coalitions opposées ou en renforçant certaines dépendances. L’exportation de matières premières fournit des revenus mais expose aux prix, aux marchés et aux sanctions. Ce jalon permet donc d’opposer deux questions : **quelles capacités ont été reconstituées ?** et **quels résultats durables ont-elles permis d’obtenir ?** Une réponse rigoureuse évite aussi bien de présenter la Russie comme omnipotente que de la réduire à une puissance inexistante.

## Axe 2 — Formes indirectes de la puissance : une approche géopolitique

### Langues et influence : anglais, français, francophonie et instituts Confucius {#P02-AXE2-J01}

Une langue facilite l’accès aux marchés, à la formation, à la recherche et aux échanges diplomatiques. Sa diffusion produit des effets de réseau : plus elle est utilisée, plus il devient utile de l’apprendre. L’anglais bénéficie notamment des héritages de l’expansion britannique, de la puissance américaine et de sa place dans certaines communautés scientifiques et économiques. Ce poids ne résulte pas d’une propriété linguistique qui rendrait l’anglais naturellement supérieur. ([B09](#ref-B09) ; [R-P02](#ref-R-P02))

Le français conserve une fonction diplomatique et circule dans des espaces très divers. La **francophonie**, ensemble de pratiques et de locuteurs, ne se confond pas avec la **Francophonie institutionnelle**, structurée notamment autour de l’Organisation internationale de la Francophonie. Les centres de création, de croissance démographique et d’appropriation de la langue ne se limitent pas à la France. Des sociétés anciennement colonisées transforment la langue, la combinent à d’autres et peuvent l’utiliser pour critiquer les dominations. Il serait donc erroné de traiter tous les francophones comme des relais de la diplomatie française.

Les instituts Confucius, développés à partir de 2004, illustrent une politique de diffusion linguistique et culturelle liée à la Chine. L’apprentissage peut favoriser la connaissance mutuelle et les échanges ; les modalités de financement et de gouvernance peuvent aussi susciter des interrogations sur l’autonomie universitaire. Pour analyser un dispositif précis, il faut examiner ses conventions, ses activités et les décisions des établissements, et non attribuer les mêmes pratiques à toutes ses implantations.

L’influence linguistique ne se convertit pas mécaniquement en adhésion politique. On peut utiliser l’anglais tout en contestant la politique américaine, apprendre le chinois pour travailler sans soutenir un gouvernement, ou lire en français des auteurs critiques de la colonisation. La langue est un instrument et un espace d’appropriation. Dans une composition, expliquez la chaîne : diffusion → accès à des réseaux → familiarité ou dépendance → effets possibles, en indiquant où cette chaîne peut être interrompue.

### Géants du numérique : puissance privée, pouvoirs publics et normes {#P02-AXE2-J02}

Les plateformes organisent l’accès à l’information, au commerce, à la publicité, aux logiciels et aux infrastructures de calcul. Les sigles **GAFAM** et **BATX** du programme servent à désigner des groupes d’entreprises américaines et chinoises ; ils ne constituent ni une liste exhaustive ni une photographie permanente des dénominations et des marchés. L’essentiel est le mécanisme : effets de réseau, accumulation de données, économies d’échelle et intégration de services peuvent rendre la concurrence difficile. ([R-P02](#ref-R-P02) ; [B10](#ref-B10))

Une plateforme qui classe les contenus ne se contente pas de les transporter : elle sélectionne leur visibilité. Un fournisseur de cloud ou de système d’exploitation peut créer une dépendance technique. Les entreprises disposent ainsi d’un pouvoir d’organisation, mais elles ne sont pas des États souverains : elles dépendent de droits nationaux, d’infrastructures publiques, de contrats et de marchés. Elles peuvent négocier avec plusieurs gouvernements, tandis que ceux-ci cherchent à protéger la concurrence, les données, la sécurité ou leurs intérêts stratégiques.

L’Union européenne fournit un exemple de puissance par les règles. Le règlement général sur la protection des données, applicable depuis 2018, et les règlements sur les services et les marchés numériques montrent que les autorités publiques disposent d’instruments. Leur adoption ne prouve toutefois pas une application parfaite : les compétences techniques, les procédures, les sanctions et les coopérations restent déterminantes. L’opposition « firmes toutes-puissantes / États impuissants » est donc trop simple. ([B10](#ref-B10))

Il faut également distinguer contrôle d’une infrastructure, contrôle économique d’une entreprise et maîtrise effective de ses usages. Un service étranger peut être indispensable sans contrôler toutes les décisions de ses clients. À l’inverse, une entreprise nationale ne garantit pas à elle seule une autonomie technologique si elle dépend de composants, de brevets ou de logiciels extérieurs. Ce raisonnement prépare T06 : le cyberespace associe des couches matérielles, logiques et informationnelles.

### Les nouvelles routes de la soie : connecter et créer des interdépendances {#P02-AXE2-J03}

Annoncées à partir de 2013, les nouvelles routes de la soie désignent une initiative chinoise de coopération et d’infrastructures, souvent appelée BRI. Corridors ferroviaires, ports, routes, installations énergétiques et réseaux numériques visent à améliorer des connexions entre la Chine et de nombreux espaces. Le nom évoque une continuité historique valorisante, mais les projets contemporains relèvent de technologies, de financements et de rapports de force nouveaux. ([B11](#ref-B11))

Les infrastructures peuvent réduire des coûts de transport, ouvrir des marchés et fournir des débouchés aux entreprises qui les construisent. Elles peuvent aussi faciliter un approvisionnement ou contourner une vulnérabilité. Un port ou un corridor modifie l’organisation des territoires : il favorise certains pôles, en marginalise d’autres et mobilise du foncier. Pour les États partenaires, l’enjeu n’est pas seulement « accepter la Chine » ; il peut s’agir de financer un équipement, de négocier avec plusieurs investisseurs ou d’accroître leur capacité d’action régionale.

Les conséquences dépendent des contrats, de la rentabilité des projets, de la monnaie des emprunts, des garanties et des capacités de négociation. Un endettement important crée un risque, mais l’existence d’un prêt chinois ne démontre pas à elle seule une stratégie délibérée de capture. De même, la participation d’une entreprise chinoise à un port ne transforme pas automatiquement celui-ci en base militaire. Il faut distinguer propriété, concession, exploitation commerciale et usage stratégique.

L’exemple permet de comprendre la **géopolitique des réseaux** : relier des espaces peut accroître leur coopération tout en créant des dépendances. Une route n’abolit pas les frontières ; elle les traverse selon des règles, des contrôles et des intérêts. L’analyse doit donc associer la carte des corridors à celle des États, des points de passage et des acteurs financiers. Un schéma de raisonnement peut relier financement → construction → exploitation → circulation → négociation politique. Chaque flèche représente un mécanisme à vérifier, non une causalité automatique ni une carte exhaustive des projets de la BRI.

## Objet de travail conclusif — La puissance des États-Unis aujourd’hui

### Des lieux spécialisés reliés entre eux : New York, Hollywood et le MIT {#P02-OTC-J01}

La puissance américaine se construit dans un territoire organisé par des métropoles, des réseaux de transport, des universités et des pôles industriels. New York combine des fonctions financières, médiatiques et diplomatiques. Le siège de l’ONU lui apporte une centralité internationale ; il ne signifie pas que l’organisation appartient au gouvernement américain. Washington concentre des institutions politiques et des organes de décision, tandis que d’autres régions produisent des ressources agricoles, énergétiques, technologiques ou militaires. ([R-P02](#ref-R-P02) ; [B12](#ref-B12))

Hollywood illustre l’organisation industrielle de la production culturelle : financement, studios, acteurs, distribution et marchés mondiaux. Les œuvres diffusent des représentations et rendent des modes de vie familiers, mais leurs publics les interprètent de façons différentes. Une réussite commerciale ne vaut pas alignement diplomatique. Les industries culturelles peuvent d’ailleurs porter des critiques de la société dont elles sont issues ; l’attraction n’exige pas un message gouvernemental uniforme.

Le Massachusetts Institute of Technology, dans l’agglomération de Boston, représente un pôle de recherche et de formation lié à des laboratoires, des financements publics et privés et des entreprises. L’attraction d’étudiants et de chercheurs internationaux alimente ces compétences. Elle montre qu’une puissance nationale dépend aussi de circulations transnationales. La concentration des activités favorise les échanges de savoirs, les recrutements et les innovations ; elle peut simultanément renforcer les inégalités territoriales.

La bonne échelle d’analyse relie donc **lieux**, **fonctions** et **réseaux**. Dans un croquis, une métropole n’est pas un simple point prestigieux : sa légende doit expliquer ce qu’elle commande, produit ou connecte. Le territoire américain constitue une base de puissance, mais ses effets passent par des circuits mondiaux, des alliances et des interdépendances.

### Unilatéralisme et multilatéralisme : un choix de moyens, non une opposition morale simple {#P02-OTC-J02}

Le **multilatéralisme** organise une action avec plusieurs partenaires dans un cadre commun ; l’**unilatéralisme** privilégie une décision prise sans se soumettre à une négociation collective déterminante. Ces mots ne signifient ni désintérêt national d’un côté, ni isolement total de l’autre. Un État peut défendre ses intérêts par une institution multilatérale ou agir unilatéralement en conservant des alliés. ([R-P02](#ref-R-P02) ; [D09](#ref-D09))

La participation américaine à la création de l’ONU et aux institutions économiques de l’après-guerre associe un projet d’ordre international à des intérêts de puissance. En 1991, l’intervention contre l’Irak après l’invasion du Koweït s’inscrit dans une coalition autorisée par le Conseil de sécurité. En 2003, l’invasion de l’Irak conduite par les États-Unis et leurs alliés ne bénéficie pas d’une nouvelle autorisation explicite du Conseil ; les arguments juridiques avancés par ses partisans font l’objet de contestations. La présence d’une coalition ne suffit donc pas à établir le caractère multilatéral de la décision au sens institutionnel.

Les politiques américaines varient également selon les domaines et les administrations. Une coopération peut être maintenue dans la sécurité et contestée dans le commerce ou le climat. Le retrait, le retour puis le second retrait de l’accord de Paris, présenté en T05, donnent un exemple de cette variabilité. Les institutions limitent l’arbitraire et facilitent l’action collective, mais les États les évaluent aussi à partir de leurs coûts et de leur marge de manœuvre.

Pour argumenter, comparez des décisions datées, les partenaires concernés, les règles invoquées et les effets obtenus. Évitez « les États-Unis sont toujours… ». La continuité d’un intérêt — autonomie, sécurité ou accès aux marchés — peut s’accompagner d’un changement d’instrument.

### Points d’appui et zones d’influence dans un monde multipolaire {#P02-OTC-J03}

Les États-Unis s’appuient sur des alliances, des bases, des accords militaires, des routes maritimes, des réseaux financiers et des communautés scientifiques. L’OTAN structure une partie de leurs relations en Europe ; les alliances avec le Japon et la Corée du Sud sont des points d’appui en Asie orientale. Les dispositifs navals permettent de protéger des communications et de projeter des forces. La monnaie, les marchés et les normes techniques complètent ces instruments. ([B12](#ref-B12))

Une zone d’influence n’est pas nécessairement un territoire administré. Elle désigne un espace où un acteur dispose d’une capacité particulière à orienter des décisions, sans supprimer toute autonomie de ses partenaires. Un allié conserve des intérêts propres ; un État peut coopérer militairement avec Washington tout en commerçant avec la Chine. Les interdépendances ne se rangent pas toujours dans deux blocs homogènes.

La montée de la Chine et l’action d’autres puissances réduisent certains avantages relatifs et multiplient les négociations. La **multipolarité** désigne une distribution de capacités entre plusieurs pôles, mais ceux-ci ne sont ni égaux ni comparables dans tous les domaines. Un classement économique n’est pas une carte des alliances, et une capacité militaire ne donne pas le même pouvoir qu’une maîtrise des normes numériques.

Le bilan doit donc être raisonné : les États-Unis conservent des ressources diversifiées et des réseaux d’appui, mais rencontrent des résistances, des dépendances et des limites à la conversion de leurs moyens en résultats. La puissance n’est pas un capital que l’on posséderait une fois pour toutes ; elle se construit et se négocie dans des relations changeantes.

## Documents et atelier de raisonnement

### P02-Doc1 — Distinguer un instrument de son résultat

**Nature : tableau analytique original, d’après les mécanismes expliqués dans le cours ; aucune donnée chiffrée fictive n’est présentée comme mesurée.**

| Instrument | Effet recherché | Ce qu’il faudrait vérifier |
| --- | --- | --- |
| Institut de langue | Familiarité, formation, réseau | Publics touchés, pratiques et réception |
| Port financé par un partenaire | Connexion et débouchés | Contrat, trafic, coût, gouvernance |
| Plateforme numérique | Accès à un marché et fidélisation | Alternatives, données, règles et dépendances |
| Alliance militaire | Sécurité et influence | Engagements, moyens disponibles, autonomie des partenaires |

**Exemple résolu.** Un port construit n’est pas encore un trafic rentable ; un trafic rentable n’est pas encore un soutien diplomatique. Il faut identifier les étapes de la conversion. La formule « infrastructure donc domination » saute plusieurs relations causales : financement, exploitation, dépendance éventuelle et capacité du financeur à utiliser cette dépendance.

### P02-Doc2 — Deux ruptures d’ordre impérial

**Nature : chronologie comparative éditoriale ; sources R-P02, B07–B08.**

| Trajectoire | Rupture | Héritages et recompositions |
| --- | --- | --- |
| Empire ottoman | Défaite de 1918 ; abolition du sultanat en 1922 | Turquie républicaine, nouveaux États et frontières, mémoires impériales |
| URSS / Russie | Disparition de l’URSS en 1991 | États indépendants, arsenaux, réseaux et reconstructions de puissance |

**Activité P02-A.** Expliquez en 180 mots pourquoi « fin de l’empire » ne signifie pas « disparition de toute puissance ». Ne présentez pas la Turquie républicaine et la Russie comme deux trajectoires identiques. Correction : compagnon P02-A.

## Synthèse à reconstruire

Une puissance utilise des ressources par des instruments dont les effets dépendent des autres acteurs. Les empires peuvent s’étendre, se transformer puis se défaire sans suivre une loi universelle de déclin. Langues, plateformes et routes procurent des positions centrales et des capacités d’influence, mais leur réception et leurs conditions d’usage comptent. L’exemple américain combine territoires, réseaux, alliances et débats sur les modes d’action. **Un bon paragraphe de puissance montre une capacité, son fonctionnement et sa limite.**

**Repères :** 1453 ; 1699 ; 1839 ; 1991 ; 2013 ; 2014 ; 2022. **Notions :** empire, puissance relative, coercition, attraction, multilatéralisme, interdépendance. **Transferts :** mers et espace en T01 ; guerre et paix en T02 ; connaissance et cyberespace en T06.

**Références :** S02, R-P02 ; B07–B12 ; D09. Les faits postérieurs aux ressources d’accompagnement sont explicitement datés et renvoyés au registre d’actualisation.

## Entraînements — P02 {#P02-entrainements}

Les degrés 1, 2 et 3 désignent la difficulté, non les parcours N1/N2. Commencez sans aide ; consultez ensuite l’indice si nécessaire. Les corrections, les critères détaillés et les remédiations sont dans le compagnon, sous les mêmes identifiants.

### P02-E1 — Identifier les instruments {#P02-E1}

**Degré 1 · 15 minutes · Méthode M2**

Associez puis justifiez : sanction économique ; attractivité d’une université ; base militaire ; norme technique très utilisée. Les catégories hard power, soft power et pouvoir structurel sont-elles exclusives ?

**Aide, après une première tentative.** Classez par mécanisme : contrainte, attraction, organisation durable des choix. Un instrument peut combiner plusieurs effets.

### P02-E2 — Raconter sans déterminisme {#P02-E2}

**Degré 1 · 20 minutes · Méthode M2**

À partir du cours, choisissez quatre repères pour expliquer la trajectoire ottomane. Pour chacun, formulez une transformation. Terminez par une phrase qui refuse l’idée d’un déclin continu et inévitable.

**Aide, après une première tentative.** Choisissez des repères éloignés et expliquez une transformation, pas seulement une victoire ou une défaite.

### P02-E3 — Une alliance n’est pas un empire {#P02-E3}

**Degré 2 · 30 minutes · Méthode M4**

Document de travail : tableau établi d’après la chronologie publique de l’OTAN ([D07](#ref-D07)).

| État | Année d’adhésion |
|---|---|
| France et États-Unis | 1949 |
| Pologne | 1999 |
| Finlande | 2023 |
| Suède | 2024 |

Expliquez ce que ce tableau révèle sur les points d’appui de la puissance américaine. Donne-t-il une mesure complète de la puissance ou une preuve d’obéissance automatique de tous les alliés ?

**Aide, après une première tentative.** Le tableau porte sur des adhésions à une alliance, pas sur le PIB ou sur des votes unanimes à chaque crise.

### P02-E4 — Langue et numérique : comparer des mécanismes {#P02-E4}

**Degré 2 · 25 minutes · Méthode M5**

Réalisez deux chaînes de quatre maillons : une langue utilisée dans l’enseignement supérieur ; une plateforme numérique dominante. Pour chaque chaîne, ajoutez un acteur pouvant résister à cette influence.

**Aide, après une première tentative.** Pour chaque chaîne, passer d’une ressource à un comportement ou à une dépendance ; ajouter une possibilité de résistance concrète.

### P02-E5 — Réviser une affirmation excessive {#P02-E5}

**Degré 2 · 25 minutes · Méthode M5**

Copie fictive : « Les routes de la soie font de tous les pays partenaires des colonies chinoises. Leur seule fonction est de déplacer des marchandises. » Réécrivez en 150 mots en distinguant projet, mécanisme et résultat.

**Aide, après une première tentative.** Séparez l’annonce de 2013, les infrastructures ou financements, puis leurs effets variables ; le mot colonie exige plus qu’un contrat.

### P02-E6 — Construire une comparaison diachronique {#P02-E6}

**Degré 2 · 35 minutes · Méthode M6**

Proposez un plan pour : « Essor et déclin : les puissances se transforment-elles plutôt qu’elles ne disparaissent ? » Mobilisez Empire ottoman et Russie depuis 1991 ; distinguez transformations, ruptures et héritages.

**Aide, après une première tentative.** Comparer trois critères : cadre politique, ressources conservées et nouvelles stratégies. Ne pas faire de la Russie une simple URSS renommée.

### P02-E7 — Composition autonome {#P02-E7}

**Degré 3 · 120 minutes · Méthode M8**

En deux heures : « Les formes indirectes de la puissance ». Expliquez les mécanismes à partir des langues, du numérique et des nouvelles routes de la soie.

**Aide, après une première tentative.** Le cœur est l’axe 2 : langues, plateformes et routes de la soie. Expliquez attraction, structuration et dépendance, avec des limites.

### P02-E8 — Localiser une puissance en réseau {#P02-E8}

**Degré 3 · 25 minutes · Méthode M4**

Sur le carnet cartographique, localisez New York, Los Angeles/Hollywood et Boston/Cambridge. Préparez trois minutes expliquant pourquoi ces lieux ne représentent pas trois puissances américaines indépendantes.

**Aide, après une première tentative.** Le carnet fournit les localisations. Distinguez fonctions spécialisées et réseaux qui les relient au territoire national et au monde.

### P02 — QCM de vérification {#P02-qcm}

Une seule proposition correcte par question. Notez votre réponse et justifiez-la en une phrase ; la correction explique aussi pourquoi les autres propositions ne conviennent pas.

**P02-Q1.** Une ressource de puissance…

**A.** produit toujours le résultat attendu

**B.** doit être transformée en capacité d’action

**C.** est toujours militaire

**P02-Q2.** La disparition de l’URSS date de…

**A.** 1991

**B.** 1982

**C.** 2003

**P02-Q3.** Le soft power suppose notamment…

**A.** l’attraction et sa réception

**B.** l’annexion automatique

**C.** l’absence de tout financement

**P02-Q4.** Les nouvelles routes de la soie sont annoncées à partir de…

**A.** 1949

**B.** 1991

**C.** 2013

**P02-Q5.** Un multilatéralisme américain…

**A.** exclut toujours la poursuite d’intérêts nationaux

**B.** organise une action avec plusieurs partenaires dans un cadre commun

**C.** supprime tous les désaccords

### P02-RT — Nouveau test et réactivation {#P02-RT}

**20 minutes, sans cours, à distance du premier entraînement.**

1. Expliquez un instrument de puissance non militaire à partir d’un mécanisme. 2. Pourquoi l’Empire ottoman ne doit-il pas être raconté comme en déclin continu depuis sa naissance ? 3. Donnez un exemple de dépendance créée par une infrastructure.

**Vérifier la maîtrise.** Réussite : trois réponses justifiées, avec notions distinguées et exemples situés. Une erreur de date appelle R1 ; une confusion de notion R2 ; une relation non expliquée R3. Refaire le point faible à J+2.

**Réactivation espacée.** J+7 : Relier 1453, 1991 et 2013 à trois trajectoires distinctes. J+21 : Montrer comment une infrastructure spatiale ou numérique relie P02 à T01 ou T06.

**Trace de progression.** Date : … · Je restitue : oui / à reprendre · J’explique : oui / à reprendre · Je mobilise dans un sujet nouveau : oui / à reprendre · Erreur prioritaire : … · Nouvelle tentative prévue : …

# P03 — Étudier les divisions politiques du monde : les frontières {#p03}

**Première • Parcours N1 ; passerelle vers T01, T02 et T06**

**Question directrice.** Pourquoi des sociétés tracent-elles des frontières et comment une limite peut-elle simultanément séparer, organiser des échanges et devenir un objet de conflit ?

**Objectifs.** Distinguer tracer, matérialiser et reconnaître ; expliquer trois fonctions historiques ; raisonner sur les frontières maritimes ; comprendre l’articulation entre ouverture interne et contrôle externe dans l’Union européenne.

**Diagnostic P03-D — 10 minutes.** Une frontière suit-elle nécessairement un obstacle naturel ? Une zone économique exclusive est-elle une portion du territoire où tout passage étranger serait interdit ? Un travailleur qui franchit quotidiennement une frontière prouve-t-il sa disparition ? Justifiez chaque réponse.

**Itinéraire.** Introduction puis E1 ; axe 1 puis E2 et E5 ; axe 2 puis E3–E4 ; objet conclusif puis E6–E8. À J+7, comparez le Rhin romain et le Rhin contemporain en évitant de leur attribuer les mêmes fonctions.

## Introduction — Une construction politique, plusieurs matérialisations

La **frontière** est une limite politique qui sépare des espaces relevant d’autorités différentes. Elle n’est pas réductible à un mur. Sa forme peut être une ligne juridiquement définie, un ensemble de postes de contrôle ou une zone où s’exerce une autorité inégalement assurée. Une montagne ou un fleuve peuvent servir de support, mais ils ne décident pas du tracé : des acteurs choisissent de les retenir, de les franchir ou de les partager. La frontière dite « naturelle » reste donc une construction historique. ([S02](#ref-S02) ; [R-P03](#ref-R-P03))

Il faut distinguer la **délimitation**, définition juridique du tracé, la **démarcation**, matérialisation sur le terrain, et la **reconnaissance**, acceptation politique et juridique de la limite. Une frontière peut être précisément matérialisée tout en étant contestée. Inversement, une limite reconnue peut être peu visible. Enfin, une ligne de cessez-le-feu peut séparer des forces sans constituer une frontière internationale définitivement reconnue.

La multiplication des États à la suite des décolonisations et de la disparition de fédérations a augmenté le nombre de frontières internationales. Dans le même temps, les échanges et les mobilités se sont intensifiés. Ces évolutions ne s’annulent pas : un poste frontière sélectionne des personnes, des marchandises et des informations selon leur statut. On peut ainsi ouvrir à certains flux et fermer à d’autres. Une frontière fonctionne comme une **interface** lorsqu’elle met en relation des espaces différenciés ; les écarts de salaires, de prix, de droit ou de langue peuvent précisément susciter les échanges.

## Axe 1 — Tracer des frontières, approche géopolitique

### Le limes rhénan : défendre, surveiller, organiser {#P03-AXE1-J01}

Le limes rhénan appartient au système de frontières de l’Empire romain. Sur le Rhin inférieur, des camps, des voies, des installations fluviales et des établissements civils forment un dispositif progressivement consolidé. Il ne s’agit pas d’un mur continu comparable à toutes les fortifications romaines : le fleuve, les forteresses et les communications composent ensemble la limite. La géographie fluviale facilite le déplacement des troupes et des approvisionnements autant qu’elle constitue un obstacle. ([B13](#ref-B13) ; [R-P03](#ref-R-P03))

La fonction militaire est centrale : surveiller des passages, abriter des soldats, soutenir des opérations et manifester la présence impériale. Mais le limes n’isole pas deux mondes totalement étrangers. Des échanges commerciaux, des circulations de personnes, des négociations et des recrutements franchissent la limite. Les installations militaires attirent artisans, commerçants et familles. La frontière produit ainsi des espaces de contact et des formes d’urbanisation.

Ce dispositif exprime aussi une capacité de gouvernement : construire, entretenir et ravitailler des forts suppose des ressources fiscales, des routes et une organisation. La frontière romaine protège un espace dominé, mais permet également d’agir au-delà de celui-ci. L’opposition entre une « civilisation » enfermée derrière une barrière et un extérieur homogène reprendrait une représentation impériale au lieu de l’analyser. Les populations extérieures sont diverses ; leurs relations avec Rome varient selon les lieux et les périodes.

Dans une réponse, partez d’un élément matériel — camp, route, port — puis expliquez les fonctions qui lui sont associées. **Le même aménagement peut servir la défense et la circulation.** Ce jalon prépare la comparaison avec les frontières contemporaines : il existe des continuités fonctionnelles, mais ni la souveraineté nationale, ni les catégories de nationalité actuelles ne doivent être projetées sur l’Empire romain.

### La conférence de Berlin : négocier entre puissances sans représenter les populations dominées {#P03-AXE1-J02}

Réunie de novembre 1884 à février 1885 à l’initiative de Bismarck, la conférence de Berlin intervient dans un contexte d’expansion coloniale européenne en Afrique. Des puissances cherchent à organiser leurs rivalités commerciales et territoriales, notamment autour du bassin du Congo. Les sociétés africaines concernées ne disposent pas d’une représentation leur permettant de décider à égalité de leur avenir. Cette exclusion est un élément du rapport de domination, et pas un simple détail diplomatique. ([B14](#ref-B14) ; [R-P03](#ref-R-P03))

La conférence n’a pas dessiné en quelques semaines toutes les frontières actuelles de l’Afrique. Son acte général règle notamment des questions de commerce et de navigation, ainsi que la notification de certaines prises de possession et les exigences d’autorité effective sur les territoires concernés. Les conquêtes, traités inégaux, négociations entre puissances et résistances africaines poursuivent ensuite la production des espaces coloniaux. Une carte du partage à une date donnée ne doit donc pas être présentée comme la transcription directe d’une seule réunion.

Les tracés servent des projets impériaux : contrôler des ressources et des routes, éviter une confrontation avec un concurrent ou consolider une administration. Certains s’appuient sur des cours d’eau, d’autres sur des lignes géométriques ou sur des arrangements locaux. Ils peuvent couper des espaces de circulation et réunir des populations différentes, mais il serait erroné d’imaginer une Afrique précoloniale sans pouvoirs territoriaux ni limites. La singularité coloniale réside dans l’imposition extérieure et asymétrique des nouvelles souverainetés.

Après les indépendances, les États africains privilégient largement le maintien des frontières héritées afin de limiter les guerres de révision territoriale. Ce choix n’efface ni les violences de leur formation ni les revendications locales. Le jalon permet de distinguer **origine d’une frontière**, **effets sociaux** et **choix politiques ultérieurs**. Une limite d’origine coloniale peut devenir un cadre de citoyenneté et de coopération ; elle ne produit pas mécaniquement chaque conflit qui survient près d’elle.

### Les deux Corées : séparer des systèmes et stabiliser un arrêt des combats {#P03-AXE1-J03}

À la fin de la domination japonaise en 1945, la péninsule coréenne est divisée en zones d’occupation soviétique et américaine autour du 38e parallèle. Deux États sont constitués en 1948. La guerre commencée en 1950 internationalise cette division : interviennent notamment les forces du Commandement des Nations unies, dominées par les États-Unis, et les volontaires chinois aux côtés du Nord. L’armistice du 27 juillet 1953 interrompt les combats sans constituer un traité de paix. ([B15](#ref-B15) ; [R-P03](#ref-R-P03))

La ligne de démarcation militaire de 1953 suit la ligne de contact des forces ; elle ne coïncide donc pas exactement avec le 38e parallèle. Le retrait de deux kilomètres de chaque côté forme une zone démilitarisée d’environ quatre kilomètres de largeur. L’appellation ne signifie pas que l’ensemble de la région serait sans présence militaire : les abords sont fortement surveillés et les conditions de circulation strictes. Il faut distinguer le statut de la bande de séparation et l’organisation militaire qui l’entoure.

La division sépare des systèmes politiques, économiques et sociaux qui se sont transformés de façon très différente. Elle entraîne des ruptures familiales, des contraintes de déplacement et des usages symboliques du territoire. Des périodes de dialogue ont permis des rencontres, des projets de coopération et des ouvertures limitées ; leur fragilité rappelle qu’une frontière peut changer de degré d’ouverture sans changer immédiatement de tracé. Les accords et projets doivent toujours être datés : une initiative passée n’est pas la preuve d’une circulation libre aujourd’hui.

L’exemple montre enfin les effets d’échelle. La limite concerne les populations coréennes, mais sa stabilité dépend aussi de puissances extérieures, d’alliances et de stratégies nucléaires. Une analyse géopolitique ne se réduit ni à une photographie des barbelés ni à une opposition abstraite entre deux blocs. Elle relie **héritage d’une guerre, dispositifs concrets et rapports de force régionaux**.

## Axe 2 — Les frontières en débat

### La frontière germano-polonaise de 1939 à 1990 : du déplacement à la reconnaissance {#P03-AXE2-J01}

L’invasion de la Pologne par l’Allemagne nazie en septembre 1939, suivie de l’entrée des forces soviétiques à l’est, bouleverse les frontières et s’accompagne de violences de masse. À la fin de la Seconde Guerre mondiale, le territoire polonais est déplacé vers l’ouest : des territoires orientaux sont intégrés à l’URSS tandis que la Pologne administre des territoires auparavant allemands à l’est de l’Oder et de la Neisse. Les décisions alliées, notamment à Potsdam en 1945, s’articulent avec des déplacements et expulsions de populations. ([B16](#ref-B16) ; [R-P03](#ref-R-P03))

Une frontière ne se comprend donc pas uniquement par son trait sur une carte. Les changements de souveraineté transforment les appartenances, les propriétés, les noms de lieux et les mémoires. Pour les populations déplacées, l’espace peut devenir le support de récits de perte ; pour les nouveaux habitants et l’État polonais, la stabilisation territoriale constitue un enjeu de sécurité. Reconnaître ces expériences n’impose pas de reprendre une revendication territoriale.

La RDA reconnaît la ligne Oder-Neisse en 1950. La RFA, dans le contexte de l’Ostpolitik de Willy Brandt, signe avec la Pologne le traité de Varsovie en 1970, qui affirme notamment l’inviolabilité de la frontière. La question de son règlement définitif reste liée à celle de l’unité allemande. En 1990, le règlement international accompagnant l’unification et le traité frontalier germano-polonais confirment la frontière existante. Il faut donc expliquer une succession de reconnaissances, et non affirmer que la limite aurait soudain été tracée en 1990.

Ce jalon distingue **fait territorial**, **reconnaissance diplomatique** et **acceptation mémorielle**. Le droit peut stabiliser une limite alors que les souvenirs restent pluriels. La coopération européenne transforme ensuite les usages de la frontière sans abolir les États : le passage quotidien et les projets communs deviennent compatibles avec la reconnaissance mutuelle de la souveraineté.

### Partager la mer : un droit des espaces et des ressources {#P03-AXE2-J02}

La Convention des Nations unies sur le droit de la mer, signée à Montego Bay en 1982 et entrée en vigueur en 1994, organise les espaces maritimes. Les distances se mesurent depuis des **lignes de base**, et non automatiquement depuis le centre d’un port. La mer territoriale peut s’étendre jusqu’à 12 milles marins ; l’État y exerce sa souveraineté, sous réserve notamment du passage inoffensif. La zone économique exclusive peut atteindre 200 milles marins depuis les lignes de base : l’État y possède des droits souverains sur les ressources, mais pas une souveraineté territoriale générale interdisant toute navigation étrangère. [D02, art. 2–3, 17, 55–58]

Le plateau continental concerne le fond et le sous-sol, non toute la colonne d’eau. Sous certaines conditions prévues par la convention, ses limites extérieures peuvent dépasser 200 milles. Il ne faut donc pas dessiner des anneaux équivalents en supposant qu’à chaque distance correspond le même ensemble de droits. La haute mer et les fonds marins situés au-delà des juridictions nationales relèvent également de régimes distincts.

Lorsque les côtes sont proches, les prétentions se chevauchent : la distance maximale ne garantit pas à chacun un espace complet de 200 milles. Des accords ou des règlements juridictionnels doivent définir une délimitation équitable. Les îles, les ressources halieutiques, les hydrocarbures et les routes renforcent les enjeux. La convention fournit des règles et des procédures ; elle ne supprime pas les conflits d’interprétation ni les rapports de force.

**Document P03-Doc1 — Synthèse éditoriale du droit de la mer, d’après D02.**

| Espace | Repère maximal usuel | Droit à distinguer |
|---|---|---|
| Mer territoriale | 12 milles depuis les lignes de base | Souveraineté avec obligations, dont le passage inoffensif. |
| ZEE | 200 milles depuis les lignes de base | Droits souverains sur les ressources ; libertés de navigation préservées. |
| Plateau continental | Fond et sous-sol ; extension encadrée possible | Droits sur des ressources du fond, sans appropriation générale des eaux. |

Ce tableau est une **adaptation pédagogique**, pas une citation intégrale de la convention. Un mille marin vaut 1 852 mètres. La carte-schéma de l’atlas montre pourquoi les 200 milles incluent la bande des 12 milles dans la mesure depuis les lignes de base.

## Objet de travail conclusif — Les frontières internes et externes de l’Union européenne

### Schengen : déplacer et différencier les contrôles {#P03-OTC-J01}

L’accord de Schengen de 1985 puis sa mise en application en 1995 organisent la suppression des contrôles systématiques des personnes à certaines frontières intérieures. L’espace Schengen ne se confond ni avec l’Union européenne, ni avec la zone euro. Des États non membres de l’UE y participent ; tous les États de l’UE n’y sont pas intégrés de la même façon. Au point de vérification du 8 septembre 2026, il réunit 29 États ; les contrôles terrestres internes avec la Bulgarie et la Roumanie ont été levés le 1er janvier 2025. ([D04](#ref-D04))

L’ouverture intérieure suppose des règles communes concernant les frontières extérieures, les visas et la coopération entre autorités. Frontex intervient en appui des États ; sa présence ne signifie pas qu’une institution européenne remplace toutes les compétences nationales. Les contrôles peuvent utiliser des bases de données, des vérifications en amont ou des opérations éloignées de la ligne. La frontière devient un dispositif distribué, et pas seulement une barrière à franchir.

Le droit prévoit aussi, dans des conditions encadrées, la réintroduction temporaire de contrôles intérieurs. Cela ne supprime pas juridiquement l’espace Schengen. Les crises sanitaires, les préoccupations sécuritaires et les politiques migratoires mettent en tension mobilité, souveraineté et droits fondamentaux. Un contrôle plus intense ne doit pas être décrit comme nécessairement efficace sans examiner ses objectifs et ses conséquences. Il faut également distinguer demande d’asile, migration de travail et déplacement touristique : ces situations relèvent de cadres différents.

### Les frontières de la France : changer d’échelle {#P03-OTC-J02}

La France fournit un exemple d’État membre dont les frontières possèdent plusieurs statuts. En Europe, certaines limites terrestres sont intérieures à Schengen et séparent néanmoins des législations, des administrations et des systèmes fiscaux. Le lien avec le Royaume-Uni associe, depuis le Brexit, frontière de l’UE, échanges économiques et dispositifs de contrôle spécifiques. Une frontière peut donc être ouverte à des flux importants tout en demandant des formalités accrues. ([R-P03](#ref-R-P03) ; [D04](#ref-D04))

Les territoires ultramarins rappellent que la carte métropolitaine ne suffit pas. La Guyane partage des frontières terrestres avec le Brésil et le Suriname ; les espaces maritimes français s’étendent dans plusieurs océans. Les régimes européens et Schengen applicables à l’outre-mer ne sont pas tous identiques. On ne doit donc pas colorier indistinctement tout territoire français comme une même frontière extérieure de Schengen. Pour une étude locale, identifier d’abord le statut juridique précis est une étape indispensable.

La France agit à plusieurs échelles : État, collectivités, coopération bilatérale et politiques européennes. Les choix de sécurité et de circulation rencontrent les besoins des habitants, des entreprises et des associations. L’analyse gagne à partir d’un passage concret — pont, gare, port — puis à remonter vers les normes et les acteurs qui l’organisent. Le « retour des frontières » peut ainsi désigner le retour de certains contrôles, non la réapparition d’une limite qui aurait cessé d’exister.

### Vivre la frontière : les espaces transfrontaliers {#P03-OTC-J03}

Dans le Rhin supérieur, les relations entre territoires français, allemands et suisses permettent d’observer des mobilités de travail, d’études, de consommation et de services. Les écarts de salaires, les spécialisations économiques et la proximité géographique stimulent les déplacements. La frontière est une ressource parce qu’elle met en contact des systèmes différents ; elle reste aussi une contrainte lorsque langues, tarifs, fiscalité ou reconnaissance des qualifications compliquent les parcours. ([B17](#ref-B17) ; [R-P03](#ref-R-P03))

La coopération transfrontalière cherche à traiter ces difficultés : transports collectifs, projets environnementaux, santé, formation et gouvernance partagée. Le tramway Strasbourg–Kehl, mis en service transfrontalier en 2017, est un exemple de connexion matérielle. Une ligne de transport ne fait cependant pas disparaître les compétences des autorités. Elle exige financement, accords techniques et coordination des réseaux. Les dispositifs européens de coopération contribuent à cette organisation sans produire une fusion des territoires.

**Document P03-Doc2 — Lire un espace transfrontalier.** Tableau éditorial, sans données statistiques inventées.

| Pratique | Ce que permet la proximité | Ce que maintient la frontière |
|---|---|---|
| Travailler de l’autre côté | Accéder à un marché de l’emploi voisin. | Règles fiscales, sociales et qualifications à articuler. |
| Utiliser un transport commun | Relier des pôles urbains complémentaires. | Autorités organisatrices et financements distincts. |
| Gérer un risque fluvial | Partager des observations et des alertes. | Responsabilités et procédures nationales à coordonner. |

**Exemple résolu.** « Un pont abolit-il une frontière ? » Non : il réduit un obstacle matériel et facilite des flux, mais le droit, les différentiels économiques et les contrôles éventuels subsistent. L’argument complet relie donc l’aménagement à ses usages et à ses conditions institutionnelles. Dire seulement « les échanges augmentent » ne démontre pas une disparition politique.

## S’entraîner, retenir, transférer

**Activité guidée P03-A — 20 minutes.** À partir des deux tableaux, rédigez deux paragraphes opposant la nature des droits dans une ZEE et la nature des différenciations dans un espace transfrontalier. Employez « souveraineté », « droits souverains » et « interface » sans les rendre synonymes. Terminez par une limite de la comparaison.

**Synthèse.** Les frontières sont produites par des rapports de force, des accords et des pratiques. Elles peuvent défendre un empire, organiser un partage colonial ou stabiliser un armistice. Leur reconnaissance se construit parfois sur plusieurs décennies. Sur mer, la différenciation des droits impose de distinguer souveraineté et maîtrise des ressources. En Europe, ouverture et contrôle se recomposent à plusieurs échelles. Une bonne copie demande toujours : **qui trace, selon quelle règle, pour quels flux et avec quels effets sur les populations ?**

**Repères à maîtriser.** 1884–1885 : conférence de Berlin ; 1939–1945 : bouleversements polonais ; 1953 : armistice coréen ; 1970 puis 1990 : étapes de reconnaissance germano-polonaise ; 1982/1994 : convention sur le droit de la mer ; 1985/1995 : accord puis mise en application de Schengen. Vérifiez les fonctions de chaque date plutôt que d’apprendre une succession sans explication.

**Transfert.** Pour T01, expliquer pourquoi une ressource maritime ne suffit pas à déterminer une délimitation. Pour T06, montrer qu’un réseau numérique transfrontalier reste installé dans des territoires soumis à des autorités.

**Références du chapitre.** S02 ; R-P03 ; B13 à B17 ; D02 ; D04. Le registre précise nature, auteur, date et provenance. Les documents P03-Doc1 et Doc2 sont de nouvelles synthèses pédagogiques ; les exercices récupérés sont identifiés dans la banque.

## Entraînements — P03 {#P03-entrainements}

Les degrés 1, 2 et 3 désignent la difficulté, non les parcours N1/N2. Commencez sans aide ; consultez ensuite l’indice si nécessaire. Les corrections, les critères détaillés et les remédiations sont dans le compagnon, sous les mêmes identifiants.

### P03-E1 — Employer le mot frontière {#P03-E1}

**Degré 1 · 20 minutes · Méthode M2**

Expliquez pourquoi ces expressions ne sont pas interchangeables : mur, frontière internationale, ligne de cessez-le-feu, interface. Donnez un exemple précis pour deux d’entre elles.

**Aide, après une première tentative.** Une frontière est une limite politique ; un mur est un aménagement ; une ligne de cessez-le-feu a un statut particulier ; une interface décrit une fonction.

### P03-E2 — Berlin sans légende simplificatrice {#P03-E2}

**Degré 1 · 20 minutes · Méthode M5**

Rédigez huit lignes corrigeant : « En 1885, les Européens ont dessiné d’un seul coup toutes les frontières africaines autour d’une table. » Mentionnez ce que la conférence organise et ce qu’elle ne suffit pas à expliquer.

**Aide, après une première tentative.** Distinguez les règles adoptées à Berlin et les conquêtes, négociations et tracés qui se poursuivent ensuite.

### P03-E3 — Lire un dispositif de mobilité {#P03-E3}

**Degré 2 · 30 minutes · Méthode M3**

Document — synthèse éditoriale d’après le Conseil de l’Union européenne ([D04](#ref-D04)), état consulté en septembre 2026. Schengen supprime en principe les contrôles systématiques des personnes aux frontières intérieures entre participants. Il organise aussi la coopération et la gestion des frontières extérieures. Des États non membres de l’UE y participent ; tous les membres de l’UE n’y appliquent pas intégralement le même régime.

Expliquez en 180 mots pourquoi la phrase « Schengen supprime les États » n’est pas déduite du document.

**Aide, après une première tentative.** Le document porte sur les contrôles des personnes. Il ne dit pas que souveraineté, droit ou administrations disparaissent.

### P03-E4 — Comparer deux séparations {#P03-E4}

**Degré 2 · 30 minutes · Méthode M2**

Comparez la frontière entre les deux Corées et la frontière germano-polonaise : origine, conflit, transformations et reconnaissance. Préparez un tableau puis une conclusion de six lignes.

**Aide, après une première tentative.** Utilisez les mêmes critères pour les deux cas, mais ne supposez pas qu’ils ont le même statut final.

### P03-E5 — Réparer une carte mentale {#P03-E5}

**Degré 2 · 25 minutes · Méthode M4**

Un élève écrit : « mer territoriale = ZEE = haute mer = territoire intégral de l’État côtier ». Réécrivez la distinction et expliquez pourquoi un espace marin peut associer plusieurs types de droits.

**Aide, après une première tentative.** La convention distingue souveraineté, droits souverains sur des ressources et libertés de circulation. Les mêmes mots ne s’appliquent pas partout.

### P03-E6 — Construire une problématique {#P03-E6}

**Degré 2 · 35 minutes · Méthode M6**

Sujet : « Les frontières européennes, entre intégration et différenciation ». Proposez un plan utilisant Schengen, la Pologne et un espace transfrontalier sans confondre leurs échelles.

**Aide, après une première tentative.** Le cas polonais peut servir l’histoire d’une stabilisation et d’une intégration ; Schengen est un régime, le Rhin supérieur un espace de pratiques.

### P03-E7 — Composition autonome {#P03-E7}

**Degré 3 · 120 minutes · Méthode M8**

En deux heures : « Les frontières internes et externes de l’Union européenne ». Construisez une réponse qui explique leurs transformations et leurs fonctions.

**Aide, après une première tentative.** Le sujet est l’OTC de P03. Organisez la relation entre ouverture interne, contrôle externe et pratiques transfrontalières.

### P03-E8 — Transférer le raisonnement {#P03-E8}

**Degré 3 · 25 minutes · Méthode M4**

Préparez une explication orale : « Une frontière ouverte peut-elle rester une frontière ? » Appuyez-vous sur un exemple historique et un exemple européen. Dessinez un schéma de cinq éléments légendés.

**Aide, après une première tentative.** Le schéma doit montrer une limite et des flux, puis une institution ou une règle. Une ouverture ne supprime pas les différences.

### P03 — QCM de vérification {#P03-qcm}

Une seule proposition correcte par question. Notez votre réponse et justifiez-la en une phrase ; la correction explique aussi pourquoi les autres propositions ne conviennent pas.

**P03-Q1.** Une frontière dite naturelle…

**A.** s’impose sans choix politique

**B.** peut utiliser un élément physique mais résulte d’une construction politique

**C.** ne peut jamais changer

**P03-Q2.** L’armistice coréen date de…

**A.** 1953

**B.** 1990

**C.** 1885

**P03-Q3.** La ZEE attribue…

**A.** toute souveraineté sur toute navigation

**B.** des droits sur certaines ressources et des compétences

**C.** la propriété de toute la haute mer

**P03-Q4.** Schengen et l’Union européenne…

**A.** sont strictement le même ensemble

**B.** ne concernent que des États sans frontières

**C.** doivent être distingués

**P03-Q5.** Un espace transfrontalier…

**A.** utilise aussi les complémentarités et différences

**B.** est toujours un nouvel État

**C.** n’a aucun habitant permanent

### P03-RT — Nouveau test et réactivation {#P03-RT}

**20 minutes, sans cours, à distance du premier entraînement.**

1. Expliquez une frontière qui fonctionne comme interface. 2. Distinguez la délimitation, la démarcation et la reconnaissance. 3. Pourquoi Schengen ne signifie-t-il pas absence de toutes les frontières européennes ?

**Vérifier la maîtrise.** Réussite : trois réponses justifiées, avec notions distinguées et exemples situés. Une erreur de date appelle R1 ; une confusion de notion R2 ; une relation non expliquée R3. Refaire le point faible à J+2.

**Réactivation espacée.** J+7 : Dessiner mer territoriale, ZEE et haute mer en nommant les droits. J+21 : Comparer frontières physiques de P03 et ancrages territoriaux du cyberespace de T06.

**Trace de progression.** Date : … · Je restitue : oui / à reprendre · J’explique : oui / à reprendre · Je mobilise dans un sujet nouveau : oui / à reprendre · Erreur prioritaire : … · Nouvelle tentative prévue : …

# P04 — S’informer : un regard critique sur les sources et modes de communication {#p04}

**Première • Parcours N1 ; méthode transversale pour tout le cycle**

**Question directrice.** Comment les transformations des techniques et des modèles économiques modifient-elles la production de l’information, sa circulation et son contrôle ?

**Objectifs.** Distinguer support, média, source et contenu ; contextualiser trois révolutions techniques ; expliquer les tensions entre liberté, marché et État ; vérifier une information sans confondre esprit critique et soupçon systématique.

**Diagnostic P04-D — 10 minutes.** Une photographie est-elle une preuve suffisante de sa légende ? Dix sites qui reproduisent la même dépêche constituent-ils dix sources indépendantes ? Une information devenue virale est-elle nécessairement fausse ? Justifiez sans utiliser « toujours » ou « jamais » comme substitut à l’explication.

**Itinéraire.** Axe 1 : repères et mécanismes, E1–E2 ; axe 2 : contextualiser et confronter, E3–E5 ; objet conclusif : vérifier et argumenter, E6–E8. Réactivation : analyser à J+7 une information différente avec la même méthode, non avec les mêmes conclusions.

## Introduction — S’informer est une pratique sociale

Une information est un contenu transmis qui apporte un renseignement sur un objet ou un événement. Elle peut être exacte, erronée, incomplète ou trompeuse. Le **média** organise une production et une diffusion ; le **support** est le moyen matériel ou technique ; la **source** est l’origine d’un renseignement ou d’un document. Un même téléphone permet ainsi d’accéder à une enquête journalistique, une publication institutionnelle, un témoignage, une publicité ou une fiction. L’appareil utilisé ne suffit pas à définir le statut du contenu. ([S02](#ref-S02) ; [R-P04](#ref-R-P04))

Les pratiques d’information varient avec les habitudes, les ressources économiques, la formation, les sociabilités et l’accès aux réseaux. Les générations n’utilisent pas toutes les mêmes supports, mais cette différence n’autorise pas à opposer mécaniquement des jeunes crédules à des adultes compétents. L’expérience d’un média ne garantit pas la vérification de ses contenus. Il faut étudier comment chacun sélectionne, partage et confronte les informations.

Une **opinion** exprime un jugement ; un **fait** peut être soumis à des procédures d’établissement ; une **interprétation** relie des faits selon un raisonnement. Une enquête contient souvent ces trois dimensions. La neutralité de ton ne prouve pas l’exactitude, et l’engagement d’un auteur ne rend pas automatiquement ses documents inutilisables. L’esprit critique consiste à déterminer ce qu’une source permet d’établir, dans quelles conditions et avec quelles limites.

## Axe 1 — Les grandes révolutions techniques de l’information

### De l’imprimerie à la presse à grand tirage {#P04-AXE1-J01}

Le développement de l’imprimerie à caractères métalliques mobiles en Europe au milieu du XVe siècle, associé à Gutenberg, transforme la reproduction des textes. Cette innovation s’inscrit dans une histoire plus ancienne des techniques d’impression en Asie ; elle ne doit pas être racontée comme l’apparition universelle du livre. En Europe, l’augmentation des exemplaires disponibles favorise la circulation des savoirs, des controverses religieuses et des nouvelles. Elle dépend toutefois du coût, de l’alphabétisation, des circuits commerciaux et des autorisations. ([B18](#ref-B18) ; [R-P04](#ref-R-P04))

La presse périodique organise ensuite une relation régulière au public. Au XIXe siècle, les presses mécaniques, les rotatives, l’amélioration des transports et le télégraphe permettent une production plus rapide et une diffusion élargie. La baisse du prix de certains journaux repose aussi sur les annonces publicitaires et sur l’augmentation des ventes. Le grand tirage résulte donc d’une combinaison de techniques, de marchés et de transformations sociales ; une machine seule ne crée pas un lectorat.

La presse participe à la formation d’espaces de débat. Elle peut enquêter et contester les autorités, mais aussi diffuser des stéréotypes, des campagnes de haine ou des informations non vérifiées. En France, la loi du 29 juillet 1881 constitue un repère majeur de la liberté de la presse tout en définissant des responsabilités. Cette liberté n’efface pas les inégalités de moyens : financer une imprimerie, disposer de correspondants ou accéder aux réseaux de distribution reste déterminant. ([B20a](#ref-B20a))

Le mécanisme à retenir est double : la reproduction et la diffusion élargissent l’accès ; l’organisation économique et politique sélectionne ce qui peut être publié et vu. Pour expliquer une « révolution », montrez donc le changement d’échelle et ses conditions, puis ce qui ne disparaît pas : dépendances financières, choix éditoriaux et rapports de pouvoir.

### Radio et télévision au XXe siècle : l’information entre dans le quotidien {#P04-AXE1-J02}

La radio permet une diffusion sonore rapide vers de nombreux auditeurs, sans exiger la lecture d’un texte. Son essor au XXe siècle repose sur les réseaux d’émetteurs, les récepteurs et l’organisation des programmes. Le direct produit un sentiment de proximité ; la voix d’un dirigeant ou d’un journaliste devient familière. Les États comprennent tôt l’intérêt stratégique de cette diffusion. Pendant la Seconde Guerre mondiale, propagandes et émissions concurrentes montrent que les ondes peuvent à la fois soutenir une domination et la contester. ([B18](#ref-B18) ; [R-P04](#ref-R-P04))

La télévision ajoute l’image animée à cette présence domestique. Sa diffusion après la Seconde Guerre mondiale modifie le rythme des nouvelles et la représentation de la vie politique. Un journal télévisé hiérarchise des événements, choisit des plans, monte des séquences et fait parler certains acteurs. Le spectateur voit des images réelles, mais jamais la totalité de l’événement. L’apparence d’immédiateté masque parfois le travail de sélection et les contraintes de tournage.

Les régimes d’organisation diffèrent : monopoles publics, services publics autonomes, entreprises privées ou combinaisons de ces modèles. En France, l’histoire de la radiodiffusion publique, de l’ORTF créé en 1964 puis dissous en 1974, et de la libéralisation des ondes dans les années 1980 montre des transformations successives. Il serait inexact de déduire automatiquement la propagande d’un financement public ou l’indépendance d’un financement publicitaire : il faut examiner les garanties éditoriales et les dépendances effectives.

Une comparaison avec la presse doit porter sur la vitesse, les publics et les modalités de réception. La radio et la télévision ne remplacent pas intégralement l’écrit : les médias s’articulent, se citent et se concurrencent. Les usages comptent autant que les inventions.

### Internet : interconnexion, standards et ouverture des usages {#P04-AXE1-J03}

Internet est un réseau de réseaux informatiques utilisant des protocoles communs. ARPANET, dont les premières connexions datent de 1969, constitue une étape importante, mais pas l’unique origine de tous les dispositifs ultérieurs. Les recherches sur la commutation de paquets, les collaborations universitaires et les financements publics contribuent à l’interconnexion. L’adoption de TCP/IP par ARPANET en 1983 est un repère majeur de cette évolution. ([B21a](#ref-B21a))

Le **Web** n’est pas synonyme d’Internet. Il est un service permettant de relier et consulter des ressources grâce à des adresses, des liens et des protocoles. Tim Berners-Lee le conçoit au CERN à partir de 1989 ; la mise à disposition publique du logiciel en 1993 favorise son développement. Le courrier électronique peut utiliser Internet sans être une page Web. Distinguer infrastructure et service évite de raconter une invention unique attribuée à un seul acteur. ([B21b](#ref-B21b))

L’extension des accès, des ordinateurs puis des terminaux mobiles permet de publier, commenter et partager à grande échelle. Les coûts d’entrée dans la publication diminuent, sans devenir nuls : équipement, connexion, compétences et visibilité restent inégalement distribués. L’ouverture technique rend possibles de nouveaux producteurs, tandis que moteurs de recherche et plateformes concentrent une partie de l’intermédiation.

**Document P04-Doc1 — Trois transformations, trois conditions.** Synthèse éditoriale.

| Transformation | Possibilité nouvelle | Condition ou limite |
|---|---|---|
| Imprimerie et grand tirage | Reproduire et diffuser largement l’écrit. | Alphabétisation, financement, distribution, droit de publier. |
| Radio et télévision | Toucher simultanément de vastes publics par le son et l’image. | Émetteurs, programmation, accès aux antennes, choix de montage. |
| Internet et Web | Publier, relier, rechercher et partager des contenus. | Accès, standards, compétences, classement par les intermédiaires. |

Aucune ligne ne démontre à elle seule une démocratisation politique : il faut observer les usages et les institutions.

## Axe 2 — Liberté ou contrôle de l’information : un débat politique fondamental

### L’affaire Dreyfus : la presse produit et conteste une injustice {#P04-AXE2-J01}

En 1894, le capitaine Alfred Dreyfus est condamné pour trahison à l’issue d’une procédure marquée par des éléments erronés et des irrégularités. L’antisémitisme contribue à rendre plausible, pour une partie de l’opinion, une accusation dirigée contre cet officier juif. La presse ne forme pas un bloc : des journaux nationalistes et antisémites soutiennent la culpabilité, tandis que des proches, des journalistes et des intellectuels recherchent des preuves et dénoncent l’injustice. ([B19](#ref-B19) ; [R-P04](#ref-R-P04))

La publication de « J’accuse…! » par Émile Zola dans *L’Aurore*, le 13 janvier 1898, donne une visibilité exceptionnelle à la contestation. Ce texte est une lettre ouverte et une intervention politique, pas un compte rendu neutre. Zola utilise sa notoriété et la puissance de diffusion du journal pour provoquer un débat et un affrontement judiciaire. Son engagement s’inscrit dans une mobilisation collective, notamment celle de Bernard Lazare, de la famille Dreyfus et d’autres défenseurs ; il ne découvre ni ne résout seul l’affaire.

La presse façonne les catégories du débat : honneur de l’armée, raison d’État, droits de l’individu, vérité judiciaire et antisémitisme. Des caricatures et des titres cherchent à susciter l’émotion. Ils sont des sources sur les représentations et les stratégies de persuasion, mais ne prouvent pas la vérité de leurs accusations. La réhabilitation de Dreyfus en 1906 ne doit pas être confondue avec la grâce de 1899 : la grâce ne supprimait pas la condamnation.

Ce cas montre qu’un média peut être instrument de contrôle social et moyen de contestation. Pour analyser une une, identifiez le public visé, la place donnée au texte, les mots utilisés et le contexte de publication. N’écrivez pas « les Français pensent que… » à partir d’un seul journal : l’opinion publique est plurielle et ne se lit pas directement dans un titre.

### De Havas à l’AFP : l’information entre marché et État {#P04-AXE2-J02}

Fondée en 1835, l’agence Havas organise la collecte, la traduction et la transmission de nouvelles. Une agence fournit des contenus à d’autres médias : elle se distingue d’un journal qui s’adresse directement à son lectorat. Le télégraphe, les correspondants et les accords de partage des marchés permettent d’accélérer la circulation. Cette position en amont lui donne une influence importante : une même dépêche peut nourrir de nombreux articles. ([B20](#ref-B20) ; [R-P04](#ref-R-P04))

Le modèle économique dépend des abonnements et des relations avec les clients ; l’accès à l’information peut aussi dépendre des gouvernements. Sous l’Occupation, le service d’information de Havas est intégré à l’Office français d’information, lié au régime de Vichy. L’AFP naît à la Libération en 1944. Son statut de 1957 vise à organiser une autonomie et des obligations d’exactitude, d’objectivité et d’indépendance à l’égard des influences politiques, idéologiques et économiques. ([B20](#ref-B20))

Ces garanties juridiques sont essentielles, mais elles doivent être mises en œuvre : diversité des ressources, procédures de vérification, protection des journalistes, transparence et corrections. Le financement public n’autorise pas à conclure automatiquement à une information gouvernementale ; une recette privée n’exclut pas une pression commerciale. Le problème est celui des mécanismes concrets qui permettent ou empêchent l’indépendance.

**Exemple résolu.** Trois quotidiens reprennent une dépêche AFP contenant la même donnée. Leur accord ne constitue pas trois confirmations indépendantes : ils partagent une origine. Pour recouper, il faut retrouver la donnée initiale ou une enquête distincte. Le nombre de reproductions mesure une diffusion, non le nombre de vérifications. Cette distinction est décisive dans un dossier documentaire comme dans une recherche personnelle.

### La guerre du Vietnam : informer sous contraintes et contester le récit officiel {#P04-AXE2-J03}

La guerre du Vietnam place les médias au contact d’un conflit de décolonisation, de guerre froide et de lutte pour le pouvoir. Les autorités cherchent à présenter les opérations et leurs résultats de manière favorable ; les journalistes travaillent sous des contraintes d’accès, de sécurité, de transport et de dépendance à l’égard des sources militaires. Les images diffusées ne sont donc pas un miroir complet de la guerre. ([B22](#ref-B22) ; [R-P04](#ref-R-P04))

L’offensive du Têt en 1968 contribue à rendre visible l’écart entre certains discours optimistes américains et la persistance de la capacité offensive adverse. Des photographies, des reportages et des témoignages alimentent les débats sur les violences et sur les objectifs de l’intervention. Il faut éviter la formule simpliste selon laquelle la télévision aurait, à elle seule, « fait perdre la guerre » : les décisions politiques, les pertes humaines, les mobilisations sociales et la situation militaire interagissent.

En 1971, la publication de documents connus sous le nom de *Pentagon Papers*, transmis notamment par Daniel Ellsberg, révèle des éléments de l’histoire interne de l’engagement américain. La confrontation judiciaire autour de leur diffusion met en tension secret d’État et liberté de la presse. Leur valeur ne réside pas seulement dans leur caractère secret : leur provenance administrative, leur contenu et leur confrontation avec d’autres sources permettent d’examiner les écarts entre décisions et déclarations. ([B22](#ref-B22))

Le jalon prépare une règle méthodologique : une source produite par un acteur engagé peut fournir des informations essentielles, mais il faut identifier ce qu’elle cherche à montrer, ce qu’elle ignore et ce qu’elle ne dit pas. Une photographie de victimes documente une violence située ; elle ne suffit pas à expliquer toutes les causes du conflit.

## Objet de travail conclusif — L’information à l’heure d’Internet

### Une information fragmentée et horizontale, mais inégalement visible {#P04-OTC-J01}

Les réseaux permettent à un usager de recevoir, produire et relayer des contenus sans passer systématiquement par une rédaction. Cette horizontalité élargit la prise de parole et facilite des enquêtes collectives. Mais l’accès à la publication ne garantit pas une audience comparable : moteurs de recherche, recommandations, publicité et communautés structurent la visibilité. L’information peut donc circuler horizontalement entre usagers tout en dépendant d’intermédiaires très concentrés. ([R-P04](#ref-R-P04) ; [B23](#ref-B23))

La fragmentation désigne la diversité des publics, des formats et des parcours d’information. Un même événement peut être rencontré sous la forme d’un titre, d’un extrait vidéo, d’un commentaire ou d’une capture d’écran privée de contexte. Les contenus attirant l’attention peuvent être favorisés par les modèles économiques de la publicité. Cela ne signifie pas que chaque algorithme diffuse nécessairement des mensonges ; il faut examiner les critères de classement, les usages et les résultats observés.

L’idée de « bulle » aide à interroger l’exposition sélective, mais ne doit pas devenir une explication universelle. Les individus peuvent consulter plusieurs médias, discuter avec des proches et rencontrer des positions différentes. Une analyse rigoureuse distingue ce que le dispositif rend possible, ce que l’utilisateur choisit et ce qu’une enquête démontre effectivement.

### Témoignages et lanceurs d’alerte : élargir les sources sans renoncer à les vérifier {#P04-OTC-J02}

Un témoin peut rendre visible un événement auquel les journalistes n’ont pas accès. Un téléphone permet d’enregistrer une scène et de la diffuser rapidement. L’intérêt documentaire dépend toutefois de la localisation, de la date, de l’intégrité de l’enregistrement et de la position de l’auteur. Une personne peut témoigner sincèrement tout en ne percevant qu’une partie des faits. La sincérité n’est pas une garantie d’exhaustivité.

Un lanceur d’alerte signale des faits qu’il estime contraires à l’intérêt général, souvent à partir d’une position professionnelle ou institutionnelle lui donnant accès à des informations. Cette démarche se distingue d’une simple rumeur ou d’une accusation sans élément. Les révélations d’Edward Snowden en 2013 sur des dispositifs de surveillance illustrent les tensions entre sécurité, secret, vie privée et contrôle démocratique. Elles ont été relayées et examinées par des journalistes : l’alerte et l’enquête sont des fonctions complémentaires. ([B23](#ref-B23))

La protection juridique des lanceurs d’alerte dépend du cadre applicable et de conditions précises ; le manuel n’est pas un guide de divulgation de documents secrets. Pour l’analyse, posez quatre questions : quelle connaissance l’auteur pouvait-il avoir ? Quels éléments fournit-il ? Quelles vérifications indépendantes sont possibles ? Quels risques ou intérêts influencent sa publication ? Évaluer ces conditions évite aussi bien la confiance automatique que le discrédit systématique.

### Théories du complot : distinguer enquête et récit fermé {#P04-OTC-J03}

Des complots réels ont existé ; les mettre au jour suppose des preuves, des acteurs identifiés et des mécanismes documentés. Une théorie du complot, au sens étudié ici, tend au contraire à expliquer des événements complexes par l’action cachée d’un groupe tout-puissant, en transformant parfois chaque objection en preuve supplémentaire de dissimulation. Son défaut n’est pas de poser une question gênante, mais de rendre l’explication impossible à contredire par des faits. ([R-P04](#ref-R-P04) ; [B23](#ref-B23))

Internet accélère la diffusion de récits anciens, la circulation de montages et la constitution de communautés de validation. L’émotion, le sentiment de détenir un secret et la défiance envers les institutions peuvent favoriser l’adhésion. Ces mécanismes n’autorisent pas à réduire tous les publics à une même psychologie. Il faut étudier les producteurs, les intérêts financiers ou politiques, les supports et les circonstances de réception.

**Document P04-Doc2 — Vérifier une capture d’écran.** Situation méthodologique fictive : un compte publie une photographie d’une foule avec la légende « manifestation ce matin dans la ville A » ; aucune date ni source initiale n’est fournie. Un second compte reprend la capture ; un troisième affirme qu’elle prouve une mobilisation nationale. Ce document n’évoque aucun événement réel.

La vérification commence par retrouver l’image originale, sa date et son lieu, puis par consulter des sources indépendantes sur l’événement allégué. Même une photographie authentique d’une manifestation locale ne prouve pas une mobilisation nationale. La conclusion peut être « non établi » : l’absence de confirmation n’autorise pas à inventer une réfutation. L’esprit critique accepte un degré d’incertitude explicitement délimité.

## S’entraîner, retenir, transférer

**Activité P04-A — 25 minutes.** Pour P04-Doc2, rédigez une note de vérification en distinguant ce qui est observable, ce qui est affirmé et ce qui reste à établir. Puis comparez cette situation au problème de la dépêche reprise par trois journaux. Donnez deux vérifications communes et une différence.

**Synthèse.** Les innovations changent la vitesse et l’échelle de l’information, sans supprimer les rapports de pouvoir. La presse, l’audiovisuel et les réseaux numériques combinent production, sélection et diffusion. Les conflits autour de Dreyfus, de l’indépendance des agences ou du Vietnam montrent que la liberté de s’informer dépend de garanties, de pratiques professionnelles et de mobilisations. Internet élargit les sources, mais exige de retrouver leur origine et de mesurer leurs limites.

**Repères.** Milieu du XVe siècle : imprimerie européenne ; 1835 : Havas ; 1881 : liberté de la presse en France ; 1894–1906 : affaire Dreyfus ; 1944/1957 : création puis statut de l’AFP ; 1969 : premières connexions ARPANET ; 1971 : Pentagon Papers ; 1989/1993 : conception du Web puis diffusion publique du logiciel ; 2013 : révélations Snowden.

**Transfert.** Toute étude critique de document demande les mêmes opérations : identifier, contextualiser, confronter, expliquer, limiter. En T03, cette méthode distingue témoignage et travail historien ; en T06, elle distingue circulation d’informations et production de connaissances.

**Références.** S02 ; R-P04 ; B18 à B23, avec sous-références précisées au registre. Les deux documents intégrés et l’exemple résolu sont des constructions pédagogiques nouvelles, non des archives historiques.

## Entraînements — P04 {#P04-entrainements}

Les degrés 1, 2 et 3 désignent la difficulté, non les parcours N1/N2. Commencez sans aide ; consultez ensuite l’indice si nécessaire. Les corrections, les critères détaillés et les remédiations sont dans le compagnon, sous les mêmes identifiants.

### P04-E1 — Information, opinion, preuve {#P04-E1}

**Degré 1 · 15 minutes · Méthode M1**

Classez les trois phrases fictives et justifiez : A. « La réunion commence à 15 heures selon la convocation. » B. « Cette réunion sera inutile. » C. « La convocation prouve que tous les invités seront présents. » Indiquez ce qui est vérifiable et ce qui est déduit abusivement.

**Aide, après une première tentative.** Le support d’une annonce ne prouve pas que tous les faits futurs se réaliseront.

### P04-E2 — Des techniques aux publics {#P04-E2}

**Degré 1 · 25 minutes · Méthode M2**

Construisez une chronologie de quatre étapes : imprimerie européenne, radio et télévision, Internet, Web. Pour chaque étape, expliquez une transformation de diffusion et une limite. Pourquoi une technique ne supprime-t-elle pas automatiquement la censure ?

**Aide, après une première tentative.** Internet et le Web ont des histoires liées mais ne sont pas synonymes.

### P04-E3 — Lire une liberté inscrite dans la loi {#P04-E3}

**Degré 2 · 25 minutes · Méthode M3**

**Document authentique.** Loi française du 29 juillet 1881 sur la liberté de la presse, article 1 : « L’imprimerie et la librairie sont libres. » Source : Légifrance ([B20a](#ref-B20a)), formulation originale, extrait limité à cet article.

Présentez la nature du document et son contexte. Expliquez ce qu’il établit. Peut-on en déduire que toute publication était accessible à tous ou que toute expression était sans limites ? Rédigez 150 mots.

**Aide, après une première tentative.** Une norme établit un principe juridique ; son application et ses autres dispositions doivent être étudiées séparément.

### P04-E4 — Dreyfus : distinguer événement et traitement médiatique {#P04-E4}

**Degré 2 · 30 minutes · Méthode M4**

**Tableau éditorial d’après P04.** 1894 : condamnation de Dreyfus ; 1898 : publication de « J’accuse…! » ; 1899 : nouvelle condamnation puis grâce ; 1906 : réhabilitation.

Expliquez pourquoi grâce et réhabilitation ne sont pas équivalentes. Rédigez ensuite un paragraphe sur le rôle de la presse, sans affirmer que tous les journaux défendent la même position.

**Aide, après une première tentative.** Une grâce modifie l’exécution d’une peine ; elle n’efface pas nécessairement la condamnation ni n’établit l’innocence.

### P04-E5 — Vietnam et contrôle de l’information {#P04-E5}

**Degré 2 · 25 minutes · Méthode M5**

Corrigez cette copie fictive : « Une guerre est connue exactement comme le gouvernement la décrit. Les Pentagon Papers publiés en 1971 étaient un sondage sur l’opinion américaine. Les images du Vietnam suffisent à expliquer toutes les décisions politiques. »

**Aide, après une première tentative.** Identifier la nature des Pentagon Papers et distinguer information, réception et décision.

### P04-E6 — Le Web : horizontalité et nouveaux intermédiaires {#P04-E6}

**Degré 2 · 35 minutes · Méthode M6**

Proposez une problématique et un plan pour « Internet rend-il l’information entièrement horizontale ? ». Mobilisez acteurs individuels, agences, plateformes, algorithmes de classement et vérification.

**Aide, après une première tentative.** Pouvoir publier ne signifie pas avoir la même visibilité ni le même pouvoir économique.

### P04-E7 — Composition : l’information à l’heure d’Internet {#P04-E7}

**Degré 3 · 120 minutes · Méthode M8**

Composition N1 d’entraînement, périmètre OTC : « L’information à l’heure d’Internet : nouvelles libertés, nouveaux défis ». Traitez en deux heures ; conservez le brouillon et les temps.

**Aide, après une première tentative.** Articulez horizontalité, lanceurs d’alerte et conspirationnisme ; ne consacrez pas une partie entière à l’imprimerie.

### P04-E8 — Une image virale : expliquer une vérification {#P04-E8}

**Degré 3 · 25 minutes · Méthode M11**

À partir de la capture fictive P04-Doc2, préparez trois minutes expliquant ce qu’il faudrait vérifier avant de partager. Distinguez authenticité de l’image, date, lieu, légende et indépendance des reprises.

**Aide, après une première tentative.** Une photographie non retouchée peut recevoir une légende fausse.

### P04 — QCM de vérification {#P04-qcm}

Une seule proposition correcte par question. Notez votre réponse et justifiez-la en une phrase ; la correction explique aussi pourquoi les autres propositions ne conviennent pas.

**P04-Q1.** Une source primaire est…

**A.** toujours vraie

**B.** produite en relation directe avec l’objet étudié, selon la question

**C.** nécessairement un article scientifique récent

**P04-Q2.** La publication de « J’accuse…! » date de…

**A.** 1898

**B.** 1906

**C.** 1971

**P04-Q3.** Internet et le Web…

**A.** sont deux noms strictement synonymes

**B.** ont été inventés ensemble en 1450

**C.** sont liés mais ne désignent pas le même objet

**P04-Q4.** Dix sites reprenant la même dépêche…

**A.** constituent dix sources indépendantes

**B.** peuvent dépendre d’une source unique

**C.** prouvent que la dépêche est fausse

**P04-Q5.** Le doute critique…

**A.** accepte de confronter et de réviser une hypothèse

**B.** considère toute réfutation comme une preuve du complot

**C.** refuse toujours les sources institutionnelles

### P04-RT — Nouveau test et réactivation {#P04-RT}

**20 minutes, sans cours, à distance du premier entraînement.**

1. Distinguez information et opinion. 2. Situez « J’accuse…! » et expliquez un rôle de la presse. 3. Pourquoi trois reprises d’une même source ne sont-elles pas trois confirmations indépendantes ?

**Vérifier la maîtrise.** Réussite : trois réponses justifiées, avec notions distinguées et exemples situés. Une erreur de date appelle R1 ; une confusion de notion R2 ; une relation non expliquée R3. Refaire le point faible à J+2.

**Réactivation espacée.** J+7 : Refaire la chronologie 1894/1898/1899/1906 en précisant grâce et réhabilitation. J+21 : Analyser comment une information scientifique de T06 peut être simplifiée ou déformée dans sa diffusion.

**Trace de progression.** Date : … · Je restitue : oui / à reprendre · J’explique : oui / à reprendre · Je mobilise dans un sujet nouveau : oui / à reprendre · Erreur prioritaire : … · Nouvelle tentative prévue : …

# P05 — Analyser les relations entre États et religions {#p05}

**Première • Parcours N1 ; passerelle vers T02, T03 et T04**

**Question directrice.** Comment les pouvoirs politiques organisent-ils leurs relations avec les autorités, les pratiques et les appartenances religieuses, et pourquoi ces relations se transforment-elles sans suivre un modèle unique ?

**Objectifs.** Distinguer croyance, institution religieuse et usage politique ; comparer des légitimités médiévales ; définir sécularisation et laïcité ; expliquer le sécularisme indien et les dimensions religieuses d’un conflit territorial sans réduire celui-ci à la religion.

**Diagnostic P05-D — 10 minutes.** Un État sans religion officielle est-il nécessairement une société sans croyants ? La laïcité signifie-t-elle obligatoirement que l’État ne gère aucune institution religieuse ? Une majorité religieuse partage-t-elle toujours une même préférence politique ? Justifiez par une distinction conceptuelle.

**Itinéraire.** Introduction et axe 1 : E1–E3 ; comparaison Turquie–États-Unis : E4–E5 ; Inde : E6–E8. Réactivation à J+7 : comparer les trois modèles contemporains à partir de leurs institutions, et non d’un classement du « plus » au « moins » moderne.

## Introduction — Des liens juridiques et sociaux à distinguer

Un **État** organise un pouvoir sur un territoire et une population. Une **religion** associe, selon des formes très diverses, croyances, pratiques, institutions et communautés. Il n’existe pas toujours une autorité unique capable de parler au nom de tous les croyants. Étudier leurs relations demande de distinguer le statut juridique, la place sociale des pratiques et les mobilisations politiques. Une religion majoritaire peut être reconnue socialement sans devenir religion officielle ; inversement, une institution établie peut coexister avec une société très sécularisée. ([S02](#ref-S02) ; [R-P05](#ref-R-P05))

La **liberté de conscience** comprend la possibilité de croire, de ne pas croire et de changer de conviction. La **liberté religieuse** protège l’exercice des pratiques dans un cadre juridique. La **séparation** désigne une organisation institutionnelle ; la **sécularisation**, un processus de différenciation des activités sociales et de transformation de l’autorité religieuse. Cette dernière ne signifie pas nécessairement disparition des croyances. La **laïcité** renvoie à des principes et dispositifs historiques dont les formes varient selon les pays.

Les termes doivent être employés sans jugement implicite : décrire une monarchie sacrée n’est pas l’approuver ; étudier un mouvement religieux n’est pas attribuer ses positions à tous les fidèles. On distinguera aussi les catégories utilisées par les acteurs et celles de l’analyse. « Civilisation », « tradition » ou « identité » peuvent être des instruments de mobilisation qui simplifient des sociétés traversées de désaccords.

## Axe 1 — Pouvoir et religion : des liens historiques traditionnels

### Charlemagne et le pape : une alliance et une concurrence de légitimités {#P05-AXE1-J01}

Le 25 décembre 800, à Rome, le pape Léon III couronne Charlemagne empereur. L’événement s’inscrit dans une alliance entre la papauté et les souverains francs, dans l’expansion du pouvoir carolingien et dans les difficultés du pape à Rome. Charlemagne possède déjà des ressources militaires et politiques considérables ; le rite ne crée pas son pouvoir à partir de rien. Il lui confère une légitimation impériale chrétienne, tandis que le pape bénéficie de la protection d’un souverain puissant. ([B24](#ref-B24) ; [R-P05](#ref-R-P05))

Le couronnement permet plusieurs interprétations. En posant la couronne, le pape semble participer à la reconnaissance de l’empereur ; celui-ci peut, de son côté, se considérer comme protecteur et organisateur de la chrétienté. Les récits ne doivent pas être lus comme des photographies neutres. Éginhard, proche du pouvoir carolingien, écrit après les faits ; son récit de l’attitude de Charlemagne renseigne aussi sur une manière de présenter la dignité impériale. La question de la surprise éventuelle de l’empereur appelle donc une critique de source, pas une certitude psychologique.

L’empereur intervient dans la vie religieuse : soutien aux monastères, réformes, organisation des clercs et diffusion de normes. La religion contribue à unifier un ensemble territorial, mais les pratiques et les pouvoirs locaux restent divers. L’unité chrétienne invoquée ne correspond ni à une administration uniforme ni à une frontière religieuse parfaitement stable. Le titre impérial implique également une relation avec l’Empire byzantin, qui revendique la continuité romaine.

Ce jalon montre une **interdépendance** : le pouvoir religieux légitime le souverain ; le souverain protège et organise des institutions religieuses. Cette proximité n’exclut pas la concurrence pour définir qui détient l’autorité suprême. Il faut éviter de projeter sur l’an 800 une séparation contemporaine entre « politique » et « religion » que les acteurs ne concevaient pas de la même manière.

### Calife et empereur byzantin aux IXe et Xe siècles : des magistères différents {#P05-AXE1-J02}

Le calife revendique la succession politique du Prophète dans la conduite de la communauté musulmane ; il n’est pas un nouveau prophète. Sous les Abbassides, dont Bagdad devient la capitale au VIIIe siècle, le califat articule administration, fiscalité, armée et légitimation religieuse. Son autorité n’épuise toutefois pas la production des savoirs religieux : juristes et savants interprètent les textes et peuvent contester certaines décisions du pouvoir. ([B25](#ref-B25) ; [R-P05](#ref-R-P05))

L’épisode de la *mihna*, au IXe siècle, durant lequel des califes cherchent à imposer une position doctrinale à des savants, révèle une tension entre commandement politique et autorité savante. Au Xe siècle, la fragmentation politique réduit parfois la capacité effective du calife, alors même que son titre conserve un prestige. Les revendications concurrentes, notamment fatimide et omeyyade de Cordoue, montrent qu’il n’existe pas une unité politique musulmane permanente correspondant à une unique communauté de croyance.

À Byzance, l’empereur se présente comme souverain chrétien et héritier de l’Empire romain. Son pouvoir est sacralisé ; il intervient dans l’organisation de l’Église et dans les controverses religieuses. Il n’est pourtant pas prêtre, et le patriarche, les évêques, les moines ou les conciles possèdent des formes d’autorité distinctes. Les conflits autour des images religieuses, achevés par le rétablissement de leur vénération en 843, illustrent des désaccords qui traversent le pouvoir et la société.

Comparer ne signifie donc pas établir une équivalence : le calife et l’empereur byzantin associent pouvoir politique et légitimité religieuse dans des institutions différentes. Dans les deux cas, il faut distinguer **prétention universelle**, **capacité de gouvernement** et **autorité doctrinale**. La formule « chef politique et religieux » constitue un point de départ trop général ; une bonne analyse précise ce que le souverain peut réellement décider et quels acteurs peuvent lui résister.

**Document P05-Doc1 — Comparaison éditoriale des pouvoirs médiévaux.**

| Situation | Ressource de légitimité | Limite à une lecture simpliste |
|---|---|---|
| Charlemagne, couronné en 800 | Protection de l’Église et dignité impériale chrétienne. | Alliance avec le pape, mais concurrence possible sur l’origine de l’autorité. |
| Calife abbasside | Succession politique et conduite de la communauté. | Autorité des savants et fragmentation du pouvoir effectif. |
| Empereur byzantin | Souverain chrétien et continuité romaine. | Distinction avec les fonctions sacerdotales ; controverses ecclésiales. |

Le tableau synthétise des situations historiques ; il ne reproduit pas un texte doctrinal de ces acteurs.

## Axe 2 — États et religions : une inégale sécularisation

### La Turquie : abolir le califat, réorganiser la religion {#P05-AXE2-J01}

La disparition de l’Empire ottoman ouvre un processus de construction nationale autour de Mustapha Kemal. Le sultanat est aboli en 1922, la République proclamée en 1923 et le califat aboli le 3 mars 1924. Ces trois étapes concernent des institutions différentes. L’abolition du califat met fin à une prétention de représentation politique et religieuse qui dépassait le seul territoire turc ; elle affirme la primauté du nouvel État national. ([B26](#ref-B26) ; [R-P05](#ref-R-P05))

Les réformes cherchent à transformer l’école, le droit, les pratiques administratives et les signes publics de l’autorité. Elles s’inscrivent dans une entreprise de modernisation autoritaire, et non dans une consultation libre et uniforme de tous les groupes sociaux. La laïcité turque ne se réduit pas à un retrait de l’État hors du religieux : la création de la Direction des affaires religieuses, le Diyanet, en 1924 organise au contraire une administration de certaines activités religieuses.

Ce modèle illustre une distinction essentielle : **séparer une autorité religieuse souveraine de l’État** n’implique pas nécessairement **cesser de gérer la religion**. L’État peut contrôler la formation, les lieux de culte ou les personnels tout en affirmant sa laïcité. Il faut aussi interroger les effets différenciés de cette organisation sur les diverses traditions et minorités, plutôt que de considérer l’islam turc comme un bloc homogène.

Les transformations politiques ultérieures ont modifié la visibilité et les usages de la religion. Les débats sur l’enseignement, les vêtements, les symboles et les institutions montrent que la sécularisation n’est ni linéaire ni définitivement acquise. Pour le jalon, le cœur de la démonstration reste le mécanisme de 1924 : la refondation nationale retire au califat une autorité politique, tout en plaçant une partie de l’organisation religieuse sous tutelle publique. Il serait donc inexact d’assimiler automatiquement cette trajectoire au modèle français de 1905.

### Les États-Unis depuis 1945 : séparation juridique et présence publique du religieux {#P05-AXE2-J02}

Le premier amendement de la Constitution américaine interdit au Congrès d’établir une religion et protège son libre exercice. Ces deux dimensions — non-établissement et liberté — doivent être étudiées ensemble. L’absence de religion fédérale officielle n’exclut pas une forte présence des références religieuses dans la société et dans les discours politiques. ([D06](#ref-D06))

Pendant la guerre froide, la référence à Dieu participe à la distinction avec le communisme présenté comme athée : les mots « under God » sont ajoutés au serment d’allégeance en 1954 et « In God We Trust » devient devise nationale en 1956. On peut analyser ces usages comme une forme de **religion civile**, ensemble de références et de rituels donnant une signification collective à la nation. Ils ne se confondent pas avec la direction de l’État par une Église unique. ([B27](#ref-B27) ; [R-P05](#ref-R-P05))

Les mobilisations religieuses ne suivent pas une orientation politique uniforme. Des Églises et des militants chrétiens jouent un rôle important dans la lutte pour les droits civiques, notamment autour de Martin Luther King. À partir des années 1970, des réseaux de la droite chrétienne se mobilisent sur l’école, la famille, la sexualité ou l’avortement. Des croyants soutiennent des positions différentes, tandis que les citoyens sans affiliation religieuse participent également à ces débats. Une appartenance ne permet donc pas de déduire mécaniquement un vote.

La Cour suprême arbitre des conflits entre liberté religieuse, non-établissement et autres droits. L’arrêt *Engel v. Vitale* de 1962, relatif à une prière organisée dans l’école publique, constitue un repère : il ne supprime pas toute pratique religieuse privée, mais met en cause une prescription publique. Les controverses ultérieures montrent que l’application des principes fait l’objet de lectures concurrentes. Pour comparer avec la Turquie, n’opposez pas « religion présente » et « religion absente » : étudiez qui organise les pratiques, qui finance, qui décide et quels recours existent. ([B27](#ref-B27))

## Objet de travail conclusif — État et religions en Inde

### Sécularisme et dimension politique de la religion {#P05-OTC-J01}

L’indépendance de 1947 s’accompagne de la partition entre l’Inde et le Pakistan, de violences et de déplacements massifs. L’Union indienne adopte une Constitution entrée en vigueur en 1950. Elle affirme l’égalité et la liberté de conscience, tout en organisant des droits concernant les pratiques et les institutions des communautés. Le mot « secular » est ajouté au préambule en 1976 ; les principes de liberté et d’égalité religieuses ne naissent cependant pas seulement à cette date. ([B28](#ref-B28) ; [R-P05](#ref-R-P05))

Le **sécularisme indien** ne reproduit pas exactement une séparation à la française. L’État peut intervenir pour garantir l’égalité, réformer certaines pratiques et protéger des groupes, tout en reconnaissant une pluralité d’institutions. Cette organisation est traversée de tensions, notamment lorsque des règles de statut personnel ou des protections collectives rencontrent des revendications d’égalité individuelle. L’enjeu n’est pas uniquement la présence du religieux, mais la manière dont une citoyenneté commune s’articule à des appartenances diverses.

L’**hindouisme**, ensemble religieux pluriel, doit être distingué de l’**hindutva**, projet politique qui définit la nation à partir d’une identité hindoue. Le développement de mouvements nationalistes hindous et leur accès au pouvoir modifient les rapports entre majorité, État et minorités. La destruction de la mosquée de Babri à Ayodhya en 1992 constitue un repère de mobilisation et de violence. L’analyse doit identifier les organisations, les décisions et les discours, sans attribuer une volonté unique à tous les hindous.

Le cadre constitutionnel et les pratiques politiques peuvent donc entrer en tension. Une copie solide ne se contente ni de citer le préambule comme preuve que toute égalité est réalisée, ni d’ignorer le droit au profit d’un récit de conflit permanent. Elle examine les garanties, les contestations et les effets concrets des politiques sur les personnes.

### Les minorités religieuses : droits, diversité et rapports de force {#P05-OTC-J02}

L’Inde compte notamment des communautés musulmanes, chrétiennes, sikhes, bouddhistes, jaïnes et parsies, auxquelles s’ajoutent des pratiques et appartenances difficiles à réduire à des catégories uniformes. Le statut de minorité dépend de l’échelle : un groupe minoritaire à l’échelle nationale peut être majoritaire dans un territoire. Il faut également distinguer religion, langue, caste, région et position sociale ; ces dimensions se croisent sans être équivalentes. ([B28](#ref-B28) ; [R-P05](#ref-R-P05))

Les articles constitutionnels sur la liberté religieuse et sur les droits culturels et éducatifs protègent des espaces de pratique et d’organisation. Mais un droit formel peut rencontrer des discriminations, des violences ou des obstacles administratifs. Les situations diffèrent selon les régions et les périodes. Une étude documentaire doit donc dater ses constats et identifier les institutions responsables, plutôt que généraliser un événement à l’ensemble du pays.

La question des minorités est aussi politique : représentation, accès aux ressources, sécurité, éducation et usages électoraux des identités. Les politiques de protection peuvent être contestées comme insuffisantes ou comme favorisant certains groupes ; ces discours doivent être analysés comme des positions, non repris automatiquement comme des faits. Le critère de l’analyse reste la manière dont les institutions garantissent les droits et traitent les citoyens.

**Document P05-Doc2 — Principes constitutionnels indiens, adaptation pédagogique.** D’après B28, articles 14–15, 25 et 29–30 : égalité devant la loi ; interdiction de certaines discriminations ; liberté de conscience et de pratique sous les conditions prévues par la Constitution ; protection de droits culturels et éducatifs. Ce résumé n’est pas une traduction juridique intégrale et ne décrit pas à lui seul l’application effective de ces droits.

### Inde et Pakistan : un conflit où religion, territoire et puissance s’articulent {#P05-OTC-J03}

La partition de 1947 associe projets nationaux, décisions coloniales, mobilisations politiques et appartenances religieuses. Le Pakistan se construit comme État destiné aux musulmans du sous-continent, tandis que l’Inde revendique une citoyenneté qui ne se réduit pas à l’appartenance hindoue. Cette opposition de projets ne signifie pas une séparation complète des populations : de nombreux musulmans demeurent en Inde, et les sociétés des deux États restent diverses. ([B29](#ref-B29) ; [R-P05](#ref-R-P05))

Le Cachemire devient un enjeu central. Les conditions de son rattachement à l’Inde, les interventions armées et les revendications concurrentes conduisent à une division de fait. Les guerres de 1947–1948 et de 1965, puis d’autres crises, ne peuvent être expliquées par la seule religion : contrôle territorial, sécurité, légitimité des gouvernements, aspirations des habitants et rapports régionaux interviennent. La guerre de 1971 aboutit à l’indépendance du Bangladesh et révèle également que la langue et les rapports de domination peuvent diviser un ensemble pourtant majoritairement musulman.

Les essais nucléaires indiens et pakistanais de 1998 ajoutent une dimension de dissuasion. Ils n’empêchent pas des affrontements limités, comme à Kargil en 1999, ni les crises liées à des attentats. La dissuasion peut limiter certaines escalades tout en laissant subsister une conflictualité sous le seuil d’une guerre générale. Il faut distinguer les forces régulières, les groupes armés et les populations civiles, et ne pas attribuer automatiquement chaque action non étatique à tous les acteurs d’un pays.

**Exemple résolu.** « Le Cachemire est-il un conflit religieux ? » La religion participe aux représentations nationales et aux mobilisations ; elle n’explique seule ni le tracé des zones contrôlées, ni les décisions militaires, ni les aspirations diverses des habitants. Une réponse recevable parle donc d’un conflit **territorial et politique comportant une dimension religieuse**, et démontre l’articulation plutôt que d’opposer artificiellement les causes.

## S’entraîner, retenir, transférer

**Activité P05-A — 25 minutes.** Construisez trois paragraphes comparant Turquie, États-Unis et Inde. Pour chacun, indiquez un principe institutionnel, un exemple daté et une tension. Concluez en expliquant pourquoi « plus de religion » n’est pas une mesure suffisante de la relation entre État et religions.

**Synthèse.** Les liens entre pouvoir et religion peuvent légitimer un souverain tout en créant des concurrences d’autorité. Les trajectoires contemporaines combinent séparation, contrôle, liberté et mobilisations collectives. La sécularisation est différenciée et réversible dans certaines de ses dimensions. L’exemple indien montre que pluralisme juridique, rapports majoritaires et conflits géopolitiques doivent être étudiés ensemble, sans transformer une communauté religieuse en acteur unique.

**Repères.** 800 : couronnement de Charlemagne ; 843 : rétablissement des images à Byzance ; 1922/1923/1924 : sultanat, République turque, califat ; 1947 : indépendance et partition ; 1950 : Constitution indienne ; 1954/1956 : références religieuses nationales américaines ; 1962 : arrêt Engel ; 1971 : Bangladesh ; 1976 : ajout de « secular » au préambule indien ; 1998 : essais nucléaires indiens et pakistanais.

**Transfert.** En T02, refuser l’explication monocausale des conflits du Moyen-Orient. En T04, analyser un lieu religieux comme lieu de culte, patrimoine et enjeu politique sans confondre ces fonctions.

**Références.** S02 ; R-P05 ; B24 à B29 ; D06. Textes et tableaux du chapitre nouvellement rédigés ; les documents constitutionnels sont explicitement présentés comme adaptations.

## Entraînements — P05 {#P05-entrainements}

Les degrés 1, 2 et 3 désignent la difficulté, non les parcours N1/N2. Commencez sans aide ; consultez ensuite l’indice si nécessaire. Les corrections, les critères détaillés et les remédiations sont dans le compagnon, sous les mêmes identifiants.

### P05-E1 — Distinguer trois modèles {#P05-E1}

**Degré 1 · 20 minutes · Méthode M1**

Expliquez les différences entre religion officielle, séparation institutionnelle et sécularisation de la société. Une forte pratique religieuse est-elle incompatible avec l’absence de religion d’État ?

**Aide, après une première tentative.** Un statut juridique et une pratique sociale ne se mesurent pas de la même façon.

### P05-E2 — Pouvoirs médiévaux : comparer sans confondre {#P05-E2}

**Degré 1 · 30 minutes · Méthode M2**

Comparez Charlemagne, le califat abbasside et l’Empire byzantin : titre politique, relation au religieux, rôle des institutions et limite de l’autorité. Utilisez au moins un repère par cas.

**Aide, après une première tentative.** Un empereur chrétien et un calife ne disposent ni des mêmes titres ni de la même organisation religieuse.

### P05-E3 — Le premier amendement américain {#P05-E3}

**Degré 2 · 25 minutes · Méthode M3**

**Document adapté**, Constitution des États-Unis, premier amendement, ratifié en 1791 ([D06](#ref-D06)). Reformulation française du passage religieux : le Congrès ne doit établir aucune religion ni interdire son libre exercice.

Expliquez les deux garanties et leur portée. Le document démontre-t-il que la religion serait absente de la vie politique américaine ?

**Aide, après une première tentative.** Non-établissement et libre exercice sont complémentaires ; ils ne décrivent pas une absence de croyance.

### P05-E4 — La Turquie : une laïcité qui organise aussi le religieux {#P05-E4}

**Degré 2 · 25 minutes · Méthode M5**

Corrigez : « En 1924, la Turquie abolit toute religion et toute administration des cultes. La laïcité signifie partout exactement la même organisation. » Appuyez-vous sur le califat et la Diyanet.

**Aide, après une première tentative.** Abolir une institution politico-religieuse ne supprime pas les croyances ; le contrôle peut accompagner la séparation.

### P05-E5 — L’Inde : majorité, pluralisme et droits {#P05-E5}

**Degré 2 · 30 minutes · Méthode M3**

**Document éditorial d’après la Constitution indienne** ([B28](#ref-B28)) : le cadre constitutionnel associe égalité, liberté religieuse et protections de certaines minorités ; le mot « secular » est ajouté au préambule en 1976, alors que plusieurs garanties existent depuis 1950.

Expliquez pourquoi majorité religieuse, nationalisme hindou et État indien ne sont pas trois expressions synonymes. Donnez une limite de ce document pour étudier les pratiques.

**Aide, après une première tentative.** Une population, un projet politique et un ensemble d’institutions sont trois objets différents.

### P05-E6 — Religion et conflit : éviter la cause unique {#P05-E6}

**Degré 2 · 35 minutes · Méthode M6**

Construisez un plan pour « Les tensions entre l’Inde et le Pakistan peuvent-elles être expliquées par la seule religion ? ». Mobilisez partition, territoires, États, Cachemire et enjeux stratégiques.

**Aide, après une première tentative.** La religion intervient dans les identités et les mobilisations ; elle n’efface pas les territoires, les armées et les décisions.

### P05-E7 — Composition : États et religions aux États-Unis {#P05-E7}

**Degré 3 · 120 minutes · Méthode M8**

Composition N1, périmètre axe 2 : « Aux États-Unis, séparation institutionnelle et présence publique du religieux ». Traitez le cas américain en deux heures, en le situant dans la réflexion sur les modèles de séparation.

**Aide, après une première tentative.** Le sujet demande une articulation, pas une partie affirmant la séparation puis une autre affirmant son contraire.

### P05-E8 — Comparer trois modèles à l’oral {#P05-E8}

**Degré 3 · 30 minutes · Méthode M11**

Préparez quatre minutes sur « Le même mot laïcité décrit-il partout le même modèle ? ». Comparez Turquie, États-Unis et Inde selon trois critères : norme, institutions, pratiques. Formulez une limite de votre comparaison.

**Aide, après une première tentative.** Comparer n’impose pas de classer du « plus » au « moins » religieux sur une échelle unique.

### P05 — QCM de vérification {#P05-qcm}

Une seule proposition correcte par question. Notez votre réponse et justifiez-la en une phrase ; la correction explique aussi pourquoi les autres propositions ne conviennent pas.

**P05-Q1.** La sécularisation concerne principalement…

**A.** la transformation de la place du religieux dans la société

**B.** la suppression automatique de toute croyance

**C.** le seul nom officiel d’un État

**P05-Q2.** Charlemagne est couronné empereur à Rome en…

**A.** 1453

**B.** 800

**C.** 1924

**P05-Q3.** La Diyanet montre que la laïcité turque…

**A.** abolit toute administration religieuse

**B.** se confond avec le modèle américain

**C.** peut s’accompagner d’une organisation publique du religieux

**P05-Q4.** Le premier amendement américain…

**A.** impose une religion officielle

**B.** articule non-établissement et libre exercice

**C.** interdit toute conviction religieuse aux citoyens

**P05-Q5.** Les tensions indo-pakistanaises…

**A.** articulent dimensions religieuses, territoriales et stratégiques

**B.** s’expliquent sans aucune histoire politique

**C.** prouvent que chaque religion forme un bloc unique

### P05-RT — Nouveau test et réactivation {#P05-RT}

**20 minutes, sans cours, à distance du premier entraînement.**

1. Distinguez séparation et sécularisation. 2. Expliquez ce que montrent ensemble l’abolition du califat et la Diyanet en 1924. 3. Donnez deux facteurs non exclusivement religieux des tensions indo-pakistanaises.

**Vérifier la maîtrise.** Réussite : trois réponses justifiées, avec notions distinguées et exemples situés. Une erreur de date appelle R1 ; une confusion de notion R2 ; une relation non expliquée R3. Refaire le point faible à J+2.

**Réactivation espacée.** J+7 : Comparer 800, 1924 et 1947 sans mélanger les espaces. J+21 : Relier les identités et les territoires de P05 aux conflits de T02 en refusant une cause unique.

**Trace de progression.** Date : … · Je restitue : oui / à reprendre · J’explique : oui / à reprendre · Je mobilise dans un sujet nouveau : oui / à reprendre · Erreur prioritaire : … · Nouvelle tentative prévue : …

# T01 — De nouveaux espaces de conquête {#t01}

**Terminale • Parcours N2 • Thème du programme, hors rotation de l’écrit 2027**

Ce thème reste à étudier : il nourrit la compréhension du cycle, les questions possibles du Grand oral et les comparaisons avec T02, T05 et T06. Il ne doit pas être choisi comme thème d’un exercice de l’écrit HGGSP de la session 2027 selon S04.

**Question directrice.** Comment la connaissance et la maîtrise des océans et de l’espace deviennent-elles des instruments de puissance, tout en rendant nécessaires des coopérations ?

**Objectifs.** Distinguer exploration, appropriation et contrôle ; expliquer dissuasion et projection ; analyser le droit de la mer et de l’espace ; montrer l’articulation entre ambition chinoise, dépendances et rivalités.

**Diagnostic T01-D — 10 minutes.** Planter un drapeau sur la Lune crée-t-il une souveraineté ? Un sous-marin nucléaire lanceur d’engins et un porte-avions ont-ils la même fonction ? Une coopération scientifique implique-t-elle l’absence de rivalité ? Justifiez en mobilisant P02 et P03.

**Itinéraire.** Reprendre puissance et ZEE ; axe 1 puis E1–E3 ; axe 2 puis E4–E5 ; Chine puis E6–E8. À J+7, relier un exemple spatial à un exemple maritime sans les rendre identiques.

## Introduction — Connaître, atteindre, maîtriser

Les océans et l’espace sont étudiés comme de nouveaux espaces de conquête non parce qu’ils auraient été totalement inconnus, mais parce que les techniques et les ambitions en transforment l’accès. Les grandes profondeurs imposent pression, obscurité et difficultés de communication ; le milieu spatial exige de surmonter la gravité, le vide, les radiations et les coûts du transport. La connaissance scientifique dépend d’instruments : satellites, sondes, navires, capteurs et robots. ([S03](#ref-S03) ; [R-T01](#ref-R-T01))

La **conquête** peut désigner exploration, compétition symbolique, exploitation économique ou maîtrise stratégique. Ces dimensions ne coïncident pas toujours. Photographier un espace ne signifie pas le gouverner ; être capable d’y envoyer un engin ne donne pas nécessairement un droit de propriété. La géopolitique étudie précisément l’écart entre capacités techniques, prétentions des acteurs et règles applicables.

Les océans sont des milieux, des réservoirs de ressources et des supports de circulation. L’espace proche de la Terre accueille des fonctions devenues essentielles : télécommunications, navigation, météorologie et observation. Les deux domaines sont liés : des satellites guident et surveillent les navires ; les câbles sous-marins portent une partie majeure des échanges numériques. Leur maîtrise produit donc des effets sur les territoires terrestres. Les enjeux ne se limitent pas à des exploits lointains : ils concernent la sécurité, l’économie et la vie quotidienne.

## Axe 1 — Conquêtes, affirmations de puissance et rivalités

### La conquête spatiale : de la guerre froide à la diversification des acteurs {#T01-AXE1-J01}

Le lancement de Spoutnik par l’URSS en 1957 puis le vol de Youri Gagarine en 1961 donnent à la compétition spatiale une visibilité mondiale. Les fusées mobilisent des savoirs également utiles aux missiles ; la prouesse scientifique devient une démonstration de capacité industrielle et militaire. Les États-Unis répondent notamment par le programme Apollo, qui conduit des astronautes sur la Lune en 1969. Les images, les discours et les calendriers des missions participent à une lutte de prestige entre systèmes politiques. ([B30](#ref-B30) ; [R-T01](#ref-R-T01))

Cette compétition ne se réduit pas à une succession de « premières ». Elle repose sur des budgets, des ingénieurs, des bases de lancement, des industries et des choix de risque. Les retombées concernent les communications, l’observation et l’organisation de la recherche. La coopération Apollo-Soyouz de 1975 montre qu’une rivalité peut coexister avec un rapprochement diplomatique : compétition et coopération ne sont pas deux périodes totalement séparées.

D’autres États et ensembles régionaux développent des capacités : la France et les programmes européens, le Japon, la Chine ou l’Inde ne poursuivent pas tous les mêmes priorités. L’autonomie d’accès à l’espace, la maîtrise des télécommunications ou l’observation du territoire peuvent compter davantage qu’un vol habité. Une comparaison pertinente porte donc sur les fonctions maîtrisées, non sur un palmarès unique. ([B30](#ref-B30))

Les entreprises privées occupent une place croissante dans les lancements, les satellites et les services. Le « New Space » désigne notamment de nouveaux modèles industriels et financiers, avec la réutilisation de certains lanceurs et la multiplication de constellations. Pourtant, les États restent essentiels par les commandes publiques, les autorisations, la recherche et les usages militaires. Une société commerciale ne remplace pas la souveraineté ; elle peut devenir un partenaire indispensable et créer de nouvelles dépendances.

Enfin, la militarisation ne signifie pas seulement installer des armes : renseignement, navigation et communications soutiennent des opérations terrestres. Il faut distinguer ces usages de l’**arsenalisation**, c’est-à-dire du développement ou de l’emploi de moyens d’action offensive dans ou contre l’espace. Débris et collisions font peser des risques sur tous les opérateurs. Le traité de 1967 interdit notamment l’appropriation nationale et la mise en orbite d’armes nucléaires ou d’autres armes de destruction massive ; il ne bannit pas indistinctement tout usage militaire de l’espace. ([D08](#ref-D08))

### Les mers : dissuader, projeter, sécuriser les circulations {#T01-AXE1-J02}

Une marine de guerre peut protéger des approches maritimes, escorter des navires, surveiller des routes et intervenir loin du territoire national. Ces missions demandent des bâtiments, des équipages, des ports, du renseignement et du ravitaillement. Le nombre de navires ne suffit donc pas à mesurer une puissance : leur disponibilité, leurs capacités, leur soutien logistique et la coordination avec d’autres forces sont déterminants. ([B31](#ref-B31) ; [R-T01](#ref-R-T01))

La **dissuasion nucléaire** cherche à prévenir une attaque en faisant craindre des dommages jugés inacceptables. Les sous-marins nucléaires lanceurs d’engins, difficiles à détecter lorsqu’ils patrouillent, contribuent à la capacité de riposte. Leur fonction n’est pas de participer ordinairement à une bataille navale. La crédibilité repose sur la capacité technique, la survivabilité des moyens et la perception de la volonté politique. Elle ne garantit pas l’absence de toute guerre, notamment sous le seuil envisagé par la doctrine.

La **projection de puissance** permet d’agir à distance : groupes aéronavals, bâtiments amphibies, missiles et forces embarquées donnent des options d’intervention. Un porte-avions sert de base aérienne mobile, mais dépend d’une protection et d’un soutien. Les bases et accords d’accès complètent cette mobilité. Les détroits et canaux concentrent les flux et constituent des points sensibles : sécuriser une route n’équivaut pas à posséder les espaces qu’elle traverse.

Les États-Unis disposent d’un réseau d’alliances et de points d’appui ; la France associe dissuasion, capacités de projection et présence ultramarine ; la Chine développe ses moyens maritimes dans un contexte de dépendance aux échanges et de rivalités régionales. L’analyse doit relier chaque capacité à un objectif et à une limite. Par exemple, une présence navale peut protéger des ressortissants ou afficher une détermination, mais aussi provoquer des réactions adverses et accroître un risque d’incident.

**Document T01-Doc1 — Fonctions navales, synthèse éditoriale.**

| Moyen ou dispositif | Fonction principale étudiée | Ce qu’il ne prouve pas à lui seul |
|---|---|---|
| Sous-marin lanceur d’engins | Préserver une capacité de riposte nucléaire. | L’impossibilité de tout conflit limité. |
| Groupe aéronaval | Projeter une capacité aérienne et soutenir une présence. | Une autonomie logistique illimitée. |
| Base ou accord d’accès | Entretenir, ravitailler, coordonner. | La souveraineté sur tout l’espace environnant. |

## Axe 2 — Enjeux diplomatiques et coopérations

### La Station spatiale internationale : une interdépendance organisée {#T01-AXE2-J01}

L’assemblage de la Station spatiale internationale commence en 1998 ; une présence humaine continue y est assurée depuis novembre 2000. Le projet associe les agences américaine, russe, européenne, japonaise et canadienne. Il permet des recherches en microgravité, des observations et des expériences sur les conditions du séjour spatial. La coopération est inscrite dans des accords définissant les contributions, les responsabilités et les usages. ([B32](#ref-B32))

La station illustre une division internationale des compétences : modules, transports, robotique, énergie, systèmes de contrôle et équipes scientifiques se complètent. Cette spécialisation réduit certains coûts et rend possibles des opérations qu’un partenaire ne mènerait pas nécessairement seul. Mais elle crée aussi une dépendance : le fonctionnement collectif suppose l’entretien des interfaces, des procédures communes et une continuité des engagements.

La coopération ne découle pas spontanément de la seule science. Elle répond à des objectifs diplomatiques, industriels et budgétaires ; le rapprochement avec la Russie après la guerre froide en constitue une dimension historique. Les tensions internationales peuvent fragiliser les relations, tandis que les contraintes techniques favorisent la poursuite de certains échanges. Il serait donc excessif de présenter la station comme un espace totalement soustrait à la politique ou comme un simple décor diplomatique sans activité scientifique réelle.

Pour analyser le jalon, distinguez trois résultats : **production de connaissances**, **partage des capacités** et **maintien d’une relation institutionnelle**. Un désaccord sur Terre ne conduit pas automatiquement à l’arrêt immédiat de toutes les coopérations ; leur poursuite ne signifie pas une réconciliation générale. Les calendriers de fin d’exploitation ou de remplacement sont des projets susceptibles d’évoluer : ils ne doivent pas être appris comme des faits déjà accomplis.

### Gouverner les mers : exploitation, partage et biodiversité {#T01-AXE2-J02}

La convention de Montego Bay de 1982, entrée en vigueur en 1994, fournit le cadre étudié en P03. Elle distingue souveraineté en mer territoriale, droits souverains dans la ZEE, régime du plateau continental et espaces au-delà des juridictions nationales. Cette différenciation permet d’organiser l’exploitation et les circulations ; elle ne transforme pas toute la mer en un ensemble de territoires nationaux. ([D02](#ref-D02))

Les rivalités portent sur les délimitations, les ressources halieutiques, les hydrocarbures, les routes et les fonctions stratégiques. Les organisations régionales, les accords de pêche et les juridictions internationales peuvent contribuer à la coopération. Cependant, une décision juridique n’est pas automatiquement appliquée, et des acteurs privés jouent un rôle important dans l’exploitation. Il faut donc observer la chaîne allant de la règle au contrôle effectif.

La protection de la biodiversité exige de dépasser les frontières : espèces migratrices, pollutions et changements climatiques circulent entre espaces. Une aire marine protégée ne produit pas les mêmes effets selon ses règles, ses moyens de surveillance et les activités effectivement interdites. L’annonce d’une surface protégée doit être distinguée de la qualité de la protection. Les intérêts économiques, les moyens scientifiques et les capacités de contrôle sont très inégaux entre États.

**Actualisation vérifiée au 8 septembre 2026.** L’accord BBNJ sur la conservation et l’utilisation durable de la biodiversité marine au-delà des juridictions nationales, adopté le 19 juin 2023, est entré en vigueur le **17 janvier 2026**. Il ne faut plus le présenter comme un simple projet en attente d’entrée en vigueur. Il traite notamment des ressources génétiques marines, des outils de gestion par zone, des évaluations environnementales et du renforcement des capacités. Son existence juridique ne prouve pas que tous les espaces sont déjà protégés ni que tous les États y participent. ([D03](#ref-D03))

**Exemple résolu.** « La haute mer est-elle un espace sans droit ? » Non : des règles internationales existent. Le problème peut être la fragmentation des compétences, l’adhésion des États, le contrôle et l’exécution. Remplacer « absence de droit » par « difficulté de gouvernance et d’application » permet une explication plus précise. L’accord BBNJ complète ce cadre sans devenir un gouvernement mondial des océans.

## Objet de travail conclusif — La Chine : à la conquête de l’espace, des mers et des océans

### Affirmer une volonté politique : discours, investissements et appropriations {#T01-OTC-J01}

Les ambitions chinoises associent prestige, développement industriel, autonomie stratégique et sécurité. Le programme spatial s’inscrit dans une histoire de longue durée : premier satellite chinois en 1970, premier vol habité national avec Yang Liwei en 2003, puis développement de missions lunaires et d’une station. Ces étapes mobilisent des institutions, des ingénieurs et des entreprises ; elles ne sont pas seulement des événements de communication. ([B33](#ref-B33) ; [R-T01](#ref-R-T01))

La mission Chang’e-6 a rapporté sur Terre, le 25 juin 2024, les premiers échantillons prélevés sur la face cachée de la Lune. Cette réalisation montre une capacité scientifique et technique complexe, notamment en communication et en retour d’échantillons. La présence d’un drapeau a une signification symbolique ; elle ne crée pas une souveraineté lunaire. Le récit officiel de la mission constitue une source sur les résultats annoncés et sur la manière dont l’État les valorise. ([B33](#ref-B33) ; [D08](#ref-D08))

Sur mer, la modernisation navale et les aménagements d’îlots ou de récifs en mer de Chine méridionale servent des objectifs de présence et de contrôle. Il faut distinguer revendication, occupation matérielle, statut juridique des formations et droits maritimes éventuels. Une île artificielle n’acquiert pas automatiquement les droits d’une île naturelle au sens de la convention. La décision arbitrale de 2016 dans l’affaire engagée par les Philippines a traité plusieurs questions de droits maritimes ; elle n’a pas tranché la souveraineté sur toutes les terres disputées. ([B34](#ref-B34) ; [D02](#ref-D02))

Le langage des « appropriations » doit donc être utilisé avec précision. Il peut décrire une prise de contrôle de fait, une tentative de normalisation d’une présence ou une revendication symbolique, sans signifier que celle-ci est reconnue juridiquement. Les investissements portuaires à l’étranger doivent aussi être étudiés contrat par contrat : concession commerciale, participation financière et installation militaire ne sont pas équivalentes.

### Des enjeux économiques et géopolitiques pour la Chine et le reste du monde {#T01-OTC-J02}

La Chine dépend de routes maritimes pour ses approvisionnements et ses exportations. Les ports, les détroits et les capacités de transport constituent des enjeux de sécurité économique. Les nouvelles routes de la soie, étudiées en P02, cherchent à améliorer des connexions et à diversifier les points d’appui. L’objectif peut être de réduire certaines vulnérabilités, mais chaque infrastructure crée aussi des coûts, des engagements et des relations avec les États partenaires. ([B11](#ref-B11) ; [R-T01](#ref-R-T01))

Les satellites contribuent à l’observation, aux communications et à la navigation ; la maîtrise de ces fonctions réduit la dépendance à des systèmes étrangers. Elle peut soutenir des services commerciaux et des capacités militaires. L’autonomie n’est pourtant jamais absolue : composants, marchés, connaissances et normes circulent. Une stratégie nationale doit donc être analysée à travers les chaînes de valeur et les réseaux internationaux.

Les voisins et les autres puissances réagissent à ces ambitions. Alliances, exercices, contestations juridiques, coopérations scientifiques et choix économiques composent des réponses diverses. Présenter toute l’Asie comme un bloc opposé ou soumis à la Chine effacerait les stratégies propres des États. Un pays peut commercer intensément avec la Chine tout en contestant une revendication maritime ou en recherchant un partenariat de sécurité ailleurs.

**Document T01-Doc2 — Chaîne d’analyse d’une infrastructure stratégique.** Schéma conceptuel éditorial :

**Investissement → capacité technique → service ou présence → dépendances et effets politiques → réactions des autres acteurs.**

À chaque flèche, une condition intervient : financement durable, personnel qualifié, contrats, droit applicable, acceptation des partenaires. Le schéma n’établit pas qu’un investissement produit nécessairement une domination. Il fournit une grille pour démontrer ou nuancer cet effet dans un cas précis.

Le bilan doit articuler rivalité et coopération. Les océans et l’espace renforcent la compétition parce qu’ils concentrent des ressources et des services stratégiques ; ils rendent également les acteurs interdépendants face aux risques, aux coûts et aux besoins de connaissance. Le problème n’est pas de choisir entre deux descriptions exclusives, mais d’expliquer leur coexistence.

## S’entraîner, retenir, transférer

**Activité T01-A — 25 minutes.** Appliquez T01-Doc2 à une mission spatiale puis à un port. Dans chaque cas, indiquez un objectif, deux conditions de réussite, un effet possible et une limite. Terminez par ce qui rend les deux cas juridiquement différents.

**Synthèse.** La conquête transforme des capacités techniques en prestige, services, ressources ou moyens militaires. La puissance maritime distingue dissuasion et projection ; la puissance spatiale associe fonctions civiles et stratégiques. L’ISS montre une coopération structurée par des interdépendances. Le droit de la mer et l’accord BBNJ organisent des usages sans abolir les rivalités. La Chine illustre une ambition globale dont les effets dépendent des réactions, des règles et des coûts.

**Repères.** 1957 : Spoutnik ; 1961 : Gagarine ; 1967 : traité de l’espace ; 1969 : Apollo 11 ; 1975 : Apollo-Soyouz ; 1982/1994 : Montego Bay ; 1998/2000 : assemblage puis présence continue dans l’ISS ; 2003 : vol de Yang Liwei ; 2016 : sentence arbitrale sur la mer de Chine méridionale ; 2024 : retour de Chang’e-6 ; 2026 : entrée en vigueur de BBNJ.

**Transfert.** T02 : coopération et sécurité collective ; T05 : biens communs, environnement et application des engagements ; T06 : infrastructures de connaissance et souveraineté.

**Références.** S03–S04 ; R-T01 ; B30 à B34 ; B11 ; D02–D03 ; D08. Les deux documents sont des synthèses nouvelles. Les exemples contemporains sont datés ; les programmes futurs ne sont pas présentés comme réalisés.

## Entraînements — T01 {#T01-entrainements}

Les degrés 1, 2 et 3 désignent la difficulté, non les parcours N1/N2. Commencez sans aide ; consultez ensuite l’indice si nécessaire. Les corrections, les critères détaillés et les remédiations sont dans le compagnon, sous les mêmes identifiants.

### T01-E1 — Conquête et appropriation {#T01-E1}

**Degré 1 · 20 minutes · Méthode M1**

Expliquez pourquoi planter un drapeau sur la Lune, exploiter une ressource dans une ZEE et naviguer en haute mer ne relèvent pas du même régime. Utilisez les notions de souveraineté, droits et liberté.

**Aide, après une première tentative.** La présence technique n’est pas automatiquement un titre de propriété.

### T01-E2 — Une chronologie spatiale explicative {#T01-E2}

**Degré 1 · 25 minutes · Méthode M2**

Choisissez cinq repères entre 1957 et 2024 : Spoutnik, premier vol humain, Apollo 11, ISS, Chang’e 6. Pour chacun, expliquez une fonction scientifique ou géopolitique. Refusez une lecture réduite à une course unique et continue.

**Aide, après une première tentative.** La compétition bipolaire, la coopération et la diversification des acteurs n’ont pas exactement les mêmes logiques.

### T01-E3 — Dissuasion et projection navales {#T01-E3}

**Degré 2 · 25 minutes · Méthode M5**

Comparez un sous-marin nucléaire lanceur d’engins et un porte-avions selon objectif, visibilité, emploi et limites. Pourquoi leur possession ne donne-t-elle pas une maîtrise absolue des océans ?

**Aide, après une première tentative.** La dissuasion repose notamment sur la crédibilité d’une capacité de riposte ; la projection permet une action éloignée.

### T01-E4 — L’ISS : une coopération sous conditions {#T01-E4}

**Degré 2 · 30 minutes · Méthode M3**

**Document éditorial d’après la NASA** ([B32](#ref-B32)) : l’ISS associe cinq agences partenaires ; son assemblage commence en 1998 et une présence humaine continue débute en novembre 2000. Les partenaires apportent des modules, des moyens, des équipages et des compétences.

Expliquez deux raisons de coopérer, deux contraintes et une limite de ce document pour conclure à la fin des rivalités.

**Aide, après une première tentative.** Le partage des coûts et des capacités ne signifie pas disparition des intérêts nationaux.

### T01-E5 — Droit maritime et coopération {#T01-E5}

**Degré 2 · 30 minutes · Méthode M6**

Comparez la convention de 1982 sur le droit de la mer et l’accord BBNJ : objets, espaces concernés et moyens de coopération. Expliquez pourquoi l’entrée en vigueur du BBNJ le 17 janvier 2026 ne supprime pas toutes les rivalités maritimes.

**Aide, après une première tentative.** Le BBNJ concerne la biodiversité au-delà des juridictions nationales ; il ne remplace pas toute la convention de 1982.

### T01-E6 — La Chine : capacités et effets de puissance {#T01-E6}

**Degré 2 · 35 minutes · Méthode M6**

Proposez un plan pour « Océans et espace : des instruments de l’affirmation chinoise ». Utilisez une capacité spatiale, une capacité maritime, une infrastructure et une limite juridique ou politique.

**Aide, après une première tentative.** Organisez le passage de l’investissement à la capacité, puis à l’effet ; ne confondez pas un port commercial et une base militaire.

### T01-E7 — Dissertation de formation hors rotation écrite 2027 {#T01-E7}

**Degré 3 · 110 minutes · Méthode M9**

Entraînement de formation, **pas un sujet blanc de l’écrit 2027** : « Les nouveaux espaces de conquête : rivalités et coopérations ». Rédigez en 110 minutes en croisant océans et espace.

**Aide, après une première tentative.** Le thème T01 reste enseigné mais ne figure pas dans la rotation écrite 2027. Le travail prépare des transferts et l’oral.

### T01-E8 — Présenter un schéma de conquête {#T01-E8}

**Degré 3 · 30 minutes · Méthode M11**

À partir des exemples du cours et du schéma A02 du carnet, préparez trois minutes sur une chaîne « investissement → capacité → effet géopolitique → limite ». Choisissez une mission spatiale et un équipement naval ; comparez-les sans détails techniques inutiles.

**Aide, après une première tentative.** Une capacité doit avoir un effet identifié : observer, dissuader, projeter, coopérer ou montrer un savoir-faire.

### T01 — QCM de vérification {#T01-qcm}

Une seule proposition correcte par question. Notez votre réponse et justifiez-la en une phrase ; la correction explique aussi pourquoi les autres propositions ne conviennent pas.

**T01-Q1.** Le traité de l’espace de 1967…

**A.** autorise l’annexion par plantation d’un drapeau

**B.** pose un principe de non-appropriation nationale

**C.** interdit toute coopération scientifique

**T01-Q2.** La présence humaine continue sur l’ISS débute en…

**A.** 2000

**B.** 1957

**C.** 1969

**T01-Q3.** Un porte-avions et un SNLE…

**A.** ont toujours exactement la même fonction

**B.** garantissent une victoire politique

**C.** contribuent à des fonctions stratégiques différentes

**T01-Q4.** L’accord BBNJ entre en vigueur le…

**A.** 19 juin 2023

**B.** 17 janvier 2026

**C.** 1er janvier 1982

**T01-Q5.** Un port commercial à participation chinoise…

**A.** n’est pas automatiquement une base militaire

**B.** prouve toujours une annexion

**C.** n’a jamais aucun enjeu stratégique

### T01-RT — Nouveau test et réactivation {#T01-RT}

**20 minutes, sans cours, à distance du premier entraînement.**

1. Distinguez projection et dissuasion. 2. Expliquez un bénéfice et une contrainte de l’ISS. 3. Pourquoi une revendication ou une présence ne suffit-elle pas à créer un droit d’appropriation ?

**Vérifier la maîtrise.** Réussite : trois réponses justifiées, avec notions distinguées et exemples situés. Une erreur de date appelle R1 ; une confusion de notion R2 ; une relation non expliquée R3. Refaire le point faible à J+2.

**Réactivation espacée.** J+7 : Restituer 1957, 1967, 1969, 1998/2000 et 2026 avec leur fonction. J+21 : Utiliser l’ISS pour expliquer la production collective des connaissances de T06.

**Trace de progression.** Date : … · Je restitue : oui / à reprendre · J’explique : oui / à reprendre · Je mobilise dans un sujet nouveau : oui / à reprendre · Erreur prioritaire : … · Nouvelle tentative prévue : …

# T02 — Faire la guerre, faire la paix : formes de conflits et modes de résolution {#t02}

**Terminale • Parcours N2 • Thème évaluable à l’écrit en 2027**

**Question directrice.** Comment les objectifs politiques organisent-ils la guerre, et pourquoi l’arrêt des combats ne suffit-il pas à construire une paix durable ?

**Objectifs.** Distinguer les formes de conflictualité ; mobiliser Clausewitz sans le réduire à une formule ; comparer paix négociée et sécurité collective ; expliquer l’emboîtement des acteurs au Moyen-Orient.

**Diagnostic T02-D — 10 minutes.** Toute rivalité est-elle une guerre ? Une guerre menée par un groupe non étatique est-elle dépourvue d’objectif politique ? Une victoire militaire garantit-elle une paix ? Appuyez chaque distinction sur un exemple ou un mécanisme.

**Itinéraire.** Reprendre P02 et P03 ; axe 1 puis E1–E3 ; axe 2 puis E4–E5 ; Moyen-Orient puis E6–E8. Après le chapitre, réaliser une dissertation puis une étude critique sur deux séances distinctes avant un écrit complet de quatre heures.

## Introduction — Nommer les conflits, définir les paix

Un **conflit** est une opposition d’intérêts, de positions ou de projets ; il peut être négocié sans violence. Une **guerre** implique une violence armée organisée entre acteurs politiques. Les classifications distinguent conflits interétatiques, conflits internes et conflits internes internationalisés. Elles ne sont pas des cases immuables : une guerre peut changer de forme, et plusieurs dimensions peuvent coexister. ([S03](#ref-S03) ; [R-T02](#ref-R-T02))

Les acteurs comprennent États, armées régulières, organisations internationales, groupes armés, entreprises et populations civiles. Ces dernières ne sont pas de simples spectatrices : elles peuvent subir déplacements, destructions et violences, mais aussi s’organiser pour survivre, documenter ou négocier. Une carte de conflits doit préciser sa date, son indicateur et son échelle. Le nombre d’événements, de victimes ou de conflits actifs ne mesure pas la même chose ; le manuel ne propose pas de classement contemporain sans données définies.

La **guerre régulière** oppose principalement des forces organisées selon des cadres militaires identifiables ; la **guerre irrégulière** emploie notamment guérilla, dispersion et évitement du combat frontal. L’**asymétrie** désigne un déséquilibre de moyens ou de méthodes, non l’absence d’organisation du plus faible. Le terrorisme est une stratégie de violence visant notamment à produire un effet de peur et de contrainte politique au-delà des victimes immédiates ; il ne résume pas toutes les guerres irrégulières.

Une paix « négative » désigne l’absence de violence armée directe ; une paix plus substantielle suppose sécurité, institutions, droits et traitement des causes du conflit. Cessez-le-feu, armistice, traité, réconciliation et reconstruction ne sont donc pas synonymes. La question centrale du thème est celle du passage **d’un rapport de force à un ordre jugé suffisamment acceptable pour durer**.

## Axe 1 — La dimension politique de la guerre : des conflits interétatiques aux enjeux transnationaux

### Clausewitz : de la guerre de Sept Ans aux guerres napoléoniennes {#T02-AXE1-J01}

Officier prussien marqué par les guerres de son temps, Carl von Clausewitz élabore une réflexion publiée après sa mort dans *De la guerre*, à partir de 1832. Son objet n’est pas de justifier moralement chaque guerre, mais d’expliquer sa nature et sa conduite. La violence vise à contraindre un adversaire ; elle s’inscrit dans un objectif politique. La formule sur la continuation de la politique signifie que la guerre ne devient pas, une fois engagée, un domaine sans finalité ni décision politique. ([B35](#ref-B35))

La guerre de Sept Ans, de 1756 à 1763, permet d’étudier une compétition entre puissances, dynasties et empires. Elle se déroule en Europe mais aussi dans des espaces coloniaux ; les rivalités franco-britanniques associent commerce, possessions et maîtrise maritime. Les armées et les finances imposent des contraintes. Décrire cette guerre comme « limitée » par certains objectifs ne signifie pas qu’elle serait peu violente pour les populations ou confinée à un seul continent. ([R-T02](#ref-R-T02) ; [B35a](#ref-B35a))

Les guerres révolutionnaires puis napoléoniennes changent l’échelle des mobilisations. La levée en masse de 1793 et la conscription élargissent les ressources militaires ; l’engagement national, les réformes administratives et les ambitions impériales renforcent la capacité de poursuivre l’adversaire. Les victoires françaises entraînent occupations et résistances, notamment en Espagne. La guerre ne concerne plus seulement les calculs de cabinets, mais aussi des mobilisations collectives et des projets de transformation politique.

Clausewitz distingue la logique abstraite d’une montée réciproque aux extrêmes et les guerres réelles, limitées ou orientées par les buts, les moyens, les informations disponibles et les circonstances. La **friction** désigne l’accumulation d’obstacles qui sépare un plan de son exécution. Sa « trinité » articule passions et hostilité, hasard et probabilités, finalité politique et raison ; la réduire mécaniquement à trois institutions fixes ferait perdre sa portée. ([B35](#ref-B35))

Il faut surtout distinguer **guerre absolue**, construction théorique, et **guerre totale**, notion historique associée à la mobilisation de sociétés entières et à l’extension des moyens et des cibles. Une bataille décisive ou une grande armée ne suffit pas à rendre les termes interchangeables. Pour mobiliser Clausewitz dans une dissertation, identifiez l’objectif, la relation entre moyens et fins, puis les contraintes qui modifient la conduite effective de la guerre.

### Al-Qaïda et Daech : transformations et permanence du politique {#T02-AXE1-J02}

Al-Qaïda se structure à la fin des années 1980 dans le contexte des mobilisations liées à la guerre d’Afghanistan. L’organisation développe un projet djihadiste transnational et utilise notamment les attentats pour frapper des adversaires, attirer l’attention et susciter des effets politiques. Les attaques du 11 septembre 2001 montrent la capacité d’un réseau non étatique à provoquer des conséquences internationales majeures sans disposer d’une armée comparable à celle des États-Unis. ([B36a](#ref-B36a) ; [R-T02](#ref-R-T02))

Daech, également appelé organisation État islamique, se développe à partir de la conflictualité irakienne puis syrienne. En 2014, il conquiert des territoires et proclame un « califat ». Cette prétention ne doit pas être confondue avec une légitimité religieuse reconnue ou avec la reconnaissance d’un État par la communauté internationale. Le groupe associe administration coercitive, prélèvements de ressources, propagande, combats et attentats. Il commet des violences de masse contre des populations diverses.

Les deux organisations ne sont pas identiques. Al-Qaïda privilégie historiquement une logique de réseau transnational, tandis que Daech a combiné un projet territorial particulièrement visible avec des branches et des actions extérieures. La perte de son dernier territoire majeur en Syrie en 2019 ne signifie pas la disparition de toutes ses cellules, de ses réseaux ou de son idéologie. Il faut distinguer contrôle territorial et capacité de nuisance. ([B36a](#ref-B36a))

Ces acteurs contestent la forme classique de la guerre interétatique : frontières traversées, combattants dispersés, cibles civiles et usages numériques compliquent l’identification du théâtre de guerre et des conditions d’une victoire. Pour autant, leurs objectifs restent politiques : imposer un ordre, gouverner, délégitimer des États ou modifier des comportements. Affirmer que Clausewitz ne s’appliquerait plus parce que l’adversaire n’est pas un État serait donc trop rapide.

La pertinence du modèle se discute précisément : le lien entre violence et finalité demeure utile ; les acteurs, les échelles et les modes de négociation se transforment. Une réponse critique doit montrer à la fois ce qui reste explicatif et ce qui demande adaptation. Lutter contre une organisation ne se réduit pas à détruire une armée : police, renseignement, justice, prévention et reconstruction des institutions peuvent être nécessaires, avec des obligations de respect des droits.

## Axe 2 — Le défi de la construction de la paix

### Westphalie en 1648 : négocier un ordre après des guerres prolongées {#T02-AXE2-J01}

Les négociations de Münster et d’Osnabrück aboutissent en 1648 à des traités qui mettent fin à la guerre de Trente Ans dans le Saint-Empire et règlent d’autres conflits, notamment entre l’Espagne et les Provinces-Unies. Les enjeux sont religieux, dynastiques et territoriaux. Les alliances ne suivent pas une simple opposition entre catholiques et protestants : la France catholique combat la puissance des Habsbourg. ([B36](#ref-B36) ; [R-T02](#ref-R-T02))

La négociation est longue parce qu’elle doit coordonner des intérêts multiples, déterminer des garanties et rendre un compromis acceptable. Les traités règlent des questions territoriales et institutionnelles, ainsi que des équilibres confessionnels. Ils reconnaissent des capacités d’action aux composantes du Saint-Empire tout en maintenant cet ensemble. Ils ne créent donc pas instantanément une Europe composée d’États-nations souverains identiques aux États actuels.

L’expression « ordre westphalien » sert souvent à désigner un système fondé sur la souveraineté et les relations entre États. Elle est utile comme modèle, mais devient trompeuse lorsqu’elle transforme 1648 en date de naissance absolue de tous les principes contemporains. Les souverainetés restent imbriquées, les hiérarchies dynastiques persistent et toutes les guerres ne cessent pas : la guerre franco-espagnole se poursuit jusqu’en 1659.

Le mécanisme central est celui d’une **paix garantie par un compromis politique et juridique**, soutenu par des rapports de force. Une signature ne supprime ni les mémoires de violence ni les intérêts concurrents. La stabilité dépend de l’application des clauses, des garanties et de la capacité des acteurs à préférer cet ordre à une reprise de la guerre. Ce jalon permet ainsi d’expliquer pourquoi la paix ne se réduit pas à la volonté morale de cesser les combats.

### L’ONU sous Kofi Annan, 1997–2006 : la sécurité collective et ses limites {#T02-AXE2-J02}

La Charte des Nations unies de 1945 fonde un système de **sécurité collective** : une menace contre la paix est une question d’intérêt commun. Le Conseil de sécurité possède une responsabilité centrale ; il peut décider de mesures non militaires ou autoriser l’emploi de la force dans le cadre du chapitre VII. L’interdiction du recours à la force et la légitime défense prévue à l’article 51 doivent être étudiées ensemble. L’ONU n’est cependant pas un État mondial disposant automatiquement de ses propres moyens militaires. ([D09](#ref-D09))

Kofi Annan exerce deux mandats de secrétaire général de 1997 à 2006. Il cherche à renforcer la prévention, les opérations de paix et la prise en compte des droits humains. Les échecs du Rwanda en 1994 et de Srebrenica en 1995 précèdent ses mandats de secrétaire général ; ils pèsent sur cette réflexion. Annan avait alors des responsabilités au sein du département des opérations de maintien de la paix : distinguer les fonctions et les dates évite une attribution erronée. ([B37](#ref-B37))

Les opérations peuvent surveiller un cessez-le-feu, protéger des civils selon leur mandat, soutenir un processus électoral ou contribuer à reconstruire des institutions. Les expériences du Timor oriental et de la Sierra Leone montrent que l’action combine dimensions militaires, administratives et politiques. Les résultats dépendent du mandat, des moyens fournis par les États, de la coopération locale et de la durée de l’engagement. Le casque bleu n’est pas un symbole qui produirait la paix indépendamment de ces conditions.

En 2005, les États membres reconnaissent la responsabilité de protéger les populations contre le génocide, les crimes de guerre, le nettoyage ethnique et les crimes contre l’humanité. Le texte prévoit d’abord la responsabilité des États et des moyens pacifiques, ainsi qu’une action collective selon la Charte lorsque les conditions sont réunies. Il ne crée pas un droit général pour n’importe quel État d’envahir un autre au nom d’une intention humanitaire. ([B37a](#ref-B37a))

Les désaccords entre membres permanents, leurs intérêts et le veto peuvent bloquer une décision. La guerre en Irak en 2003 illustre la crise du multilatéralisme lorsque des États agissent sans nouvelle autorisation explicite du Conseil pour cette intervention. L’évaluation de l’ONU doit donc éviter deux excès : la déclarer toute-puissante ou conclure de ses limites qu’elle ne sert à rien. Elle fournit des normes, des espaces de négociation et des opérations dont les effets doivent être examinés cas par cas.

**Document T02-Doc1 — Trois moyens de paix.** Synthèse pédagogique, d’après D09, B36 et B37.

| Moyen | Ce qu’il peut obtenir | Condition décisive |
|---|---|---|
| Traité | Définir un compromis et des engagements. | Acceptation, garanties et application. |
| Opération de paix | Sécuriser et soutenir un processus selon un mandat. | Moyens, coopération et stratégie politique. |
| Justice et reconstruction | Traiter des crimes, restaurer des droits et des institutions. | Accès aux preuves, légitimité et durée. |

## Objet de travail conclusif — Le Moyen-Orient, conflits et tentatives de paix

### Du conflit israélo-arabe au conflit israélo-palestinien : des dimensions qui se superposent {#T02-OTC-J01}

Le conflit s’inscrit dans la fin de l’Empire ottoman, le mandat britannique en Palestine, les projets nationaux sioniste et arabe palestinien, les migrations et les effets de l’antisémitisme européen puis du génocide des Juifs. Le plan de partage adopté par l’Assemblée générale de l’ONU en 1947 propose deux États et un statut particulier pour Jérusalem. La proclamation d’Israël en mai 1948 et la guerre avec des États arabes conduisent à un nouvel ordre territorial. Pour les Palestiniens, l’exode, les expulsions et la perte du cadre de vie constituent la **Nakba**. ([B38](#ref-B38) ; [R-T02](#ref-R-T02))

Les guerres de 1956, 1967 et 1973 associent rivalités régionales et interventions des grandes puissances. En 1967, Israël occupe notamment la Cisjordanie, Jérusalem-Est, Gaza, le Golan et le Sinaï. La résolution 242 du Conseil de sécurité devient une référence des négociations, articulant retrait de territoires occupés et droit des États à vivre en paix dans des frontières sûres et reconnues. Les désaccords sur l’interprétation et l’application ne doivent pas être effacés. ([B38a](#ref-B38a))

La question palestinienne acquiert une expression politique propre, notamment avec l’Organisation de libération de la Palestine. La centralité croissante du conflit israélo-palestinien ne fait pas disparaître les dimensions interétatiques. Les accords de Camp David de 1978 puis le traité israélo-égyptien de 1979 montrent qu’une paix entre États peut progresser sans régler l’ensemble des revendications palestiniennes. Le traité avec la Jordanie en 1994 constitue un autre exemple de dissociation partielle des dossiers.

Les accords d’Oslo de 1993 ouvrent un processus de reconnaissance mutuelle et d’autonomie palestinienne transitoire. Ils ne créent pas immédiatement un État palestinien souverain et ne résolvent pas les questions de Jérusalem, des réfugiés, des frontières, des colonies et de la sécurité. La colonisation, les violences, l’assassinat d’Yitzhak Rabin en 1995, les divisions politiques et l’échec de négociations contribuent à fragiliser le processus. La seconde Intifada à partir de 2000, puis la séparation politique entre la Cisjordanie et Gaza après 2007, complexifient les interlocuteurs.

Les attaques du 7 octobre 2023 menées par le Hamas et d’autres groupes contre Israël, comprenant des massacres de civils et des prises d’otages, puis la guerre conduite par Israël à Gaza, les destructions, déplacements et pertes civiles massives, imposent de distinguer populations, gouvernements et organisations armées. Aucune population ne doit être rendue collectivement responsable des décisions de ses dirigeants. Le droit international humanitaire s’applique aux parties indépendamment de leurs justifications politiques. ([B38b](#ref-B38b))

L’avis consultatif de la Cour internationale de Justice du 19 juillet 2024 porte sur les conséquences juridiques de l’occupation et juge illicite la présence continue d’Israël dans le territoire palestinien occupé. Il ne doit pas être confondu avec une décision finale dans une procédure distincte relative au génocide, ni avec un jugement pénal contre des individus. **Au point documentaire du 8 septembre 2026**, les communications onusiennes du 26 août continuent de souligner la gravité de la situation humanitaire à Gaza et l’interdépendance entre reconstruction et processus politique. Aucun règlement définitif n’est supposé dans ce manuel. ([B38c](#ref-B38c) ; [B38d](#ref-B38d))

Le changement d’échelle est la clé : revendications nationales, sécurité, occupation, droits des populations, rivalités régionales et médiations internationales s’imbriquent. Une conclusion recevable ne promet pas une solution simple ; elle précise les conditions qu’un accord devrait traiter et les obstacles à sa mise en œuvre.

### Les guerres du Golfe de 1991 et 2003 : gagner la guerre, construire quel ordre ? {#T02-OTC-J02}

En août 1990, l’Irak de Saddam Hussein envahit le Koweït. Le Conseil de sécurité condamne l’invasion et adopte sanctions puis autorisation de recours à la force dans la résolution 678. En 1991, une coalition conduite par les États-Unis chasse les forces irakiennes du Koweït. L’objectif affiché est la restauration de la souveraineté koweïtienne, non l’occupation durable de tout l’Irak. La supériorité militaire de la coalition s’inscrit dans un cadre multilatéral largement soutenu. ([B39](#ref-B39))

Le cessez-le-feu et les dispositifs de désarmement ne mettent pas fin à toutes les tensions. Sanctions, inspections, répression interne et crises successives marquent les années 1990. Une victoire dans un conflit interétatique peut donc laisser subsister un ordre régional instable. Il faut distinguer l’objectif opérationnel atteint et les conséquences politiques et humaines de plus longue durée.

En 2003, les États-Unis et leurs alliés envahissent l’Irak en invoquant notamment la menace d’armes de destruction massive et le non-respect des obligations internationales. Les arsenaux avancés pour justifier l’intervention ne sont pas retrouvés tels qu’annoncés. La guerre ne bénéficie pas d’une nouvelle autorisation explicite du Conseil de sécurité ; l’interprétation des résolutions antérieures fait l’objet d’un conflit juridique et diplomatique majeur. Confondre 1991 et 2003 effacerait cette différence essentielle. ([B39a](#ref-B39a))

La chute rapide du régime ne produit pas une stabilisation durable. L’occupation, le démantèlement d’institutions, les luttes pour le pouvoir, les violences confessionnelles et les ingérences favorisent des insurrections et des recompositions. Des acteurs non étatiques exploitent ces conditions ; la guerre en Syrie ajoute ensuite un espace de circulation et de mobilisation. Il ne faut pas présenter Daech comme un résultat automatique d’une seule décision : une chaîne de causes et de choix successifs est nécessaire.

**Document T02-Doc2 — Comparaison 1991/2003, synthèse éditoriale.**

| Question | 1991 | 2003 |
|---|---|---|
| Contexte immédiat | Invasion et occupation du Koweït. | Crise des inspections et accusations contre l’Irak. |
| Cadre international | Autorisation du Conseil de sécurité, résolution 678. | Pas de nouvelle autorisation explicite pour l’invasion. |
| Résultat militaire initial | Retrait irakien du Koweït. | Chute du régime de Saddam Hussein. |
| Problème de l’après-guerre | Désarmement, sanctions et ordre régional. | Occupation, reconstruction institutionnelle et insurrections. |

**Exemple résolu.** « La supériorité technique suffit-elle à faire la paix ? » La chute du régime irakien en 2003 montre qu’elle peut permettre une victoire militaire rapide. La construction d’institutions légitimes, la sécurité des populations et l’accord entre acteurs ne découlent pourtant pas automatiquement de cette victoire. L’exemple démontre l’écart entre moyen militaire et finalité politique, plutôt qu’une inutilité générale de toute capacité militaire.

## S’entraîner, retenir, transférer

**Activité T02-A — 30 minutes.** Rédigez 250 mots répondant à « Pourquoi la paix ne se décrète-t-elle pas ? ». Mobilisez un mécanisme de Westphalie, un exemple onusien et la comparaison 1991/2003. Chaque cas doit apporter un argument différent. Terminez par une condition commune, sans prétendre que les situations sont identiques.

**Synthèse.** La guerre est une violence organisée au service de projets politiques, même lorsque ses acteurs et ses moyens diffèrent des modèles interétatiques. Clausewitz aide à interroger les finalités, les contraintes et les interactions. La paix demande compromis, garanties, institutions et durée. Westphalie montre la construction négociée d’un ordre ; l’ONU, les possibilités et les blocages de la sécurité collective. Les conflits du Moyen-Orient révèlent l’emboîtement des échelles et la différence entre fin d’une campagne militaire et règlement politique.

**Repères.** 1648 : Westphalie ; 1756–1763 : guerre de Sept Ans ; 1832 : début de publication de *De la guerre* ; 1945 : ONU ; 1948, 1967, 1973 : guerres israélo-arabes ; 1978/1979 : Camp David et paix israélo-égyptienne ; 1991/2003 : guerres du Golfe étudiées ; 1993 : Oslo ; 1997–2006 : mandats d’Annan ; 2001 : 11-Septembre ; 2005 : responsabilité de protéger ; 2014/2019 : expansion territoriale puis perte du dernier bastion majeur de Daech en Syrie.

**Références.** S03–S04 ; R-T02 ; B35 à B39 et leurs sous-références ; D09. Les tableaux sont des synthèses nouvelles ; les positions politiques et les qualifications juridiques sont distinguées.

## Entraînements — T02 {#T02-entrainements}

Les degrés 1, 2 et 3 désignent la difficulté, non les parcours N1/N2. Commencez sans aide ; consultez ensuite l’indice si nécessaire. Les corrections, les critères détaillés et les remédiations sont dans le compagnon, sous les mêmes identifiants.

### T02-E1 — Nommer un conflit {#T02-E1}

**Degré 1 · 20 minutes · Méthode M1**

Distinguez rivalité, guerre interétatique, guerre civile et terrorisme. Expliquez pourquoi un même conflit peut combiner plusieurs formes sans rendre les mots interchangeables.

**Aide, après une première tentative.** Les catégories décrivent acteurs, intensité et méthodes ; elles ne se situent pas toutes au même niveau.

### T02-E2 — Clausewitz sans formule simpliste {#T02-E2}

**Degré 1 · 25 minutes · Méthode M2**

Corrigez : « Clausewitz affirme que toute guerre est totale, parfaitement rationnelle et toujours menée par deux États réguliers. » Mobilisez politique, friction et diversité des acteurs.

**Aide, après une première tentative.** Un modèle théorique et une guerre concrète ne sont pas identiques ; la politique ne supprime pas le hasard.

### T02-E3 — De la guerre de Sept Ans aux guerres révolutionnaires {#T02-E3}

**Degré 2 · 30 minutes · Méthode M5**

Comparez la guerre de Sept Ans et les guerres révolutionnaires et napoléoniennes selon échelles, objectifs, mobilisation et moyens. Pourquoi l’opposition « guerre limitée / guerre totale » serait-elle trop simple ?

**Aide, après une première tentative.** La guerre de Sept Ans a une dimension mondiale ; la mobilisation révolutionnaire transforme les armées sans rendre toutes les opérations identiques.

### T02-E4 — Al-Qaïda et Daech : ressemblances et différences {#T02-E4}

**Degré 2 · 30 minutes · Méthode M6**

Construisez un tableau comparant Al-Qaïda et Daech : organisation, rapport au territoire, méthodes et objectifs. Expliquez pourquoi la perte du territoire contrôlé par Daech en 2019 ne signifie pas automatiquement disparition de toute activité.

**Aide, après une première tentative.** Un réseau, une emprise territoriale et une idéologie ne disparaissent pas nécessairement au même rythme.

### T02-E5 — Westphalie et sécurité collective {#T02-E5}

**Degré 2 · 35 minutes · Méthode M3**

**Dossier éditorial.** A : les traités de Westphalie de 1648 règlent des conflits et des relations entre acteurs européens par la négociation ([B36](#ref-B36)). B : la Charte de 1945 organise une sécurité collective et attribue au Conseil de sécurité des responsabilités particulières ([D09](#ref-D09)).

Comparez objectifs, acteurs et limites. Pourquoi aucun des deux documents ne permet-il de conclure à la disparition définitive de la guerre ?

**Aide, après une première tentative.** Un règlement de paix et un dispositif permanent de sécurité collective ne sont pas le même instrument.

### T02-E6 — Construire la paix au Moyen-Orient {#T02-E6}

**Degré 2 · 35 minutes · Méthode M6**

Proposez un plan répondant à « Pourquoi la victoire militaire ne suffit-elle pas à construire une paix durable au Moyen-Orient ? ». Utilisez les guerres du Golfe de 1991 et 2003 et le conflit israélo-palestinien, en distinguant les situations.

**Aide, après une première tentative.** Nommer les objectifs, les cadres juridiques, les acteurs civils et les questions politiques non réglées.

### T02-E7 — Dissertation : faire la paix {#T02-E7}

**Degré 3 · 110 minutes · Méthode M9**

En 110 minutes : « Faire la paix : des accords entre États à la sécurité collective ». Mobilisez Westphalie, l’ONU et un cas du Moyen-Orient, sans effacer les limites des dispositifs.

**Aide, après une première tentative.** Le sujet demande une évolution des instruments et une comparaison de leur effectivité, pas une chronologie exhaustive.

### T02-E8 — Une objection à l’oral {#T02-E8}

**Degré 3 · 25 minutes · Méthode M11**

Préparez trois minutes répondant à : « Si les guerres continuent, l’ONU ne sert-elle à rien ? » Donnez deux fonctions, un exemple situé et deux limites. Distinguez l’organisation et les décisions de ses États membres.

**Aide, après une première tentative.** Évaluer une institution ne consiste pas à lui attribuer un pouvoir mondial qu’elle ne possède pas.

### T02 — QCM de vérification {#T02-qcm}

Une seule proposition correcte par question. Notez votre réponse et justifiez-la en une phrase ; la correction explique aussi pourquoi les autres propositions ne conviennent pas.

**T02-Q1.** Chez Clausewitz, la friction…

**A.** rend toute politique impossible

**B.** désigne seulement le frottement des armes

**C.** aide à comprendre les obstacles entre plan et action

**T02-Q2.** La guerre de Sept Ans…

**A.** a aussi une dimension coloniale et mondiale

**B.** se déroule seulement dans une ville

**C.** commence en 1914

**T02-Q3.** Westphalie, en 1648…

**A.** met fin à toutes les guerres du monde

**B.** organise des règlements de conflits dans un contexte européen

**C.** crée l’ONU

**T02-Q4.** La perte territoriale de Daech en 2019…

**A.** prouve la disparition de toute cellule

**B.** rend son histoire purement économique

**C.** ne suffit pas à prouver la disparition de toute capacité d’action

**T02-Q5.** Les guerres d’Irak de 1991 et 2003…

**A.** doivent être distinguées par leurs objectifs, contextes et cadres

**B.** ont exactement le même mandat

**C.** ne comportent aucun enjeu politique

### T02-RT — Nouveau test et réactivation {#T02-RT}

**20 minutes, sans cours, à distance du premier entraînement.**

1. Distinguez victoire, cessez-le-feu et paix durable. 2. Expliquez un apport et une limite de Clausewitz. 3. Comparez un instrument de Westphalie et un de l’ONU.

**Vérifier la maîtrise.** Réussite : trois réponses justifiées, avec notions distinguées et exemples situés. Une erreur de date appelle R1 ; une confusion de notion R2 ; une relation non expliquée R3. Refaire le point faible à J+2.

**Réactivation espacée.** J+7 : Restituer 1648, 1945, 1991 et 2003 avec ce qu’ils changent. J+21 : Relier la destruction patrimoniale de T04 aux violences et à la reconstruction de la paix.

**Trace de progression.** Date : … · Je restitue : oui / à reprendre · J’explique : oui / à reprendre · Je mobilise dans un sujet nouveau : oui / à reprendre · Erreur prioritaire : … · Nouvelle tentative prévue : …

# T03 — Histoire et mémoires {#t03}

**Terminale • Parcours N2 • Thème du programme, hors rotation de l’écrit 2027**

Le thème demeure nécessaire pour la formation du cycle et peut nourrir le Grand oral. Son exclusion de la rotation écrite de 2027 ne signifie ni suppression du programme ni inutilité de ses méthodes. ([S03](#ref-S03) ; [S04](#ref-S04))

**Question directrice.** Comment les sociétés connaissent-elles, racontent-elles et jugent-elles les violences du passé, et pourquoi ces démarches peuvent-elles se compléter ou entrer en tension ?

**Objectifs.** Distinguer histoire, mémoire et justice ; expliquer une controverse historique ; comparer des échelles de justice ; analyser un lieu ou une œuvre de mémoire sans la confondre avec l’événement représenté.

**Diagnostic T03-D — 10 minutes.** Un témoin peut-il se tromper sans mentir ? Un jugement pénal écrit-il toute l’histoire d’une guerre ? Des mémoires différentes impliquent-elles que tous les récits factuels se valent ? Justifiez.

**Itinéraire.** Introduction puis E1 ; axe 1 puis E2–E3 ; justice puis E4–E5 ; génocides puis E6–E8. Reprendre M3 et M10 avant toute analyse de témoignage.

## Introduction — Trois démarches, des exigences différentes

L’**histoire** est une enquête critique sur le passé, fondée sur des sources, des méthodes et une discussion des interprétations. Elle vise une connaissance argumentée, susceptible d’être révisée par de nouvelles preuves ou de nouvelles questions. La **mémoire** est une relation vécue ou transmise au passé : elle sélectionne, donne du sens, associe émotions et identités. Les mémoires sont individuelles et collectives ; elles évoluent avec les générations et les contextes. L’historien ne se place pas hors de toute société, mais il doit rendre ses procédures contrôlables. ([S03](#ref-S03) ; [R-T03](#ref-R-T03))

La **justice** établit des responsabilités selon des règles de droit, des compétences et des procédures. Elle examine des faits pour juger des personnes ou des différends ; elle ne poursuit pas exactement le même objectif qu’un historien. Ses archives deviennent néanmoins des sources majeures. Une décision de justice ne remplace pas toute recherche, et une interprétation historique ne permet pas de condamner sans procès.

Raphael Lemkin forge le terme **génocide** en 1944. La convention de 1948 le définit par des actes commis avec l’intention de détruire, en tout ou en partie, un groupe national, ethnique, racial ou religieux comme tel. L’intention spécifique est déterminante ; le terme ne signifie pas simplement « massacre très important ». Le **crime contre l’humanité** concerne notamment des actes commis dans le cadre d’une attaque généralisée ou systématique contre une population civile, selon le droit applicable. Les qualifications doivent être distinguées des usages rhétoriques. ([D17](#ref-D17))

**Document T03-Doc1 — Trois questions différentes.** Tableau éditorial.

| Démarche | Question principale | Type de vigilance |
|---|---|---|
| Histoire | Que s’est-il passé, comment et pourquoi ? | Critique, confrontation et contextualisation des sources. |
| Mémoire | Que retenons-nous et transmettons-nous de ce passé ? | Sélections, silences, identités et contextes de transmission. |
| Justice | Quels faits et responsabilités relèvent du droit applicable ? | Preuve, compétence, contradictoire et garanties procédurales. |

## Axe 1 — Histoire et mémoires des conflits

### Les causes de la Première Guerre mondiale : une controverse aux enjeux politiques {#T03-AXE1-J01}

L’attentat de Sarajevo du 28 juin 1914 est un déclencheur, non une explication suffisante de la guerre. La crise de juillet associe décisions austro-hongroises, soutien allemand, position russe, alliances, mobilisations et choix des autres puissances. Les rivalités impériales et nationales constituent un contexte de longue durée ; elles ne rendent pas chaque décision de l’été 1914 inévitable. Une explication historique doit articuler structures et initiatives des acteurs. ([B40](#ref-B40) ; [R-T03](#ref-R-T03))

Après la guerre, la question des responsabilités possède un enjeu diplomatique et financier. L’article 231 du traité de Versailles sert de fondement aux réparations en attribuant à l’Allemagne et à ses alliés la responsabilité des pertes et dommages résultant de la guerre imposée par leur agression. Il ne constitue pas, à lui seul, une enquête historienne complète sur toutes les causes. Les gouvernements publient des documents et défendent des récits qui peuvent sélectionner les pièces favorables à leur position. ([B40a](#ref-B40a))

Les historiens réexaminent ensuite les archives. Fritz Fischer, dans les années 1960, insiste sur les ambitions et les responsabilités allemandes ; d’autres travaux étudient davantage les décisions de l’ensemble des puissances, les cultures politiques et les mécanismes de crise. L’ouvrage de Christopher Clark publié en 2012 remet notamment l’accent sur les interactions et les choix des acteurs. Ces débats ne se réduisent pas à un passage de la « culpabilité allemande » à l’« innocence de tous » : pondérer les responsabilités exige de préciser les actes, les marges de manœuvre et les preuves. ([B40](#ref-B40))

La controverse montre que l’histoire n’est pas une opinion arbitraire. Les interprétations peuvent diverger tout en étant contraintes par des sources communes ; elles sont évaluées selon leur capacité à rendre compte des faits et à répondre aux objections. L’usage politique d’un ouvrage n’en détermine pas automatiquement la valeur scientifique. Dans une copie, nommez la thèse, son objet et sa limite ; ne transformez pas une liste d’historiens en substitut à l’explication.

### La guerre d’Algérie : des mémoires plurielles, des reconnaissances différenciées {#T03-AXE1-J02}

La guerre de 1954–1962 s’inscrit dans une colonisation commencée en 1830, des inégalités politiques et sociales, des nationalismes et des répressions. Les attentats du FLN du 1er novembre 1954 ouvrent une nouvelle phase du conflit. La guerre mobilise l’armée française, des appelés, les organisations nationalistes algériennes et des groupes aux projets divergents. Les violences incluent torture, attentats, répression, déplacements et affrontements entre organisations. Les accords d’Évian de mars 1962 précèdent l’indépendance de juillet ; ils ne font pas disparaître immédiatement les violences. ([B41](#ref-B41) ; [R-T03](#ref-R-T03))

Les expériences sont diverses : anciens combattants, militants indépendantistes, appelés français, pieds-noirs, harkis, immigrés et familles ne transmettent pas le même passé. Ces catégories restent elles-mêmes traversées de différences. Les départs, les massacres de harkis et les conditions de leur accueil en France, la perte d’un pays vécu comme sien ou les souvenirs de domination coloniale produisent des mémoires parfois concurrentes. Les reconnaître ne revient pas à rendre toutes les positions politiques équivalentes ni à nier les rapports coloniaux.

En France, les amnisties, les silences familiaux et la difficulté des reconnaissances publiques coexistent avec des témoignages, des films, des mobilisations et des travaux historiques. Parler d’une absence totale de mémoire jusqu’aux années 1990 serait donc faux. La loi du 18 octobre 1999 substitue notamment l’expression « guerre d’Algérie » à celle d’« opérations effectuées en Afrique du Nord » dans les textes concernés : elle marque une reconnaissance officielle, non la découverte soudaine du conflit. ([B41a](#ref-B41a))

En Algérie, le récit de la guerre de libération joue un rôle central dans la légitimité de l’État issu de l’indépendance. Cette centralité peut laisser moins de place à certaines divisions internes et à des trajectoires discordantes. De part et d’autre, l’accès aux archives, les commémorations et les déclarations politiques deviennent des enjeux. L’historien travaille sur ces récits autant que sur les événements : il distingue le moment de la guerre et celui où une société choisit de la raconter.

**Exemple résolu.** Un discours commémoratif de 1999 sur la guerre d’Algérie est une source de 1999 concernant une guerre antérieure. Il peut renseigner sur la reconnaissance publique et la mémoire ; il ne permet pas, sans confrontation, d’établir chaque détail d’une opération de 1957. La double datation — fait évoqué et document produit — évite un anachronisme fréquent.

## Axe 2 — Histoire, mémoire et justice

### Les gacaca au Rwanda : juger localement un génocide de masse {#T03-AXE2-J01}

En 1994, le génocide des Tutsis au Rwanda est organisé et perpétré dans un contexte de guerre civile, de propagande et de mobilisation d’appareils administratifs et de milices. Des Hutus opposés aux massacres sont également assassinés. Décrire un affrontement indifférencié entre deux groupes ferait disparaître l’intention génocidaire et la responsabilité des organisateurs. La justice doit traiter un nombre considérable de suspects et de faits, alors que les institutions et les communautés ont été profondément détruites. ([B42](#ref-B42) ; [D17](#ref-D17))

Les juridictions **gacaca**, mises en place au début des années 2000 et closes en 2012, s’inspirent de formes locales de règlement des différends tout en constituant une institution nouvelle adaptée aux crimes du génocide. Des juges issus des communautés participent à des audiences publiques ; aveux, témoignages et informations locales doivent permettre d’établir les faits et de juger. Le dispositif cherche à réduire l’engorgement judiciaire, à connaître le sort des victimes et à favoriser la réintégration de certains condamnés. ([B42](#ref-B42))

L’échelle locale donne accès à des connaissances que des juridictions éloignées recueilleraient difficilement. Elle expose aussi les participants à des pressions, à des craintes de représailles, à des accusations intéressées ou à la difficulté de témoigner devant des voisins. Les garanties de la défense, la formation des juges et le traitement de certains crimes font l’objet de critiques. Une justice rapide et nombreuse n’est pas automatiquement une justice pleinement équitable ; une critique du dispositif ne signifie pas que tous ses résultats seraient dépourvus de valeur.

Les gacaca ne doivent pas être confondues avec le Tribunal pénal international pour le Rwanda, créé en 1994 et établi à Arusha, qui juge notamment des responsables majeurs. Les deux échelles répondent à des problèmes différents. Juger peut contribuer à une reconnaissance, mais ne commande pas le pardon des victimes. **Justice, réconciliation et cohabitation sont des processus liés sans être identiques.**

### Le Tribunal pénal international pour l’ex-Yougoslavie : individualiser les responsabilités {#T03-AXE2-J02}

Créé en 1993 par le Conseil de sécurité, le TPIY est une juridiction internationale ad hoc chargée de crimes commis sur le territoire de l’ex-Yougoslavie depuis 1991. Il siège à La Haye. Son action intervient alors que les conflits et les violences se poursuivent : le droit international cherche à établir des responsabilités individuelles, et non à condamner collectivement un peuple. ([B43](#ref-B43))

Les enquêtes mobilisent témoignages, documents militaires, interceptions, photographies, exhumations et expertises. Les procédures contribuent à documenter les violences, notamment les crimes sexuels, les persécutions et les massacres. Les jugements relatifs à Srebrenica reconnaissent le génocide commis en 1995 contre les musulmans de Bosnie dans cette enclave. L’établissement judiciaire des faits ne dépend pas de l’acceptation de chaque récit national. ([B43](#ref-B43))

Les limites sont réelles : arrestations dépendant de la coopération des États, durée des procédures, éloignement géographique, protection des témoins et réception locale. Des condamnés peuvent être présentés comme héros par certains groupes, tandis que des victimes jugent les réparations insuffisantes. Le jugement peut fournir un socle de faits et de responsabilités sans produire une mémoire partagée.

Le TPIY achève ses travaux en 2017 ; le Mécanisme international résiduel assure certaines fonctions et conserve les archives. Il ne faut pas le confondre avec la Cour pénale internationale, institution permanente issue du statut de Rome, ni avec la Cour internationale de Justice, qui traite notamment des différends entre États. La proximité des noms et des lieux ne signifie pas identité de compétence. Le jalon montre comment la justice participe à la connaissance du passé tout en poursuivant un objectif propre : juger selon le droit.

## Objet de travail conclusif — L’histoire et les mémoires du génocide des Juifs et des Tsiganes

### Les lieux de mémoire : conserver des traces et construire des significations {#T03-OTC-J01}

Le génocide des Juifs d’Europe, perpétré par l’Allemagne nazie avec des alliés et des collaborateurs, a causé la mort d’environ six millions de Juifs. Les Roma et Sinti, désignés dans le programme par le terme « Tsiganes », ont également subi un génocide, selon des modalités et des temporalités variables. Il faut étudier les persécutions, les déportations, les fusillades et les centres de mise à mort sans réduire l’ensemble au seul camp d’Auschwitz. ([B44](#ref-B44))

Un **lieu de mémoire** peut être un site où des faits se sont déroulés, un monument construit après coup, un musée ou un espace de commémoration. Auschwitz-Birkenau est à la fois un ensemble de traces historiques et un lieu de transmission. Sa conservation impose des choix : préserver les bâtiments, expliquer les usages, rendre les parcours compréhensibles et éviter que l’affluence ou l’émotion ne remplace la connaissance. Le visiteur ne « revit » pas l’expérience des victimes ; il rencontre des traces et un dispositif d’interprétation.

Les monuments construits ailleurs, comme les mémoriaux berlinois consacrés aux Juifs assassinés d’Europe et aux Sinti et Roma victimes du nazisme, rendent visible une reconnaissance dans l’espace public. Leur implantation, leurs formes et leurs dates renseignent sur les sociétés qui les érigent. La reconnaissance du génocide des Roma et Sinti a été tardive, dans un contexte de discriminations persistantes après 1945. La mémoire n’évolue donc pas au même rythme pour tous les groupes. ([B44a](#ref-B44a))

L’analyse d’un site doit articuler trois questions : que s’y est-il passé ? Que conserve-t-on ? Que choisit-on de transmettre aujourd’hui ? Elle distingue l’authenticité d’une trace et la signification construite par sa présentation. Le respect des victimes n’interdit pas cette analyse ; il exige au contraire de ne pas transformer le lieu en symbole dépourvu d’histoire.

### Juger les crimes nazis après Nuremberg {#T03-OTC-J02}

Le procès de Nuremberg de 1945–1946 juge des dirigeants nazis selon le statut du Tribunal militaire international. Crimes contre la paix, crimes de guerre et crimes contre l’humanité y structurent l’accusation. Le mot génocide existe déjà, mais ne constitue pas alors une qualification autonome identique à celle fixée par la convention de 1948. Cette chronologie est essentielle pour comprendre la construction du droit. ([B45](#ref-B45) ; [D17](#ref-D17))

Après Nuremberg, d’autres procès poursuivent l’établissement des responsabilités. Le procès d’Adolf Eichmann à Jérusalem en 1961 donne une place importante aux témoignages de survivants et une audience internationale à la parole des victimes. Les procès d’Auschwitz à Francfort, dans les années 1960, interrogent la participation de responsables à un système criminel. En France, les procès de Klaus Barbie en 1987, de Paul Touvier en 1994 et de Maurice Papon en 1997–1998 mettent en jeu des responsabilités différentes et les conditions juridiques de leur poursuite. ([B45](#ref-B45))

La temporalité judiciaire dépend des enquêtes, des arrestations, des règles de prescription, des qualifications et des contextes politiques. Le retard ne signifie pas seulement oubli : il peut résulter d’obstacles matériels et institutionnels, de protections ou de réticences. Inversement, juger tardivement ne répare pas toutes les conséquences d’un crime. Les procès produisent des archives et des reconnaissances, mais ne remplacent ni les politiques de réparation ni le travail historique.

Le candidat doit éviter deux confusions : la responsabilité individuelle n’efface pas le fonctionnement d’institutions ; l’étude d’un système ne dispense pas d’établir ce qu’un accusé a effectivement fait. Une analyse solide relie acteurs, actes, droit et preuve.

### Littérature et cinéma : transmettre sans confondre représentation et événement {#T03-OTC-J03}

Les œuvres contribuent à rendre accessibles des expériences, des traces et des questions que les seuls tableaux chronologiques ne transmettent pas. *Si c’est un homme*, publié par Primo Levi en 1947, associe témoignage et réflexion sur l’expérience concentrationnaire. Son auteur est un témoin, mais son livre est aussi une construction écrite : choix de scènes, organisation, langue et destinataire. L’analyse ne diminue pas la valeur testimoniale ; elle précise les conditions de sa transmission. ([B46](#ref-B46))

Le cinéma emploie des dispositifs différents. *Nuit et Brouillard* d’Alain Resnais, réalisé en 1955, associe images d’archives et vues des lieux après la guerre ; il témoigne aussi de l’état des connaissances et des cadres mémoriels de son époque. *Shoah* de Claude Lanzmann, sorti en 1985, repose sur des entretiens et des lieux filmés, sans recours aux images d’archives pour représenter l’extermination. Ce choix oblige à réfléchir à la parole, aux absences et aux limites de la représentation. ([B46](#ref-B46))

La fiction peut toucher un large public et susciter une recherche, mais elle ne doit pas être utilisée comme preuve directe d’une scène historique sans vérification. Les personnages composites, les dialogues reconstruits et les choix dramatiques relèvent de conventions. Un film n’est pas évalué uniquement selon sa ressemblance apparente avec le passé : il faut identifier son projet et distinguer les libertés narratives des faits établis.

**Document T03-Doc2 — Grille éditoriale pour étudier une œuvre.** Relever l’auteur, la date de production, le genre, le public visé et le dispositif ; distinguer témoignage, archive insérée et reconstitution ; choisir une séquence ou un passage ; expliquer ce qu’il transmet et ce qu’il ne permet pas d’établir. Aucune reproduction d’œuvre protégée n’est nécessaire pour appliquer cette grille aux descriptions données ici.

## S’entraîner, retenir, transférer

**Activité T03-A — 25 minutes.** Comparez un procès, un mémorial et un témoignage écrit en utilisant T03-Doc1. Pour chacun, donnez une contribution à la connaissance ou à la reconnaissance, puis une limite. Votre conclusion doit expliquer leur complémentarité sans les rendre interchangeables.

**Synthèse.** Histoire, mémoire et justice ont des objets communs mais des finalités différentes. Les controverses sur 1914 montrent le rôle des sources et des interprétations ; les mémoires de la guerre d’Algérie, les effets des trajectoires collectives et des politiques de reconnaissance. Gacaca et TPIY articulent justice et société à des échelles différentes. Les lieux, les procès et les œuvres transmettent les génocides tout en révélant les contextes dans lesquels cette transmission s’organise.

**Repères.** 1914 : crise de juillet ; 1919 : Versailles ; 1944 : terme génocide ; 1945–1946 : Nuremberg ; 1948 : convention ; 1954–1962 : guerre d’Algérie ; 1961 : procès Eichmann ; 1985 : *Shoah* ; 1993 : TPIY ; 1994 : génocide des Tutsis et création du TPIR ; 1995 : Srebrenica ; 1999 : reconnaissance légale française de la guerre d’Algérie ; 2012 : clôture des gacaca ; 2017 : fin des travaux du TPIY.

**Références.** S03–S04 ; R-T03 ; B40 à B46 ; D17. Les deux tableaux méthodologiques sont nouveaux ; aucune fiction n’est présentée comme un témoignage authentique.

## Entraînements — T03 {#T03-entrainements}

Les degrés 1, 2 et 3 désignent la difficulté, non les parcours N1/N2. Commencez sans aide ; consultez ensuite l’indice si nécessaire. Les corrections, les critères détaillés et les remédiations sont dans le compagnon, sous les mêmes identifiants.

### T03-E1 — Trois rapports au passé {#T03-E1}

**Degré 1 · 20 minutes · Méthode M2**

Un historien confronte des archives ; une association organise une commémoration ; un tribunal apprécie la responsabilité d’un accusé. Comparez leurs objectifs, leurs preuves et leurs limites. Peuvent-ils coopérer sans se confondre ?

**Aide, après une première tentative.** Ne répartissez pas mécaniquement vérité, émotion et sanction entre trois mondes étanches.

### T03-E2 — La responsabilité de 1914 : poser une controverse {#T03-E2}

**Degré 1 · 25 minutes · Méthode M3**

Comparez une analyse insistant sur les ambitions allemandes et une analyse soulignant les interactions entre plusieurs dirigeants pendant la crise de juillet 1914. Expliquez pourquoi pluralité des acteurs ne signifie pas égalité de responsabilité. Situez Fischer et Clark sans réduire leur œuvre à une formule.

**Aide, après une première tentative.** Une controverse porte notamment sur l’échelle, les archives et la question posée.

### T03-E3 — Nommer la guerre d’Algérie {#T03-E3}

**Degré 2 · 25 minutes · Méthode M3**

**Document éditorial.** En 1999, une loi française remplace, dans des dispositions relatives aux anciens combattants, l’expression « opérations effectuées en Afrique du Nord » par « guerre d’Algérie ou combats en Tunisie et au Maroc » ([B41a](#ref-B41a)).

Que modifie cette reconnaissance ? Pourquoi ne signifie-t-elle ni que le conflit était inconnu auparavant, ni que toutes ses mémoires sont désormais réconciliées ?

**Aide, après une première tentative.** Distinguez qualification publique, savoir historique et expériences des groupes.

### T03-E4 — Deux justices, deux échelles {#T03-E4}

**Degré 2 · 30 minutes · Méthode M4**

Comparez les juridictions gacaca au Rwanda et le TPIY : contexte de création, échelle, personnes concernées, objectif et limite. Expliquez pourquoi il serait faux d’appeler les gacaca un tribunal de l’ONU. Appuyez-vous sur le cours, sans inventer de bilan chiffré.

**Aide, après une première tentative.** La proximité sociale et la procédure internationale ne produisent pas les mêmes possibilités.

### T03-E5 — Un lieu de mémoire n’explique pas tout seul {#T03-E5}

**Degré 2 · 30 minutes · Méthode M3**

Comparez un site conservé d’Auschwitz-Birkenau et un mémorial construit après la guerre à Berlin. Que peut apprendre le visiteur ? Pourquoi une médiation reste-t-elle nécessaire ? Intégrez la mémoire du génocide des Roms et des Sinti sans la confondre avec celle de la Shoah.

**Aide, après une première tentative.** Un lieu matériel est une source, mais son sens dépend aussi de sa présentation.

### T03-E6 — Écrire un plan sur justice et histoire {#T03-E6}

**Degré 2 · 30 minutes · Méthode M6**

Construisez un plan détaillé pour : « Les procès permettent-ils de connaître et de transmettre l’histoire des génocides ? » Mobilisez Nuremberg, Eichmann et un procès français. Chaque partie doit comporter un argument et une limite.

**Aide, après une première tentative.** La question ne demande ni une chronologie exhaustive des procès ni un verdict unique sur leur utilité.

### T03-E7 — Dissertation d’entraînement : des mémoires à l’histoire {#T03-E7}

**Degré 3 · 90 minutes · Méthode M9**

« Pourquoi la connaissance du passé ne peut-elle se réduire à la coexistence des mémoires ? » Rédigez introduction, développement et conclusion. Entraînement au raisonnement : T03 n’appartient pas au périmètre de l’écrit HGGSP 2027.

**Aide, après une première tentative.** Ne dévalorisez pas les mémoires : expliquez leur apport, puis les opérations nécessaires pour construire un savoir critique.

### T03-E8 — Présenter une œuvre sans la transformer en archive transparente {#T03-E8}

**Degré 3 · 25 minutes · Méthode M11**

Préparez trois minutes sur le rôle d’une œuvre dans la transmission d’un génocide. Choisissez Si c’est un homme, Nuit et Brouillard ou Shoah. Présentez nature, date, démarche, apport et limite. Aucun visionnage intégral n’est supposé par cet exercice : utilisez le cours et annoncez cette limite.

**Aide, après une première tentative.** Une œuvre peut être un témoignage, un montage documentaire ou une enquête filmée ; ces catégories ne sont pas interchangeables.

### T03 — QCM de vérification {#T03-qcm}

Une seule proposition correcte par question. Notez votre réponse et justifiez-la en une phrase ; la correction explique aussi pourquoi les autres propositions ne conviennent pas.

**T03-Q1.** Une mémoire est…

**A.** un rapport situé au passé

**B.** toujours un mensonge

**C.** une preuve suffisante de tout fait raconté

**T03-Q2.** Les gacaca sont…

**A.** une chambre de la CPI

**B.** des juridictions rwandaises

**C.** un tribunal créé pour l’ex-Yougoslavie

**T03-Q3.** Le TPIY établit principalement…

**A.** la culpabilité de tous les membres d’un peuple

**B.** une mémoire officielle universelle

**C.** des responsabilités pénales individuelles

**T03-Q4.** Un mémorial inauguré après les faits renseigne…

**A.** aussi sur la société qui le construit

**B.** uniquement sur le passé commémoré

**C.** sur tous les détails du crime sans autre source

**T03-Q5.** Respecter la pluralité des mémoires impose-t-il de valider toutes les affirmations factuelles ?

**A.** Oui, toute affirmation se vaut

**B.** Non, les faits restent soumis à la critique

**C.** Non, il faut supprimer les témoignages

### T03-RT — Nouveau test et réactivation {#T03-RT}

**20 minutes, sans cours, à distance du premier entraînement.**

1. Distinguez histoire, mémoire et justice par leurs opérations. 2. Situez un procès et un mémorial. 3. Expliquez en huit lignes pourquoi la justice ne suffit pas à réconcilier une société.

**Vérifier la maîtrise.** Réussite : trois réponses justifiées, avec notions distinguées et exemples situés. Une erreur de date appelle R1 ; une confusion de notion R2 ; une relation non expliquée R3. Refaire le point faible à J+2.

**Réactivation espacée.** J+7 : Comparez deux usages publics d’un même événement. J+21 : Transférez la distinction mémoire/histoire à une commémoration locale.

**Trace de progression.** Date : … · Je restitue : oui / à reprendre · J’explique : oui / à reprendre · Je mobilise dans un sujet nouveau : oui / à reprendre · Erreur prioritaire : … · Nouvelle tentative prévue : …

# T04 — Identifier, protéger et valoriser le patrimoine : enjeux géopolitiques {#t04}

**Terminale • Parcours N2 • Thème évaluable à l’écrit 2027**

**Question directrice.** Comment des sociétés transforment-elles des héritages en patrimoines, et pourquoi leur protection et leur mise en valeur produisent-elles à la fois de la coopération et des conflits ?

**Objectifs.** Expliquer la patrimonialisation ; distinguer conservation, restauration et valorisation ; confronter des usages politiques ; raisonner à plusieurs échelles ; évaluer une politique sans réduire sa réussite au nombre de visiteurs.

**Diagnostic T04-D — 10 minutes.** Tout objet ancien est-il automatiquement un patrimoine ? L’inscription par l’UNESCO transfère-t-elle la propriété d’un site à cette organisation ? Restaurer consiste-t-il toujours à reconstruire exactement un état originel ? Justifiez.

**Itinéraire.** Introduction puis E1 ; usages politiques puis E2–E3 ; tensions puis E4–E5 ; politiques françaises puis E6–E8. Mobiliser M3 pour les positions d’acteurs et M10 pour les dossiers de documents.

## Introduction — Le patrimoine : un héritage sélectionné et transmis

Dans son sens familial, le patrimoine désigne des biens transmis. Son extension à des monuments, paysages, pratiques ou savoir-faire suppose un changement d’échelle et de justification : un groupe considère certains héritages comme dignes d’être conservés pour les générations suivantes. La **patrimonialisation** est ce processus de reconnaissance, de sélection et de protection. Elle n’est ni automatique ni irréversible. Des bâtiments longtemps jugés ordinaires deviennent remarquables lorsque leur disparition menace une mémoire collective ; d’autres héritages sont contestés parce qu’ils incarnent une domination. ([S03](#ref-S03) ; [R-T04](#ref-R-T04))

Les acteurs ne sélectionnent pas tous pour les mêmes raisons. Un habitant peut défendre un lieu de vie ; un historien, une source ; une municipalité, une identité et une attractivité ; un État, un récit national ; une organisation internationale, une valeur dépassant les frontières. Ces intérêts peuvent converger, mais aussi entrer en concurrence. Déclarer qu’un site appartient symboliquement à l’humanité ne dispense pas de demander qui y habite, qui décide et qui supporte les coûts de sa conservation.

La convention de l’UNESCO de **1972** organise la protection du patrimoine mondial culturel et naturel. Les États proposent des biens ; un comité intergouvernemental décide des inscriptions selon des critères et un examen. L’inscription ne transforme pas l’UNESCO en propriétaire ou en gouvernement local. Elle engage une responsabilité de protection, organise une reconnaissance et favorise une coopération. La convention de **2003** porte sur le patrimoine culturel immatériel : pratiques, représentations, expressions, connaissances et savoir-faire reconnus par les communautés concernées. Une pratique vivante ne se conserve pas exactement comme une façade : sa transmission peut comporter des adaptations. ([D11](#ref-D11) ; [D12](#ref-D12))

**Document T04-Doc1 — Les opérations de patrimonialisation.** Schéma éditorial établi pour ce manuel.

| Opération | Question à examiner | Risque à discuter |
|---|---|---|
| Identifier et documenter | Que veut-on transmettre, sur quelles preuves ? | Oublier certains groupes ou certaines périodes. |
| Reconnaître et protéger | Qui décide, avec quelle règle et quel financement ? | Confondre label et protection effective. |
| Conserver ou restaurer | Quel état maintenir, quels matériaux et quels usages ? | Effacer les traces ou inventer une authenticité. |
| Valoriser et transmettre | Pour quels publics et avec quelles explications ? | Réduire l’héritage à un produit touristique. |

## Axe 1 — Usages sociaux et politiques du patrimoine

### Versailles : un lieu réinterprété de l’Empire à la République {#T04-AXE1-J01}

Le château de Versailles est associé à la monarchie de Louis XIV, mais son histoire politique ne s’arrête pas à 1789. Après le départ de la famille royale, les régimes doivent décider du sort d’un ensemble coûteux, chargé de symboles monarchiques et susceptible de nouveaux usages. Sous l’Empire, des projets et des restaurations concernent le domaine ; Napoléon utilise notamment Trianon, sans rétablir à Versailles le fonctionnement de la cour de Louis XIV. Le bâtiment peut survivre à la disparition du système politique qui l’a produit. ([B47](#ref-B47) ; [R-T04](#ref-R-T04))

En **1837**, Louis-Philippe inaugure les galeries historiques. Transformer une résidence royale en musée consacré à l’histoire nationale permet de sélectionner des épisodes, de rapprocher des traditions politiques concurrentes et d’inscrire la monarchie de Juillet dans une continuité française. Le musée n’est pas un dépôt neutre d’images : l’organisation des salles et le choix des batailles mettent en scène une histoire. Le visiteur doit distinguer l’événement représenté, la date de création du tableau et l’intention de l’exposition.

La galerie des Glaces reçoit ensuite des usages antagonistes. La proclamation de l’Empire allemand, en **1871**, transforme un symbole de puissance française en théâtre d’une victoire allemande. La signature du traité de Versailles, en **1919**, réinvestit le lieu dans un autre rapport de force. Le même espace matérialise donc des mémoires opposées ; sa signification dépend aussi de la cérémonie et du public auxquels on l’associe. ([B47a](#ref-B47a))

La République emploie Versailles pour des réceptions diplomatiques et pour certaines réunions du Parlement en Congrès. L’ancien palais royal participe ainsi à la représentation d’un régime qui n’est pas monarchique. Cette réutilisation n’efface pas les usages précédents : elle les superpose. La conservation, la fréquentation touristique et les cérémonies officielles imposent des arbitrages entre accessibilité, sécurité, entretien et prestige.

**Idée à mobiliser.** Un pouvoir ne reçoit pas seulement un patrimoine ; il en transforme la signification. Versailles permet de montrer une continuité matérielle et une discontinuité des usages, plutôt qu’une simple permanence de « la grandeur ».

### Les frises du Parthénon : conservation, appropriation et réunification {#T04-AXE1-J02}

Au début du XIXe siècle, Lord Elgin fait prélever à Athènes, alors sous domination ottomane, des sculptures du Parthénon. Le British Museum les acquiert en **1816**. Les conditions du prélèvement et la portée des autorisations invoquées sont au cœur d’une controverse durable. Il faut distinguer les faits de déplacement, l’histoire des titres juridiques allégués et les arguments éthiques formulés aujourd’hui. Une revendication ne peut être comprise sans le contexte impérial dans lequel les collections se sont constituées. ([B48](#ref-B48) ; [B48a](#ref-B48a))

La position grecque insiste sur la réunion d’éléments d’un même monument et sur leur intelligibilité dans leur contexte athénien. Le musée de l’Acropole, ouvert en **2009**, organise notamment une présentation liée à la disposition des sculptures du Parthénon. La demande n’est donc pas seulement celle de récupérer des objets précieux : elle porte sur la cohérence d’un ensemble et sur le droit de raconter son histoire. ([B48a](#ref-B48a))

Le British Museum met en avant la légalité de son acquisition selon son interprétation, la conservation, l’accès international et la mise en relation de civilisations dans un musée à vocation universelle. Ces arguments doivent être attribués à l’institution qui les défend, non présentés comme des conclusions incontestées. Réciproquement, qualifier le retour de réunification exprime un cadrage qu’il faut expliciter. Le rôle de l’historien est d’analyser les arguments et les pièces, non de faire disparaître le conflit de vocabulaire. ([B48](#ref-B48))

Les solutions envisagées peuvent associer retour, prêt, partenariat ou circulation d’autres œuvres. Elles ne sont pas équivalentes : accepter un prêt peut soulever une question de reconnaissance de propriété. **Un accord de circulation ne tranche donc pas nécessairement le désaccord de souveraineté culturelle.** Le cas révèle une tension entre patrimoine situé, collections mondialisées et asymétries historiques. Ce manuel n’annonce pas un accord définitif qui ne serait pas établi par une source officielle datée.

## Axe 2 — Patrimoine, préservation, tensions et concurrences

### Paris : conserver une ville qui continue de se transformer {#T04-AXE2-J01}

Paris concentre des fonctions résidentielles, économiques, politiques et touristiques. La préservation ne concerne pas uniquement quelques monuments isolés : elle porte aussi sur des perspectives, des ensembles urbains et des rapports entre bâtiments. Les rives de la Seine sont inscrites au patrimoine mondial en **1991**. Cela ne signifie pas que toute la ville serait classée, ni que toute construction nouvelle serait interdite. ([B49](#ref-B49))

La transformation haussmannienne du XIXe siècle rappelle que des paysages aujourd’hui patrimonialisés furent eux-mêmes produits par des démolitions et des opérations contestées. Le patrimoine n’est pas simplement ce qui échappe au changement : il peut être le résultat d’un changement devenu référence. Au XXe siècle, les débats sur les tours, les Halles ou les interventions dans les centres anciens opposent des conceptions du progrès, de l’habitat et de l’esthétique. La loi de **1962** sur les secteurs sauvegardés marque l’importance d’une protection à l’échelle d’ensembles urbains. ([B52](#ref-B52))

Le problème n’est pas de choisir abstraitement entre « tout conserver » et « tout moderniser ». Rénover un logement, améliorer l’accessibilité, limiter les consommations d’énergie ou accueillir de nouveaux services peut nécessiter des interventions. Il faut évaluer leurs effets sur le bâti et sur les habitants. Un quartier admirablement restauré mais devenu inaccessible à ceux qui y vivaient pose une question sociale que la seule qualité architecturale ne résout pas.

L’analyse géographique examine donc les acteurs, les périmètres et les usages. Qui bénéficie de la hausse de valeur ? Quels logements et commerces subsistent ? Comment articuler les décisions de l’État, de la ville, des propriétaires et des experts ? La préservation est une politique de transformation encadrée, non la mise à l’arrêt d’une ville.

### Le Mali : détruire un patrimoine, atteindre une société ; reconstruire, transmettre {#T04-AXE2-J02}

Le patrimoine malien comprend des architectures, des manuscrits, des pratiques et des lieux religieux liés à des histoires d’échanges et de savoirs. À Tombouctou, en **2012**, des groupes armés détruisent notamment des mausolées. Ces destructions ne sont pas des dégâts collatéraux ordinaires : elles visent des lieux investis de significations religieuses et sociales, et participent à l’imposition d’un ordre. Attaquer un patrimoine peut chercher à intimider, à rompre des transmissions et à rendre visible une domination. ([B50](#ref-B50))

La sauvegarde n’est pas uniquement l’œuvre d’acteurs internationaux. Des habitants, bibliothécaires, familles et professionnels contribuent à protéger des manuscrits et des pratiques. Les reconstructions associent ensuite des compétences locales, l’État malien et des partenaires internationaux, dont l’UNESCO. L’emploi de savoir-faire de construction constitue lui-même une transmission patrimoniale. Une reconstruction peut donc restituer des usages et des capacités collectives, sans prétendre annuler la violence passée.

En **2016**, la Cour pénale internationale condamne Ahmad Al Faqi Al Mahdi pour le crime de guerre consistant à diriger des attaques contre des bâtiments religieux et historiques à Tombouctou. Il faut préciser l’objet de cette décision : il s’agit d’une responsabilité pénale individuelle pour des attaques déterminées, non d’un jugement portant sur l’ensemble du conflit malien. ([B50a](#ref-B50a))

Le cas fait apparaître trois dimensions complémentaires : protéger les personnes, préserver les traces et poursuivre les responsables selon le droit. Elles ne doivent pas être opposées. Des monuments restaurés ne prouvent pas à eux seuls le retour de la sécurité ou de la confiance ; leur destruction ne se mesure pas seulement à un coût matériel. L’enjeu est aussi celui des liens sociaux et du droit des populations à transmettre leur histoire.

### Venise : la réussite touristique peut-elle menacer le patrimoine ? {#T04-AXE2-J03}

Venise et sa lagune, inscrites au patrimoine mondial en **1987**, forment un système associant ville, eaux, activités et écosystèmes. L’exceptionnelle attractivité du site procure emplois et recettes, mais la concentration de visiteurs peut augmenter l’usure des espaces, transformer les commerces et favoriser les locations touristiques au détriment de l’habitat permanent. L’affluence n’est donc pas, à elle seule, un indicateur de bonne conservation. ([B51](#ref-B51))

Les menaces se cumulent : hautes eaux, mouvements de vagues, fragilité des bâtiments, pressions sur la lagune et transformations socio-économiques. Le tourisme n’explique pas tout, et le changement climatique ne doit pas servir à effacer les choix d’aménagement. Il faut distinguer les mécanismes, leurs échelles et leurs interactions. Des ouvrages de protection contre les submersions ne règlent pas automatiquement la question du logement ou de la monoculture touristique.

Les politiques peuvent agir sur les circulations, l’accès des grands navires, la répartition des flux, les usages immobiliers et le financement de la conservation. Chacune a des effets distributifs : un commerçant, un salarié du tourisme et un résident ne subissent pas les mêmes coûts. Les mesures précises et leurs tarifs évoluent ; pour une copie, mieux vaut expliquer un mécanisme daté que réciter un montant devenu caduc.

Le risque de **muséification** désigne ici la réduction d’un espace vivant à un décor principalement organisé pour la visite. Préserver Venise exige donc de préserver aussi les conditions d’une vie urbaine. Le patrimoine est une ressource économique, mais sa valeur ne se réduit pas au revenu qu’il produit. L’objectif raisonnable n’est ni l’absence de visiteurs ni leur croissance sans limite : c’est une compatibilité durable entre transmission, usages et capacités du milieu.

## Objet de travail conclusif — La France et le patrimoine : acteurs, valorisation, rayonnement

### Une politique publique qui élargit progressivement ses objets {#T04-OTC-J01}

La Révolution française détruit certains symboles de l’Ancien Régime, mais suscite aussi inventaires, musées et débats sur la conservation de biens devenus nationaux. Cette ambivalence rappelle que rupture politique et protection peuvent coexister. Au XIXe siècle, l’inspection des monuments historiques et les inventaires contribuent à organiser une intervention publique. La sélection privilégie d’abord certains monuments anciens ; elle est ensuite élargie. ([B52](#ref-B52))

La loi de **1913** constitue un repère majeur pour la protection des monuments historiques. La création du ministère des Affaires culturelles en **1959**, puis les secteurs sauvegardés de **1962**, favorisent une politique qui ne se limite plus à l’objet isolé. Au fil du temps, les patrimoines industriels, ruraux, techniques, paysagers et immatériels acquièrent une visibilité accrue. Cet élargissement révèle des changements de regard sur le travail, la vie quotidienne et les groupes dont l’histoire mérite reconnaissance.

L’État n’agit pas seul. Collectivités territoriales, propriétaires, associations, entreprises, mécènes, professionnels et habitants participent à la conservation. Leurs responsabilités et leurs ressources diffèrent. Un financement privé peut rendre possible une restauration ; il invite aussi à examiner les contreparties, la visibilité donnée au financeur et le maintien d’un accès public. La décentralisation ne supprime pas le rôle des normes nationales ni celui de l’expertise.

Une politique patrimoniale se juge sur plusieurs critères : état de conservation, qualité de la transmission, participation des populations, accessibilité, soutenabilité financière et articulation avec les autres besoins. Le nombre de classements ou de visiteurs ne suffit pas. **Élargir le patrimoine exige aussi de choisir**, car les moyens disponibles ne permettent pas de conserver indistinctement chaque trace.

### Le bassin minier du Nord-Pas-de-Calais : d’un espace productif à un paysage patrimonial {#T04-OTC-J02}

Le bassin minier porte les traces de l’extraction du charbon : fosses, chevalements, terrils, cités ouvrières, équipements collectifs et paysages transformés. La fin de l’extraction en **1990** ne fait pas disparaître ces formes ni les mémoires du travail. La reconversion répond à des difficultés économiques, sociales et environnementales ; elle ne se réduit pas à ouvrir des musées. ([B53](#ref-B53))

L’inscription au patrimoine mondial en **2012** reconnaît un paysage culturel évolutif. Elle valorise un ensemble territorial et social, pas seulement une machine exceptionnelle. Cette reconnaissance peut inverser un regard dépréciatif porté sur les friches et rendre visible l’histoire des mineurs, des migrations, des solidarités et des conflits du travail. La patrimonialisation comporte ainsi un enjeu de dignité et de représentation.

Les reconversions associent conservation, nouveaux usages culturels, activités économiques, espaces de loisirs et réhabilitation de l’habitat. Elles supposent de traiter les pollutions, les contraintes des bâtiments et les attentes des habitants. Un site restauré peut attirer des visiteurs sans produire à lui seul assez d’emplois pour remplacer une économie disparue. Il faut éviter l’équation « inscription UNESCO = prospérité assurée ».

L’intérêt du jalon est de relier paysage et société. Un terril est un relief artificiel, une trace technique, un support écologique possible et un repère identitaire. Ces lectures ne s’excluent pas. Une reconversion convaincante ne nie ni la pénibilité ni les conflits du passé ; elle rend leur connaissance compatible avec des usages présents.

### Le repas gastronomique des Français : un patrimoine immatériel et un instrument de rayonnement {#T04-OTC-J03}

L’inscription de **2010** concerne le **repas gastronomique des Français**, pratique sociale de célébration et de convivialité. Elle ne constitue pas un classement de toutes les recettes françaises, ni un jugement de supériorité sur les autres cuisines. Elle porte sur des savoir-faire, des usages et une transmission : choix de produits, préparation, organisation du repas, partage et attention portée à l’expérience commune. ([B54](#ref-B54))

La distinction est décisive. Un patrimoine immatériel réside dans des pratiques vivantes et des communautés de transmission ; on ne le protège pas en mettant un plat sous vitrine. Les institutions, associations et professionnels peuvent documenter et transmettre ces pratiques, mais doivent éviter de les figer dans une définition qui exclurait les variations sociales et régionales.

La gastronomie participe au rayonnement : réceptions diplomatiques, formations, échanges professionnels, tourisme et événements culturels rendent visibles des savoir-faire. L’effet relève de l’attractivité et de l’influence, non d’un pouvoir de contrainte automatique. Un repas apprécié ne garantit pas le soutien d’un partenaire sur un dossier stratégique.

La valorisation commerciale peut financer la transmission, mais elle peut aussi réduire la pratique à une marque. Il faut donc distinguer reconnaissance patrimoniale, stratégie économique et diplomatie culturelle. Le patrimoine devient une ressource géopolitique lorsque des acteurs l’emploient pour construire une image et des relations ; son contenu ne se résume pas à cette utilisation.

## Exemple commenté — Construire une explication plutôt qu’un catalogue

**Sujet d’entraînement :** « La valorisation protège-t-elle nécessairement le patrimoine ? » Une réponse affirmative fondée sur les recettes du tourisme oublierait les tensions de Venise. Une réponse négative oublierait les financements et les nouveaux usages du bassin minier. Une démonstration peut d’abord établir les conditions dans lesquelles la valorisation soutient la conservation, puis montrer les arbitrages nécessaires pour qu’elle ne dégrade pas ce qu’elle prétend transmettre. Deux parties suffisent ici si elles répondent réellement au problème.

**Paragraphe modèle.** La valorisation peut rendre un héritage socialement et financièrement soutenable, mais cet effet dépend des usages qu’elle encourage. Dans le bassin minier, la reconnaissance d’un paysage de travail favorise la conservation de bâtiments et leur réemploi. Elle permet aussi de transmettre une histoire longtemps associée au déclin industriel. Cependant, l’attractivité culturelle ne remplace pas automatiquement les emplois disparus et doit s’articuler à la vie des habitants. La valorisation constitue donc un moyen de protection sous conditions, non une garantie indépendante des politiques territoriales.

**Document T04-Doc2 — Trois indicateurs à ne pas confondre.** Tableau éditorial, sans données chiffrées fictivement attribuées à un site.

| Indicateur observé | Ce qu’il renseigne | Ce qu’il ne prouve pas seul |
|---|---|---|
| Hausse des visiteurs | Attractivité et fréquentation | Conservation matérielle ou bénéfice pour tous les habitants. |
| Restauration achevée | Intervention sur un état matériel | Transmission des usages ou résolution d’un conflit. |
| Participation des habitants | Implication d’une partie de la population | Représentation de tous les groupes ni accord unanime. |

**Activité T04-A — 25 minutes.** Rédigez une note de 200 mots à une municipalité qui veut transformer un ancien atelier en lieu touristique. La situation est fictive. Proposez trois critères d’évaluation et deux risques ; appuyez vos choix sur le bassin minier et Venise, sans leur attribuer les données de la fiction. Corrigé dans le compagnon.

## Synthèse active et transfert

Retenir la chaîne **sélection → protection → usages → transmission**, puis montrer les conflits possibles à chaque étape. Les huit jalons permettent d’étudier le pouvoir de mise en scène, les restitutions, les villes vivantes, la guerre, le tourisme, les politiques publiques, la reconversion et la diplomatie culturelle.

**Repères utiles.** 1816 : acquisition des sculptures par le British Museum ; 1837 : musée historique de Versailles ; 1913 : loi française sur les monuments historiques ; 1962 : secteurs sauvegardés ; 1972 et 2003 : conventions de l’UNESCO ; 2010 : repas gastronomique ; 2012 : inscription du bassin minier et destructions à Tombouctou ; 2016 : jugement Al Mahdi.

**Preuve de maîtrise.** Expliquez un conflit patrimonial en nommant au moins deux acteurs, deux échelles et deux critères de décision. **Transfert.** Devant un nouveau cas de restitution ou de rénovation, distinguez le droit, les faits historiques, les usages présents et les choix politiques. Un slogan ne remplace aucun de ces quatre examens.

**Sources du chapitre.** Programme et accompagnement ([S03](#ref-S03) ; [R-T04](#ref-R-T04)) ; conventions ([D11](#ref-D11) ; [D12](#ref-D12)) ; établissements patrimoniaux, UNESCO, ministère de la Culture et CPI ([B47](#ref-B47)–[B54](#ref-B54)). Les analyses, tableaux et situations d’entraînement sont des rédactions éditoriales nouvelles.

## Entraînements — T04 {#T04-entrainements}

Les degrés 1, 2 et 3 désignent la difficulté, non les parcours N1/N2. Commencez sans aide ; consultez ensuite l’indice si nécessaire. Les corrections, les critères détaillés et les remédiations sont dans le compagnon, sous les mêmes identifiants.

### T04-E1 — Patrimonialiser : une sélection {#T04-E1}

**Degré 1 · 20 minutes · Méthode M2**

Une ancienne usine est menacée de démolition. Proposez trois critères permettant de discuter sa patrimonialisation et deux acteurs à consulter. Pourquoi l’ancienneté et la rentabilité touristique ne suffisent-elles pas ?

**Aide, après une première tentative.** Distinguez valeur historique, usages sociaux et état matériel.

### T04-E2 — Versailles : continuité et discontinuité {#T04-E2}

**Degré 1 · 25 minutes · Méthode M2**

Associez 1837, 1871 et 1919 à un usage de Versailles. Montrez en dix lignes comment une continuité matérielle peut soutenir des significations politiques opposées.

**Aide, après une première tentative.** Le lieu n’agit pas seul : des régimes et des cérémonies lui attribuent un sens.

### T04-E3 — Parthénon : attribuer les arguments {#T04-E3}

**Degré 2 · 30 minutes · Méthode M3**

**Documents éditoriaux, sans citation verbatim.** A. La position grecque insiste sur la réunion d’éléments d’un même monument, près de leur contexte athénien. B. Le British Museum défend la légalité de son acquisition selon son interprétation et la comparaison de civilisations dans un musée mondial. Sources : ([B48](#ref-B48) ; [B48a](#ref-B48a)).

Comparez le cadrage, l’échelle et la limite des deux positions. Pourquoi un prêt peut-il laisser entier un désaccord de propriété ?

**Aide, après une première tentative.** Ne transformez pas l’argument d’une partie en fait juridiquement tranché.

### T04-E4 — Mali : reconstruire quoi ? {#T04-E4}

**Degré 2 · 30 minutes · Méthode M5**

Rédigez un paragraphe sur la reconstruction des mausolées de Tombouctou après 2012. Reliez matérialité, pratiques, acteurs locaux et coopération. Introduisez la condamnation d’Al Mahdi en 2016 sans faire de la CPI un organisme de restauration.

**Aide, après une première tentative.** Une reconstruction peut transmettre des savoir-faire sans effacer le crime.

### T04-E5 — Venise : construire un indicateur pertinent {#T04-E5}

**Degré 2 · 30 minutes · Méthode M4**

**Tableau fictif de raisonnement.** Dans une ville patrimoniale imaginaire, les visiteurs passent de 10 à 12 millions, les résidents de 50 000 à 48 000 et les logements permanents de 20 000 à 18 000. Ces chiffres ne sont pas ceux de Venise.

Calculez les évolutions relatives. Pourquoi la hausse de fréquentation ne suffit-elle pas à conclure à une meilleure valorisation ? Transférez le raisonnement à Venise sans lui attribuer ces données.

**Aide, après une première tentative.** Le dénominateur est chaque valeur initiale ; l’évaluation doit croiser les usages.

### T04-E6 — Une politique française à plusieurs échelles {#T04-E6}

**Degré 2 · 30 minutes · Méthode M6**

Préparez un plan détaillé répondant à : « La protection patrimoniale en France relève-t-elle seulement de l’État ? » Mobilisez la politique des monuments historiques, le bassin minier et le repas gastronomique.

**Aide, après une première tentative.** Il faut distinguer pouvoir réglementaire, initiative, financement et pratique.

### T04-E7 — Dissertation : conserver ou transformer ? {#T04-E7}

**Degré 3 · 90 minutes · Méthode M9**

« Protéger le patrimoine impose-t-il de le soustraire aux transformations ? » Rédigez une dissertation en mobilisant au moins trois jalons. Faites apparaître les habitants et les usages, pas seulement les monuments.

**Aide, après une première tentative.** La question oppose une apparente contradiction ; définissez ce qui peut changer et ce qu’il faut transmettre.

### T04-E8 — Conseil municipal : défendre un arbitrage {#T04-E8}

**Degré 3 · 25 minutes · Méthode M11**

Vous présentez une proposition fictive pour reconvertir un atelier industriel : musée, logements, espace associatif ou combinaison. Exposez en trois minutes une décision, trois critères, deux risques et les personnes à consulter. Mobilisez le bassin minier et une comparaison avec Venise.

**Aide, après une première tentative.** Il n’y a pas une fonction attendue : la justification et les conditions comptent.

### T04 — QCM de vérification {#T04-qcm}

Une seule proposition correcte par question. Notez votre réponse et justifiez-la en une phrase ; la correction explique aussi pourquoi les autres propositions ne conviennent pas.

**T04-Q1.** La patrimonialisation est…

**A.** une sélection et une reconnaissance

**B.** une propriété naturelle de tout objet ancien

**C.** un transfert automatique à l’UNESCO

**T04-Q2.** Le musée historique de Versailles inauguré en 1837 relève…

**A.** de Louis XIV

**B.** de Louis-Philippe

**C.** du traité de Versailles

**T04-Q3.** La protection du repas gastronomique concerne principalement…

**A.** un menu obligatoire immuable

**B.** une marque commerciale

**C.** une pratique sociale et sa transmission

**T04-Q4.** La CPI, dans l’affaire Al Mahdi, a…

**A.** jugé une responsabilité pénale

**B.** classé toute la ville de Tombouctou

**C.** dirigé les travaux de maçonnerie

**T04-Q5.** Une hausse de visiteurs démontre-t-elle à elle seule une valorisation réussie ?

**A.** Oui, sans autre critère

**B.** Non, il faut croiser conservation, usages et effets sociaux

**C.** Non, tout tourisme détruit nécessairement

### T04-RT — Nouveau test et réactivation {#T04-RT}

**20 minutes, sans cours, à distance du premier entraînement.**

1. Définissez patrimonialisation et valorisation. 2. Comparez Versailles et le bassin minier en montrant un changement d’usage. 3. Proposez deux critères de protection qui ne soient pas la fréquentation.

**Vérifier la maîtrise.** Réussite : trois réponses justifiées, avec notions distinguées et exemples situés. Une erreur de date appelle R1 ; une confusion de notion R2 ; une relation non expliquée R3. Refaire le point faible à J+2.

**Réactivation espacée.** J+7 : Analysez les acteurs d’un patrimoine de votre environnement. J+21 : Construisez un paragraphe sur une tension conservation/usage sans exemple appris par cœur.

**Trace de progression.** Date : … · Je restitue : oui / à reprendre · J’explique : oui / à reprendre · Je mobilise dans un sujet nouveau : oui / à reprendre · Erreur prioritaire : … · Nouvelle tentative prévue : …

# T05 — L’environnement, entre exploitation et protection : un enjeu planétaire {#t05}

**Terminale • Parcours N2 • Thème évaluable à l’écrit 2027**

**Question directrice.** Comment les sociétés transforment-elles leurs milieux, construisent-elles des politiques de protection et négocient-elles des responsabilités à l’échelle planétaire ?

**Objectifs.** Historiciser les relations entre sociétés et milieux ; distinguer ressource, risque et écosystème ; expliquer les ruptures sans déterminisme ; lire un indicateur climatique ; analyser la gouvernance et les inégalités de responsabilité.

**Diagnostic T05-D — 10 minutes.** Une forêt exploitée est-elle nécessairement détruite ? Un hiver froid réfute-t-il le réchauffement global ? La signature d’un accord garantit-elle son application ? Justifiez chaque distinction.

**Itinéraire.** Introduction puis E1 ; forêt et ruptures puis E2–E3 ; climat puis E4–E5 ; États-Unis puis E6–E8. M4 est indispensable pour distinguer valeur, unité, période et espace.

## Introduction — L’environnement : un objet à la fois matériel, social et politique

L’**environnement** désigne ici les relations entre les sociétés et les composantes biophysiques de leur milieu : air, eaux, sols, êtres vivants, climats. Ce n’est pas une nature entièrement extérieure à l’humanité. Les sociétés transforment leurs milieux, dépendent de leurs fonctionnements et interprètent différemment leur valeur. Une forêt peut être simultanément habitat d’espèces, ressource en bois, espace de loisirs, puits de carbone et lieu chargé de mémoire. ([S03](#ref-S03) ; [R-T05](#ref-R-T05))

Une **ressource** est une potentialité identifiée et utilisable dans un contexte technique, économique et politique. Un gisement n’a pas la même valeur selon les besoins, les techniques d’extraction et les règles d’accès. Un **risque** résulte de la rencontre d’un aléa avec des enjeux exposés et vulnérables. Deux sociétés confrontées à une sécheresse comparable peuvent subir des conséquences différentes selon leurs réserves, leurs infrastructures, leurs droits d’accès à l’eau et leurs capacités d’entraide.

L’histoire environnementale étudie ces interactions dans le temps. Elle ne raconte ni une harmonie originelle universelle ni une dégradation linéaire attribuable indistinctement à « l’homme ». Les activités, les pouvoirs et les responsabilités sont inégaux. Le concept d’**Anthropocène**, employé dans de nombreux débats scientifiques et sociaux pour penser l’ampleur de l’influence humaine, ne dispense pas d’identifier précisément les systèmes productifs, les groupes et les périodes concernés. Son usage comme concept ne doit pas être confondu avec une validation automatique comme unité officielle de l’échelle géologique. ([R-T05](#ref-R-T05))

La protection environnementale est ancienne sous certaines formes, mais ses objets et ses justifications changent. Préserver du bois pour la marine royale n’équivaut pas à protéger la biodiversité pour elle-même. Les politiques contemporaines combinent réglementations, aires protégées, fiscalité, coopération scientifique, information et négociation. Leur efficacité dépend de leur application et de leur acceptabilité, non de la seule proclamation d’un objectif.

## Axe 1 — Exploiter, préserver et protéger

### La forêt française depuis Colbert : protéger pour produire, puis diversifier les objectifs {#T05-AXE1-J01}

Au XVIIe siècle, le bois sert à construire, chauffer, produire et équiper les navires. La monarchie voit dans la disponibilité de grands arbres un enjeu économique et militaire. L’ordonnance de **1669**, préparée sous l’impulsion de Colbert, réorganise et encadre les usages forestiers. Elle vise notamment à limiter des surexploitations, à renforcer le contrôle royal et à assurer des ressources futures. La protection peut donc être conçue comme une condition d’exploitation durable, et non comme son contraire. ([B55](#ref-B55))

La croissance d’un arbre impose une temporalité longue. Réserver, inventorier et organiser les coupes revient à arbitrer entre des besoins immédiats et des usages futurs. Ces décisions peuvent limiter les droits coutumiers de populations qui dépendent du bois, du pâturage ou de la collecte. La forêt devient un espace de conflits entre puissance publique, propriétaires et usagers. Il serait anachronique de présenter Colbert comme un militant de l’écologie contemporaine : ses priorités sont celles d’un État monarchique et de sa puissance.

Au XIXe siècle, le Code forestier de **1827** prolonge une logique de réglementation. Les besoins industriels, les transformations agricoles et les politiques de reboisement modifient les paysages. La restauration de terrains de montagne vise notamment à limiter l’érosion et les dommages liés à certaines dynamiques torrentielles. Les forêts françaises ne sont donc pas toutes des vestiges immobiles d’un état « naturel » ; beaucoup résultent d’interventions, de plantations et de choix d’essences. ([B55a](#ref-B55a))

Au XXe et au XXIe siècle, les objectifs se diversifient : production de bois, protection des sols et de l’eau, biodiversité, accueil du public, stockage de carbone et adaptation au changement climatique. L’Office national des forêts, créé en **1964**, intervient dans la gestion de forêts publiques ; cela ne signifie pas que toutes les forêts françaises seraient publiques. Les propriétaires privés, collectivités, entreprises et associations comptent également parmi les acteurs. ([B55a](#ref-B55a))

La **gestion multifonctionnelle** cherche à articuler ces usages. Elle n’abolit pas les tensions : une coupe peut être justifiée par une stratégie sylvicole et contestée pour ses effets paysagers ou écologiques ; une plantation peut accroître une production sans restaurer la diversité d’un écosystème. Pour analyser un conflit, il faut préciser le peuplement, le type d’intervention, l’échelle temporelle et les objectifs. « Couper » ne signifie pas toujours déforester ; « planter » ne signifie pas toujours réparer toutes les fonctions d’une forêt.

### Néolithique et révolution industrielle : deux grandes ruptures, des temporalités différentes {#T05-AXE1-J02}

La **néolithisation** correspond au développement de sociétés fondées notamment sur l’agriculture et l’élevage. Elle débute dans certains foyers plusieurs millénaires avant notre ère et se diffuse selon des rythmes variés ; elle ne se produit pas partout simultanément. La domestication, les défrichements, la sédentarisation de nombreux groupes et la transformation des sols modifient les paysages et les relations entre humains, animaux et végétaux. ([B56](#ref-B56))

L’agriculture permet d’accroître et de stocker certaines productions, mais elle introduit aussi de nouvelles dépendances : saisons, récoltes, gestion de l’eau, protection des réserves et accès à la terre. Des sociétés deviennent plus nombreuses et plus hiérarchisées dans des configurations diverses. Il faut éviter de faire d’une innovation technique la cause unique d’un type d’organisation politique. Les interactions entre milieu et société n’obéissent pas à une loi simple.

La **révolution industrielle**, engagée notamment en Grande-Bretagne à la fin du XVIIIe siècle, transforme l’échelle et les sources de l’énergie mobilisée. Le charbon, puis le pétrole et le gaz, permettent une croissance des productions, des transports et des extractions. Ces énergies fossiles s’ajoutent longtemps aux usages plus anciens plutôt qu’elles ne les remplacent immédiatement. L’industrialisation associe innovations, capitaux, travail, marchés, rapports impériaux et politiques publiques. ([R-T05](#ref-R-T05) ; [B56a](#ref-B56a))

Les transformations produisent des pollutions locales, des risques professionnels, une urbanisation rapide et des changements globaux liés à l’accumulation des gaz à effet de serre. L’impact ne se limite pas aux lieux de consommation : les chaînes d’approvisionnement déplacent l’extraction, les déchets et certaines nuisances. Les bénéfices et les coûts sont distribués de manière inégale entre groupes sociaux et territoires.

Comparer les deux ruptures suppose donc de distinguer **nature des transformations, rythmes, énergie et échelles**. Le Néolithique transforme profondément les milieux sans mobiliser un système mondial d’énergies fossiles. L’industrialisation amplifie et mondialise certains effets. Dans les deux cas, les sociétés modifient leurs dépendances plutôt qu’elles ne s’affranchissent de toute contrainte environnementale.

**Document T05-Doc1 — Comparer sans confondre.** Tableau éditorial.

| Dimension | Néolithisations | Industrialisations |
|---|---|---|
| Transformation majeure | Agriculture, élevage, domestication et nouveaux paysages. | Mécanisation, énergies fossiles et accroissement des flux. |
| Temporalité | Diffusions longues, foyers et rythmes multiples. | Diffusion inégale depuis la fin du XVIIIe siècle ; accélérations ultérieures. |
| Dépendances | Sols, saisons, récoltes, accès aux terres et à l’eau. | Approvisionnements énergétiques, infrastructures et marchés. |
| Vigilance | Ne pas supposer une révolution simultanée partout. | Ne pas attribuer les mêmes responsabilités à toutes les populations. |

## Axe 2 — Le changement climatique : approches historique et géopolitique

### Les fluctuations climatiques en Europe du Moyen Âge au XIXe siècle {#T05-AXE2-J01}

Le climat décrit des distributions et des tendances sur des durées longues ; la météo décrit un état ou un événement de courte durée. Pour reconstituer les climats anciens, les chercheurs croisent archives écrites, dates de vendanges, cernes d’arbres, sédiments, glaciers et autres indicateurs. Chaque source possède une résolution, une aire de validité et des incertitudes. Une chronique relatant un hiver exceptionnel est une information précieuse, mais ne fournit pas seule une moyenne mondiale. ([B57](#ref-B57))

L’Europe connaît des variations désignées notamment par les expressions « anomalie climatique médiévale » et « petit âge glaciaire ». Leurs limites chronologiques varient selon les régions et les indicateurs ; il ne faut pas imaginer deux périodes homogènes ayant partout la même intensité. Le petit âge glaciaire, particulièrement étudié entre la fin du Moyen Âge et le XIXe siècle, comporte des épisodes froids et des avancées glaciaires. Les mécanismes naturels, dont le volcanisme et certaines variations solaires, interagissent avec la variabilité du système climatique. ([B57](#ref-B57) ; [D13](#ref-D13))

Les conséquences sociales dépendent de la vulnérabilité. Une succession de mauvaises récoltes peut accroître les prix et aggraver la sous-alimentation, mais les marchés, les réserves, les transports, les guerres et les décisions politiques modifient l’effet du choc. Dire qu’un changement climatique « provoque » une crise politique sans examiner ces médiations relève du déterminisme. L’histoire compare les réponses, les capacités d’adaptation et les inégalités.

L’existence de fluctuations anciennes ne réfute pas l’origine humaine du réchauffement contemporain. Les causes d’un changement se démontrent par des observations, des mécanismes et des comparaisons de modèles, non par l’idée qu’un phénomène aurait toujours une cause identique. Le GIEC conclut en **2023** que les activités humaines ont sans équivoque causé le réchauffement global ; sa synthèse indique environ **1,1 °C** pour 2011–2020 par rapport à 1850–1900. Cette valeur est liée à deux périodes précises, pas à une température quotidienne ni à un chiffre valable pour chaque territoire. ([D13](#ref-D13))

**Document T05-Doc2 — Lire un résultat climatique.** Reformulation pédagogique d’un résultat du GIEC, AR6, rapport de synthèse 2023, résumé pour décideurs, A.1 ; traduction et présentation éditoriales, sans citation littérale.

| Indicateur | Période étudiée | Référence | Résultat présenté |
|---|---|---|---|
| Température de surface mondiale | Moyenne 2011–2020 | Moyenne 1850–1900 | Environ +1,1 °C. |

Le tableau ne permet pas de donner la température d’une ville, ni d’affirmer que chaque année a connu la même anomalie. Il faut aussi distinguer le franchissement d’un seuil pendant une année et un réchauffement durable apprécié sur une période longue.

### Des sommets de la Terre aux COP : construire une gouvernance sans gouvernement mondial {#T05-AXE2-J02}

La conférence de **Stockholm de 1972** contribue à installer l’environnement dans l’agenda international. Le sommet de **Rio de 1992** associe environnement et développement et accompagne l’ouverture à la signature de grandes conventions, dont celle sur le climat. Les conférences des parties, ou **COP**, réunissent les parties à une convention ; elles ne sont pas toutes consacrées au même domaine. Une COP climat n’est pas une assemblée qui gouverne directement chaque économie nationale. ([B58](#ref-B58))

Le protocole de **Kyoto de 1997** fixe des engagements chiffrés à certaines parties industrialisées. L’accord de **Paris de 2015**, entré en vigueur en 2016, organise une participation plus large à partir de contributions déterminées au niveau national. Il vise à contenir l’élévation de température nettement en dessous de 2 °C et à poursuivre l’effort vers 1,5 °C par rapport aux niveaux préindustriels. Ses mécanismes prévoient progression, transparence et bilan collectif. Il ne faut pas confondre obligation de présenter et d’actualiser une contribution, objectif annoncé et réduction effectivement réalisée. ([D10](#ref-D10) ; [B58a](#ref-B58a))

La négociation porte sur une question distributive : qui doit agir, à quelle vitesse, avec quels moyens et au bénéfice de qui ? Les émissions historiques, les émissions actuelles, celles rapportées à la population et celles associées à la consommation ne racontent pas exactement la même chose. Les pays vulnérables peuvent avoir peu contribué au problème et disposer de faibles capacités d’adaptation. Le principe de responsabilités communes mais différenciées cherche à articuler universalité du problème et inégalités de situation.

L’**atténuation** vise les causes, notamment par la réduction des émissions et la préservation des puits. L’**adaptation** vise à réduire les vulnérabilités face aux effets. Les financements, les transferts de technologies et les pertes et préjudices soulèvent des débats distincts, même s’ils se rejoignent. Une digue peut réduire une exposition locale sans diminuer les émissions ; une politique électrique bas-carbone peut atténuer le changement sans protéger immédiatement une population déjà menacée par une submersion.

La gouvernance associe États, organisations internationales, scientifiques, collectivités, entreprises, associations et mobilisations citoyennes. Ces acteurs n’ont ni les mêmes intérêts ni les mêmes pouvoirs. Le GIEC évalue les connaissances scientifiques disponibles ; il ne négocie pas les contributions nationales à la place des gouvernements. La science éclaire les conséquences des choix ; elle ne décide pas seule de leur répartition sociale. ([D13](#ref-D13))

## Objet de travail conclusif — Les États-Unis et l’environnement : tensions et contrastes

### Depuis le XIXe siècle : exploiter, conserver, préserver à plusieurs échelles {#T05-OTC-J01}

L’expansion territoriale et économique des États-Unis s’appuie sur l’exploitation des terres, du bois, des minerais et des énergies. La représentation de grands espaces disponibles masque souvent la présence et les droits des peuples autochtones. Les paysages qualifiés de sauvages ont aussi des histoires humaines. Il faut donc étudier la protection de la nature sans effacer les déplacements et les exclusions qui ont parfois accompagné la création d’espaces protégés. ([B59](#ref-B59))

La création de **Yellowstone en 1872** constitue un repère majeur de l’histoire des parcs nationaux. À la fin du XIXe et au début du XXe siècle, deux orientations sont souvent distinguées : la **préservation**, associée notamment à John Muir, défend des espaces contre certains usages ; la **conservation**, associée à Gifford Pinchot, promeut une gestion raisonnée des ressources dans la durée. Cette distinction aide à comprendre des débats, mais ne doit pas transformer chaque acteur en incarnation parfaitement stable d’une doctrine unique. ([B59a](#ref-B59a))

L’État fédéral crée des institutions et des protections, tandis que les États fédérés, les collectivités, les propriétaires et les entreprises poursuivent leurs propres politiques. L’Agence de protection de l’environnement, créée en **1970**, devient un acteur majeur de la réglementation fédérale. Les mobilisations autour de la pollution, de la santé et de la justice environnementale soulignent que l’exposition aux nuisances est socialement inégale. Protéger un paysage spectaculaire et réduire la pollution d’un quartier industriel sont deux dimensions de l’action environnementale. ([B59b](#ref-B59b))

Les tensions ne se résument pas à « Américains contre écologie ». Elles opposent et rapprochent des coalitions variables : industries fossiles, entreprises de technologies propres, salariés, élus, associations, populations autochtones et consommateurs. Des emplois peuvent dépendre d’une activité polluante ; la transition pose alors la question de l’accompagnement et de la redistribution. L’analyse géopolitique relie les ressources, les intérêts économiques et les choix de souveraineté.

### Les États-Unis dans les négociations internationales : poids, discontinuités et diversité d’acteurs {#T05-OTC-J02}

Le poids économique et énergétique des États-Unis donne à leurs décisions une portée internationale. Leur participation est déterminante pour les financements, les marchés, l’innovation et la crédibilité de la coopération. Pourtant, l’engagement fédéral connaît des discontinuités. Les États-Unis n’ont pas ratifié le protocole de Kyoto. Ils ont participé à l’accord de Paris, puis s’en sont retirés une première fois en **2020**, avant d’y revenir en **2021**. Un second retrait, notifié en janvier 2025, est devenu effectif le **27 janvier 2026**. ([D10](#ref-D10))

**Actualisation arrêtée au 8 septembre 2026.** Il ne faut donc pas écrire que le retour de 2021 décrit encore, à lui seul, la situation américaine dans l’accord de Paris. En outre, le dépositaire des Nations unies a enregistré le 27 février 2026 une notification de retrait de la convention-cadre sur le climat, dont la prise d’effet est prévue le 27 février 2027. Une notification et une prise d’effet sont deux dates distinctes ; une actualisation sera nécessaire avant l’examen pour tout développement portant sur la situation de 2027. ([D10a](#ref-D10a))

Ces variations montrent la dépendance de la coopération aux rapports politiques internes et aux procédures juridiques. Une annonce présidentielle, une notification diplomatique, une entrée en vigueur et une mise en œuvre économique ne se confondent pas. La durée des investissements peut dépasser celle d’un mandat, tandis que l’incertitude réglementaire influence les décisions des entreprises et des partenaires.

L’action américaine ne se réduit cependant pas au gouvernement fédéral. Des États fédérés, des villes, des universités, des associations et des entreprises poursuivent des stratégies climatiques ou contestent des reculs. Ces initiatives peuvent produire des effets réels, mais ne remplacent pas intégralement les engagements diplomatiques et les moyens d’un État. Il faut éviter deux excès : considérer tout retrait fédéral comme l’arrêt de toute action, ou croire que l’action locale annule toutes ses conséquences. ([B60](#ref-B60))

Le jalon conduit ainsi à raisonner en termes de **gouvernance multiniveaux**. Les politiques environnementales articulent coopération et concurrence, expertise et décision, intérêts nationaux et interdépendances. Un engagement international reste d’autant plus crédible qu’il se traduit par des dispositifs durables et vérifiables.

## Exemple commenté — Articuler facteurs physiques et choix sociaux

**Affirmation à discuter :** « Une sécheresse entraîne nécessairement une famine. » La sécheresse peut diminuer une production et constitue un aléa. Mais l’accès aux stocks, le revenu, les transports, les importations, la guerre et les politiques d’assistance modifient les conséquences. Une explication rigoureuse relie donc **aléa → exposition → vulnérabilité → réponse**, sans supprimer le rôle matériel du climat ni présenter la société comme impuissante.

**Paragraphe modèle.** Les fluctuations climatiques mettent les sociétés à l’épreuve, mais leurs effets ne sont pas uniformes. Dans une économie fortement dépendante des récoltes locales, une succession d’intempéries peut réduire les disponibilités et accroître les prix. L’ampleur de la crise dépend toutefois de l’accès aux réserves, des circulations et des décisions publiques. La comparaison historique permet ainsi de comprendre pourquoi une contrainte climatique devient, dans certains contextes, une catastrophe sociale. Elle interdit d’attribuer automatiquement une crise politique à une température ou à une précipitation.

**Activité T05-A — 25 minutes.** À partir de T05-Doc2, rédigez une présentation exacte de l’indicateur, puis réfutez en deux arguments la phrase « Il a fait froid cette semaine, donc le résultat est faux ». Enfin, proposez une mesure d’atténuation et une d’adaptation, en expliquant leur mécanisme. Corrigé dans le compagnon.

## Synthèse active et transfert

L’environnement est transformé par des choix inscrits dans l’histoire. Exploitation et protection peuvent s’opposer ou se combiner ; leurs effets doivent être évalués. Le changement climatique exige une coopération mondiale, mais ses responsabilités, ses conséquences et les capacités d’action sont inégales.

**Repères utiles.** 1669 : ordonnance forestière ; 1827 : Code forestier ; 1872 : Yellowstone ; 1970 : EPA ; 1972 : Stockholm ; 1992 : Rio et convention-cadre ; 1997 : Kyoto ; 2015 : Paris ; 2023 : synthèse AR6 ; 27 janvier 2026 : second retrait américain de Paris.

**Preuve de maîtrise.** Pour une politique, identifier objectif, instrument, acteurs, échelles, résultat observé et limite. **Transfert.** Étudier un conflit sur l’eau ou une forêt en distinguant les usages, les temporalités et les inégalités ; ne pas choisir d’avance un seul acteur « bon » ou « mauvais » sans analyse de ses décisions.

**Sources du chapitre.** ([S03](#ref-S03) ; [R-T05](#ref-R-T05) ; [B55](#ref-B55)–[B60](#ref-B60) ; [D10](#ref-D10) ; [D10a](#ref-D10a) ; [D13](#ref-D13)). Les documents sont des présentations éditoriales ; le résultat chiffré est celui du GIEC pour les périodes explicitement indiquées, pas une estimation nouvelle.

## Entraînements — T05 {#T05-entrainements}

Les degrés 1, 2 et 3 désignent la difficulté, non les parcours N1/N2. Commencez sans aide ; consultez ensuite l’indice si nécessaire. Les corrections, les critères détaillés et les remédiations sont dans le compagnon, sous les mêmes identifiants.

### T05-E1 — Exploiter n’est pas nécessairement détruire {#T05-E1}

**Degré 1 · 20 minutes · Méthode M2**

Distinguez exploitation, conservation, préservation et protection. Utilisez la forêt française pour montrer qu’une réglementation peut poursuivre un objectif productif, puis évoluer.

**Aide, après une première tentative.** Précisez la finalité : protéger quoi, pour qui et pour combien de temps ?

### T05-E2 — Deux transformations, pas une cause unique {#T05-E2}

**Degré 1 · 25 minutes · Méthode M2**

Comparez la néolithisation et l’industrialisation : temporalités, techniques, ressources et transformations des milieux. Pourquoi « l’être humain détruit depuis toujours » n’explique-t-il pas le réchauffement contemporain ?

**Aide, après une première tentative.** Différenciez les rythmes, les régions et les sources d’énergie.

### T05-E3 — Lire un indicateur climatique {#T05-E3}

**Degré 2 · 25 minutes · Méthode M4**

**Donnée de synthèse scientifique.** Le GIEC indique environ +1,1 °C pour la température de surface mondiale en 2011–2020 par rapport à 1850–1900 ([D13](#ref-D13)). Expliquez indicateur, échelle, période observée et référence. Une semaine froide dans une ville réfute-t-elle ce résultat ?

**Aide, après une première tentative.** Une moyenne mondiale sur dix ans n’est pas la température de chaque journée.

### T05-E4 — Le Petit Âge glaciaire : raisonner sans monocausalité {#T05-E4}

**Degré 2 · 30 minutes · Méthode M5**

Rédigez un paragraphe expliquant comment des variations climatiques ont pu affecter les sociétés européennes entre le Moyen Âge et le XIXe siècle, sans expliquer une crise ou une révolte par le seul climat.

**Aide, après une première tentative.** Entre un aléa et une crise interviennent récoltes, prix, institutions et inégalités.

### T05-E5 — Accord, contribution et application {#T05-E5}

**Degré 2 · 30 minutes · Méthode M3**

**Document éditorial.** L’accord de Paris adopté en 2015 combine un objectif collectif de température, des contributions déterminées au niveau national et un mécanisme de révision. Les contributions ne constituent pas un partage uniforme des mêmes réductions ([D10](#ref-D10) ; [B58a](#ref-B58a)).

Expliquez l’intérêt et la limite de cette architecture. Distinguez adoption, entrée en vigueur, engagement national et effet mesuré.

**Aide, après une première tentative.** Un dispositif de coopération doit être analysé sans le présenter comme un gouvernement mondial.

### T05-E6 — États-Unis : pluralité des acteurs {#T05-E6}

**Degré 2 · 30 minutes · Méthode M6**

Construisez un plan détaillé pour : « Peut-on parler d’une politique environnementale américaine unique ? » Mobilisez acteurs fédéraux, États fédérés, entreprises et associations. Situez les retraits internationaux sans confondre Paris et la Convention-cadre.

**Aide, après une première tentative.** La pluralité ne signifie pas l’absence de tout cadre fédéral.

### T05-E7 — Dissertation : une gouvernance à l’épreuve {#T05-E7}

**Degré 3 · 90 minutes · Méthode M9**

« Pourquoi la protection de l’environnement exige-t-elle une coopération qui reste difficile à mettre en œuvre ? » Rédigez une dissertation avec au moins trois exemples situés, en distinguant environnement et climat.

**Aide, après une première tentative.** Expliquez successivement interdépendances, divergences et instruments ; ne remplacez pas l’analyse par une exhortation.

### T05-E8 — Contredire une objection à l’oral {#T05-E8}

**Degré 3 · 25 minutes · Méthode M11**

Répondez en trois minutes à : « Puisqu’un État peut se retirer d’un accord climatique, les accords ne servent à rien. » Donnez deux fonctions des accords, deux limites et un exemple daté. Ne supposez pas que le retrait éteint toutes les politiques intérieures.

**Aide, après une première tentative.** La réfutation doit reconnaître le fait qui rend l’objection plausible.

### T05 — QCM de vérification {#T05-qcm}

Une seule proposition correcte par question. Notez votre réponse et justifiez-la en une phrase ; la correction explique aussi pourquoi les autres propositions ne conviennent pas.

**T05-Q1.** L’ordonnance de Colbert de 1669…

**A.** répond déjà exactement aux objectifs climatiques actuels

**B.** encadre notamment une ressource stratégique

**C.** interdit toute utilisation du bois

**T05-Q2.** Une semaine froide dans une ville…

**A.** réfute une tendance mondiale sur plusieurs décennies

**B.** prouve que le climat est stable

**C.** ne suffit pas à réfuter une moyenne climatique mondiale

**T05-Q3.** L’atténuation vise principalement…

**A.** les causes du changement climatique

**B.** uniquement la réparation après catastrophe

**C.** la suppression de toute variabilité naturelle

**T05-Q4.** Une contribution nationale annoncée est…

**A.** une réduction déjà mesurée

**B.** un engagement à confronter aux politiques et résultats

**C.** un quota identique imposé à tous les pays

**T05-Q5.** Au 8 septembre 2026, le retrait américain de la Convention-cadre notifié en février 2026 est…

**A.** déjà effectif depuis janvier 2026

**B.** impossible à distinguer du retrait de Paris

**C.** prévu pour le 27 février 2027 selon la notification du dépositaire

### T05-RT — Nouveau test et réactivation {#T05-RT}

**20 minutes, sans cours, à distance du premier entraînement.**

1. Distinguez exploitation et destruction à partir d’une forêt. 2. Distinguez atténuation et adaptation avec un exemple chacune. 3. Expliquez une difficulté de coopération climatique par un mécanisme, non par « les États ne veulent pas ».

**Vérifier la maîtrise.** Réussite : trois réponses justifiées, avec notions distinguées et exemples situés. Une erreur de date appelle R1 ; une confusion de notion R2 ; une relation non expliquée R3. Refaire le point faible à J+2.

**Réactivation espacée.** J+7 : Analysez une mesure en distinguant objectif, instrument et effet. J+21 : Appliquez le raisonnement d’échelle à un problème d’eau ou de biodiversité.

**Trace de progression.** Date : … · Je restitue : oui / à reprendre · J’explique : oui / à reprendre · Je mobilise dans un sujet nouveau : oui / à reprendre · Erreur prioritaire : … · Nouvelle tentative prévue : …

# T06 — L’enjeu de la connaissance {#t06}

**Terminale • Parcours N2 • Thème évaluable à l’écrit 2027**

**Question directrice.** Pourquoi la production, la diffusion et le contrôle des connaissances sont-ils à la fois des facteurs d’émancipation, des ressources de puissance et des objets de coopération ?

**Objectifs.** Distinguer information et connaissance ; expliquer une production collective ; historiciser l’accès des femmes aux savoirs ; analyser renseignement et circulations ; territorialiser le cyberespace ; évaluer une attribution sans transformer un indice en preuve.

**Diagnostic T06-D — 10 minutes.** Disposer d’un grand nombre de données suffit-il pour connaître ? Une découverte peut-elle être individuelle et collective à la fois ? Une attaque passant par un serveur situé dans un pays prouve-t-elle la responsabilité de son gouvernement ? Justifiez.

**Itinéraire.** Introduction puis E1 ; alphabétisation et radioactivité puis E2–E4 ; renseignement et Inde puis E5–E6 ; cyberespace puis E7–E8. Les énoncés P01–P03 et T06 récupérés sont conservés dans la banque ; leurs corrections sont nouvelles.

## Introduction — Des informations aux connaissances, des individus aux communautés

Une **information** est un contenu susceptible de renseigner sur un fait, une situation ou une idée. Une **connaissance** suppose un travail d’interprétation, d’organisation et de validation. Accumuler des données ne garantit ni leur qualité ni leur compréhension. La distinction ne signifie pas qu’il faudrait opposer absolument les deux : les informations constituent des matériaux, mais leur traitement demande des méthodes et un contexte. ([S03](#ref-S03) ; [R-T06](#ref-R-T06))

La notion de **société de la connaissance**, associée notamment aux réflexions de Peter Drucker à la fin des années 1960, souligne le rôle croissant de la formation, de la recherche et des compétences dans les économies et les organisations. Elle ne signifie pas que les sociétés précédentes auraient été dépourvues de savoirs, ni que tous les individus accèdent également aux ressources contemporaines. L’expression constitue une grille de lecture ; elle doit être confrontée aux inégalités de scolarisation, de financement, de langue et d’infrastructures. ([B61](#ref-B61))

La production de connaissances implique des **communautés savantes** : chercheurs, techniciens, institutions, revues, instruments, financeurs et réseaux d’échange. Les procédures de discussion, de preuve et de reproduction des résultats rendent possible une connaissance qui ne dépend pas uniquement du prestige de son auteur. Ces communautés ne sont pas exemptes de hiérarchies, de concurrences ou d’exclusions ; leurs règles peuvent cependant organiser une critique qui corrige les erreurs.

La connaissance est une ressource particulière. Sa diffusion peut permettre à d’autres de l’utiliser sans que son premier détenteur la perde. Mais l’accès aux instruments, aux compétences, aux brevets, aux données et aux financements peut être restreint. Les tensions entre ouverture et appropriation structurent donc la recherche, l’économie et la sécurité. La connaissance devient un enjeu géopolitique lorsque son contrôle modifie des rapports de dépendance, de décision ou de puissance.

**Document T06-Doc1 — Produire une connaissance ne se réduit pas à publier une donnée.** Chaîne éditoriale.

| Étape | Opération | Question critique |
|---|---|---|
| Recueillir | Observer, mesurer, rechercher une trace. | Comment le matériau a-t-il été obtenu ? |
| Interpréter | Comparer, modéliser, contextualiser. | Quelles hypothèses et quelles limites ? |
| Discuter | Confronter les résultats et les méthodes. | D’autres peuvent-ils examiner les preuves ? |
| Transmettre | Enseigner, publier, documenter. | Qui peut comprendre et réutiliser ? |

## Axe 1 — Produire et diffuser des connaissances

### L’alphabétisation des femmes du XVIe siècle à nos jours : des progrès inégaux et disputés {#T06-AXE1-J01}

L’**alphabétisation** désigne l’acquisition de compétences de lecture et d’écriture ; les indicateurs contemporains en proposent des définitions opérationnelles qu’il faut préciser. Lire, écrire, signer et comprendre un texte complexe ne sont pas exactement la même compétence. Pour les périodes anciennes, la capacité à signer un acte peut servir d’indice, mais elle ne mesure pas directement toutes les pratiques de lecture. L’historien croise donc plusieurs types de traces. ([B62](#ref-B62) ; [D14](#ref-D14))

À partir du XVIe siècle en Europe, l’imprimerie, les Réformes religieuses et les transformations de l’enseignement modifient les possibilités d’accès aux textes. Dans certains milieux protestants, la lecture religieuse favorise l’instruction ; des institutions catholiques développent également des formes d’éducation féminine. Ces dynamiques ne produisent pas partout les mêmes résultats. Le statut social, la ville ou la campagne, les ressources familiales et les normes de genre sont déterminants. Les femmes ne forment pas un groupe homogène face à l’écrit. ([R-T06](#ref-R-T06) ; [B62](#ref-B62))

L’éducation féminine reste longtemps justifiée par des rôles domestiques ou religieux et limitée dans ses contenus. Des femmes instruisent, écrivent, traduisent et participent à des réseaux intellectuels, mais se heurtent à des restrictions institutionnelles. L’accès à l’alphabétisation ne signifie pas encore l’accès égal aux études supérieures, aux professions savantes ou à l’autorité publique. Il faut distinguer **ouverture d’un enseignement, égalité des programmes et égalité des carrières**.

En France, la loi Camille Sée de **1880** organise un enseignement secondaire public pour les jeunes filles. Les lois scolaires de **1881–1882** favorisent l’accès à l’instruction primaire, tandis que l’alignement des études secondaires féminines sur celles des garçons intervient plus tard, notamment en **1924**. Ces repères montrent une progression par étapes, non une égalité achevée en une seule date. Les mobilisations des femmes, les besoins sociaux et les décisions publiques concourent à cette évolution. ([B62a](#ref-B62a))

À l’échelle mondiale, l’élargissement de la scolarisation au XXe siècle transforme les possibilités d’autonomie, de participation et d’accès à l’information. Les inégalités persistent toutefois selon les pays, les générations, les revenus et les contextes de conflit. Pour utiliser un taux d’alphabétisation, il faut vérifier l’âge concerné, l’année, la définition et la méthode d’estimation. Un écart national moyen peut masquer des différences territoriales importantes. ([D14](#ref-D14))

L’accès des femmes aux savoirs constitue un enjeu de pouvoir parce qu’il élargit les possibilités de comprendre des droits, de maîtriser des démarches, d’accéder à un emploi ou de participer au débat. Il n’agit pas mécaniquement : des compétences acquises peuvent rester limitées par des discriminations et des violences. Le jalon conduit à analyser conjointement les institutions, les pratiques et les rapports sociaux.

### La radioactivité, de 1896 aux années 1950 : individus, instruments et collectifs {#T06-AXE1-J02}

En **1896**, Henri Becquerel met en évidence des rayonnements émis par des sels d’uranium. Marie Curie entreprend l’étude de ces phénomènes ; avec Pierre Curie, elle annonce en **1898** la découverte du polonium et du radium. Les travaux mobilisent des mesures, des instruments, des opérations chimiques et des échanges avec d’autres chercheurs. Le récit ne doit pas réduire la découverte à un éclair de génie isolé de ses conditions matérielles. ([B63](#ref-B63))

La mesure permet de comparer des substances et de formuler des hypothèses. Les instruments utilisés dépendent eux-mêmes d’autres recherches et de savoir-faire techniques. L’extraction et la caractérisation des substances exigent du temps, des matériaux, des financements et du travail. Les publications rendent les résultats discutables et réutilisables. La reconnaissance individuelle, comme les prix Nobel, ne doit pas rendre invisibles les réseaux qui rendent l’enquête possible.

Les recherches de Rutherford et de Soddy contribuent au début du XXe siècle à comprendre les transformations radioactives. D’autres découvertes, comme celle du neutron par Chadwick en **1932**, ouvrent de nouvelles possibilités. Irène et Frédéric Joliot-Curie mettent en évidence la **radioactivité artificielle en 1934**. La connaissance progresse par accumulation, controverses, nouvelles observations et réinterprétations, pas par une ligne parfaitement prévisible. ([B63a](#ref-B63a))

La fission nucléaire, identifiée à la fin des années 1930 à partir notamment des résultats de Hahn et Strassmann et de leur interprétation par Meitner et Frisch, transforme les horizons scientifiques et stratégiques. Pendant la Seconde Guerre mondiale, le projet Manhattan organise une recherche de très grande ampleur, marquée par la mobilisation étatique et le secret. Les bombardements atomiques d’Hiroshima et de Nagasaki en **1945** rendent manifeste l’enjeu politique et moral des applications. ([B63b](#ref-B63b))

Après la guerre, les usages médicaux, énergétiques et militaires se développent dans un contexte de concurrence et de coopération. Le partage scientifique coexiste avec le contrôle des technologies et des matières. Une même connaissance peut contribuer à soigner, produire de l’énergie ou fabriquer une arme ; ces applications dépendent d’institutions et de décisions. Il faut distinguer la découverte d’un phénomène, la maîtrise d’un dispositif et le choix de l’employer.

Le cas éclaire également la place des femmes dans les sciences : Marie Curie, Irène Joliot-Curie et Lise Meitner montrent des contributions majeures, mais leurs trajectoires ne prouvent pas l’absence de discriminations. Un parcours exceptionnel peut révéler autant les possibilités que les obstacles d’un système. **La production est collective sans que toutes les contributions soient reconnues de façon égale.**

## Axe 2 — La connaissance, enjeu politique et géopolitique

### Le renseignement pendant la guerre froide : savoir pour décider, dans l’incertitude {#T06-AXE2-J01}

Le **renseignement** désigne à la fois une information évaluée utile à la décision et l’activité organisée pour la produire. Son cycle associe orientation des besoins, collecte, traitement, analyse et diffusion. Il ne se réduit pas à l’espionnage : les sources ouvertes, l’imagerie, les interceptions et les échanges diplomatiques comptent également. La clandestinité d’une source ne garantit pas sa vérité ; une information publique peut être décisive. ([R-T06](#ref-R-T06) ; [B64](#ref-B64))

Pendant la guerre froide, les États-Unis et l’URSS cherchent à connaître les capacités, les intentions et les vulnérabilités de l’adversaire. Les services, notamment la CIA et le KGB, participent à cette compétition, mais les dispositifs sont plus vastes que deux agences. La collecte humaine se combine aux moyens techniques. Les programmes aéronautiques et spatiaux illustrent le lien entre connaissances scientifiques, observation stratégique et capacité de décision.

La crise des missiles de **Cuba en 1962** montre l’importance des photographies prises par les avions U-2 et de leur interprétation. Identifier des installations contribue à établir une menace et à organiser la réponse américaine. Mais connaître l’existence d’un dispositif ne signifie pas connaître parfaitement les intentions de l’adversaire ou toutes les conséquences d’une décision. La collecte réduit certaines incertitudes sans supprimer le risque de mauvaise appréciation. ([B64](#ref-B64))

Le renseignement peut favoriser la stabilité en évitant de surestimer ou de sous-estimer une capacité ; il peut aussi alimenter la méfiance, la manipulation et l’escalade. Les opérations clandestines, l’action d’influence et le contre-espionnage posent des problèmes de contrôle politique et de droits. Les archives déclassifiées sont essentielles pour l’histoire, mais elles sont partielles et produites par des institutions intéressées à leur propre représentation. Une source de service doit être contextualisée comme toute autre.

Une analyse rigoureuse distingue **donnée collectée, interprétation, niveau de confiance et décision**. Le décideur n’applique pas automatiquement une conclusion technique : il arbitre entre des risques, des objectifs et des contraintes. Le jalon permet donc de comprendre pourquoi posséder davantage d’informations ne garantit pas une politique juste ou efficace.

### L’Inde : circulations étudiantes, transferts de technologies et réseaux de puissance {#T06-AXE2-J02}

L’Inde investit après son indépendance dans des institutions scientifiques, des universités et des formations techniques. Les mobilités étudiantes vers des pôles étrangers permettent d’acquérir des diplômes, des compétences et des réseaux. Elles s’inscrivent dans des rapports inégaux de financement, de prestige et de possibilités d’emploi. Les données américaines sur les diplômés en sciences et ingénierie attestent l’importance des trajectoires originaires d’Inde, mais chaque série doit être datée et définie. ([B65](#ref-B65))

La **fuite des cerveaux** désigne la perte de compétences lorsque des personnes formées quittent durablement un territoire qui a investi dans leur formation. Cette lecture met en évidence des coûts réels, notamment lorsqu’un secteur manque de professionnels. Elle ne décrit cependant pas toutes les trajectoires. Retours, collaborations, investissements, enseignements à distance et créations d’entreprises peuvent transformer l’émigration en circulation de savoirs.

La **diaspora** peut relier des lieux de formation, des entreprises et des institutions publiques. Ces réseaux favorisent parfois l’accès à des marchés, à des capitaux ou à des technologies. Le transfert ne consiste pas seulement à acheter une machine : il suppose de pouvoir l’utiliser, l’adapter, l’entretenir et produire de nouvelles compétences. La **capacité d’absorption** du territoire d’accueil dépend de son système de formation, de recherche et d’organisation productive. ([B65a](#ref-B65a))

Les pôles technologiques indiens, dont Bengaluru, illustrent l’articulation entre formation, entreprises, services informatiques et relations internationales. Ils ne représentent pas toute l’économie ni toute la population indienne. Les inégalités régionales, sociales et de genre limitent l’accès aux opportunités. La réussite d’une entreprise ou de quelques dirigeants expatriés ne suffit pas à mesurer le développement de l’ensemble du pays.

Le jalon invite à sortir d’une opposition binaire entre départ et perte. Pour évaluer une circulation, il faut observer les retours de compétences, les emplois créés, les dépendances technologiques et les bénéfices pour les institutions locales. La mobilité devient une ressource de puissance sous conditions ; elle n’efface pas automatiquement les rapports asymétriques.

## Objet de travail conclusif — Le cyberespace : conflictualité et coopération entre acteurs

### Un espace de réseaux qui reste ancré dans des territoires {#T06-OTC-J01}

Le **cyberespace** peut être étudié à travers plusieurs couches complémentaires. La couche physique comprend câbles, antennes, satellites, centres de données et équipements. La couche logique associe protocoles, logiciels, adressage et systèmes. La couche informationnelle comprend les contenus et les interactions. Ces distinctions sont des outils d’analyse ; elles ne décrivent pas des mondes séparés. ([B66](#ref-B66) ; [D15](#ref-D15))

La circulation rapide des données ne fait pas disparaître les territoires. Les infrastructures occupent des lieux, utilisent de l’énergie, relèvent de propriétaires et sont soumises à des juridictions. Les points de concentration et les dépendances techniques peuvent constituer des vulnérabilités. Une entreprise privée peut disposer d’un pouvoir important sur l’hébergement, la visibilité ou l’accès, tandis que les États cherchent à réguler, sécuriser ou contrôler.

Les conflits portent sur l’espionnage, le sabotage, l’extorsion, l’influence, la surveillance et l’accès aux ressources. Il faut distinguer une panne, une erreur, un acte criminel et une opération liée à un État. Un **rançongiciel** bloque ou chiffre des ressources afin d’obtenir un paiement ; une opération d’influence vise des représentations et des comportements ; un sabotage cherche à dégrader un fonctionnement. Une même campagne peut combiner plusieurs objectifs, mais toute activité hostile n’est pas automatiquement une guerre.

L’**attribution** consiste à identifier un responsable. Une adresse IP, une langue ou un outil ne suffisent généralement pas à désigner un gouvernement : des infrastructures peuvent être compromises, louées ou utilisées pour masquer l’origine. L’analyse rapproche indices techniques, contexte, comportements et informations complémentaires, avec un niveau de confiance. L’attribution publique est aussi une décision politique. Il faut distinguer ce qui est observé, ce qui est inféré et ce qui est officiellement affirmé.

**Document T06-Doc2 — Un incident fictif, trois niveaux de conclusion.** Situation pédagogique nouvelle : une université constate un chiffrement de fichiers. Les connexions observées passent par un serveur étranger. Un message réclame une somme d’argent. Aucun autre élément n’est fourni.

| Niveau | Conclusion recevable avec ces seuls éléments |
|---|---|
| Observation | Des fichiers sont chiffrés ; un message réclame un paiement ; une connexion utilise un serveur étranger. |
| Hypothèse | Une opération d’extorsion de type rançongiciel est plausible. |
| Limite | Le pays du serveur ne permet pas, à lui seul, d’attribuer l’opération à son gouvernement. |

### La cyberdéfense française et la coopération européenne {#T06-OTC-J02}

La **cybersécurité** vise la protection des systèmes, des données et des services. La **cyberdéfense** renvoie notamment aux capacités de l’État pour prévenir, détecter et répondre à des menaces touchant ses intérêts et sa sécurité. En France, l’ANSSI, créée en **2009**, joue un rôle central dans la sécurité des systèmes d’information ; les armées disposent également d’organisations et de capacités propres. Les missions doivent être distinguées plutôt que regroupées sous le mot vague de « cyber ». ([D15](#ref-D15))

La protection ne repose pas uniquement sur des outils techniques. Elle associe inventaire des ressources, maîtrise des accès, mises à jour, sauvegardes, formation, détection et gestion de crise. La **résilience** est la capacité à maintenir ou rétablir des fonctions essentielles malgré une perturbation. Elle implique de préparer la continuité, de tester les restaurations et de tirer des enseignements des incidents. Cette description vise l’analyse des politiques de sécurité, non l’apprentissage d’attaques.

L’échelle européenne répond à l’interdépendance des réseaux et des services. L’ENISA soutient la coopération et l’expertise ; les dispositifs européens favorisent des exigences communes, des échanges d’informations et une coordination. La directive **NIS2**, adoptée en **2022** et entrée en vigueur en **2023**, renforce le cadre de sécurité pour de nombreux secteurs. Il faut distinguer texte européen, transposition nationale et application effective ; ce manuel ne suppose pas que toutes les étapes seraient identiques partout. ([D16](#ref-D16))

La coopération rencontre des obstacles : souveraineté, secret, intérêts industriels, hétérogénéité des moyens et protection des données. Elle reste nécessaire parce qu’une vulnérabilité chez un fournisseur peut affecter de nombreux acteurs. La sécurité collective ne signifie pas l’abolition des responsabilités nationales ou privées. Le cyberespace illustre ainsi une tension générale du thème : les connaissances doivent circuler pour protéger et innover, mais leur contrôle peut également constituer une ressource stratégique.

## Exemple commenté — Distinguer une preuve, une interprétation et une décision

**Mauvaise phrase :** « Le serveur est dans le pays X, donc X a attaqué. » Elle transforme une localisation technique en identité politique. **Réécriture :** « La connexion observée utilise un serveur situé dans X ; cet élément renseigne sur un passage du trafic, mais ne suffit pas à identifier l’opérateur ni son commanditaire. Une attribution nécessiterait des indices complémentaires et un niveau de confiance explicité. » La seconde phrase ne refuse pas toute conclusion : elle ajuste sa force aux preuves disponibles.

**Activité T06-A — 25 minutes.** À partir de T06-Doc2, rédigez une note de 180 mots séparant faits, hypothèses et informations à rechercher. Proposez ensuite une coopération utile entre l’université, une autorité nationale et un partenaire étranger. Expliquez une limite de ce partage. Corrigé dans le compagnon.

## Synthèse active et transfert

La connaissance dépend de conditions d’accès, de production, de validation et de circulation. Elle peut émanciper et accroître la puissance ; elle peut aussi être monopolisée, orientée ou mal interprétée. Les six jalons relient l’école, le laboratoire, les services de renseignement, les mobilités et les infrastructures numériques.

**Repères utiles.** 1880 : loi Camille Sée ; 1896 : Becquerel ; 1898 : polonium et radium ; 1934 : radioactivité artificielle ; 1945 : applications militaires de la fission ; 1962 : Cuba ; 2009 : ANSSI ; 2022–2023 : adoption puis entrée en vigueur de NIS2.

**Preuve de maîtrise.** Présenter une chaîne complète reliant acteur, connaissance, moyen de circulation ou de contrôle, effet et limite. **Transfert.** Pour une innovation nouvelle, demander qui produit, qui finance, qui valide, qui bénéficie et qui demeure dépendant. Ne pas confondre annonce d’une capacité et preuve de son efficacité.

**Sources du chapitre.** ([S03](#ref-S03) ; [R-T06](#ref-R-T06) ; [B61](#ref-B61)–[B66](#ref-B66) ; [D14](#ref-D14)–[D16](#ref-D16)). Les documents intégrés sont éditoriaux ; la situation d’incident est explicitement fictive. Les dates scientifiques sont rapprochées des ressources du Musée Curie et des institutions de recherche.

## Entraînements — T06 {#T06-entrainements}

Les degrés 1, 2 et 3 désignent la difficulté, non les parcours N1/N2. Commencez sans aide ; consultez ensuite l’indice si nécessaire. Les corrections, les critères détaillés et les remédiations sont dans le compagnon, sous les mêmes identifiants.

### T06-E1 — Du document au savoir {#T06-E1}

**Degré 1 · 20 minutes · Méthode M2**

Expliquez les différences entre donnée, information et connaissance à partir d’un exemple d’alphabétisation. Pourquoi un moteur de recherche ne remplace-t-il pas tout apprentissage ?

**Aide, après une première tentative.** Choisissez un nombre, puis une information définie, puis une interprétation confrontée à d’autres éléments.

### T06-E2 — Qui produit une découverte ? {#T06-E2}

**Degré 1 · 25 minutes · Méthode M2**

Établissez une chaîne de quatre étapes entre Becquerel, Marie et Pierre Curie, les Joliot-Curie et les travaux sur la fission. Expliquez le rôle des institutions et des échanges.

**Aide, après une première tentative.** Reliez chaque découverte à une nouvelle question ou possibilité. Ne faites pas de 1945 la date de découverte de toute radioactivité.

### T06-E3 — Lire les dénominateurs {#T06-E3}

**Degré 2 · 30 minutes · Méthode M4**

**Document fictif pour travailler les dénominateurs.** Dans une population pédagogique de 1 000 adultes, dont 500 femmes, le taux global d’alphabétisation passe de 60 % à 75 %. À la seconde date, 150 des 250 adultes non alphabétisés sont des femmes. Ces nombres ne décrivent aucun pays et ne sont pas des données de l’UNESCO.

1. Calculez la hausse en points et la hausse relative du taux. 2. Calculez la proportion de femmes parmi les adultes non alphabétisés et la proportion de personnes non alphabétisées parmi les femmes. 3. Expliquez pourquoi ces proportions diffèrent.

**Adaptation signalée :** deux valeurs de l’énoncé récupéré étaient illisibles. L’original est archivé ; cette nouvelle version remplace le jeu de données, sans prétendre reconstituer ces valeurs.

**Aide, après une première tentative.** Écrivez le dénominateur sous chaque proportion avant de calculer. Les nombres de cette version sont fictifs.

### T06-E4 — Comparer circulation et rétention {#T06-E4}

**Degré 2 · 30 minutes · Méthode M6**

Comparez circulation des étudiants et diaspora indienne avec renseignements durant la guerre froide. En quoi le savoir est-il une ressource dans les deux cas, et quelles différences empêchent de les assimiler ?

**Aide, après une première tentative.** Comparer objectifs, modes de circulation, acteurs et limites ; une mobilité étudiante n’est pas en elle-même une opération d’espionnage.

### T06-E5 — Le cloud n’est pas hors du monde {#T06-E5}

**Degré 2 · 20 minutes · Méthode M5**

Copie fictive : « Les données du cloud n’existent nulle part. Une attaque venant d’une adresse IP étrangère prouve immédiatement que le gouvernement correspondant l’a ordonnée. » Corrigez les deux erreurs.

**Aide, après une première tentative.** Le cloud a une matérialité ; une IP situe une infrastructure ou un passage, pas nécessairement le responsable.

### T06-E6 — Construire une réponse sur la souveraineté {#T06-E6}

**Degré 2 · 35 minutes · Méthode M6**

Sujet : « Maîtriser le cyberespace : se fermer ou coopérer ? » Proposez un plan qui distingue infrastructures, normes, sécurité et coopération française/européenne.

**Aide, après une première tentative.** La fermeture peut réduire certaines dépendances mais aussi priver de coopération ; distinguez les couches du cyberespace.

### T06-E7 — Dissertation autonome {#T06-E7}

**Degré 3 · 110 minutes · Méthode M9**

En 110 minutes : « Produire et diffuser la connaissance : émancipation et puissance ». Mobilisez l’alphabétisation, les sciences et les dimensions géopolitiques du thème.

**Aide, après une première tentative.** Répondez par des mécanismes : accès, production collective, circulation et contrôle. L’émancipation ne doit pas disparaître derrière la seule puissance des États.

### T06-E8 — Mini-projet de cartographie d’un service {#T06-E8}

**Degré 3 · 40 minutes · Méthode M4**

À partir du cours et du schéma du carnet cartographique, décrivez le trajet plausible d’une consultation de document : terminal, réseau, centre de données, service et droits. Indiquez ce que vous savez, ce que vous supposez et ce qui demanderait une enquête technique.

**Aide, après une première tentative.** Le carnet A09 fournit un schéma de principe, pas le trajet réel d’une connexion. Distinguez architecture plausible et mesure technique.

### T06 — QCM de vérification {#T06-qcm}

Une seule proposition correcte par question. Notez votre réponse et justifiez-la en une phrase ; la correction explique aussi pourquoi les autres propositions ne conviennent pas.

**T06-Q1.** L’alphabétisation…

**A.** se réduit toujours à signer son nom

**B.** élargit des capacités sans supprimer automatiquement toutes les inégalités

**C.** n’a aucun lien avec les rapports sociaux

**T06-Q2.** La découverte de la radioactivité étudiée avec Becquerel commence en…

**A.** 1896

**B.** 1648

**C.** 2015

**T06-Q3.** La diaspora peut contribuer à…

**A.** des circulations de compétences et de réseaux

**B.** un retour obligatoire de tous les diplômés

**C.** une absence de toute relation avec les pays d’origine

**T06-Q4.** Le cyberespace…

**A.** est purement immatériel

**B.** combine infrastructures, règles techniques et contenus

**C.** n’a aucun enjeu de droit

**T06-Q5.** Une adresse IP observée lors d’une attaque…

**A.** suffit à prouver l’ordre d’un gouvernement

**B.** n’est jamais une information utile

**C.** est un indice à confronter, pas une attribution politique automatique

### T06-RT — Nouveau test et réactivation {#T06-RT}

**20 minutes, sans cours, à distance du premier entraînement.**

1. Distinguez information et connaissance. 2. Pourquoi la radioactivité doit-elle être étudiée comme une production collective ? 3. Expliquez un enjeu territorial du cyberespace et une limite d’attribution d’attaque.

**Vérifier la maîtrise.** Réussite : trois réponses justifiées, avec notions distinguées et exemples situés. Une erreur de date appelle R1 ; une confusion de notion R2 ; une relation non expliquée R3. Refaire le point faible à J+2.

**Réactivation espacée.** J+7 : Rappeler 1896, 1934 et 2009 avec acteur et fonction. J+21 : Relier la coopération scientifique à T01 ou l’accès aux savoirs aux libertés de P01.

**Trace de progression.** Date : … · Je restitue : oui / à reprendre · J’explique : oui / à reprendre · Je mobilise dans un sujet nouveau : oui / à reprendre · Erreur prioritaire : … · Nouvelle tentative prévue : …

# Douze méthodes pour travailler et réussir les épreuves {#methodes}

## M1 — Comprendre un sujet avant de réciter le cours {#M1}

Un sujet n’est pas le nom d’un chapitre. Commencer par identifier les termes, la relation demandée, les limites spatiales et les bornes chronologiques. Puis reformuler la tâche en une phrase : « Je dois expliquer pourquoi… », « comparer selon… » ou « montrer comment… ». Une question contenant « et » n’appelle pas nécessairement une partie sur chaque terme : elle demande souvent d’étudier leur relation.

**Exemple.** « Patrimoine et tourisme : des intérêts toujours convergents ? » invite à examiner les conditions d’une convergence et ses limites. Une copie qui raconte successivement l’histoire de Versailles et celle de Venise sans les relier au tourisme ne répond pas. Le mot « toujours » demande une mise à l’épreuve : financements, fréquentation, pression sur l’habitat, conservation et choix publics.

Au brouillon, dessiner trois colonnes : **ce que le sujet demande ; ce que je sais utiliser ; ce que je dois laisser de côté**. Écarter une connaissance exacte n’est pas un échec lorsqu’elle n’éclaire pas le problème. Définir les mots par leurs usages dans le sujet, et non par une longue succession de définitions de dictionnaire.

**Micro-entraînement.** Pour « Faire la paix par la sécurité collective », garder la Charte de l’ONU, les mandats, la coopération et leurs limites ; ne pas transformer la réponse en histoire de toutes les batailles du XXe siècle. Une problématique possible est : comment des États souverains peuvent-ils organiser une sécurité commune malgré leurs intérêts divergents ? **Critère de réussite :** chaque partie annoncée répond à un aspect de cette question.

## M2 — Construire des repères utiles {#M2}

Un repère associe **date, acteur, espace, événement et signification**. « 1648 » seul est fragile ; « traités de Westphalie, règlement de conflits européens par la négociation, sans fin de toutes les guerres » est utilisable. Mémoriser un nombre de dates très élevé sans savoir les mobiliser crée une illusion de maîtrise.

Construire une chronologie à deux niveaux : cinq repères structurants par thème, puis quelques dates permettant de préciser un exemple. Relier les événements par des mots prudents : « permet », « fragilise », « contribue à », « dans un contexte de ». La succession ne prouve pas la causalité. L’élection d’Allende en 1970 précède le coup d’État de 1973 ; elle ne suffit pas, isolément, à l’expliquer.

**Exemple comparatif.** Portugal : rupture militaire du 25 avril 1974, phase de transition, Constitution de 1976. Espagne : mort de Franco en 1975, réformes et élections de 1977, Constitution de 1978, alternance de 1982. Le tableau ne doit pas faire croire que ces trajectoires ont le même point de départ ou le même rôle de l’armée.

Pour apprendre, fermer le cours et restituer le repère avec sa signification. Vérifier, corriger, puis rappeler après deux jours et une semaine. **Micro-entraînement corrigé :** 1896 renvoie à Becquerel, 1934 à la radioactivité artificielle, 1945 aux bombardements atomiques ; leur lien est une histoire de recherches et d’applications, non une découverte unique en trois dates. **Critère :** expliquer le rôle de la date dans l’argument, pas seulement la placer.

## M3 — Présenter et critiquer une source {#M3}

Présenter une source exige son auteur ou producteur, sa nature, sa date, son contexte, ses destinataires et son objectif lorsque ces éléments sont connus. Ne pas inventer ce que la notice ne donne pas. Distinguer date des faits, date de production et date de publication ou de republication.

La critique ne consiste pas à déclarer une source « subjective donc inutile ». Elle examine ce que sa position permet de voir et ce qu’elle ne permet pas d’établir. Un discours officiel renseigne sur une stratégie de présentation, même lorsqu’il ne prouve pas l’efficacité de la politique annoncée. Un témoignage fournit une expérience située, non une vision exhaustive de tout un conflit.

**Exemple.** L’article 10 du traité sur l’Union européenne est un texte juridique normatif. Il décrit des circuits de représentation. Il peut étayer l’analyse institutionnelle ; il ne mesure ni la satisfaction ni la participation effective des citoyens. Pour ces questions, il faut d’autres matériaux : enquêtes, résultats électoraux, études et comparaisons datées.

Procédure : relever un élément exact ; l’expliquer grâce au cours ; préciser sa portée ; confronter, lorsque nécessaire, une autre source. **Micro-entraînement corrigé :** une brochure vantant un site patrimonial permet d’étudier sa promotion et les publics visés ; elle ne constitue pas seule une preuve de bénéfices équitablement distribués. **Critère :** une limite formulée porte sur une question précise, sans disqualifier automatiquement toutes les informations du document.

## M4 — Lire un tableau, un graphique ou une carte {#M4}

Avant de commenter, vérifier titre, producteur, date, unité, champ, échelle et légende. Pour un taux, identifier le numérateur et le dénominateur. Pour une carte, distinguer ce qui est localisé, représenté par une surface ou figuré par un flux. Un schéma de principe n’a pas nécessairement une échelle métrique.

**Calcul.** Un taux passant de 60 % à 75 % augmente de **15 points de pourcentage**. Son augmentation relative est de 15/60, soit **25 %**. Ces deux formulations sont différentes et toutes deux recevables si l’on précise ce qui est mesuré. « Deux tiers des personnes non alphabétisées sont des femmes » n’équivaut pas à « deux tiers des femmes ne sont pas alphabétisées » : le dénominateur change.

Pour un graphique, commenter une tendance et une rupture avec des valeurs exactes, puis proposer une explication située. Ne pas inventer une évolution entre deux observations trop espacées. Une corrélation invite à enquêter sur un mécanisme ; elle ne le démontre pas seule.

Pour une carte de réseaux, étudier nœuds, axes, interfaces, hiérarchies et absences. **Exemple maritime :** une zone de 200 milles marins mesurée depuis les lignes de base ne doit pas être présentée comme 200 milles supplémentaires au-delà de la mer territoriale. Les chevauchements demandent des délimitations. **Critère :** chaque commentaire chiffré conserve son unité, son espace et sa période ; chaque interprétation se distingue de la simple lecture.

## M5 — Rédiger un paragraphe argumenté {#M5}

Un paragraphe défend une idée en répondant au problème. Il articule une affirmation, une explication, un exemple précis et une phrase qui établit la portée de l’exemple. Cet ordre peut varier ; ce n’est pas une formule à recopier mécaniquement. L’exemple doit être **analysé**, pas ajouté comme décoration.

**Phrase pauvre :** « La connaissance est importante. Marie Curie a découvert le radium. » **Réécriture :** « La production des connaissances repose sur l’articulation d’initiatives individuelles et de ressources collectives. Les travaux de Marie et Pierre Curie sur le radium en 1898 mobilisent des instruments, des opérations chimiques et des échanges savants. La reconnaissance de leur contribution ne doit donc pas masquer les conditions matérielles et institutionnelles qui rendent la recherche possible. »

Employer des connecteurs qui correspondent au raisonnement : « parce que » pour une explication ; « cependant » pour une limite ; « tandis que » pour une comparaison. Remplacer « cela montre que » lorsque le lien reste implicite par une phrase qui précise **ce qui est montré et pourquoi**.

**Micro-entraînement.** Expliquer en cinq phrases pourquoi une frontière peut faciliter certains échanges tout en les contrôlant. La correction doit contenir une interface, des règles, des acteurs et un exemple comme le Rhin supérieur. **Critère :** un lecteur peut identifier l’idée du paragraphe sans deviner le sujet ; la dernière phrase n’annonce pas simplement qu’on a donné un exemple.

## M6 — Construire un plan qui répond {#M6}

Un plan est la structure d’une démonstration, pas un rangement de souvenirs. Les parties doivent être distinctes, équilibrées et reliées. Deux parties solides peuvent être préférables à trois parties dont la dernière répète les précédentes. Il n’existe pas de plan universel « causes, conséquences, solutions » ni de plan obligé « oui, non, peut-être ».

Pour choisir, partir des relations établies au brouillon. Une progression chronologique convient lorsqu’elle explique une transformation et respecte les bornes ; une comparaison doit utiliser les mêmes critères ; un plan thématique doit répondre à une tension, non juxtaposer des dossiers.

**Exemple.** « La connaissance, une ressource de puissance » : I. La produire et y accéder élargit les capacités d’action ; II. La contrôler et organiser sa circulation crée des dépendances mais impose aussi des coopérations. Dans I, alphabétisation et recherche ; dans II, renseignement, Inde et cyberespace. Ce plan est recevable si les exemples sont analysés et si la dimension d’émancipation ne disparaît pas.

Tester chaque titre en ajoutant mentalement « car… ». Si aucune proposition explicative ne suit, la partie est probablement descriptive. Puis vérifier que chaque exemple sert le titre. **Micro-entraînement corrigé :** « I. Versailles ; II. Venise ; III. Mali » ne constitue pas encore une démonstration sur les conflits patrimoniaux. On peut préférer « des usages concurrents », puis « des dispositifs de protection et leurs arbitrages », en croisant les exemples. **Critère :** le plan devient inadapté lorsqu’on change le sujet ; s’il fonctionne pour presque tout, il est trop vague.

## M7 — Introduire, conclure, relire {#M7}

L’introduction situe l’objet, définit les termes utiles, construit le problème et annonce une démarche. Une accroche n’est pas obligatoire si elle est artificielle. Éviter « depuis la nuit des temps », les citations mal connues et les définitions interminables. Pour l’étude critique, présenter les documents et leur intérêt dans le problème, sans réciter une fiche d’identité séparée de l’analyse.

**Exemple d’ouverture.** « La reconnaissance d’un site comme patrimoine peut favoriser sa protection, mais elle attire aussi des usages concurrents. Le tourisme apporte des ressources tout en accentuant parfois les pressions sur les lieux et les habitants. Il faut donc examiner à quelles conditions la valorisation soutient la transmission plutôt qu’elle ne la compromet. » La suite annonce les deux mouvements réellement suivis.

La conclusion répond à la question et hiérarchise les résultats. Elle ne répète pas intégralement les titres et n’ajoute pas un exemple essentiel oublié. L’ouverture est facultative : une conclusion exacte vaut mieux qu’une question vague sur « l’avenir du monde ».

Relire en trois passages rapides : réponse au sujet ; exactitude des noms, dates et notions ; lisibilité de l’expression. Vérifier les pronoms sans antécédent et les phrases excessivement longues. **Micro-entraînement corrigé :** « En conclusion, le patrimoine est important » doit devenir une réponse, par exemple « sa valorisation protège sous conditions de régulation, de financement durable et de prise en compte des habitants ». **Critère :** la conclusion ne pourrait pas être écrite avant d’avoir établi les arguments.

## M8 — Réussir la composition du niveau 1 {#M8}

La composition N1 est une réponse organisée en **deux heures** à un sujet relevant d’un axe ou d’un objet conclusif de Première. Elle ne demande pas une étude critique séparée. Les connaissances doivent être sélectionnées, expliquées et reliées au sujet. Le volume de pages n’est pas un barème national. ([S05](#ref-S05))

Répartition indicative : 10 minutes pour analyser ; 20 minutes pour élaborer le plan et les exemples ; 80 minutes pour rédiger ; 10 minutes pour relire. Adapter après deux simulations. Ne pas rédiger tout le devoir au brouillon. Préparer surtout la problématique, l’ordre des idées et les faits qui soutiendront chaque paragraphe.

**Exemple.** Pour « Avancées et reculs des démocraties : des processus réversibles », le cœur est l’axe 2 de P01 : inquiétudes de Tocqueville, Chili, Portugal et Espagne. Athènes ne doit pas prendre la moitié de la copie. Montrer comment des institutions démocratiques peuvent être fragilisées, puis comment des transitions les construisent sans garantir leur irréversibilité, constitue une démarche possible.

**Grille pédagogique, non officielle :** compréhension et problématisation 4 points ; connaissances précises 6 ; argumentation et organisation 6 ; expression et achèvement 4. La note sert à localiser les besoins, pas à faire croire qu’un jury appliquerait obligatoirement cette décomposition. **Critère :** réponse complète, délimitée, nourrie de plusieurs exemples de l’axe ou de l’OTC, avec des relations explicitées et une conclusion.

## M9 — Réussir l’écrit terminal : deux exercices à mener jusqu’au bout {#M9}

L’écrit dure **quatre heures**. La dissertation et l’étude critique sont chacune notées sur 10. Deux dissertations sont proposées ; une seule doit être traitée. Les deux options relèvent de thèmes différents, et le dossier critique d’un troisième. Pour 2027, préparer T02, T04, T05 et T06 sans miser sur un sujet prédit. ([S04](#ref-S04))

Lire les trois propositions avant de choisir. Retenir la dissertation dont on comprend le problème et pour laquelle on dispose d’exemples précis, pas simplement celle dont un mot semble familier. Une proposition peut être plus connue en apparence mais exiger une relation mal maîtrisée.

Répartition indicative : 10 minutes de lecture et choix ; 110 minutes pour la dissertation ; 110 minutes pour l’étude critique ; 10 minutes de relecture finale. Une autre répartition est possible, mais laisser l’un des exercices inachevé coûte une part importante de l’évaluation. Inscrire des heures de bascule au brouillon et s’y tenir.

La dissertation mobilise le cours sans documents supports imposés. L’étude critique part des documents et les confronte au cours. Passer de l’une à l’autre exige donc un changement de démarche. **Exercice de préparation :** avant chaque blanc, écrire ce qui constituera la preuve d’achèvement : introduction, développement structuré et conclusion pour chacun des deux exercices. **Critère :** aucun exercice n’est sacrifié ; les exemples de dissertation répondent au sujet et les documents restent centraux dans l’étude critique.

## M10 — Organiser une étude critique de document(s) {#M10}

L’étude critique répond à une consigne en analysant un ou deux documents. Elle ne consiste ni à paraphraser, ni à réciter un cours qui oublie les documents. Commencer par lire la consigne, présenter les sources, repérer leurs idées et relever les éléments qui permettront une démonstration.

Au brouillon, utiliser quatre colonnes : **élément du document ; sens dans son contexte ; connaissance qui l’éclaire ; portée ou limite**. Une courte citation exacte peut être utile ; une reformulation fidèle suffit souvent. Toujours expliquer l’élément retenu. Avec deux documents, chercher convergences, compléments, contradictions et différences de nature ; éviter une partie entière par document lorsque la consigne demande de les confronter.

**Exemple.** Un texte de l’UNESCO affirme des objectifs de conservation ; un jugement de la CPI établit une responsabilité pour des destructions. Le premier renseigne sur une norme et une coopération ; le second sur une procédure et des faits jugés. Les rapprocher montre des instruments complémentaires, sans prétendre que l’UNESCO condamne pénalement ni que la CPI gère les restaurations.

L’introduction situe les documents et construit le problème ; le développement analyse des ensembles d’idées ; la conclusion répond et précise ce que le dossier permet d’établir. **Grille pédagogique sur 10 :** compréhension de la consigne 2 ; analyse et confrontation 3 ; contextualisation 2 ; critique de portée 2 ; organisation et expression 1. **Critère :** une limite est argumentée et liée au document, non ajoutée sous la formule « l’auteur est subjectif ».

## M11 — Préparer l’oral sans apprendre un texte immobile {#M11}

Le Grand oral n’est pas la récitation d’un exposé encyclopédique. Une question précise doit permettre un raisonnement, des exemples et une discussion. Préparer les deux questions avec les deux spécialités conservées ; vérifier leur conformité aux indications officielles. En 2027, la présentation dure dix minutes, suivie de dix minutes d’échange, après vingt minutes de préparation. ([S08](#ref-S08))

Construire une fiche d’appui : question, réponse directrice, deux ou trois mouvements, exemples, limites et sources. Répéter à partir de cette fiche plutôt que d’un texte appris mot à mot. Enregistrer une simulation, mesurer la durée et vérifier si les transitions sont audibles. Un support éventuel doit aider à raisonner, pas contenir tout le discours.

**Exemple HGGSP à adapter à l’autre spécialité :** « Les réseaux de connaissances peuvent-ils réduire la dépendance technologique d’un État ? » La question autorise Inde, recherche et cyberespace. Une question transversale avec NSI pourrait préciser les infrastructures et les conditions de maîtrise ; avec SES, formation et innovation. Ces exemples ne constituent pas des couples obligatoires.

Lors de l’échange, reformuler une question ambiguë, distinguer ce que l’on sait de ce que l’on suppose et reconnaître une limite précise. « Je ne dispose pas de ce chiffre, mais le mécanisme étudié est… » est préférable à une valeur inventée. Pour l’oral de contrôle HGGSP, préparer en vingt minutes une réponse au sujet remis, puis organiser dix minutes de présentation et dix minutes d’échange. **Critère :** répondre à une objection en mobilisant un exemple, sans quitter la question.

## M12 — Rechercher, vérifier, utiliser une actualité {#M12}

Une actualité illustre une connaissance ; elle ne doit pas remplacer le programme ni devenir une suite d’événements non expliqués. Commencer par définir la question et la date d’arrêt de l’enquête. Rechercher un document original, identifier son producteur, puis confronter des sources de nature différente lorsque les faits ou les interprétations sont disputés.

Distinguer annonce, décision, notification, entrée en vigueur et application. **Exemple :** le second retrait américain de l’accord de Paris est notifié en janvier 2025 et devient effectif le 27 janvier 2026. Confondre ces étapes produit une erreur même si le nom de l’accord est exact. Le dépôt d’une requête devant une juridiction n’équivaut pas à une condamnation ; une mesure provisoire n’est pas un jugement définitif sur tous les faits. ([D10](#ref-D10))

Tenir une fiche : fait établi ; source et date ; contexte ; interprétations ; incertitudes ; lien avec un jalon. Ne pas intégrer une statistique dont on ignore l’unité ou la population. Une image doit être vérifiée dans son contexte : source originale, date, lieu et éventuelle réutilisation.

Une réponse d’intelligence artificielle peut aider à organiser une recherche, mais elle n’est pas une preuve historique. Vérifier les références, les citations et les chiffres dans les documents originaux. Ne pas transmettre de données personnelles inutiles. **Critère :** pouvoir expliquer pourquoi une source est pertinente pour une affirmation précise et quelles limites subsistent. Une bonne actualisation peut être courte ; sa valeur vient de sa traçabilité et de son rôle dans l’argument.

# Six remédiations ciblées {#remediations}

Une remédiation commence par une erreur observée dans votre copie. Elle se termine par une tâche différente, réalisée sans regarder le modèle. Recopier le corrigé n’est pas une preuve de maîtrise. Les solutions des micro-tests ci-dessous figurent dans le compagnon ; consulter ensuite le nouveau test du thème.

## R1 — Je mélange les périodes et les acteurs {#R1}

**Signal.** Vous attribuez la convention de 1972 au patrimoine immatériel, ou présentez la proclamation de 1871 comme une cérémonie de Louis-Philippe.

**Réparation, 15 minutes.** Tracez trois colonnes : date ou durée, acteur, opération. Placez seulement cinq repères du thème. Pour chacun, écrivez une phrase avec un verbe précis : inaugurer, signer, créer, contester. Ajoutez ensuite une relation « avant », « après » ou « pendant », sans affirmer que succession signifie causalité. Cachez la colonne des dates et restituez-la ; cachez celle des acteurs et recommencez.

**Exemple.** 1837 : Louis-Philippe inaugure les galeries historiques de Versailles. 1871 : proclamation de l’Empire allemand dans la galerie des Glaces. 1919 : signature du traité de Versailles. La permanence du lieu ne signifie pas la permanence du régime.

**Micro-test R1-T, 5 minutes.** Associez 1972 et 2003 à deux conventions patrimoniales, puis 1993 et 1994 au TPIY et au génocide des Tutsi. Écrivez une phrase expliquant pourquoi la chronologie interdit de confondre ces deux dernières entrées.

**Critère.** Quatre associations exactes, puis une distinction entre institution judiciaire et événement criminel. À J+2, reprenez trois autres dates ; à J+7, réutilisez deux repères dans un paragraphe sans consulter la frise.

## R2 — J’emploie un mot sans maîtriser le concept {#R2}

**Signal.** Vous écrivez « puissance », « démocratie », « mémoire » ou « souveraineté » comme des étiquettes qui expliqueraient seules un phénomène.

**Réparation, 20 minutes.** Pour la notion fragile, écrivez une définition en une phrase, un exemple, un contre-exemple et un mot voisin à distinguer. Évitez de définir un terme par sa répétition. Testez ensuite votre définition sur une situation nouvelle : elle doit aider à décider ce qui entre dans la catégorie et ce qui n’y entre pas.

**Exemple.** Une ZEE attribue notamment des droits souverains sur certaines ressources ; elle ne constitue pas une mer territoriale de 200 milles. Le navire qui la traverse n’exerce pas pour autant un droit d’exploitation des ressources. Les deux activités relèvent de compétences distinctes.

**Micro-test R2-T, 5 minutes.** Une sanction économique est-elle du soft power parce qu’elle n’emploie pas l’armée ? Un film apprécié à l’étranger prouve-t-il le soutien au gouvernement du pays producteur ? Donnez un argument pour chaque réponse.

**Critère.** Distinguer contrainte et attraction, puis ressource culturelle et effet politique. À J+2, refaire avec atténuation/adaptation ; à J+7, comparer patrimoine matériel/immatériel à partir d’un exemple inédit.

## R3 — Je raconte, mais je n’explique pas {#R3}

**Signal.** Votre paragraphe juxtapose des dates ; le lecteur ne comprend ni le mécanisme ni le lien avec le sujet.

**Réparation, 20 minutes.** Soulignez une affirmation. Ajoutez « parce que » et identifiez un mécanisme. Donnez un fait situé qui le rend observable. Terminez par la réponse partielle au sujet et, si nécessaire, une limite. Les connecteurs ne remplacent pas l’explication : « donc » exige une relation démontrée.

**Exemple.** Une ville peut gagner en fréquentation tout en perdant des habitants parce que la conversion de logements vers des usages touristiques réduit l’offre résidentielle. Ce mécanisme doit être vérifié par des données localisées ; il ne résulte pas automatiquement de toute hausse de visiteurs.

**Micro-test R3-T, 8 minutes.** Transformez « L’ONU existe depuis 1945, mais il y a encore des guerres » en un paragraphe de six phrases : fonction, instrument, dépendance politique, exemple du cours, limite et réponse à l’idée d’inutilité.

**Critère.** Un instrument nommé et une dépendance expliquée, sans promesse d’efficacité absolue. À J+2, relire un ancien paragraphe ; à J+7, refaire le raisonnement avec une organisation différente.

## R4 — Je paraphrase le document {#R4}

**Signal.** Votre étude suit ligne après ligne le texte et remplace quelques mots par des synonymes. Les connaissances sont absentes ou ajoutées dans un bloc sans lien.

**Réparation, 20 minutes.** Construisez trois colonnes : élément précis du document ; explication par le cours ; portée et limite. Une citation courte est utile si elle devient un point d’appui. N’inventez pas d’intention de l’auteur : distinguez intention explicitée et interprétation argumentée. La critique ne consiste pas à écrire automatiquement « subjectif donc faux ».

**Exemple.** Une convention affirme un devoir de protection. Le cours permet d’identifier les États responsables et les instruments d’application. Le document établit une norme, pas la preuve que tous les sites seraient effectivement protégés. Cette limite découle de sa nature juridique.

**Micro-test R4-T, 8 minutes.** Un document éditorial expose le rôle des contributions nationales dans l’accord de Paris. Produisez une phrase d’appui, deux phrases d’explication et une phrase de limite. Indiquez ce qu’il faudrait consulter pour mesurer les résultats.

**Critère.** Au moins un élément documentaire explicite, une connaissance pertinente et une limite précise. À J+2, travailler un tableau ; à J+7, confronter deux documents de natures différentes.

## R5 — J’impose toujours le même plan {#R5}

**Signal.** Tous les sujets deviennent « causes/conséquences/solutions » ou « avantages/inconvénients », même lorsque la question porte sur une comparaison ou une transformation.

**Réparation, 20 minutes.** Soulignez le verbe et la relation du sujet. Reformulez en une question dont la réponse n’est pas une simple liste. Écrivez ensuite deux ou trois réponses partielles qui se complètent. Chaque partie doit apporter une étape de la démonstration, pas un thème appris par cœur. Vérifiez la place d’un contre-exemple.

**Exemple.** « Protéger le patrimoine impose-t-il de le figer ? » appelle une discussion sur conservation et transformation. Une progression recevable examine les limites indispensables aux destructions, puis les transformations nécessaires à la transmission. Une troisième partie sur les arbitrages est possible, non obligatoire.

**Micro-test R5-T, 8 minutes.** Proposez deux titres de parties pour « Les frontières empêchent-elles les échanges ? ». Placez le Rhin et une frontière fermée. Expliquez pourquoi « histoire/géographie/géopolitique » ne constitue pas ici un plan démonstratif suffisant.

**Critère.** Deux fonctions ou conditions distinctes, avec des exemples qui les démontrent. À J+2, changer le verbe du sujet ; à J+7, élaborer un plan sur un autre thème sans reprendre les mêmes titres.

## R6 — Je n’achève pas mon travail {#R6}

**Signal.** Le brouillon est très développé, mais une partie de la copie ou l’un des deux exercices de l’écrit terminal manque.

**Réparation.** Sur le prochain entraînement, fixez trois alarmes silencieuses ou repères de montre. Réservez dès le départ une durée aux deux exercices et à la relecture. Au brouillon, rédigez seulement problématique, titres argumentatifs, exemples et transitions essentielles ; ne produisez pas une première copie intégrale. Pour N1, testez 25 minutes d’analyse et plan, 80 minutes de rédaction et 15 minutes de vérification, puis ajustez à votre rythme. Pour N2, une répartition initiale proche de deux heures par exercice est un repère pédagogique, non une prescription officielle.

**Exercice R6-T.** En 25 minutes, traitez un sujet déjà étudié : 5 minutes de plan, 15 minutes pour une introduction et un paragraphe, 5 minutes pour la conclusion et la relecture. Notez le nombre de phrases utiles et les passages réellement manquants.

**Critère.** Toutes les fonctions attendues existent, même si le développement doit ensuite s’allonger. À J+2, refaire en 30 minutes sur une question nouvelle ; à J+7, réaliser une épreuve complète. Ne compensez pas un exercice absent par une introduction interminable à l’autre.

# Préparer le Grand oral et l’oral de contrôle {#oraux}

## Deux épreuves différentes

Le Grand oral valorise une question préparée et son argumentation. L’oral de contrôle HGGSP porte sur une question de cours tirée au sort parmi deux propositions. Ils ne partagent ni la même préparation sur l’année ni le même statut. Pour 2027, le Grand oral est affecté du coefficient 8 dans la voie générale ; il concerne les spécialités conservées, et non automatiquement la spécialité abandonnée. ([S08](#ref-S08) ; [S09](#ref-S09))

Au Grand oral, les deux questions présentées doivent, prises ensemble, porter sur les deux spécialités conservées. Elles peuvent les mobiliser séparément ou de manière transversale. Le jury choisit une question ; vingt minutes de préparation précèdent dix minutes de présentation et dix minutes d’échange. Le support préparé sert au candidat : il peut être montré mais n’est ni remis ni évalué. Les candidats individuels constituent eux-mêmes le document présentant leurs questions. Vérifier les consignes matérielles de la convocation, sans inventer une validation d’établissement exigée pour tous. ([S08](#ref-S08))

## Construire une question qui permette de démontrer

Un thème comme « le patrimoine » est trop large. « Comment la reconversion d’un héritage industriel peut-elle préserver une mémoire du travail sans figer un territoire ? » ouvre une enquête plus précise : des acteurs, une tension et des exemples. Écrire d’abord la réponse provisoire, puis chercher ce qui pourrait la contredire. Une question n’a pas besoin de promettre une solution définitive pour être pertinente.

Constituer un dossier de deux pages : question, rattachement aux programmes, cinq notions maîtrisées, deux ou trois exemples documentés, trois sources dont on connaît la nature, une objection et une réponse. Une question transversale doit réellement utiliser les concepts de l’autre spécialité ; une statistique isolée ne suffit pas à rendre une question HGGSP « mathématique ». Ne fabriquez pas la seconde spécialité d’un candidat inconnu.

## Simulation guidée : la connaissance et le cyberespace

**Question de travail, à personnaliser.** « Pourquoi l’interconnexion des universités crée-t-elle à la fois une ressource scientifique et une vulnérabilité ? » Rattachement : T06. Cette proposition ne remplace pas les deux questions personnelles conformes au parcours du candidat.

**Préparation sur l’année.** Relire le cours, distinguer données et connaissances, puis décrire une coopération réelle sans révéler de données sensibles. Construire une carte d’acteurs : laboratoire, université, fournisseur, autorité de sécurité, partenaire étranger. Utiliser la situation fictive T06-Doc2 pour tester le raisonnement, sans la raconter comme un incident historique.

**Trame de dix minutes.** Une minute pour définir le problème ; trois minutes sur le partage des données, des outils et des compétences ; trois minutes sur les dépendances et la sécurité ; deux minutes sur les conditions d’une coopération maîtrisée ; une minute de conclusion. Ce découpage est un outil d’entraînement, non un minutage imposé par les textes. Un exemple expliqué vaut mieux qu’une liste de cyberattaques mal connues.

**Relances possibles.** Une adresse IP suffit-elle à attribuer une attaque ? Faut-il garder toute connaissance secrète ? Qui décide du partage ? Quels coûts comporte une protection ? Qu’est-ce qui ferait évoluer votre réponse ? Le candidat doit savoir dire qu’un fait n’est pas établi, puis expliquer quel élément permettrait de l’établir.

## Évaluer une prestation sans la réduire à l’éloquence

Après l’enregistrement, écouter une première fois sans s’arrêter : la question et la réponse sont-elles compréhensibles ? Écouter ensuite pour compter les affirmations non justifiées et les mots non définis. Vérifier cinq dimensions : solidité des connaissances, progression de l’argumentation, précision de la langue, intelligibilité de la voix et qualité de l’interaction. La vitesse et l’assurance ne compensent pas une erreur factuelle. Une hésitation suivie d’une distinction rigoureuse peut être préférable à une réponse immédiate inventée.

Réaliser trois essais espacés. Premier essai avec notes ; deuxième avec une trame réduite ; troisième avec un interlocuteur qui interrompt uniquement pendant la phase d’échange. Après chaque essai, corriger un défaut prioritaire, pas dix à la fois. Préparer des réponses flexibles plutôt qu’un dialogue récité.

## Oral de contrôle HGGSP : une simulation complète {#controle}

**Cadre 2027.** Préparation : vingt minutes. Présentation construite : dix minutes. Échange : dix minutes. Le sujet comporte deux questions problématisées au choix portant sur des parties différentes ; le périmètre est celui de l’écrit, donc T02, T04, T05 et T06 pour 2027. ([S04](#ref-S04))

**Sujet pédagogique OC1.** Choisissez l’une des deux questions : A. « Pourquoi une victoire militaire ne suffit-elle pas à construire la paix ? » — T02. B. « Comment protéger un patrimoine tout en maintenant ses usages ? » — T04. Ce sujet est original, non issu d’une banque officielle.

Pendant les vingt minutes, consacrer cinq minutes à délimiter, dix minutes à organiser deux ou trois arguments avec exemples et cinq minutes à préparer l’entrée et la conclusion. Ne recopier ni tout le cours ni une dissertation complète. Sur la feuille, indiquer surtout les relations à expliquer.

**Repères de réponse OC1-A.** Distinguer arrêt des combats, accord politique, sécurité et reconstruction ; comparer 1991 et 2003 ; évoquer normes, acteurs locaux et institutions ; ne pas présenter toutes les opérations de l’ONU comme identiques. **Relances :** qu’apporte une victoire ? Quelles conditions permettent un compromis ? Le veto suffit-il à expliquer toute difficulté ?

**Repères de réponse OC1-B.** Définir patrimonialisation et usages ; montrer la nécessité d’empêcher des destructions ; expliquer la reconversion du bassin minier ; intégrer habitants et risques à Venise ; discuter la transmission immatérielle. **Relances :** un label protège-t-il seul ? Qui paie ? Une reconstruction est-elle toujours une falsification ?

**Autoévaluation.** Une réponse maîtrisée définit les termes, répond à la question, explique au moins deux exemples précisément situés et résiste à une relance en reconnaissant une limite. Après un essai, reprendre R1 si les repères sont confondus, R3 si les exemples sont racontés sans lien ou R5 si le plan ne répond pas au sujet.

# Carnet cartographique et schémas de raisonnement {#atlas}

Les cartes suivantes servent à localiser ; elles ne sont ni une carte des régimes politiques actuels ni une représentation exhaustive des frontières. Elles montrent les traits de côte, sans tracé des frontières d’État. Projection cylindrique équidistante ; coordonnées des villes arrondies. Fonds issus des données côtières distribuées avec Basemap/GSHHG ; réalisation éditoriale nouvelle. Les schémas A02 et A06–A09 représentent des relations, non des quantités mesurées. Les neuf figures sont disponibles séparément dans les sources.

## A01 — Démocratie : changer d’échelle {#A01}

![Carte A01 — Localisation des études de démocratie.](illustrations/A01.png){width=80%}

**Repères :** 1 Lisbonne ; 2 Madrid ; 3 Athènes ; 4 Bruxelles ; 5 Santiago du Chili ; 6 Washington. Situer un exemple ne signifie pas attribuer à l’ensemble du pays ou de la période un régime immuable. Athènes renvoie à la cité antique étudiée ; Bruxelles à une dimension institutionnelle de l’Union. La comparaison Portugal/Espagne/Chili doit conserver les temporalités différentes. (P01 ; [S02](#ref-S02))

\clearpage

## A02 — Espaces maritimes : distinguer les droits {#A02}

![Schéma A02 — Régimes maritimes simplifiés.](illustrations/A02.png){width=100%}

Une mer territoriale n’est pas une ZEE. Les 200 milles se mesurent depuis les lignes de base : on ne leur ajoute pas les 12 milles de la mer territoriale. Le schéma laisse de côté plusieurs zones et le régime détaillé du fond marin ; cette simplification ne doit pas être transformée en règle exhaustive. Source de référence : convention de Montego Bay, 1982. ([D02](#ref-D02) ; P03 ; T01)

\clearpage

## A03 — États-Unis : des lieux complémentaires {#A03}

![Carte A03 — Lieux de puissance aux États-Unis continentaux.](illustrations/A03.png){width=95%}

**Repères :** 1 Los Angeles/Hollywood ; 2 New York ; 3 Boston/Cambridge ; 4 Washington ; 5 San Francisco et aire de la Silicon Valley ; 6 Seattle. Les points désignent des lieux ou des aires, non des limites d’agglomération. Hollywood est un quartier de Los Angeles ; Cambridge appartient à l’aire de Boston. Les fonctions culturelles, financières, politiques, scientifiques et numériques se combinent ; aucun lieu ne représente à lui seul toute la puissance. L’exercice P02-E8 demande d’expliquer ces complémentarités. ([R-P02](#ref-R-P02))

\clearpage

## A04 — Europe : limites, interfaces et patrimoines {#A04}

![Carte A04 — Repères européens.](illustrations/A04.png){width=95%}

**Repères :** 1 Strasbourg, face à Kehl sur l’autre rive du Rhin ; 2 Luxembourg ; 3 Berlin ; 4 Varsovie ; 5 Bruxelles ; 6 Venise ; 7 Paris. Le fond ne représente pas l’espace Schengen. Pour parler de frontières, ajouter une légende correspondant à la date et au dispositif étudiés, sans déduire une compétence juridique du seul emplacement d’une ville. (P03 ; T04 ; [D04](#ref-D04))

\clearpage

## A05 — Moyen-Orient : localiser sans simplifier les conflits {#A05}

![Carte A05 — Repères au Moyen-Orient.](illustrations/A05.png){width=95%}

**Repères :** 1 Jérusalem ; 2 Le Caire ; 3 Damas ; 4 Bagdad ; 5 Koweït ; 6 Téhéran ; 7 Amman ; 8 Istanbul. Les points sont des repères de localisation, non une attribution de souveraineté ou une prise de position sur un statut territorial contesté. Ne pas confondre la capitale d’un État, un lieu de négociation et l’ensemble des acteurs qui y interviennent. (T02 ; [R-T02](#ref-R-T02))

\clearpage

## A06 — Information : identifier la chaîne de production {#A06}

![Schéma A06 — Production et réception d’une information.](illustrations/A06.png){width=100%}

Chaque flèche représente une opération, pas une garantie. La vérification peut échouer ; la mise en forme peut modifier un cadrage ; la réception n’est pas une adhésion automatique. Pour une dépêche reprise dans plusieurs journaux, distinguer la source initiale et les choix des rédactions. [P04 ; M3]

\clearpage

## A07 — Patrimoine : une chaîne d’opérations et d’arbitrages {#A07}

![Schéma A07 — Patrimonialisation et transmission.](illustrations/A07.png){width=100%}

La sélection précède une reconnaissance qui ne garantit pas toute la conservation. Le dernier bloc n’est pas une fin définitive : une pratique doit être transmise et un site entretenu. Revenir sur une décision peut être nécessaire lorsque les usages et les risques changent. (T04 ; [D11](#ref-D11) ; [D12](#ref-D12))

\clearpage

## A08 — Climat : raisonner sur les mécanismes {#A08}

![Schéma A08 — Causes, effets et réponses climatiques.](illustrations/A08.png){width=100%}

L’atténuation et l’adaptation sont différentes mais complémentaires. Les effets ne sont pas uniformes, parce que les espaces et les sociétés n’ont pas les mêmes expositions ni les mêmes moyens. Le schéma ne remplace pas un modèle climatique ou une série de mesures ; il organise des distinctions du cours. (T05 ; [D13](#ref-D13))

\clearpage

## A09 — Cyberespace : articuler matériel, logique et droits {#A09}

![Schéma A09 — Trajet plausible d’une consultation.](illustrations/A09.png){width=100%}

Un service peut distribuer ses données entre plusieurs centres et emprunter plusieurs réseaux. Le schéma ne prouve donc pas le trajet réel d’une consultation donnée. Il rappelle que des câbles, des logiciels, des identités et des règles sont nécessaires pour accéder à un document. Distinguer ce que l’on observe, ce que l’on suppose et ce qu’une enquête technique devrait établir. (T06 ; [D15](#ref-D15) ; [D16](#ref-D16))

# Lexique raisonné et index thématique {#lexique}

Ces définitions de travail renvoient aux chapitres où les notions sont contextualisées. Une définition ne remplace pas l’exemple ni l’analyse des limites. Plusieurs mots changent de portée selon l’époque et l’auteur ; préciser l’usage retenu dans la copie.

**Adaptation** — Réduction de la vulnérabilité aux effets d’un changement climatique ; à distinguer de l’atténuation. T05.

**Alphabétisation** — Apprentissage et maîtrise de compétences de lecture et d’écriture, mesurées selon des conventions qu’il faut préciser. Un taux exige une population de référence. T06.

**Alternance** — Remplacement des gouvernants ou de la majorité dans le respect de règles permettant la compétition politique. P01.

**Armistice** — Accord suspendant des opérations militaires ; il ne se confond pas avec un traité de paix réglant l’ensemble du conflit. P03, T02.

**Atténuation** — Action sur les causes du changement climatique, notamment les émissions et les puits de gaz à effet de serre. T05.

**Attribution** — Démarche cherchant à établir la responsabilité d’une action ; dans le cyberespace, elle ne se déduit pas de la seule localisation d’un serveur. T06.

**Autoritarisme** — Forme d’exercice du pouvoir limitant fortement la compétition politique et les libertés ; à contextualiser plutôt qu’à utiliser comme synonyme de toute décision contraignante. P01.

**Censure** — Contrôle qui empêche ou limite une expression ou une diffusion. Distinguer censure préalable, sanctions juridiques et autres pressions. P04.

**Citoyenneté** — Statut organisant l’appartenance politique, des droits et des obligations. Ses conditions varient : les habitants d’Athènes ne sont pas tous citoyens. P01.

**Connaissance** — Savoir construit par la mise en relation, l’interprétation et la validation d’informations ou d’expériences. T06.

**Conservation** — Maintien d’éléments, de ressources ou de conditions de renouvellement ; sa finalité peut être productive, scientifique ou patrimoniale selon le contexte. T04, T05.

**Contre-pouvoir** — Institution ou capacité organisée qui limite, contrôle ou conteste l’exercice d’un pouvoir. P01.

**Coopération** — Action coordonnée entre acteurs conservant des intérêts et des compétences propres. Elle n’implique pas l’absence de rivalité ou l’égalité de leurs moyens. P02, T01, T02, T05, T06.

**Cyberespace** — Ensemble de réseaux, d’infrastructures, de logiciels, d’informations et d’acteurs permettant des interactions numériques. Il ne se réduit ni à une carte des câbles ni à un espace immatériel. T06.

**Démocratie directe** — Participation des citoyens eux-mêmes à certaines décisions ; elle ne prouve pas que tous les habitants possèdent la citoyenneté. P01.

**Démocratie représentative** — Régime dans lequel des représentants exercent des fonctions politiques selon un mandat et des règles de responsabilité. Ses garanties dépassent la seule élection. P01.

**Désinformation** — Production ou diffusion intentionnelle d’informations trompeuses. Distinguer intention, erreur involontaire, satire et désaccord d’interprétation. P04.

**Dissuasion** — Action cherchant à empêcher un adversaire d’agir en lui faisant anticiper un coût jugé inacceptable. La dissuasion nucléaire est un cas spécifique. T01, T02.

**Donnée** — Élément enregistré ou mesuré qui demande un contexte, une définition et un traitement avant de soutenir une conclusion. T05, T06.

**État de droit** — Organisation dans laquelle l’exercice du pouvoir est soumis à des règles et à des garanties juridictionnelles ; ne se réduit pas à l’existence de textes. P01.

**Frontière** — Limite construite de souveraineté ou de compétence, qui peut aussi être un espace de contact, de filtrage et de coopération. P03.

**Génocide** — Crime défini par des actes et une intention de détruire, en tout ou en partie, un groupe national, ethnique, racial ou religieux comme tel. La qualification exige d’examiner les critères de la convention de 1948. T03, D17.

**Géopolitique** — Analyse de rivalités et de coopérations entre acteurs pour des territoires, ressources ou positions, intégrant leurs représentations. Module 00.

**Gouvernance** — Organisation d’une action entre plusieurs acteurs et niveaux, sans supposer un gouvernement unique qui décide de tout. T05.

**Guerre** — Affrontement armé organisé entre acteurs ; sa qualification et ses formes doivent être examinées, sans appeler guerre toute concurrence. T02.

**Histoire** — Construction critique de connaissances sur le passé à partir de sources interrogées et confrontées. T03.

**Information** — Contenu porté à la connaissance d’un destinataire ; sa vérité, son contexte et ses conditions de production doivent être établis. P04, T06.

**Interface** — Espace de contact et d’échanges entre ensembles différenciés. Une frontière peut devenir une interface sans perdre toute fonction de limite. P03.

**Jalon** — Entrée d’étude explicitement prévue dans une rubrique du programme. Les codes P01-AXE1-J01 du manuel sont locaux, non ministériels. S02, S03.

**Laïcité** — Mode d’organisation des rapports entre État et religions, dont les formes institutionnelles varient. À distinguer de la sécularisation des sociétés. P05.

**Légitimité** — Reconnaissance du droit ou de la justification d’un pouvoir ou d’une action. Elle peut être contestée et ne se confond pas avec la seule capacité matérielle. P01, T02.

**Mémoire** — Rapport situé au passé, individuel ou collectif, qui sélectionne et transmet des expériences et des significations. Ce n’est ni un mensonge par définition ni une histoire exhaustive. T03.

**Multilatéralisme** — Organisation de relations et de décisions entre plusieurs États, souvent dans un cadre institutionnel. Il n’abolit pas leurs rapports de force. T02, T05.

**Patrimonialisation** — Processus par lequel des acteurs reconnaissent, sélectionnent et organisent la transmission d’un héritage. T04.

**Patrimoine immatériel** — Pratiques, expressions, connaissances et savoir-faire reconnus par des communautés, dont la sauvegarde repose sur la transmission vivante. T04, D12.

**Pluralisme** — Reconnaissance et possibilité d’expression d’une diversité de positions, d’organisations ou d’appartenances. P01, P04, P05.

**Problématique** — Question construite qui organise la démonstration à partir de la tension du sujet ; elle ne se réduit pas à ajouter un point d’interrogation au titre. M1, M6.

**Projection de puissance** — Capacité à intervenir et à soutenir une action au-delà de son territoire, par des moyens et des relais précis. T01.

**Puissance** — Capacité d’un acteur à agir, à faire agir, à empêcher ou à peser sur une relation. Une ressource n’a pas automatiquement l’effet recherché. P02.

**Renseignement** — Informations recherchées, traitées et analysées pour éclairer une décision, notamment dans un contexte stratégique. T06.

**Représentation** — Selon le contexte, exercice d’un mandat politique ou manière de percevoir et de construire le sens d’une situation ; préciser le sens utilisé. P01, P02.

**Restauration** — Intervention sur un héritage dégradé, fondée sur des choix d’état, de matériaux et de méthode. Elle n’est pas une restitution magique d’un passé intact. T04.

**Sécularisation** — Transformation de la place du religieux dans les pratiques, les institutions et les représentations sociales ; processus distinct d’une décision juridique de séparation. P05.

**Sécurité collective** — Dispositif dans lequel des membres cherchent à répondre collectivement aux menaces contre la paix, selon des règles et des organes. T02.

**Soft power** — Capacité d’influence par l’attraction ; une sanction économique relève de la contrainte, même sans recours à l’armée. P02.

**Souveraineté** — Autorité suprême exercée dans un ordre politique et sur un territoire, soumise dans les relations internationales à des règles et des engagements. Ne pas confondre souveraineté et capacité d’action illimitée. P03, T01.

**Source** — Trace, document ou témoignage interrogé pour construire une connaissance. Identifier auteur, date, nature, contexte et conditions d’accès. M3.

**Terrorisme** — Usage de violences visant notamment à terroriser des populations ou à contraindre des autorités ; qualifier les pratiques et leurs auteurs sans en faire une explication unique. T02.

**Transition démocratique** — Processus de transformation d’un régime autoritaire vers des institutions et des pratiques démocratiques, dont la consolidation n’est pas garantie. P01.

**Valorisation** — Mise en visibilité, en usage ou en intelligibilité d’un héritage ; elle peut comporter des dimensions éducatives, sociales et économiques à évaluer. T04.

**Vulnérabilité** — Propension à subir les effets d’un aléa, liée notamment à l’exposition, aux ressources et aux capacités de protection. T05.

**ZEE** — Zone économique exclusive, pouvant s’étendre jusqu’à 200 milles depuis les lignes de base, où l’État côtier possède des droits souverains et des compétences déterminés, sans souveraineté intégrale comparable à celle de la mer territoriale. P03, T01, D02.

# Références et provenance documentaire {#references}

Les codes sont des repères locaux, non des identifiants ministériels. **S** désigne le cadre officiel ; **R** les ressources d’accompagnement ; **D** des documents de référence ; **B** une source spécifique ou un renvoi thématique à une ressource, selon la qualification indiquée. Un renvoi à une ressource pédagogique ne signifie pas que les ouvrages originaux qu’elle cite ont tous été lus intégralement.

Les documents du cours sont des synthèses éditoriales sauf indication expresse contraire. Les adaptations ne sont pas des citations verbatim. Les jeux fictifs ne sont pas des statistiques historiques. Les liens permettent une vérification complémentaire ; aucun exercice ne suppose qu’un document absent soit téléchargé pour être résolu.

**Actualisation : 8 septembre 2026.** Les règles de session et les faits contemporains demandent une nouvelle veille avant l’examen. Ce manuel ne vaut ni homologation ministérielle ni conseil individuel d’inscription.

## Cadre officiel

[**([S01](#ref-S01)) Éduscol — Programmes et ressources HGGSP**]{#ref-S01} — Texte ou information officielle. [Consulter la source](https://eduscol.education.gouv.fr/5802/programmes-et-ressources-en-histoire-geographie-geopolitique-et-sciences-politiques-voie-g).

[**([S02](#ref-S02)) Programme de Première — BO spécial du 22 janvier 2019**]{#ref-S02} — Texte ou information officielle. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/spe576annexe1062925pdf-83244.pdf).

[**([S03](#ref-S03)) Programme de Terminale — BO spécial du 25 juillet 2019**]{#ref-S03} — Texte ou information officielle. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/spe254annexe1159180pdf-83247.pdf).

[**([S04](#ref-S04)) Note du 27 août 2025, NOR MENE2521923N — Épreuve HGGSP à compter de 2026**]{#ref-S04} — Texte ou information officielle. [Consulter la source](https://www.education.gouv.fr/bo/2025/Hebdo33/MENE2521923N).

[**([S05](#ref-S05)) Évaluation ponctuelle de la spécialité non poursuivie — version consolidée juin 2025, HGGSP pages 3–4**]{#ref-S05} — Texte ou information officielle. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ndsevaluations-ponctuelleseds-non-poursuivivoie-gjuin-2025pdf-100575.pdf).

[**([S06](#ref-S06)) Éduscol — Candidats individuels au baccalauréat**]{#ref-S06} — Texte ou information officielle. [Consulter la source](https://eduscol.education.gouv.fr/5694/candidats-individuels-au-baccalaureat-general-et-au-baccalaureat-technologique).

[**([S07](#ref-S07)) Note du 25 août 2025 — Modalités d’évaluation à compter de 2026**]{#ref-S07} — Texte ou information officielle. [Consulter la source](https://www.education.gouv.fr/bo/2025/Hebdo32/MENE2523743N).

[**([S08](#ref-S08)) Éduscol — Grand oral, présentation actualisée en février 2026**]{#ref-S08} — Texte ou information officielle. [Consulter la source](https://eduscol.education.gouv.fr/5661/presentation-du-grand-oral).

[**([S09](#ref-S09)) Éduscol — Épreuves terminales et coefficients du baccalauréat général**]{#ref-S09} — Texte ou information officielle. [Consulter la source](https://eduscol.education.gouv.fr/5706/les-epreuves-terminales-du-baccalaureat-general).

[**([S10](#ref-S10)) Déclaration des droits de l’homme et du citoyen de 1789 — Légifrance**]{#ref-S10} — Texte ou information officielle. [Consulter la source](https://www.legifrance.gouv.fr/loda/id/JORFTEXT000000697056).

## Accompagnement par thème

[**([R-P01](#ref-R-P01)) Éduscol — Ressource d’accompagnement : Comprendre un régime politique : la démocratie**]{#ref-R-P01} — Accompagnement disciplinaire officiel. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra19lyceegspe1hggsptheme1democratie1169458pdf-83250.pdf). Source d’appui aux jalons et à leur problématisation ; ne vaut pas validation du présent manuel.

[**([R-P02](#ref-R-P02)) Éduscol — Ressource d’accompagnement : Analyser les dynamiques des puissances internationales**]{#ref-R-P02} — Accompagnement disciplinaire officiel. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra19lyceegspe1hggsptheme2puissancesinter1169460pdf-83253.pdf). Source d’appui aux jalons et à leur problématisation ; ne vaut pas validation du présent manuel.

[**([R-P03](#ref-R-P03)) Éduscol — Ressource d’accompagnement : Étudier les divisions politiques du monde : les frontières**]{#ref-R-P03} — Accompagnement disciplinaire officiel. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra19lyceegspe1hggsptheme3frontieres1206062pdf-83256.pdf). Source d’appui aux jalons et à leur problématisation ; ne vaut pas validation du présent manuel.

[**([R-P04](#ref-R-P04)) Éduscol — Ressource d’accompagnement : S’informer : un regard critique sur les sources et modes de communication**]{#ref-R-P04} — Accompagnement disciplinaire officiel. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra20lyceeg1histgeogeopolitique-sciencespotheme4-sinformer-regard-critique1293847pdf-83259.pdf). Source d’appui aux jalons et à leur problématisation ; ne vaut pas validation du présent manuel.

[**([R-P05](#ref-R-P05)) Éduscol — Ressource d’accompagnement : Analyser les relations entre États et religions**]{#ref-R-P05} — Accompagnement disciplinaire officiel. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra20lyceeg1histgeogeopolitique-sciencespoanalyser-relations-etats-religions1293914pdf-83262.pdf). Source d’appui aux jalons et à leur problématisation ; ne vaut pas validation du présent manuel.

[**([R-T01](#ref-R-T01)) Éduscol — Ressource d’accompagnement : De nouveaux espaces de conquête**]{#ref-R-T01} — Accompagnement disciplinaire officiel. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra20lyceegtspehgeotheme1espacesconquetes0021329089pdf-83265.pdf). Source d’appui aux jalons et à leur problématisation ; ne vaut pas validation du présent manuel.

[**([R-T02](#ref-R-T02)) Éduscol — Ressource d’accompagnement : Faire la guerre, faire la paix : formes de conflits et modes de résolution**]{#ref-R-T02} — Accompagnement disciplinaire officiel. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra22lycee-gthggsptheme-2faire-la-guerre-et-faire-la-paix-93786.pdf). Source d’appui aux jalons et à leur problématisation ; ne vaut pas validation du présent manuel.

[**([R-T03](#ref-R-T03)) Éduscol — Ressource d’accompagnement : Histoire et mémoires**]{#ref-R-T03} — Accompagnement disciplinaire officiel. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra22lycee-gthggsphistoire-et-memoires-93783.pdf). Source d’appui aux jalons et à leur problématisation ; ne vaut pas validation du présent manuel.

[**([R-T04](#ref-R-T04)) Éduscol — Ressource d’accompagnement : Identifier, protéger et valoriser le patrimoine : enjeux géopolitiques**]{#ref-R-T04} — Accompagnement disciplinaire officiel. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra25lyceegthggspidentifierprotegervaloriserpatrimoine-enjeuxgeopolitiques0pdf-121241.pdf). Source d’appui aux jalons et à leur problématisation ; ne vaut pas validation du présent manuel.

[**([R-T05](#ref-R-T05)) Éduscol — Ressource d’accompagnement : L’environnement, entre exploitation et protection : un enjeu planétaire**]{#ref-R-T05} — Accompagnement disciplinaire officiel. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra23lyceegthggspenvironnementexploitationprotectionenjeupdf-102786.pdf). Source d’appui aux jalons et à leur problématisation ; ne vaut pas validation du présent manuel.

[**([R-T06](#ref-R-T06)) Éduscol — Ressource d’accompagnement : L’enjeu de la connaissance**]{#ref-R-T06} — Accompagnement disciplinaire officiel. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra24lyceegthggspenjeuxconnaissancepdf-104487.pdf). Source d’appui aux jalons et à leur problématisation ; ne vaut pas validation du présent manuel.

## Documents de référence

[**([D01](#ref-D01)) Traité sur l’Union européenne, article 10**]{#ref-D01} — Document institutionnel de référence. [Consulter la source](https://eur-lex.europa.eu/legal-content/FR/TXT/?uri=CELEX:12012M010).

[**([D02](#ref-D02)) Convention des Nations unies sur le droit de la mer, 1982**]{#ref-D02} — Document institutionnel de référence. [Consulter la source](https://www.un.org/depts/los/convention_agreements/texts/unclos/unclos_f.pdf).

[**([D03](#ref-D03)) Accord BBNJ — Dépositaire ONU : entrée en vigueur le 17 janvier 2026**]{#ref-D03} — Document institutionnel de référence. [Consulter la source](https://treaties.un.org/Pages/ViewDetails.aspx?src=TREATY&mtdsg_no=XXI-10&chapter=21&clang=_en).

[**([D04](#ref-D04)) Conseil de l’UE — Espace Schengen**]{#ref-D04} — Document institutionnel de référence. [Consulter la source](https://www.consilium.europa.eu/en/policies/schengen-area/).

[**([D06](#ref-D06)) Archives nationales américaines — Bill of Rights, premier amendement**]{#ref-D06} — Document institutionnel de référence. [Consulter la source](https://www.archives.gov/founding-docs/bill-of-rights-transcript).

[**([D07](#ref-D07)) OTAN — Pays membres et dates d’adhésion**]{#ref-D07} — Document institutionnel de référence. [Consulter la source](https://www.nato.int/en/about-us/organization/nato-member-countries).

[**([D08](#ref-D08)) UNOOSA — Traité de l’espace de 1967**]{#ref-D08} — Document institutionnel de référence. [Consulter la source](https://www.unoosa.org/oosa/en/ourwork/spacelaw/treaties/introouterspacetreaty.html).

[**([D09](#ref-D09)) Nations unies — Charte de 1945**]{#ref-D09} — Document institutionnel de référence. [Consulter la source](https://treaties.un.org/doc/source/docs/charter-all-lang.pdf).

[**([D10](#ref-D10)) CCNUCC — Accord de Paris**]{#ref-D10} — Document institutionnel de référence. [Consulter la source](https://unfccc.int/process-and-meetings/the-paris-agreement).

[**([D10a](#ref-D10a)) Dépositaire ONU — Retrait américain de la CCNUCC, notification du 27 février 2026, effet prévu le 27 février 2027**]{#ref-D10a} — Document institutionnel de référence. [Consulter la source](https://treaties.un.org/doc/Publication/CN/2026/CN.102.2026-Eng.pdf).

[**([D11](#ref-D11)) UNESCO — Convention du patrimoine mondial de 1972**]{#ref-D11} — Document institutionnel de référence. [Consulter la source](https://whc.unesco.org/fr/conventiontexte/).

[**([D12](#ref-D12)) UNESCO — Convention pour la sauvegarde du patrimoine culturel immatériel, 2003**]{#ref-D12} — Document institutionnel de référence. [Consulter la source](https://ich.unesco.org/fr/convention). Le dispositif de 2003 est distinct de la convention de 1972. Aucun passage présenté comme transcription littérale.

[**([D13](#ref-D13)) GIEC — AR6, rapport de synthèse 2023, résumé pour décideurs**]{#ref-D13} — Document institutionnel de référence. [Consulter la source](https://www.ipcc.ch/report/ar6/syr/summary-for-policymakers/).

[**([D14](#ref-D14)) Banque mondiale / UNESCO-UIS — Indicateur d’alphabétisation des femmes adultes**]{#ref-D14} — Document institutionnel de référence. [Consulter la source](https://data.worldbank.org/indicator/SE.ADT.LITR.FE.ZS). Aucune valeur illisible de l’ancienne banque n’est reconstituée à partir de cette page ; T06-E3 est un jeu fictif explicitement nouveau.

[**([D15](#ref-D15)) Décret n° 2009-834 du 7 juillet 2009 créant l’ANSSI**]{#ref-D15} — Document institutionnel de référence. [Consulter la source](https://www.legifrance.gouv.fr/loda/id/JORFTEXT000020828212).

[**([D16](#ref-D16)) ENISA — Directive NIS 2 et coopération européenne**]{#ref-D16} — Document institutionnel de référence. [Consulter la source](https://www.enisa.europa.eu/topics/state-of-cybersecurity-in-the-eu/cybersecurity-policies/nis-directive-2).

[**([D17](#ref-D17)) ONU — Convention de 1948 pour la prévention et la répression du crime de génocide**]{#ref-D17} — Document institutionnel de référence. [Consulter la source](https://www.ohchr.org/en/instruments-mechanisms/instruments/convention-prevention-and-punishment-crime-genocide).

## Appuis documentaires et approfondissements

[**([B01](#ref-B01)) Citoyenneté athénienne — appui dans la ressource P01**]{#ref-B01} — Renvoi thématique à un accompagnement officiel. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra19lyceegspe1hggsptheme1democratie1169458pdf-83250.pdf). Le code désigne un point d’appui de la ressource Éduscol, pas une édition intégrale d’un ouvrage original. Voir le jalon correspondant.

[**([B02](#ref-B02)) Benjamin Constant : libertés des Anciens et des Modernes — appui dans la ressource P01**]{#ref-B02} — Renvoi thématique à un accompagnement officiel. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra19lyceegspe1hggsptheme1democratie1169458pdf-83250.pdf). Le code désigne un point d’appui de la ressource Éduscol, pas une édition intégrale d’un ouvrage original. Voir le jalon correspondant.

[**([B03](#ref-B03)) Tocqueville et les tensions de la démocratie — appui dans la ressource P01**]{#ref-B03} — Renvoi thématique à un accompagnement officiel. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra19lyceegspe1hggsptheme1democratie1169458pdf-83250.pdf). Le code désigne un point d’appui de la ressource Éduscol, pas une édition intégrale d’un ouvrage original. Voir le jalon correspondant.

[**([B04](#ref-B04)) Sénat américain — Covert Action in Chile, 1963–1973, rapport de 1975**]{#ref-B04} — Source institutionnelle. [Consulter la source](https://www.intelligence.senate.gov/wp-content/uploads/2024/08/sites-default-files-94chile.pdf).

[**([B05](#ref-B05)) Assemblée de la République portugaise — Construção da democracia, 1974–1976**]{#ref-B05} — Source institutionnelle. [Consulter la source](https://www.parlamento.pt/Parlamento/Paginas/construcao-democracia_1974-1976.aspx).

[**([B06](#ref-B06)) Transition et Constitution espagnoles — appui dans la ressource P01**]{#ref-B06} — Renvoi thématique à un accompagnement officiel. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra19lyceegspe1hggsptheme1democratie1169458pdf-83250.pdf). Le code désigne un point d’appui de la ressource Éduscol, pas une édition intégrale d’un ouvrage original. Voir le jalon correspondant.

[**([B07](#ref-B07)) Empire ottoman : essor et déclin — appui dans la ressource P02**]{#ref-B07} — Renvoi thématique à un accompagnement officiel. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra19lyceegspe1hggsptheme2puissancesinter1169460pdf-83253.pdf). Le code désigne un point d’appui de la ressource Éduscol, pas une édition intégrale d’un ouvrage original. Voir le jalon correspondant.

[**([B08](#ref-B08)) ONU — Agression contre l’Ukraine, résolution ES-11/1 du 2 mars 2022**]{#ref-B08} — Source institutionnelle. [Consulter la source](https://docs.un.org/fr/A/RES/ES-11/1).

[**([B09](#ref-B09)) Langues, attraction et soft power — appui dans la ressource P02**]{#ref-B09} — Renvoi thématique à un accompagnement officiel. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra19lyceegspe1hggsptheme2puissancesinter1169460pdf-83253.pdf). Le code désigne un point d’appui de la ressource Éduscol, pas une édition intégrale d’un ouvrage original. Voir le jalon correspondant.

[**([B10](#ref-B10)) Conseil de l’UE — Paquet sur les services et marchés numériques**]{#ref-B10} — Source institutionnelle. [Consulter la source](https://www.consilium.europa.eu/en/policies/digital-services-package/).

[**([B11](#ref-B11)) Routes de la soie et connectivité — appui dans la ressource P02**]{#ref-B11} — Renvoi thématique à un accompagnement officiel. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra19lyceegspe1hggsptheme2puissancesinter1169460pdf-83253.pdf). Le code désigne un point d’appui de la ressource Éduscol, pas une édition intégrale d’un ouvrage original. Voir le jalon correspondant.

[**([B12](#ref-B12)) Lieux et instruments de la puissance américaine — appui dans la ressource P02**]{#ref-B12} — Renvoi thématique à un accompagnement officiel. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra19lyceegspe1hggsptheme2puissancesinter1169460pdf-83253.pdf). Le code désigne un point d’appui de la ressource Éduscol, pas une édition intégrale d’un ouvrage original. Voir le jalon correspondant.

[**([B13](#ref-B13)) UNESCO — Frontières de l’Empire romain : limes de Germanie inférieure**]{#ref-B13} — Source institutionnelle. [Consulter la source](https://whc.unesco.org/en/list/1631/).

[**([B14](#ref-B14)) Conférence et acte de Berlin de 1885 — appui dans la ressource P03**]{#ref-B14} — Renvoi thématique à un accompagnement officiel. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra19lyceegspe1hggsptheme3frontieres1206062pdf-83256.pdf). Le code désigne un point d’appui de la ressource Éduscol, pas une édition intégrale d’un ouvrage original. Voir le jalon correspondant.

[**([B15](#ref-B15)) Commandement des Nations unies — Négociations de l’armistice coréen, 1951–1953**]{#ref-B15} — Source institutionnelle. [Consulter la source](https://www.unc.mil/History/1951-1953-Armistice-Negotiations/).

[**([B16](#ref-B16)) Frontière germano-polonaise et traités — appui dans la ressource P03**]{#ref-B16} — Renvoi thématique à un accompagnement officiel. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra19lyceegspe1hggsptheme3frontieres1206062pdf-83256.pdf). Le code désigne un point d’appui de la ressource Éduscol, pas une édition intégrale d’un ouvrage original. Voir le jalon correspondant.

[**([B17](#ref-B17)) Coopération dans le Rhin supérieur — appui dans la ressource P03**]{#ref-B17} — Renvoi thématique à un accompagnement officiel. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra19lyceegspe1hggsptheme3frontieres1206062pdf-83256.pdf). Le code désigne un point d’appui de la ressource Éduscol, pas une édition intégrale d’un ouvrage original. Voir le jalon correspondant.

[**([B18](#ref-B18)) Histoire des médias de masse — appui dans la ressource P04**]{#ref-B18} — Renvoi thématique à un accompagnement officiel. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra20lyceeg1histgeogeopolitique-sciencespotheme4-sinformer-regard-critique1293847pdf-83259.pdf). Le code désigne un point d’appui de la ressource Éduscol, pas une édition intégrale d’un ouvrage original. Voir le jalon correspondant.

[**([B19](#ref-B19)) Presse et affaire Dreyfus — appui dans la ressource P04**]{#ref-B19} — Renvoi thématique à un accompagnement officiel. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra20lyceeg1histgeogeopolitique-sciencespotheme4-sinformer-regard-critique1293847pdf-83259.pdf). Le code désigne un point d’appui de la ressource Éduscol, pas une édition intégrale d’un ouvrage original. Voir le jalon correspondant.

[**([B20](#ref-B20)) Agences de presse, Havas et AFP — appui dans la ressource P04**]{#ref-B20} — Renvoi thématique à un accompagnement officiel. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra20lyceeg1histgeogeopolitique-sciencespotheme4-sinformer-regard-critique1293847pdf-83259.pdf). Le code désigne un point d’appui de la ressource Éduscol, pas une édition intégrale d’un ouvrage original. Voir le jalon correspondant.

[**([B20a](#ref-B20a)) Loi du 29 juillet 1881, article 1 — Légifrance**]{#ref-B20a} — Source institutionnelle. [Consulter la source](https://www.legifrance.gouv.fr/loda/article_lc/LEGIARTI000006419657).

[**([B21a](#ref-B21a)) DARPA — Histoire d’ARPANET**]{#ref-B21a} — Source institutionnelle. [Consulter la source](https://www.darpa.mil/news/features/arpanet).

[**([B21b](#ref-B21b)) CERN — Naissance du Web**]{#ref-B21b} — Source institutionnelle. [Consulter la source](https://home.cern/science/computing/the-birth-of-the-web/).

[**([B22](#ref-B22)) Archives nationales américaines — Pentagon Papers**]{#ref-B22} — Source institutionnelle. [Consulter la source](https://www.archives.gov/research/pentagon-papers).

[**([B23](#ref-B23)) Information numérique, vérification et lanceurs d’alerte — appui dans la ressource P04**]{#ref-B23} — Renvoi thématique à un accompagnement officiel. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra20lyceeg1histgeogeopolitique-sciencespotheme4-sinformer-regard-critique1293847pdf-83259.pdf). Le code désigne un point d’appui de la ressource Éduscol, pas une édition intégrale d’un ouvrage original. Voir le jalon correspondant.

[**([B24](#ref-B24)) Charlemagne et pouvoirs religieux — appui dans la ressource P05**]{#ref-B24} — Renvoi thématique à un accompagnement officiel. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra20lyceeg1histgeogeopolitique-sciencespoanalyser-relations-etats-religions1293914pdf-83262.pdf). Le code désigne un point d’appui de la ressource Éduscol, pas une édition intégrale d’un ouvrage original. Voir le jalon correspondant.

[**([B25](#ref-B25)) Empereurs byzantins et califes abbassides — appui dans la ressource P05**]{#ref-B25} — Renvoi thématique à un accompagnement officiel. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra20lyceeg1histgeogeopolitique-sciencespoanalyser-relations-etats-religions1293914pdf-83262.pdf). Le code désigne un point d’appui de la ressource Éduscol, pas une édition intégrale d’un ouvrage original. Voir le jalon correspondant.

[**([B26](#ref-B26)) Turquie : laïcisation et Diyanet — appui dans la ressource P05**]{#ref-B26} — Renvoi thématique à un accompagnement officiel. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra20lyceeg1histgeogeopolitique-sciencespoanalyser-relations-etats-religions1293914pdf-83262.pdf). Le code désigne un point d’appui de la ressource Éduscol, pas une édition intégrale d’un ouvrage original. Voir le jalon correspondant.

[**([B27](#ref-B27)) Religion et politique aux États-Unis — appui dans la ressource P05**]{#ref-B27} — Renvoi thématique à un accompagnement officiel. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra20lyceeg1histgeogeopolitique-sciencespoanalyser-relations-etats-religions1293914pdf-83262.pdf). Le code désigne un point d’appui de la ressource Éduscol, pas une édition intégrale d’un ouvrage original. Voir le jalon correspondant.

[**([B28](#ref-B28)) Constitution et pluralisme en Inde — appui dans la ressource P05**]{#ref-B28} — Renvoi thématique à un accompagnement officiel. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra20lyceeg1histgeogeopolitique-sciencespoanalyser-relations-etats-religions1293914pdf-83262.pdf). Le code désigne un point d’appui de la ressource Éduscol, pas une édition intégrale d’un ouvrage original. Voir le jalon correspondant.

[**([B29](#ref-B29)) Inde, Pakistan et Cachemire — appui dans la ressource P05**]{#ref-B29} — Renvoi thématique à un accompagnement officiel. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra20lyceeg1histgeogeopolitique-sciencespoanalyser-relations-etats-religions1293914pdf-83262.pdf). Le code désigne un point d’appui de la ressource Éduscol, pas une édition intégrale d’un ouvrage original. Voir le jalon correspondant.

[**([B30](#ref-B30)) Jalons de la conquête spatiale — appui dans la ressource T01**]{#ref-B30} — Renvoi thématique à un accompagnement officiel. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra20lyceegtspehgeotheme1espacesconquetes0021329089pdf-83265.pdf). Le code désigne un point d’appui de la ressource Éduscol, pas une édition intégrale d’un ouvrage original. Voir le jalon correspondant.

[**([B31](#ref-B31)) Dissuasion et projection navale — appui dans la ressource T01**]{#ref-B31} — Renvoi thématique à un accompagnement officiel. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra20lyceegtspehgeotheme1espacesconquetes0021329089pdf-83265.pdf). Le code désigne un point d’appui de la ressource Éduscol, pas une édition intégrale d’un ouvrage original. Voir le jalon correspondant.

[**([B32](#ref-B32)) NASA — International Space Station, facts and figures**]{#ref-B32} — Source institutionnelle. [Consulter la source](https://www.nasa.gov/international-space-station/space-station-facts-and-figures/).

[**([B33](#ref-B33)) CNSA — Retour d’échantillons de Chang’e 6, juin 2024**]{#ref-B33} — Source institutionnelle. [Consulter la source](https://www.cnsa.gov.cn/english/n6465652/n6465653/c10573102/content.html).

[**([B34](#ref-B34)) Chine et enjeux maritimes — appui dans la ressource T01**]{#ref-B34} — Renvoi thématique à un accompagnement officiel. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra20lyceegtspehgeotheme1espacesconquetes0021329089pdf-83265.pdf). Le code désigne un point d’appui de la ressource Éduscol, pas une édition intégrale d’un ouvrage original. Voir le jalon correspondant.

[**([B35](#ref-B35)) Clausewitz — On War, livre I, traduction historique anglophone**]{#ref-B35} — Source institutionnelle. [Consulter la source](https://clausewitzstudies.org/readings/OnWar1873/BK1ch01.html).

[**([B35a](#ref-B35a)) Guerre de Sept Ans et guerres napoléoniennes — appui dans la ressource T02**]{#ref-B35a} — Renvoi thématique à un accompagnement officiel. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra22lycee-gthggsptheme-2faire-la-guerre-et-faire-la-paix-93786.pdf). Le code désigne un point d’appui de la ressource Éduscol, pas une édition intégrale d’un ouvrage original. Voir le jalon correspondant.

[**([B36](#ref-B36)) Yale, Avalon Project — Traité de Westphalie, 1648**]{#ref-B36} — Source institutionnelle. [Consulter la source](https://avalon.law.yale.edu/17th_century/westphal.asp).

[**([B36a](#ref-B36a)) Al-Qaïda et Daech : formes et objectifs de la violence — appui dans la ressource T02**]{#ref-B36a} — Renvoi thématique à un accompagnement officiel. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra22lycee-gthggsptheme-2faire-la-guerre-et-faire-la-paix-93786.pdf). Le code désigne un point d’appui de la ressource Éduscol, pas une édition intégrale d’un ouvrage original. Voir le jalon correspondant.

[**([B37](#ref-B37)) ONU et construction de la paix sous Kofi Annan — appui dans la ressource T02**]{#ref-B37} — Renvoi thématique à un accompagnement officiel. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra22lycee-gthggsptheme-2faire-la-guerre-et-faire-la-paix-93786.pdf). Le code désigne un point d’appui de la ressource Éduscol, pas une édition intégrale d’un ouvrage original. Voir le jalon correspondant.

[**([B37a](#ref-B37a)) ONU — Responsabilité de protéger**]{#ref-B37a} — Source institutionnelle. [Consulter la source](https://www.un.org/en/genocide-prevention/responsibility-protect/about).

[**([B38](#ref-B38)) Conflits et tentatives de paix au Moyen-Orient — appui dans la ressource T02**]{#ref-B38} — Renvoi thématique à un accompagnement officiel. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra22lycee-gthggsptheme-2faire-la-guerre-et-faire-la-paix-93786.pdf). Le code désigne un point d’appui de la ressource Éduscol, pas une édition intégrale d’un ouvrage original. Voir le jalon correspondant.

[**([B38a](#ref-B38a)) Résolution 242 et diplomatie régionale — appui dans la ressource T02**]{#ref-B38a} — Renvoi thématique à un accompagnement officiel. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra22lycee-gthggsptheme-2faire-la-guerre-et-faire-la-paix-93786.pdf). Le code désigne un point d’appui de la ressource Éduscol, pas une édition intégrale d’un ouvrage original. Voir le jalon correspondant.

[**([B38b](#ref-B38b)) ONU — Situation à Gaza et processus politique, point daté du 26 août 2026**]{#ref-B38b} — Actualisation institutionnelle. [Consulter la source](https://www.un.org/unispal/document/gazas-recovery-and-reconstruction-and-the-broader-political-process-are-mutually-dependent-un-acting-special-coordinator-for-the-middle-east-peace-process-briefs-the-security-council/). Le code désigne un point d’appui de la ressource Éduscol, pas une édition intégrale d’un ouvrage original. Voir le jalon correspondant.

[**([B38c](#ref-B38c)) Cour internationale de justice — Avis consultatif du 19 juillet 2024, affaire 186**]{#ref-B38c} — Source institutionnelle. [Consulter la source](https://www.icj-cij.org/case/186).

[**([B38d](#ref-B38d)) ONU — Briefing du coordinateur spécial par intérim au Conseil de sécurité, 26 août 2026**]{#ref-B38d} — Source institutionnelle. [Consulter la source](https://www.un.org/unispal/document/gazas-recovery-and-reconstruction-and-the-broader-political-process-are-mutually-dependent-un-acting-special-coordinator-for-the-middle-east-peace-process-briefs-the-security-council/).

[**([B39](#ref-B39)) Résolutions 678 et 687, guerre de 1991 — appui dans la ressource T02**]{#ref-B39} — Renvoi thématique à un accompagnement officiel. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra22lycee-gthggsptheme-2faire-la-guerre-et-faire-la-paix-93786.pdf). Le code désigne un point d’appui de la ressource Éduscol, pas une édition intégrale d’un ouvrage original. Voir le jalon correspondant.

[**([B39a](#ref-B39a)) Conseil de sécurité — Répertoire des pratiques, 2000–2003, chapitre XII**]{#ref-B39a} — Source institutionnelle. [Consulter la source](https://www.un.org/fr/sc/repertoire/00-03/00-03_12.pdf).

[**([B40](#ref-B40)) Controverse sur les responsabilités de 1914 : Fischer et Clark — appui dans la ressource T03**]{#ref-B40} — Renvoi thématique à un accompagnement officiel. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra22lycee-gthggsphistoire-et-memoires-93783.pdf). Le code désigne un point d’appui de la ressource Éduscol, pas une édition intégrale d’un ouvrage original. Voir le jalon correspondant.

[**([B40a](#ref-B40a)) Traité de Versailles et responsabilité — appui dans la ressource T03**]{#ref-B40a} — Renvoi thématique à un accompagnement officiel. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra22lycee-gthggsphistoire-et-memoires-93783.pdf). Le code désigne un point d’appui de la ressource Éduscol, pas une édition intégrale d’un ouvrage original. Voir le jalon correspondant.

[**([B41](#ref-B41)) Histoire et mémoires de la guerre d’Algérie — appui dans la ressource T03**]{#ref-B41} — Renvoi thématique à un accompagnement officiel. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra22lycee-gthggsphistoire-et-memoires-93783.pdf). Le code désigne un point d’appui de la ressource Éduscol, pas une édition intégrale d’un ouvrage original. Voir le jalon correspondant.

[**([B41a](#ref-B41a)) Loi du 18 octobre 1999 — Reconnaissance de la guerre d’Algérie**]{#ref-B41a} — Source institutionnelle. [Consulter la source](https://www.legifrance.gouv.fr/loda/id/JORFTEXT000000578132).

[**([B42](#ref-B42)) Rwanda : gacaca et justice après le génocide — appui dans la ressource T03**]{#ref-B42} — Renvoi thématique à un accompagnement officiel. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra22lycee-gthggsphistoire-et-memoires-93783.pdf). Le code désigne un point d’appui de la ressource Éduscol, pas une édition intégrale d’un ouvrage original. Voir le jalon correspondant.

[**([B43](#ref-B43)) TPIY : justice internationale et responsabilités — appui dans la ressource T03**]{#ref-B43} — Renvoi thématique à un accompagnement officiel. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra22lycee-gthggsphistoire-et-memoires-93783.pdf). Le code désigne un point d’appui de la ressource Éduscol, pas une édition intégrale d’un ouvrage original. Voir le jalon correspondant.

[**([B44](#ref-B44)) United States Holocaust Memorial Museum — Génocide des Roms européens, 1939–1945**]{#ref-B44} — Source institutionnelle. [Consulter la source](https://encyclopedia.ushmm.org/content/en/article/genocide-of-european-roma-gypsies-1939-1945).

[**([B44a](#ref-B44a)) Lieux de mémoire des génocides — appui dans la ressource T03**]{#ref-B44a} — Renvoi thématique à un accompagnement officiel. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra22lycee-gthggsphistoire-et-memoires-93783.pdf). Le code désigne un point d’appui de la ressource Éduscol, pas une édition intégrale d’un ouvrage original. Voir le jalon correspondant.

[**([B45](#ref-B45)) Procès après Nuremberg — appui dans la ressource T03**]{#ref-B45} — Renvoi thématique à un accompagnement officiel. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra22lycee-gthggsphistoire-et-memoires-93783.pdf). Le code désigne un point d’appui de la ressource Éduscol, pas une édition intégrale d’un ouvrage original. Voir le jalon correspondant.

[**([B46](#ref-B46)) Littérature, cinéma et transmission — appui dans la ressource T03**]{#ref-B46} — Renvoi thématique à un accompagnement officiel. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra22lycee-gthggsphistoire-et-memoires-93783.pdf). Le code désigne un point d’appui de la ressource Éduscol, pas une édition intégrale d’un ouvrage original. Voir le jalon correspondant.

[**([B47](#ref-B47)) Château de Versailles — Inauguration des galeries historiques**]{#ref-B47} — Source institutionnelle. [Consulter la source](https://www.chateauversailles.fr/decouvrir/histoire/les-grandes-dates/inauguration-galeries-historiques).

[**([B47a](#ref-B47a)) Versailles, 1871, 1919 et usages républicains — appui dans la ressource T04**]{#ref-B47a} — Renvoi thématique à un accompagnement officiel. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra25lyceegthggspidentifierprotegervaloriserpatrimoine-enjeuxgeopolitiques0pdf-121241.pdf). Le code désigne un point d’appui de la ressource Éduscol, pas une édition intégrale d’un ouvrage original. Voir le jalon correspondant.

[**([B48](#ref-B48)) British Museum — Position institutionnelle sur les sculptures du Parthénon**]{#ref-B48} — Source institutionnelle. [Consulter la source](https://www.britishmuseum.org/about-us/british-museum-story/contested-objects-collection/parthenon-sculptures). Position d’une partie à la controverse ; ne vaut pas arbitrage neutre de la propriété.

[**([B48a](#ref-B48a)) Musée de l’Acropole — Galerie du Parthénon**]{#ref-B48a} — Source institutionnelle. [Consulter la source](https://www.theacropolismuseum.gr/en/exhibit-halls/parthenon-gallery). Présentation institutionnelle de la muséographie ; pour la revendication, déclaration de réunification du 24 mars 2023.

[**([B49](#ref-B49)) UNESCO — Paris, rives de la Seine**]{#ref-B49} — Source institutionnelle. [Consulter la source](https://whc.unesco.org/en/list/600/).

[**([B50](#ref-B50)) UNESCO — Sauvegarde du patrimoine de Tombouctou**]{#ref-B50} — Source institutionnelle. [Consulter la source](https://whc.unesco.org/en/canopy/timbuktu/).

[**([B50a](#ref-B50a)) CPI — Affaire Al Mahdi**]{#ref-B50a} — Source institutionnelle. [Consulter la source](https://www.icc-cpi.int/mali/al-mahdi).

[**([B51](#ref-B51)) UNESCO — Venise et sa lagune**]{#ref-B51} — Source institutionnelle. [Consulter la source](https://whc.unesco.org/en/list/394/).

[**([B52](#ref-B52)) Ministère de la Culture — Grandes dates des monuments historiques**]{#ref-B52} — Source institutionnelle. [Consulter la source](https://www.culture.gouv.fr/thematiques/monuments-sites/monuments-historiques-sites-patrimoniaux/un-peu-d-histoire/les-grandes-dates-des-monuments-historiques).

[**([B53](#ref-B53)) UNESCO — Bassin minier du Nord-Pas-de-Calais**]{#ref-B53} — Source institutionnelle. [Consulter la source](https://whc.unesco.org/en/list/1360/).

[**([B54](#ref-B54)) UNESCO — Repas gastronomique des Français, inscription 2010**]{#ref-B54} — Source institutionnelle. [Consulter la source](https://ich.unesco.org/en/RL/gastronomic-meal-of-the-french-00437).

[**([B55](#ref-B55)) ONF — Ordonnance de Colbert de 1669 et forêt de Tronçais**]{#ref-B55} — Source institutionnelle. [Consulter la source](https://www.onf.fr/onf/%2B/ff6%3A%3Ala-grande-histoire-des-forets-episode-ordonnance-de-colbert-en-1669-la-gestion-forestiere-en-foret-de-troncais.html).

[**([B55a](#ref-B55a)) ONF — Histoire des forêts**]{#ref-B55a} — Source institutionnelle. [Consulter la source](https://www.onf.fr/vivre-la-foret/fonctionnement-gestion-foret/histoire-des-forets).

[**([B56](#ref-B56)) Inrap — Le Néolithique**]{#ref-B56} — Source institutionnelle. [Consulter la source](https://www.inrap.fr/periodes/neolithique).

[**([B56a](#ref-B56a)) Industrialisation, énergie et transformations des milieux — appui dans la ressource T05**]{#ref-B56a} — Renvoi thématique à un accompagnement officiel. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra23lyceegthggspenvironnementexploitationprotectionenjeupdf-102786.pdf). Le code désigne un point d’appui de la ressource Éduscol, pas une édition intégrale d’un ouvrage original. Voir le jalon correspondant.

[**([B57](#ref-B57)) Collège de France — Petit Âge glaciaire et passage à la modernité**]{#ref-B57} — Source institutionnelle. [Consulter la source](https://www.college-de-france.fr/fr/agenda/cours/histoire-societe-climat-entre-fragilite-et-resilience/le-petit-age-glaciaire-et-le-passage-la-modernite).

[**([B58](#ref-B58)) Stockholm, Rio et Kyoto — appui dans la ressource T05**]{#ref-B58} — Renvoi thématique à un accompagnement officiel. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra23lyceegthggspenvironnementexploitationprotectionenjeupdf-102786.pdf). Le code désigne un point d’appui de la ressource Éduscol, pas une édition intégrale d’un ouvrage original. Voir le jalon correspondant.

[**([B58a](#ref-B58a)) CCNUCC — Contributions déterminées au niveau national**]{#ref-B58a} — Source institutionnelle. [Consulter la source](https://unfccc.int/process-and-meetings/the-paris-agreement/nationally-determined-contributions-ndcs).

[**([B59](#ref-B59)) National Park Service — Histoire et interprétation des parcs**]{#ref-B59} — Source institutionnelle. [Consulter la source](https://www.nps.gov/articles/history-under-construction.htm).

[**([B59a](#ref-B59a)) USDA — Conservation versus preservation**]{#ref-B59a} — Source institutionnelle. [Consulter la source](https://www.usda.gov/about-usda/news/blog/conservation-versus-preservation).

[**([B59b](#ref-B59b)) L’action fédérale américaine et l’EPA — appui dans la ressource T05**]{#ref-B59b} — Renvoi thématique à un accompagnement officiel. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra23lyceegthggspenvironnementexploitationprotectionenjeupdf-102786.pdf). Le code désigne un point d’appui de la ressource Éduscol, pas une édition intégrale d’un ouvrage original. Voir le jalon correspondant.

[**([B60](#ref-B60)) Pluralité des acteurs environnementaux américains — appui dans la ressource T05**]{#ref-B60} — Renvoi thématique à un accompagnement officiel. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra23lyceegthggspenvironnementexploitationprotectionenjeupdf-102786.pdf). Le code désigne un point d’appui de la ressource Éduscol, pas une édition intégrale d’un ouvrage original. Voir le jalon correspondant.

[**([B61](#ref-B61)) Société de la connaissance : définition et enjeux — appui dans la ressource T06**]{#ref-B61} — Renvoi thématique à un accompagnement officiel. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra24lyceegthggspenjeuxconnaissancepdf-104487.pdf). Le code désigne un point d’appui de la ressource Éduscol, pas une édition intégrale d’un ouvrage original. Voir le jalon correspondant.

[**([B62](#ref-B62)) Histoire de l’alphabétisation des femmes — appui dans la ressource T06**]{#ref-B62} — Renvoi thématique à un accompagnement officiel. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra24lyceegthggspenjeuxconnaissancepdf-104487.pdf). Le code désigne un point d’appui de la ressource Éduscol, pas une édition intégrale d’un ouvrage original. Voir le jalon correspondant.

[**([B62a](#ref-B62a)) Sénat — Loi du 21 décembre 1880 sur l’enseignement secondaire des jeunes filles**]{#ref-B62a} — Source institutionnelle. [Consulter la source](https://www.senat.fr/connaitre-le-senat/lhistoire-du-senat/dossiers-dhistoire/les-lois-scolaires-de-jules-ferry/les-lois-scolaires-de-jules-ferry-la-loi-du-21-decembre-1880-sur-lenseignement-secondaire-des-jeunes-filles.html).

[**([B63](#ref-B63)) Musée Curie — Chronologie de Pierre et Marie Curie**]{#ref-B63} — Source institutionnelle. [Consulter la source](https://musee.curie.fr/decouvrir/la-famille-curie/pierre-et-marie-curie-chronologie).

[**([B63a](#ref-B63a)) Communautés scientifiques et découvertes — appui dans la ressource T06**]{#ref-B63a} — Renvoi thématique à un accompagnement officiel. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra24lyceegthggspenjeuxconnaissancepdf-104487.pdf). Le code désigne un point d’appui de la ressource Éduscol, pas une édition intégrale d’un ouvrage original. Voir le jalon correspondant.

[**([B63b](#ref-B63b)) Fission nucléaire et applications stratégiques — appui dans la ressource T06**]{#ref-B63b} — Renvoi thématique à un accompagnement officiel. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra24lyceegthggspenjeuxconnaissancepdf-104487.pdf). Le code désigne un point d’appui de la ressource Éduscol, pas une édition intégrale d’un ouvrage original. Voir le jalon correspondant.

[**([B64](#ref-B64)) Office of the Historian — Crise des missiles de Cuba, 1962**]{#ref-B64} — Source institutionnelle. [Consulter la source](https://history.state.gov/milestones/1961-1968/cuban-missile-crisis).

[**([B65](#ref-B65)) NSF/NCSES — Immigration and the science and engineering workforce, 2019**]{#ref-B65} — Source institutionnelle. [Consulter la source](https://ncses.nsf.gov/pubs/nsb20198/immigration-and-the-s-e-workforce).

[**([B65a](#ref-B65a)) NSF — Arrangement de coopération États-Unis–Inde, annonce du 1er février 2023**]{#ref-B65a} — Source institutionnelle. [Consulter la source](https://www.nsf.gov/news/nsf-signs-us-india-implementation-arrangement-streamline). Page archivée : exemple historique de 2023, non affirmation de la politique actuelle. Date corrigée après réouverture de la source.

[**([B66](#ref-B66)) Cyberespace : couches, acteurs et dépendances — appui dans la ressource T06**]{#ref-B66} — Renvoi thématique à un accompagnement officiel. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra24lyceegthggspenjeuxconnaissancepdf-104487.pdf). Le code désigne un point d’appui de la ressource Éduscol, pas une édition intégrale d’un ouvrage original. Voir le jalon correspondant.

## Droits, adaptations et limites

Les textes historiques du domaine public et les actes officiels sont identifiés ; les autres ressources ne sont pas reproduites intégralement. Les synthèses, tableaux, exercices et schémas nouveaux sont des créations éditoriales de cette édition. Aucun fichier de police n’est livré. Les textes du kit et les fragments récupérés restent conservés séparément avec leurs empreintes ; les nouveaux développements ne sont pas présentés comme le manuscrit ancien retrouvé.

Les vérifications effectuées portent sur la couverture, les correspondances, les points réglementaires, les données explicites et la fabrication. Elles ne constituent pas une relecture disciplinaire indépendante de l’ensemble de l’ouvrage. Le registre JSON précise les accès protégés et les renvois documentaires indirects.
