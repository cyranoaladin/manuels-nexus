---
title: "HGGSP — Autocorrection"
subtitle: "Compagnon du manuel · Comprendre, corriger, reprendre"
author: "Nexus Réussite — Collection Manuels scolaires"
date: "Session 2027 · Édition pédagogique 1.0 · 8 septembre 2026"
lang: "fr-FR"
---

# Utiliser l’autocorrection

Rédigez d’abord votre réponse, même incomplète. Comparez ensuite la démarche, les faits mobilisés et la conclusion. Une formulation différente peut être recevable si elle respecte le sujet et les sources ; un plan proposé n’est pas un plan obligatoire. Notez une erreur précise, réalisez la remédiation indiquée, puis le nouveau test sans le corrigé.

Les identifiants du manuel sont conservés. Toutes les corrections du corpus avancé sont une rédaction nouvelle de cette édition. Les énoncés récupérés sont identifiés dans les sources JSON. Les corrigés du module 00 viennent du kit fondateur, avec adaptation des identifiants. Les corrigés des neuf épreuves blanches sont dans un volume distinct.

# Entrer en HGGSP — Autocorrection du module 00

Module fondateur conservé ; identifiants préfixés « 00- » pour éviter les collisions avec ceux du manuel.

## Autocorrection — Module 00

**Entrer en HGGSP — compagnon du candidat**

**À OUVRIR APRÈS AVOIR ÉCRIT**

Une correction sert à comprendre la différence entre votre raisonnement et une réponse recevable. Lire un modèle ne suffit pas : reprenez ensuite une tâche, sans regarder ce modèle.

### Comment utiliser ce compagnon

Comparez la demande avec votre réponse. Repérez ce qui est exact avant de chercher ce qui manque. Choisissez une erreur prioritaire : datation, nature de source, causalité, proportion ou argumentation. Reprenez la fiche correspondante et répondez à une question nouvelle.

Les formulations proposées ne sont pas toutes exclusives. Une réponse différente est recevable si elle respecte les documents, explique les liens et ne prétend pas en savoir plus que les sources. Les mini-grilles sont des outils pédagogiques, pas des barèmes ministériels.

| Erreur dominante | Reprise |
| --- | --- |
| Date de consultation prise pour date du texte | 00-R1 et lecture guidée du document A. |
| Succession présentée comme cause certaine | 00-R2 et 00-E6. |
| Pourcentage appliqué à la mauvaise population | 00-R3 et 00-E7. |
| Règle assimilée à une application effective | 00-R4 et 00-E4–00-E5. |
| Opinion non appuyée ou juxtaposition de pièces | 00-M08 et 00-E8–00-E10. |

Nexus Réussite • 8 septembre 2026. Les exercices sont originaux. Les réponses portant sur des cas fictifs ne décrivent aucun territoire réel.

## Diagnostic — réponses et orientation

| Item | Réponse expliquée | Reprise |
| --- | --- | --- |
| 00-D1 | 1648, puis 1789, puis 1992. L’ordre se détermine ici directement par les années. | 00-R1 |
| 00-D2 | 1789 contextualise la production du texte. Légifrance en diffuse une transcription consultée en 2026. Il faut distinguer auteur et support de diffusion. | 00-R1 |
| 00-D3 | Non. La succession temporelle ne suffit pas à démontrer une cause ; il faut un mécanisme et des éléments complémentaires. | 00-R2 |
| 00-D4 | Non. 80 % des réponses sont favorables. Sans méthode garantissant la représentativité, la proportion ne décrit pas tous les habitants. | 00-R3 |
| 00-D5 | Non. Le règlement exprime une norme. Son application demande d’autres sources, par exemple des décisions ou observations. | 00-R4 |
| 00-D6 | Non. Vérifier origine, date, contexte ou recoupement. Le nombre de partages mesure une circulation, pas l’exactitude. | 00-R4 |
| 00-D7 | Commune, État, monde. Une question peut articuler plusieurs de ces échelles. | 00-R3 |
| 00-D8 | Il s’agit d’un jugement. Il faut préciser des critères, apporter des informations et expliquer le lien entre celles-ci et l’appréciation. | 00-R2 |

Une réponse brève mais justifiée vaut mieux qu’une affirmation longue sans contrôle. Pour les items 00-D3 à 00-D6, un simple « non » repère la direction mais ne prouve pas encore la compréhension de la limite.

**NOUVEL ESSAI**

Sans relire le tableau, expliquez la différence entre une source et sa publication numérique, puis entre une proportion de répondants et une proportion de population. Si vous hésitez, reprenez seulement les lignes utiles avant de retenter.

## 00-E1 à 00-E3 — Identifier et articuler les approches

### 00-E1 — Les quatre questions

**a : histoire.** La question porte principalement sur l’évolution de la fonction du port dans le temps.
**b : géographie.** Elle demande une localisation et une relation entre espaces.
**c : géopolitique.** Elle examine une négociation et une rivalité d’acteurs autour d’un contrôle.
**d : sciences politiques.** Elle porte sur l’autorité de décision et la participation.

Il ne s’agit pas de frontières étanches : la négociation peut aussi être éclairée par les institutions, et l’organisation spatiale par son histoire. Pour réussir, il faut identifier ce qui domine dans chaque question, puis expliquer une articulation utile.

### 00-E2 — Une question possible

« Comment les intérêts territoriaux des deux communes influencent-ils les modalités de la décision sur le port ? » La question combine une analyse des acteurs et des territoires avec celle de la décision. Elle est plus précise qu’un avis personnel sur le projet.

Autre réponse possible : « Comment l’évolution historique des activités du port a-t-elle modifié l’organisation des quartiers voisins ? » Elle articule histoire et géographie. Aucun fait supplémentaire ne doit être inventé : ce sont des questions de recherche.

### 00-E3 — Deux phrases recevables

« Les communes et l’association sont des acteurs, mais leurs objectifs ne sont pas identiques. »
« La décision s’analyse à l’échelle locale, tandis que l’étude des flux peut conduire à examiner des espaces plus larges. »

**ERREUR FRÉQUENTE**

Associer « géopolitique » seulement à la guerre ou « histoire » seulement à une date. Une approche se reconnaît par la question et le raisonnement, non par un mot isolé.

## 00-E4 et 00-E5 — Le document de 1789

### 00-E4 — Présenter, expliquer, limiter

**1.** Il s’agit de l’article 16 de la Déclaration des droits de l’homme et du citoyen, adoptée en août 1789 par l’Assemblée nationale, ici consultée dans une transcription diffusée par Légifrance. ([S10](#ref-S10))

**2.** Le texte exige la protection des droits et une organisation distinguant les pouvoirs. La réponse doit retrouver les deux exigences, sans remplacer l’une d’elles par la seule présence d’élections.

**3.** Le document énonce un principe permettant de définir ce qu’une constitution doit garantir. Il ne présente pas un compte rendu d’application ni une enquête.

**4.** La conclusion du candidat est excessive. On peut établir ce que le texte affirme ; on ne peut pas déduire de cette affirmation que les pratiques de toute une société s’y conforment aussitôt.

**5.** Des décisions, des archives de mise en œuvre, des pratiques institutionnelles documentées ou des travaux d’historiens reposant sur ces pièces peuvent éclairer l’application. Il faut préciser quelle exigence l’on souhaite examiner.

### 00-E5 — Trois fonctions distinctes

| Fonction | Exemple de formulation |
| --- | --- |
| Information | Le texte associe la constitution à deux exigences concernant droits et pouvoirs. |
| Explication | Il fixe un critère normatif d’organisation politique plutôt qu’un simple nom donné à un régime. |
| Limite | Cet article ne permet pas, seul, de décrire l’application des principes dans toutes les situations de l’époque. |

L’exercice demande une analyse du document, pas un récit intégral de la Révolution française. Une connaissance extérieure exacte peut éclairer le texte ; elle ne doit pas remplacer son étude.

Document réel : S10. Le module ne tire de cet article aucun diagnostic juridique sur une situation actuelle.

## 00-E6 à 00-E9 — Argumenter sur le dossier Rivage

### 00-E6 — Réparer les deux généralisations

Deux sauts : consulter ne suffit pas à qualifier toute la décision de démocratique ; pouvoir répondre ne signifie pas approuver. **Réécriture possible en quatre phrases :** Une consultation permet aux personnes qui y ont accès d’exprimer un avis. Elle ne prouve pas, à elle seule, l’accord de tous les habitants. Il faudrait connaître les conditions d’accès, les réponses et leur traitement. Pour apprécier la décision, il faudrait aussi examiner la pluralité de l’information, les droits et la prise en compte des avis.

### 00-E7 — Réponses précises

**1.** F1 est un communiqué favorable au projet ; F2 une note décrivant un recueil de réponses ; F3 un compte rendu d’association exprimant des réserves.
**2.** Les emplois sont annoncés comme une possibilité, non comme des emplois déjà créés.
**3.** 156 ÷ 200 = 0,78 : **78 % des réponses enregistrées** sont favorables.
**4.** La représentativité, l’absence de réponses multiples et le profil des répondants ne sont pas établis ; on ne connaît pas non plus la population totale.

### 00-E8 — Une réponse possible

Les pièces montrent un soutien important parmi les réponses enregistrées, mais elles n’établissent pas l’adhésion de tous les habitants. La note F2 compte 156 réponses favorables sur 200, soit 78 %. Le caractère volontaire du questionnaire et l’absence d’informations sur les doublons limitent cependant la portée de ce résultat. Le communiqué F1 utilise ce soutien pour défendre l’extension et évoque des emplois possibles : il ne démontre pas leur création. Enfin, F3 rend visibles des enjeux environnementaux et demande une comparaison des solutions. Ce compte rendu ne constitue pas, à lui seul, une étude d’impact. Ainsi, les documents permettent d’identifier des positions et un résultat de consultation, mais pas de trancher tous les effets du projet. Des pièces sur le recueil des réponses, les emplois et l’environnement seraient nécessaires.

### 00-E9 — Discuter les statuts

L’origine municipale n’implique pas la neutralité : F1 défend une position. L’origine associative ne rend pas F3 inutilisable : la pièce renseigne sur une demande et des réserves, dont l’expertise reste à examiner. Une enquête correctement documentée et un rapport technique d’impact apporteraient des informations de nature différente.

Une position identifiée n’est pas une preuve de mensonge. Ne pas attribuer d’intention dissimulée sans élément.

## 00-E10, 00-E11 et fiches de reprise

### 00-E10 — Problématique et plan possibles

**Problématique.** À quelles conditions la participation à une consultation éclaire-t-elle le caractère démocratique d’une décision, et quelles informations supplémentaires sont nécessaires ?

**I.** Une consultation peut ouvrir une possibilité d’expression et renseigner sur les avis recueillis.
**II.** Sa portée dépend des conditions d’accès, de la pluralité de l’information et du traitement des réponses.
**III, si utile.** L’évaluation de la décision exige aussi d’examiner les institutions, les droits et la manière dont les résultats sont pris en compte.

Un plan en deux parties regroupant les limites est recevable. En revanche, « I. La mairie ; II. L’association » juxtapose des acteurs sans nécessairement répondre à la question.

### 00-E11 — Fiche de document

Origine : Déclaration adoptée par l’Assemblée nationale. Date : 1789. Apport : critère normatif associant droits et organisation des pouvoirs. Limite : ne décrit pas à lui seul les pratiques. Question de rappel : « Pourquoi ce texte ne suffit-il pas à prouver son application ? » ([S10](#ref-S10))

### 00-R1 et 00-R2

**00-R1.** 1950 est la date des propos ; 1951 et 2020 décrivent leur publication et leur transmission. **00-R2.** Examiner notamment l’évolution du commerce, d’autres équipements, les tarifs ou la période de mesure ; chercher un mécanisme précis reliant la route à la hausse. Pour la réforme, remplacer « bonne » et « moderne » par un objectif défini, par exemple une réduction d’un délai, et demander des mesures comparables.

### 00-R3 et 00-R4

**00-R3.** 45 ÷ 60 = 75 % des réponses. « 75 % de tous les habitants » serait abusif sans information supplémentaire. **00-R4.** Ni la charte ni les dates de réunions ne prouvent un accès effectif pour tous. Un registre d’accès, des modalités publiées ou une observation documentée apporteraient des éléments utiles.

Les exemples de sources complémentaires doivent être évalués selon leur pertinence : proposer « un autre site » sans dire quelle information on cherche ne suffit pas.

## Bilan A — Correction et grille de travail

**A1.** La charte pose une règle. Le communiqué affirme une transparence totale. La note donne un décompte de comptes rendus publiés. **A2.** 24 ÷ 30 = 80 % des comptes rendus prévus ont été publiés.

**A3.** La note établit une publication partielle selon son décompte. Elle ne renseigne pas sur la complétude des comptes rendus, la facilité d’accès ou les autres formes de transparence ; elle ne permet pas non plus d’inventer les raisons des six absences.

### A4 — Un paragraphe possible

Les pièces ne suffisent pas à établir une transparence totale. La charte énonce une obligation de publicité, mais cette règle doit être distinguée de sa mise en œuvre. La note indique que 24 comptes rendus sur 30 prévus ont été publiés, soit 80 % : la publication n’est donc pas exhaustive selon le périmètre annoncé. De plus, la note ne décrit ni la qualité des informations ni leur accessibilité. Le communiqué présente une appréciation favorable que les pièces disponibles ne démontrent pas. Il faudrait examiner les comptes rendus, les modalités d’accès et les motifs des absences pour préciser l’analyse.

**A5.** Un registre de publication documenté ou les pièces elles-mêmes seraient utiles. Question de sciences politiques possible : « Quels mécanismes permettent aux habitants de demander des comptes sur la mise en œuvre de la règle ? »

| Critère pédagogique | À vérifier dans la copie |
| --- | --- |
| Nature des informations | La règle, l’affirmation et la donnée sont distinguées. |
| Donnée | Le pourcentage et son dénominateur sont corrects. |
| Raisonnement | Une pièce précise soutient chaque idée importante. |
| Limites | La conclusion ne dépasse pas le dossier. |
| Vérification | Le document supplémentaire répond à une lacune identifiée. |

Pour un suivi chiffré local, on peut attribuer 0, 1 ou 2 par critère. Ce score /10 est une proposition de diagnostic, non un barème national ni une conversion automatique en note de baccalauréat.

## Bilan B — Correction et revalidation

**B1.** Le règlement établit une règle ; le service municipal formule une affirmation ; le registre fournit un nombre de dossiers disponibles. **B2.** 21 ÷ 28 = 75 % des dossiers ont été disponibles avant la réunion.

**B3.** Sur le périmètre fourni, sept dossiers ne l’étaient pas. Les données ne soutiennent donc pas l’affirmation d’une disponibilité toujours intégrale. Elles n’expliquent ni les causes des absences ni la bonne ou mauvaise foi du service.

### B4 — Un paragraphe possible

L’information n’apparaît pas toujours intégralement disponible au regard du registre fourni. Celui-ci recense 21 dossiers disponibles avant réunion sur 28 examinés, soit 75 %. Le règlement décrit une exigence, mais le décompte montre qu’elle n’a pas été remplie pour tous les dossiers de cette série. Il existe donc un écart avec l’affirmation générale du service. En revanche, le registre n’indique ni les raisons des manques ni le nombre de personnes ayant consulté les pièces. Pour préciser l’analyse, il faudrait examiner les dates et conditions de publication ainsi que les dossiers concernés.

**B5.** Vérification : contrôler les dates de mise à disposition de chaque dossier. Question de géographie possible : « Les lieux et les moyens d’accès à ces informations sont-ils également disponibles dans les différents quartiers ? »

### Quand considérer la méthode comme acquise ?

Vous pouvez expliquer spontanément la différence entre règle et pratique, utiliser une donnée avec son dénominateur, formuler une conclusion limitée et choisir un complément pertinent. Il faut pouvoir le refaire sur un document différent, pas seulement retrouver les phrases de ce compagnon.

**RETOUR À L’APPRENTISSAGE**

Si l’un de ces gestes reste fragile, reprenez la fiche ciblée et écrivez un nouvel exemple. Si le bilan B est réussi sans aide, passez au premier thème ; gardez toutefois une réactivation de 00-M04 et 00-M08 dans les semaines suivantes.

Sources du document réel et des épreuves : registre du module élève. Tous les dossiers de ces bilans sont fictifs et conçus pour un apprentissage méthodologique.

# P01 — Corriger et progresser {#corr-P01}

## P01-D — Diagnostic : réponses et orientation

Un gouvernement élu peut restreindre les libertés ou affaiblir les contre-pouvoirs : l’élection ne garantit pas toute décision. Une monarchie constitutionnelle peut être démocratique lorsque les institutions, les droits et l’alternance le permettent. Choisir un représentant lui confie un mandat ; voter directement une loi est une participation à la décision elle-même. Ne confondez ni monarchie/république et démocratie/dictature, ni source élective et exercice libéral du pouvoir. Si les deux premières distinctions manquent, reprendre l’introduction ; si la troisième manque, reprendre l’axe 1.

## P01-A — Activité du cours : éléments de correction

Le Portugal, l’Espagne et le Chili ne suivent pas un chemin identique. Au Portugal, le 25 avril 1974 ouvre une rupture militaire et politique, suivie de conflits sur l’orientation du régime. En Espagne, la transition après 1975 combine transformations institutionnelles et compromis, dans un contexte de tensions. Au Chili, le coup d’État de 1973 montre une rupture antidémocratique ; la sortie de dictature passe notamment par le plébiscite de 1988 et le retour d’un gouvernement civil en 1990. Comparer consiste à examiner acteurs, rythmes et garanties, non à faire de l’un des pays la copie des autres. Dans les 150 mots demandés, deux différences et un mécanisme commun suffisent si chaque exemple est situé.

## Exercices : démarches, réponses et critères

### P01-E1 — Distinguer les régimes {#corr-P01-E1}

A est compatible avec une démocratie représentative : un monarque peut avoir des fonctions limitées tandis que le gouvernement est responsable devant des représentants élus. Il faut encore vérifier la réalité du pluralisme, les libertés et l’État de droit. B n’est pas démocratique du seul fait d’être une république : le parti unique supprime normalement une compétition pluraliste effective. C décrit un mécanisme de démocratie directe, non une preuve d’universalité des droits.

Les informations manquantes concernent la définition des citoyens, l’accès effectif au vote, la possibilité d’opposition, les libertés d’expression et d’association, le contrôle du pouvoir et l’indépendance de la justice. Le classement porte donc sur des indices, avec une conclusion proportionnée. Une réponse qui nomme A « monarchie » sans analyser le gouvernement manque l’enjeu ; une réponse qui appelle C « démocratie parfaite » oublie les exclusions.

**Critères observables.** Classer les trois situations ; distinguer forme du régime et garanties ; formuler au moins trois vérifications pertinentes.

**Reprise ciblée.** R2 : reprendre la distinction démocratie directe/représentative et majorité/État de droit.

### P01-E2 — Athènes et les limites du peuple politique {#corr-P01-E2}

La démocratie athénienne du Ve siècle avant notre ère organise une participation directe des citoyens, notamment à l’Ecclésia. Les citoyens réunis peuvent débattre et voter certaines décisions au lieu de confier toute l’activité politique à des représentants. Mais le peuple politique ne comprend pas tous les habitants de la cité. Les femmes, les métèques — étrangers résidents — et les esclaves sont exclus de cette citoyenneté politique. Les conditions de participation effective varient aussi selon les ressources et les activités des citoyens.

La participation est donc directe sans être universelle. Ce constat ne conduit ni à effacer l’innovation institutionnelle athénienne ni à présenter Athènes comme l’équivalent d’une démocratie contemporaine. Il faut comparer les critères : mode de décision d’une part, extension des droits d’autre part. Les quatre mots imposés sont utiles lorsqu’ils servent cette distinction, non lorsqu’ils sont simplement placés dans une liste.

**Critères observables.** Situer Athènes ; expliquer Ecclésia et métèque ; identifier les exclusions ; conclure sur deux critères distincts.

**Reprise ciblée.** R2 puis R3 : définir les mots, puis réécrire la relation entre participation et citoyenneté.

### P01-E3 — Lire une règle de représentation {#corr-P01-E3}

Le document est une synthèse éditoriale d’un texte juridique, l’article 10 du traité sur l’Union européenne. Il n’est ni un sondage ni une description exhaustive des pratiques politiques. La source sous-jacente fixe les principes du fonctionnement représentatif de l’Union.

Deux circuits se complètent. Les citoyens sont directement représentés au Parlement européen, dont les membres sont élus. Les États sont représentés au Conseil européen par leurs dirigeants et au Conseil par leurs gouvernements. La responsabilité démocratique de ces derniers s’inscrit dans les systèmes nationaux. Une décision européenne articule donc des légitimités de niveaux différents ; elle ne relève pas exclusivement d’une élection unique à l’échelle du continent.

Le texte permet d’expliquer une architecture institutionnelle, mais il ne mesure pas le sentiment des citoyens à son égard. Pour étudier la satisfaction, la confiance ou la participation, il faudrait des enquêtes et des données électorales datées, avec leur méthode et leur champ. La distinction entre norme et expérience ne signifie pas que la norme serait sans effet : elle évite de déduire mécaniquement une démocratie vécue du seul énoncé d’un principe. Une autre organisation est recevable si elle conserve ces deux circuits et cette limite.

**Critères observables.** Nature normative ; deux circuits exacts ; différence Conseil/Conseil européen/Parlement ; limite de portée explicitée.

**Reprise ciblée.** R4 : ajouter à chaque élément du texte une explication ou une limite, sans le recopier.

### P01-E4 — Comparer deux transitions {#corr-P01-E4}

Portugal : régime autoritaire de l’Estado Novo ; rupture du 25 avril 1974 menée par le Mouvement des forces armées ; phase de conflits et d’expérimentations ; rôle de l’armée, des partis et des mobilisations ; Constitution de 1976 et installation d’institutions représentatives. Espagne : dictature franquiste ; mort de Franco en 1975 ; rôle de Juan Carlos, d’Adolfo Suárez, de l’opposition et des mobilisations ; réformes, élections de 1977, Constitution de 1978 ; échec du coup de force de 1981 et alternance de 1982.

La disparition du dictateur peut ouvrir une possibilité, mais les institutions, les forces armées, les intérêts et les habitudes du régime subsistent. Une démocratie exige des garanties, une compétition politique, des règles acceptées et une pratique de l’alternance. Les acteurs peuvent diverger sur le rythme et les modalités. La comparaison oppose donc des trajectoires, pas une transition « facile » et une transition « difficile » sans critères. Les deux cas montrent que la consolidation est un processus, non le simple lendemain d’un événement.

**Critères observables.** Critères communs ; repères justes ; acteurs distingués ; explication des étapes et des incertitudes.

**Reprise ciblée.** R1 : refaire les deux chronologies ; R3 : expliquer ce que change chaque étape.

### P01-E5 — Corriger une copie {#corr-P01-E5}

Tocqueville ne dit pas que la majorité a toujours raison : il s’inquiète notamment de la pression qu’elle peut exercer sur les opinions et les minorités. La démocratie a besoin de contre-pouvoirs et de libertés. Constant ne propose pas de supprimer toute participation : il défend la représentation et les libertés individuelles tout en maintenant la nécessité d’une vigilance civique. Enfin, l’élection d’Allende en 1970 ne rend pas le régime chilien irréversible ; les tensions politiques, sociales et internationales et l’intervention militaire aboutissent au coup d’État du 11 septembre 1973.

L’idée commune est que les institutions démocratiques ne se maintiennent pas par leur seul nom ou par un événement électoral. Elles dépendent de garanties, de pratiques et de rapports de force. La correction doit conserver les différences entre une réflexion théorique sur les risques et l’histoire d’une rupture effective : Tocqueville n’explique pas directement, à lui seul, le Chili.

**Critères observables.** Trois erreurs corrigées avec contenu positif ; idée commune ; théorie et événement non confondus.

**Reprise ciblée.** R2 pour les notions, puis R3 pour la phrase de synthèse.

### P01-E6 — Passer du thème au problème {#corr-P01-E6}

Problématique possible : comment l’Union combine-t-elle des légitimités démocratiques nationales et européennes, et quelles tensions cette articulation produit-elle ?

I. Une représentation organisée à plusieurs échelles. Expliquer l’élection du Parlement européen ; le rôle des gouvernements au Conseil ; celui des dirigeants au Conseil européen ; la responsabilité nationale de ces exécutifs. La Commission doit être située dans le fonctionnement institutionnel sans être confondue avec un gouvernement directement élu par tous les citoyens.

II. Une articulation qui élargit les possibilités d’action mais rend le contrôle politique complexe. Analyser les élections, le débat public et les instruments participatifs ; montrer les problèmes de lisibilité des responsabilités, les écarts de participation et les contestations. Les mécanismes de représentation ne prouvent pas une satisfaction universelle.

Ce plan répond au sujet parce que chaque partie examine les échelles et leurs relations. Un plan en trois parties est également possible, par exemple légitimités, décision, contestations, à condition d’éviter les répétitions. Quatre exemples précis peuvent être quatre mécanismes institutionnels : il n’est pas nécessaire de multiplier des anecdotes.

**Critères observables.** Question explicative ; deux ou trois parties distinctes ; quatre mécanismes ; limites sans conclusion caricaturale.

**Reprise ciblée.** R5 : remplacer chaque titre vague par une proposition qui répond au problème.

### P01-E7 — Composition autonome {#corr-P01-E7}

**Démarche recevable.** Problème : pourquoi l’existence ou le retour d’institutions démocratiques ne garantit-il pas leur permanence ? Un plan peut d’abord expliquer les fragilités et les ruptures, puis les conditions d’une transition et d’une consolidation. Les exemples peuvent être comparés à l’intérieur de chaque partie.

**Introduction modèle.** L’élection d’un gouvernement ou la fin d’une dictature marque un moment politique décisif, mais ne suffit pas à assurer la durée d’un régime démocratique. Les libertés, les contre-pouvoirs et l’acceptation de règles communes peuvent être fragilisés. Les cas étudiés invitent donc à comprendre comment les démocraties avancent ou reculent et pourquoi ces processus restent réversibles.

**Développement modèle condensé.** Les fragilités peuvent naître au sein même d’un fonctionnement majoritaire. Tocqueville souligne le risque de pression de la majorité et la nécessité de garanties contre la concentration du pouvoir. Il ne s’agit pas de condamner toute décision majoritaire, mais de distinguer la règle de décision et le respect des libertés. Le Chili montre une rupture effective : Allende arrive au pouvoir en 1970 dans un cadre électoral, mais les conflits sociaux et politiques, la polarisation et les interventions extérieures s’articulent à l’action de forces internes. Le coup d’État militaire de 1973 détruit l’ordre démocratique. L’élection initiale n’en avait pas assuré l’irréversibilité.

Les transitions portugaise et espagnole montrent, inversement, que la fin d’un régime autoritaire ouvre un processus plutôt qu’un état achevé. Au Portugal, la rupture militaire de 1974 est suivie d’une phase de tensions et de choix, avant la Constitution de 1976. En Espagne, la mort de Franco en 1975 est suivie de réformes, de négociations, des élections de 1977 et de la Constitution de 1978. Le rôle des acteurs et les modalités diffèrent ; dans les deux cas, les règles doivent devenir effectives. L’échec du coup de force espagnol de 1981 et l’alternance de 1982 éclairent la consolidation sans autoriser à parler d’un acquis éternel.

**Conclusion modèle.** Les trajectoires démocratiques dépendent de garanties institutionnelles, de pratiques et de rapports de force. Elles peuvent connaître des ruptures ou des reconstructions. Leur réversibilité n’implique pas que tous les régimes seraient également fragiles : elle oblige à identifier les conditions concrètes de leur maintien.

**Pour votre copie.** Ce modèle condensé donne la logique ; développer les exemples avec le cours, conserver des transitions et vérifier le temps consacré à chaque partie. Une organisation chronologique comparée est recevable si elle reste explicative.

**Critères observables.** Axe 2 respecté ; Tocqueville et trois pays mobilisés ; mécanismes expliqués ; introduction et conclusion ; devoir achevé.

**Reprise ciblée.** R5 si juxtaposition ; R6 si la deuxième partie ou la conclusion manque.

### P01-E8 — Expliquer à un non-spécialiste {#corr-P01-E8}

Ouverture possible : voter est une condition importante de la démocratie représentative, mais ne garantit pas à lui seul la liberté du choix, les droits ou le contrôle du pouvoir. À Athènes, les citoyens participent directement à l’Ecclésia, mais la définition restrictive de la citoyenneté exclut une grande partie des habitants. Le mode de vote ne suffit donc pas à juger l’étendue des droits.

Dans l’Union européenne contemporaine, l’élection du Parlement participe à la représentation, à côté des circuits nationaux des gouvernements. Le débat, la responsabilité et les garanties juridiques complètent l’élection. On peut aussi mobiliser le Chili pour distinguer victoire électorale et maintien du régime.

Objection : sans vote libre, les autres garanties risquent de laisser les citoyens sans choix effectif du pouvoir. Réponse : l’élection n’est pas inutile ; elle est nécessaire dans une démocratie représentative, mais doit être accompagnée de libertés et de contre-pouvoirs. En trois minutes, consacrer environ trente secondes au problème, une minute par exemple et trente secondes à l’objection et à la conclusion.

**Critères observables.** Réponse nette ; deux époques ; objection réellement discutée ; durée respectée sans récitation du chapitre.

**Reprise ciblée.** R3 : relier chaque exemple à la suffisance ou à l’insuffisance du vote.

## QCM : comprendre chaque proposition

### P01-Q1 — Réponse B {#corr-P01-Q1}

**A.** A confond citoyens et habitants : femmes, métèques et esclaves sont exclus de la citoyenneté politique.

**B.** B définit la participation directe à certaines décisions, notamment dans l’Ecclésia.

**C.** C est faux : la démocratie athénienne possède des institutions et des procédures.

### P01-Q2 — Réponse A {#corr-P01-Q2}

**A.** A correspond au changement d’échelle et à la place des libertés individuelles chez les Modernes.

**B.** B efface la vigilance civique que Constant maintient ; représentation ne signifie pas abandon du contrôle.

**C.** C contredit l’importance des libertés et du débat dans la conception défendue.

### P01-Q3 — Réponse C {#corr-P01-Q3}

**A.** 1970 est l’année de l’élection d’Allende, non celle du coup d’État.

**B.** 1974 renvoie ici à la révolution portugaise, pas au renversement chilien.

**C.** Le coup d’État chilien a lieu le 11 septembre 1973.

### P01-Q4 — Réponse B {#corr-P01-Q4}

**A.** A confond l’élection des représentants des citoyens et la représentation des États par leurs dirigeants.

**B.** B distingue correctement les circuits de légitimation à l’échelle européenne et nationale.

**C.** C est faux : les États sont précisément représentés au Conseil européen.

### P01-Q5 — Réponse A {#corr-P01-Q5}

**A.** A rappelle qu’une majorité est soumise aux garanties juridiques et aux droits fondamentaux.

**B.** B confond majorité et pouvoir illimité ; la démocratie comprend des contre-pouvoirs.

**C.** C supprime le droit d’opposition et de critique, essentiels à une démocratie pluraliste.

## P01-RT — Corrigé du nouveau test {#corr-P01-RT}

1. Athènes associe participation directe des citoyens et exclusion des femmes, métèques et esclaves. 2. Le Chili connaît l’élection d’Allende en 1970 puis le coup d’État de 1973 ; le Portugal connaît la rupture du 25 avril 1974 puis une consolidation institutionnelle, notamment en 1976. 3. Dans l’Union, l’élection du Parlement se combine à la représentation des États par les dirigeants et gouvernements démocratiquement responsables. Ne pas conclure que le vote seul garantit toutes les libertés.

**Validation.** Réussite : trois réponses justifiées, avec notions distinguées et exemples situés. Une erreur de date appelle R1 ; une confusion de notion R2 ; une relation non expliquée R3. Refaire le point faible à J+2.

**À distance.** J+7 : Restituer 1970, 1973 et 1974 avec leur pays et leur signification. J+21 : Comparer l’usage démocratique de l’information en P04 et les garanties de P01.

# P02 — Corriger et progresser {#corr-P02}

## P02-D — Diagnostic : réponses et orientation

Un grand territoire ne produit pas automatiquement de la puissance : il faut des capacités de contrôle et de mobilisation. Une sanction économique relève de la contrainte, pas du soft power simplement parce qu’elle n’est pas militaire. Apprécier un film ne signifie pas soutenir le gouvernement du pays producteur. Une ressource culturelle n’a un effet politique que sous certaines conditions. Reprendre les distinctions capacité/instrument/effet avant de mémoriser des classements.

## P02-A — Activité du cours : éléments de correction

La fin d’un empire transforme les territoires, les institutions et les réseaux ; elle n’abolit pas toute capacité d’action. Après l’Empire ottoman, la Turquie réorganise un État sur des bases territoriales et politiques différentes. Après 1991, la Russie perd le cadre soviétique mais conserve notamment un territoire, des capacités militaires et une position internationale. Il faut préciser ce qui disparaît, ce qui subsiste et ce qui est reconstruit. Le rapprochement n’autorise pas à confondre les contextes ni à présenter les reconstitutions comme inévitables. Une note de 180 mots peut consacrer un paragraphe à chaque cas puis formuler cette comparaison.

## Exercices : démarches, réponses et critères

### P02-E1 — Identifier les instruments {#corr-P02-E1}

La sanction économique relève principalement de la contrainte, donc du hard power, même si elle n’est pas militaire. L’attractivité d’une université peut contribuer au soft power lorsqu’elle suscite une préférence et des relations favorables ; il faut observer sa réception. Une base militaire fournit une capacité de projection, de présence ou de dissuasion. Une norme technique très utilisée peut structurer les options d’autres acteurs et créer une dépendance : elle illustre un pouvoir structurel.

Les catégories ne sont pas entièrement exclusives. Une université dépend de financements et peut former des réseaux stratégiques ; une base peut rassurer un allié tout en contraignant un adversaire ; une norme peut être adoptée volontairement avant de rendre un changement coûteux. Le classement initial doit donc être suivi d’une explication du mécanisme. Posséder un instrument ne prouve pas que l’objectif politique est atteint.

**Critères observables.** Quatre mécanismes distingués ; sanction non réduite au militaire ; recoupements justifiés ; résultat non automatique.

**Reprise ciblée.** R2 : refaire hard/soft/structurel avec un effet observé pour chaque exemple.

### P02-E2 — Raconter sans déterminisme {#corr-P02-E2}

Une série recevable : 1453, prise de Constantinople et renforcement d’un centre impérial ; XVIe siècle, expansion et puissance sous Soliman ; XIXe siècle, réformes des Tanzimat et recomposition sous pressions internes et externes ; 1922–1923, fin du sultanat puis République turque, après les ruptures de la guerre et de la sortie d’empire. D’autres repères du cours sont possibles s’ils restent exacts et significatifs.

La trajectoire ne se résume pas à une montée suivie d’une chute continue. Les réformes montrent des capacités d’adaptation ; les pertes territoriales ne suppriment pas immédiatement toutes les ressources ; les rapports avec les puissances européennes varient. La disparition d’un cadre impérial laisse des héritages institutionnels, territoriaux et mémoriels sans faire de l’État suivant une simple continuation inchangée. Le terme de déclin décrit des pertes relatives selon des critères, non un destin annoncé depuis l’origine.

**Critères observables.** Quatre repères ; une transformation par repère ; distinction disparition politique et héritages.

**Reprise ciblée.** R1 : relier dates et événements ; R3 : préciser ce qui change entre les périodes.

### P02-E3 — Une alliance n’est pas un empire {#corr-P02-E3}

Le tableau, établi d’après la chronologie de l’OTAN, montre l’existence d’une alliance fondée en 1949 et son élargissement à différentes périodes. L’adhésion de la Pologne en 1999, puis de la Finlande en 2023 et de la Suède en 2024, situe l’évolution de cet ancrage européen. Pour les États-Unis, un réseau d’alliés fournit des coopérations, des possibilités d’interopérabilité et des points d’appui stratégiques. L’alliance possède toutefois des règles et des décisions collectives ; elle n’est pas le simple inventaire de territoires américains.

Le tableau ne mesure ni les moyens effectivement déployés, ni l’ensemble de la puissance économique et culturelle, ni l’accord politique sur chaque opération. Les alliés poursuivent leurs intérêts et peuvent diverger. Il serait donc erroné de transformer une date d’adhésion en preuve d’obéissance automatique. La source permet une analyse de réseau et de chronologie ; elle appelle d’autres documents pour apprécier les pratiques et les résultats.

**Critères observables.** Alliance et chronologie interprétées ; quatre dates correctement lues ; deux limites ; autonomie des partenaires reconnue.

**Reprise ciblée.** R4 : distinguer ce que le tableau montre et ce qu’il ne mesure pas.

### P02-E4 — Langue et numérique : comparer des mécanismes {#corr-P02-E4}

Langue : enseignements et publications dans une langue → apprentissage de cette langue par des étudiants → accès à des réseaux, diplômes et productions culturelles → influence et possibilités de coopération pour les acteurs qui structurent ces réseaux. Un État ou une université peut développer des formations plurilingues, traduire ou renforcer une autre langue. L’adoption linguistique ne garantit pas l’adhésion à toutes les politiques du pays associé.

Plateforme : concentration d’utilisateurs et de services → effets de réseau et accumulation de données → dépendance de créateurs, entreprises ou administrations → capacité à fixer des règles de visibilité, d’accès et de rémunération. Des régulateurs peuvent imposer des obligations ; des usagers ou concurrents peuvent développer des alternatives, avec des coûts de changement variables.

Les chaînes montrent des mécanismes possibles, pas des lois automatiques. Une réponse convaincante distingue l’acteur propriétaire, les utilisateurs et la puissance publique ; elle ne personnifie pas « Internet » comme un pouvoir unique.

**Critères observables.** Deux chaînes de quatre étapes ; effet de réseau expliqué ; deux acteurs de résistance ; limite de l’influence.

**Reprise ciblée.** R3 : remplacer les flèches vagues par des verbes explicatifs.

### P02-E5 — Réviser une affirmation excessive {#corr-P02-E5}

Les nouvelles routes de la soie, annoncées à partir de 2013, associent des projets d’infrastructures, de financement et de connexion. Elles peuvent faciliter les échanges, ouvrir des marchés et renforcer la présence économique et diplomatique chinoise. Les routes, ports ou réseaux ne servent donc pas uniquement au déplacement de marchandises : ils peuvent aussi structurer des dépendances et des relations politiques.

Cependant, un projet annoncé n’est pas nécessairement achevé, et un partenariat ne transforme pas automatiquement un pays en colonie. Les conditions de financement, la propriété, l’exploitation, la capacité de négociation et les usages locaux doivent être étudiés. Des gouvernements renégocient, suspendent ou diversifient leurs partenaires. Les résultats varient selon les territoires et les projets. L’analyse doit donc relier objectif, instrument et effet observable, sans nier les asymétries ni supposer une domination totale identique partout.

**Critères observables.** Annonce datée ; plusieurs fonctions ; mécanisme de dépendance ; marge des partenaires ; absence de généralisation coloniale.

**Reprise ciblée.** R2 sur dépendance/souveraineté ; R3 sur projet et résultat.

### P02-E6 — Construire une comparaison diachronique {#corr-P02-E6}

Problématique : comment les ruptures qui affectent une puissance redistribuent-elles ses capacités sans supprimer tous ses héritages ?

I. Les ruptures peuvent détruire un cadre politique et réduire fortement les moyens d’action. L’Empire ottoman perd des territoires et disparaît comme empire ; l’URSS se dissout en 1991, avec de nouveaux États et une crise profonde pour la Russie. Préciser les contextes et ne pas assimiler les deux sorties.

II. Les héritages et les stratégies permettent des recompositions, sans retour à l’identique. Les territoires, institutions, mémoires et ressources hérités sont réinvestis. La Turquie républicaine n’est pas l’Empire ottoman ; la Russie mobilise notamment ses ressources, ses capacités militaires et ses instruments diplomatiques, mais dans un cadre transformé.

Une troisième partie peut examiner les limites et les contestations de ces recompositions. Il faut alors la nourrir sans répéter les deux premières. La conclusion doit distinguer disparition d’un État, déclin relatif d’une capacité et permanence d’un héritage ; ces trois phénomènes ne sont pas interchangeables.

**Critères observables.** Comparaison réelle ; ruptures et héritages ; critères de puissance ; absence de continuité automatique.

**Reprise ciblée.** R5 : construire les parties sur des relations communes, pas un pays par partie sans comparaison.

### P02-E7 — Composition autonome {#corr-P02-E7}

**Problématique possible :** comment des instruments non directement militaires permettent-ils d’orienter les choix d’autres acteurs, et quelles conditions limitent leur efficacité ?

**Introduction modèle.** La puissance ne se manifeste pas uniquement par la guerre ou la menace. Des langues, des plateformes numériques et des infrastructures peuvent façonner les possibilités d’action et les préférences. Les formes indirectes de puissance reposent ainsi sur l’attraction et sur l’organisation des relations, mais leur efficacité dépend des acteurs qui les reçoivent et peuvent leur résister.

**Développement modèle condensé.** Les langues constituent d’abord des supports d’accès à l’éducation, à la recherche et à la culture. Une langue largement utilisée facilite des réseaux professionnels et intellectuels. Les institutions qui l’enseignent et les productions qu’elle véhicule peuvent renforcer une influence. Pourtant, parler une langue ou apprécier une œuvre ne signifie pas soutenir toutes les décisions d’un gouvernement. Le soft power dépend de l’attraction et de sa réception.

Les plateformes numériques organisent ensuite des interactions. Leurs effets de réseau attirent utilisateurs, créateurs et entreprises ; leurs règles de classement, d’accès et de rémunération peuvent modifier les comportements. La puissance tient ici à la capacité de structurer un espace d’activité. Elle demeure discutée par des régulateurs et des concurrents, et dépend d’infrastructures, de compétences et de confiance.

Enfin, les nouvelles routes de la soie articulent infrastructures, financements et relations diplomatiques depuis 2013. Les connexions peuvent ouvrir des marchés et créer des dépendances à l’égard de prêteurs, d’opérateurs ou de normes. Mais les projets sont divers, parfois contestés ou renégociés. Il faut donc examiner leur réalisation et leurs effets plutôt que déduire une domination totale de l’annonce d’un programme.

**Conclusion modèle.** Les formes indirectes de puissance agissent sur les préférences et sur la structure des choix. Elles peuvent compléter des moyens plus coercitifs, mais ne produisent pas automatiquement le résultat recherché. Leur étude demande de suivre la chaîne allant de la ressource à l’influence effective.

**Autre plan recevable :** I. Attirer et relier ; II. Créer des dépendances et fixer des règles ; III. Des influences contestées et conditionnelles. Il faut alors croiser les trois jalons plutôt que répéter un cas dans toutes les parties.

**Critères observables.** Trois jalons de l’axe 2 ; mécanismes précis ; résultat distingué de ressource ; limites et conclusion.

**Reprise ciblée.** R3 si catalogue d’exemples ; R6 si l’un des trois jalons disparaît faute de temps.

### P02-E8 — Localiser une puissance en réseau {#corr-P02-E8}

New York se situe sur la façade atlantique du nord-est ; Boston/Cambridge est plus au nord sur cette même façade ; Los Angeles/Hollywood se trouve sur la façade pacifique du sud-ouest. New York illustre des fonctions financières, médiatiques et diplomatiques ; Boston/Cambridge, la formation et la recherche ; Hollywood, la production et la diffusion d’industries culturelles.

Ces lieux ne constituent pas trois puissances souveraines indépendantes. Ils appartiennent à un territoire, à des marchés, à des réseaux d’entreprises et de mobilité, et bénéficient de conditions institutionnelles communes. Leurs fonctions peuvent se compléter : financement, innovation, talents et diffusion internationale. Toutefois, des entreprises privées ne se confondent pas automatiquement avec l’État fédéral et peuvent poursuivre des objectifs différents.

À l’oral, localiser d’abord, expliquer ensuite une fonction par lieu, puis montrer un lien entre les fonctions. Terminer sur cette limite : une concentration de ressources donne des possibilités d’influence, mais ne garantit pas leur transformation en résultat politique.

**Critères observables.** Trois localisations ; fonctions distinctes ; réseau national/mondial ; distinction État/acteurs privés.

**Reprise ciblée.** R1 pour les lieux ; R3 pour les liens entre fonctions.

## QCM : comprendre chaque proposition

### P02-Q1 — Réponse B {#corr-P02-Q1}

**A.** A confond possession d’une ressource et résultat ; les résistances ou les coûts peuvent empêcher l’effet attendu.

**B.** B exprime la conversion nécessaire d’une ressource en capacité effective.

**C.** C oublie les ressources économiques, culturelles, scientifiques et normatives.

### P02-Q2 — Réponse A {#corr-P02-Q2}

**A.** 1991 correspond à la dissolution de l’URSS et à la recomposition de son espace.

**B.** 1982 ne correspond pas à la dissolution ; c’est notamment un repère de la transition espagnole.

**C.** 2003 renvoie à la guerre d’Irak dans ce cycle, pas à la fin de l’URSS.

### P02-Q3 — Réponse A {#corr-P02-Q3}

**A.** A rappelle que l’attraction dépend aussi de la réception des publics et des partenaires.

**B.** B décrit une appropriation territoriale coercitive, non le mécanisme du soft power.

**C.** C est faux : universités, médias et diplomatie culturelle peuvent nécessiter d’importants financements.

### P02-Q4 — Réponse C {#corr-P02-Q4}

**A.** 1949 est un repère de la Chine populaire et de la fondation de l’OTAN, non de ce programme.

**B.** 1991 est un repère de la fin de l’URSS, pas de l’annonce des routes de la soie.

**C.** 2013 correspond aux annonces à l’origine du programme contemporain.

### P02-Q5 — Réponse B {#corr-P02-Q5}

**A.** A oppose à tort coopération multilatérale et poursuite d’intérêts nationaux.

**B.** B définit une action avec plusieurs partenaires organisée dans un cadre commun.

**C.** C confond coopération et unanimité permanente ; les désaccords demeurent possibles.

## P02-RT — Corrigé du nouveau test {#corr-P02-RT}

1. Une langue, une université, une norme ou une plateforme peut influencer par attraction, réseau ou dépendance : préciser le mécanisme. 2. L’histoire ottomane comprend expansions, adaptations et réformes ; la disparition de l’empire n’est pas un déclin linéaire depuis l’origine. 3. Une infrastructure peut relier et développer des échanges, mais aussi rendre dépendant d’un financeur, d’un opérateur ou d’une norme. L’effet dépend du contrat, de la réalisation et des alternatives.

**Validation.** Réussite : trois réponses justifiées, avec notions distinguées et exemples situés. Une erreur de date appelle R1 ; une confusion de notion R2 ; une relation non expliquée R3. Refaire le point faible à J+2.

**À distance.** J+7 : Relier 1453, 1991 et 2013 à trois trajectoires distinctes. J+21 : Montrer comment une infrastructure spatiale ou numérique relie P02 à T01 ou T06.

# P03 — Corriger et progresser {#corr-P03}

## P03-D — Diagnostic : réponses et orientation

Une montagne ou un fleuve ne devient frontière que par une décision et des pratiques politiques ; l’expression « naturelle » peut masquer cette construction. Une ZEE ne permet pas d’interdire toute navigation étrangère : droits sur les ressources et souveraineté intégrale diffèrent. Le passage de travailleurs n’abolit pas une frontière : il peut être organisé par elle. Reprendre l’introduction et le jalon maritime en cas de confusion.

## P03-A — Activité du cours : éléments de correction

Dans une ZEE, le droit organise des compétences et des libertés distinctes : la frontière maritime n’est pas l’équivalent d’un mur terrestre. Dans l’espace rhénan, les infrastructures et la coopération peuvent faire d’une limite une interface de mobilités et de services. Dans les deux cas, l’ouverture dépend de règles, d’acteurs et d’usages. La limite est que les conflits de délimitation, les asymétries et les contrôles peuvent subsister. Une bonne réponse met en relation les deux paragraphes au lieu de conclure à une disparition universelle des frontières.

## Exercices : démarches, réponses et critères

### P03-E1 — Employer le mot frontière {#corr-P03-E1}

Un mur est un dispositif matériel qui peut fortifier une frontière, mais aussi exister à l’intérieur d’un territoire. Une frontière internationale délimite des espaces de souveraineté selon un statut politique et juridique. Une ligne de cessez-le-feu sépare des forces après l’arrêt des combats sans régler nécessairement le conflit territorial. Une interface est un espace de contact et d’échanges entre ensembles ; une frontière peut remplir cette fonction.

La ligne de démarcation militaire coréenne issue de l’armistice de 1953 illustre la différence entre arrêt des combats et règlement définitif de paix. La frontière germano-polonaise sur l’Oder et la Neisse illustre une limite dont la reconnaissance a connu plusieurs étapes. Le Rhin supérieur permet de penser une interface transfrontalière. Les termes ne sont donc pas quatre espèces exclusives : ils décrivent des dimensions matérielle, juridique, militaire et fonctionnelle qui peuvent se combiner.

**Critères observables.** Quatre définitions différenciées ; deux exemples situés ; possibilité de recoupement expliquée.

**Reprise ciblée.** R2 : refaire un tableau nature/statut/fonction.

### P03-E2 — Berlin sans légende simplificatrice {#corr-P03-E2}

La conférence de Berlin de 1884–1885 réunit des puissances qui fixent notamment des règles relatives au commerce, à la navigation et aux conditions de reconnaissance de certaines occupations coloniales. Elle contribue à organiser la compétition impériale, mais elle ne dessine pas en une séance toutes les frontières africaines. Les conquêtes, traités, accords entre puissances, résistances et réalités locales interviennent ensuite dans la formation des limites.

La formule initiale efface les temporalités et les acteurs africains, comme si le continent avait été vide et passif. Corriger cette formule ne revient pas à nier la violence coloniale ni le rôle des puissances européennes : cela permet d’en expliquer les mécanismes. Un tracé peut être imposé dans un rapport de force tout en résultant d’une histoire plus longue et plus complexe qu’un partage instantané autour d’une table.

**Critères observables.** Date 1884–1885 ; fonctions de la conférence ; poursuite des tracés ; acteurs et résistances africains non effacés.

**Reprise ciblée.** R1 pour la chronologie ; R3 pour la différence entre cadre et processus.

### P03-E3 — Lire un dispositif de mobilité {#corr-P03-E3}

Le document est une synthèse éditoriale de la présentation institutionnelle de Schengen par le Conseil de l’Union européenne. Il décrit un régime de circulation et de coopération, non la disparition des États. La suppression de principe des contrôles systématiques des personnes aux frontières intérieures modifie une fonction de la frontière ; elle n’abolit pas la limite des juridictions, des politiques publiques ou des responsabilités nationales.

Le régime implique aussi une coopération aux frontières extérieures et des règles communes. L’ouverture interne s’accompagne donc d’une organisation du contrôle, plutôt que d’une absence générale de frontières. Des réintroductions temporaires de contrôles sont possibles dans un cadre juridique ; il ne faut pas confondre principe et situation ponctuelle.

Enfin, Schengen et l’Union européenne ne coïncident pas exactement. Des États non membres de l’Union participent à Schengen, tandis que l’application du régime n’est pas identique pour tous les membres de l’Union. La phrase « Schengen supprime les États » extrapole donc au-delà du document. Celui-ci permet d’étudier une transformation des fonctions frontalières et leur coordination, mais pas de conclure à une souveraineté unique sans États.

**Critères observables.** Nature du document ; contrôle/souveraineté distingués ; frontières externes ; ensembles UE/Schengen différenciés.

**Reprise ciblée.** R4 : expliquer la portée de chaque phrase au lieu de la reformuler seulement.

### P03-E4 — Comparer deux séparations {#corr-P03-E4}

Corées : division dans le contexte de la fin de la Seconde Guerre mondiale et de la guerre froide ; guerre de 1950–1953 ; armistice de 1953 et ligne de démarcation militaire entourée d’une zone démilitarisée ; séparation durable et absence de traité de paix réglant définitivement le conflit. La ligne de 1953 n’est pas simplement le 38e parallèle.

Frontière germano-polonaise : déplacement territorial à la fin de la Seconde Guerre mondiale ; ligne Oder-Neisse ; reconnaissance par la RDA en 1950, étape de l’Ostpolitik avec la RFA en 1970, confirmation dans le contexte de l’unification allemande en 1990. La frontière devient ensuite un espace d’échanges dans l’intégration européenne, sans disparaître comme limite d’État.

Les deux frontières portent les traces de conflits et de décisions internationales. Mais l’une reste fortement militarisée dans un conflit non définitivement réglé, tandis que l’autre connaît une stabilisation juridique et des coopérations. La comparaison doit donc distinguer origine, statut et fonctionnement actuel, plutôt que conclure que toutes les frontières issues d’une guerre resteraient identiques.

**Critères observables.** Critères communs ; dates principales ; statut de l’armistice ; reconnaissance et ouverture distinguées.

**Reprise ciblée.** R1 : séparer les deux séries de dates avant de comparer.

### P03-E5 — Réparer une carte mentale {#corr-P03-E5}

La mer territoriale s’étend au maximum jusqu’à 12 milles marins depuis les lignes de base. L’État côtier y exerce sa souveraineté, sous réserve notamment du passage inoffensif prévu par le droit international. La ZEE peut s’étendre jusqu’à 200 milles depuis les lignes de base : l’État y possède des droits souverains sur certaines ressources et des compétences, mais pas une souveraineté intégrale identique à celle de son territoire terrestre. Les libertés de navigation et de survol prévues par le droit y demeurent.

La haute mer ne peut être appropriée par un État ; elle relève de libertés et d’obligations internationales. Il faut également distinguer les droits sur le plateau continental de ceux sur la colonne d’eau. Les espaces marins associent donc plusieurs régimes juridiques. Les zones peuvent se chevaucher entre côtes proches, ce qui appelle une délimitation : dessiner partout un cercle de 200 milles ne règle pas les différends.

**Critères observables.** 12 et 200 milles depuis les lignes de base ; souveraineté/droits distingués ; haute mer ; chevauchements.

**Reprise ciblée.** R2 et carnet cartographique A02 : refaire les zones avec leurs droits, pas seulement leurs distances.

### P03-E6 — Construire une problématique {#corr-P03-E6}

Problématique : comment l’intégration européenne transforme-t-elle les fonctions frontalières sans supprimer les différences entre territoires ?

I. Des frontières stabilisées et rendues plus perméables par des accords. Mobiliser la reconnaissance de la frontière germano-polonaise, l’intégration européenne et les principes de Schengen. Distinguer les étapes historiques et les dispositifs juridiques.

II. Des différences et des contrôles qui demeurent, mais deviennent aussi des ressources. Les écarts de salaires, de services ou de législation peuvent nourrir les mobilités dans le Rhin supérieur. Les frontières extérieures, les exceptions au régime de circulation et les compétences nationales rappellent que l’intégration n’est pas une disparition de la souveraineté.

La conclusion doit montrer une transformation sélective : certaines circulations sont facilitées, d’autres régulées, et les pratiques varient selon les lieux. Un plan séparant « frontières ouvertes » et « frontières fermées » peut être trop binaire s’il ne montre pas qu’un même espace sélectionne différents flux. Les trois exemples imposés doivent être articulés à leur échelle propre.

**Critères observables.** Problème sur les fonctions ; trois cas ; échelles distinguées ; pas d’opposition ouverte/fermée absolue.

**Reprise ciblée.** R5 : transformer les intitulés en propositions explicatives.

### P03-E7 — Composition autonome {#corr-P03-E7}

**Problématique possible :** comment l’Union transforme-t-elle les fonctions de ses frontières tout en maintenant des limites et des contrôles ?

**Introduction modèle.** L’intégration européenne a facilité de nombreuses circulations, mais elle n’a pas supprimé toutes les frontières. Les limites entre États, les régimes de contrôle et les pratiques des habitants se recomposent à plusieurs échelles. Il faut donc comprendre comment ouverture, coopération et différenciation s’articulent aux frontières internes et externes de l’Union.

**Développement modèle condensé.** À l’intérieur, l’intégration et Schengen réduisent certains obstacles. La suppression de principe des contrôles systématiques des personnes entre participants facilite les déplacements. Elle s’accompagne de règles et de coopérations : une frontière devient plus perméable sans cesser de séparer des juridictions. Il faut distinguer l’Union et Schengen, qui ne regroupent pas exactement les mêmes États.

Les espaces transfrontaliers rendent visibles les pratiques de cette intégration. Dans le Rhin supérieur, les déplacements de travail, les services et les projets communs utilisent les proximités mais aussi les différences. L’ouverture ne produit pas une homogénéité complète : écarts de salaires, fiscalité, langues et institutions demeurent. Ces différences peuvent favoriser des échanges tout en créant des difficultés de coordination.

Aux frontières extérieures, la régulation des circulations associe des responsabilités nationales et des dispositifs européens. L’ouverture interne rend la coopération externe particulièrement importante, mais les États n’ont pas des situations géographiques ou des intérêts identiques. Le cas de la Pologne rappelle également que des frontières ont une histoire de conflit, de reconnaissance et de changement de fonction. La stabilisation d’une limite et son intégration dans de nouveaux ensembles sont deux processus liés mais distincts.

**Conclusion modèle.** Les frontières européennes ne disparaissent pas : leurs fonctions se différencient selon les flux, les espaces et les dispositifs. L’intégration organise une ouverture sélective et des coopérations, tout en maintenant des souverainetés et des inégalités territoriales. Une copie peut adopter deux parties plutôt que trois si elle établit clairement cette articulation.

**Relecture ciblée.** Vérifier que la copie ne traite pas principalement Berlin ou la Corée, exemples d’autres axes, et qu’elle ne confond pas libre circulation des personnes, marchandises et disparition des administrations.

**Critères observables.** OTC respecté ; interne/externe ; Schengen distinct ; pratiques transfrontalières ; réponse achevée.

**Reprise ciblée.** R5 si hors-sujet d’axe ; R6 si les frontières extérieures sont traitées en une seule phrase finale.

### P03-E8 — Transférer le raisonnement {#corr-P03-E8}

Réponse directrice : une frontière ouverte reste une frontière si elle continue de distinguer des territoires et des règles tout en permettant des circulations. Le limes romain peut être mobilisé comme exemple historique de frontière contrôlée comportant des échanges, sans le présenter comme un équivalent de Schengen. Le Rhin supérieur constitue un exemple européen contemporain : les mobilités quotidiennes traversent des limites d’État qui conservent des effets juridiques, linguistiques et économiques.

Schéma recevable à cinq éléments : deux territoires A et B ; une ligne frontalière ; un point de passage ; des flèches de travailleurs ou de services ; un dispositif de coopération. La légende précise que les flèches représentent des flux et non une annexion. Une autre représentation est possible si elle conserve limite, circulation et régulation.

L’oral doit conclure que l’ouverture est une propriété de certains flux à un moment donné, pas l’effacement universel de la frontière. Une limite peut être facile à franchir pour un travailleur autorisé et difficile pour un autre type de circulation.

**Critères observables.** Deux exemples de périodes différentes ; cinq éléments ; flux et limite distingués ; ouverture sélective.

**Reprise ciblée.** R2 pour interface/frontière ; R3 pour expliquer les flèches.

## QCM : comprendre chaque proposition

### P03-Q1 — Réponse B {#corr-P03-Q1}

**A.** A transforme le relief en décision politique automatique ; plusieurs tracés sont possibles.

**B.** B distingue support physique et construction politique d’une limite.

**C.** C est faux : même une frontière appuyée sur un fleuve peut être déplacée ou renégociée.

### P03-Q2 — Réponse A {#corr-P03-Q2}

**A.** L’armistice du 27 juillet 1953 arrête les combats sans constituer un traité de paix définitif.

**B.** 1990 est un repère de la frontière germano-polonaise et de l’unification allemande.

**C.** 1885 renvoie à la conférence de Berlin, pas à l’armistice coréen.

### P03-Q3 — Réponse B {#corr-P03-Q3}

**A.** A confond ZEE et souveraineté territoriale intégrale ; des libertés de navigation subsistent.

**B.** B désigne les droits souverains et compétences spécifiques prévus par la convention.

**C.** C est faux : la haute mer ne devient pas la propriété de l’État côtier.

### P03-Q4 — Réponse C {#corr-P03-Q4}

**A.** A est faux : les ensembles ne coïncident pas exactement.

**B.** B confond allègement de contrôles et absence de limites politiques.

**C.** C est exact : il faut distinguer les membres et les dispositifs de l’Union et de Schengen.

### P03-Q5 — Réponse A {#corr-P03-Q5}

**A.** A explique pourquoi des différences de salaires, services ou règles peuvent nourrir les échanges.

**B.** B confond coopération entre territoires et création d’un État souverain.

**C.** C est faux : ces espaces sont souvent des lieux de vie et de mobilités quotidiennes.

## P03-RT — Corrigé du nouveau test {#corr-P03-RT}

1. Une frontière-interface met en relation des territoires tout en conservant des différences et des règles. 2. Délimiter fixe une ligne selon un accord ou une décision ; démarquer la matérialise ; reconnaître en accepte le statut. 3. Schengen réduit certains contrôles intérieurs mais maintient des États, des juridictions et des dispositifs extérieurs. Une circulation facilitée ne signifie pas absence de toute frontière.

**Validation.** Réussite : trois réponses justifiées, avec notions distinguées et exemples situés. Une erreur de date appelle R1 ; une confusion de notion R2 ; une relation non expliquée R3. Refaire le point faible à J+2.

**À distance.** J+7 : Dessiner mer territoriale, ZEE et haute mer en nommant les droits. J+21 : Comparer frontières physiques de P03 et ancrages territoriaux du cyberespace de T06.

# P04 — Corriger et progresser {#corr-P04}

## P04-D — Diagnostic : réponses et orientation

Une photographie sans contexte ne suffit pas à établir l’événement que sa légende prétend montrer. Dix reprises d’une même dépêche ne constituent pas dix confirmations indépendantes. Une forte viralité ne prouve ni vérité ni fausseté : elle décrit une circulation. Il faut remonter à la source, dater, localiser et confronter. Reprendre M3 si vous avez utilisé la popularité comme critère de preuve.

## P04-A — Activité du cours : éléments de correction

La capture fictive ne permet pas d’affirmer immédiatement la réalité, la date ou la localisation de l’événement. Il faut rechercher la publication initiale, les indices visuels et une confirmation indépendante. Pour trois journaux reprenant une même dépêche AFP, deux contrôles communs sont l’identification de la dépêche et la vérification des faits auprès d’une autre source. Une différence porte sur les titres, coupes ou images ajoutés par chaque rédaction. La diversité des supports peut modifier le cadrage sans multiplier les enquêtes initiales. Une réponse sérieuse distingue donc production, reprise et commentaire.

## Exercices : démarches, réponses et critères

### P04-E1 — Information, opinion, preuve {#corr-P04-E1}

A rapporte une information attribuée à une source identifiable : l’horaire annoncé peut être vérifié dans la convocation. Il ne garantit pas que la réunion commencera effectivement à cette heure. B est un jugement ou une anticipation évaluative ; il faudrait des critères pour le discuter. C contient une inférence non justifiée : inviter ne prouve pas la présence future.

La correction ne consiste pas à déclarer A absolument vraie et B absolument fausse. Elle distingue la nature de l’énoncé et le type de preuve nécessaire. Une opinion peut s’appuyer sur des faits ; une information peut être erronée. Le travail critique porte sur l’attribution, la vérification et la portée de la conclusion.

**Critères observables.** Trois statuts ; source identifiée ; annonce et réalisation distinguées.

**Reprise ciblée.** R2 : distinguer information, jugement et inférence.

### P04-E2 — Des techniques aux publics {#corr-P04-E2}

Une chronologie recevable situe l’imprimerie à caractères mobiles en Europe au XVe siècle, sans effacer les inventions antérieures en Asie ; la diffusion de la radio puis de la télévision au XXe siècle ; ARPANET en 1969 et le rôle du protocole TCP/IP en 1983 ; le Web conçu au CERN à partir de 1989 et rendu librement disponible en 1993. Les repères sont expliqués par multiplication des exemplaires, diffusion audiovisuelle à de vastes publics, mise en réseau et navigation hypertexte.

Les limites sont l’accès matériel, l’alphabétisation, le coût, le contrôle des canaux et les règles politiques. Une innovation élargit des possibilités sans décider à elle seule du pluralisme. La censure peut s’adapter, et la concentration économique peut créer de nouveaux pouvoirs. Une autre sélection de quatre repères du cours est recevable si elle distingue les médias et les mécanismes.

**Critères observables.** Quatre étapes ; Internet/Web distingués ; diffusion et limites ; absence de déterminisme technique.

**Reprise ciblée.** R1 puis R3 : associer une date à un mécanisme et à une condition.

### P04-E3 — Lire une liberté inscrite dans la loi {#corr-P04-E3}

Cet extrait est un article de loi adopté sous la Troisième République. Il énonce un principe de liberté pour l’imprimerie et la librairie et constitue une source juridique, non une enquête sur les pratiques de tous les lecteurs. Il permet d’étudier la construction d’un cadre favorable à la diffusion de la presse.

Il ne prouve pas que chacun disposait des moyens d’acheter, de lire ou de publier. L’alphabétisation, les revenus, les réseaux de distribution et les rapports économiques restent déterminants. L’extrait ne permet pas non plus de conclure à une absence de toute limite juridique : il faudrait lire les autres dispositions applicables et leur évolution. La portée exacte du document est donc un principe normatif situé, que l’histoire des pratiques doit compléter. L’analyse ne doit pas transformer une phrase de loi en description intégrale d’une société.

**Critères observables.** Nature juridique ; contexte républicain ; principe expliqué ; deux limites distinctes.

**Reprise ciblée.** R4 : écrire une phrase sur ce que la source établit et une sur ce qu’elle ne mesure pas.

### P04-E4 — Dreyfus : distinguer événement et traitement médiatique {#corr-P04-E4}

La grâce de 1899 n’équivaut pas à la réhabilitation de 1906 : la première met fin à l’exécution de la peine dans les conditions décidées, tandis que la seconde intervient dans le processus judiciaire qui annule la condamnation et rétablit Dreyfus. Les deux dates traduisent donc des étapes différentes de la résolution de l’affaire.

La presse rend l’affaire publique, organise des controverses et mobilise des lecteurs. « J’accuse…! », publié par Zola en 1898, intervient dans cette lutte pour la reconnaissance de l’erreur judiciaire. Mais les journaux portent des positions antagonistes ; certains entretiennent les accusations et l’antisémitisme, d’autres contribuent à les contester. La multiplication des publications ne garantit pas seule la vérité : elle peut diffuser des preuves comme des préjugés. Il faut donc analyser les arguments, les sources et les conditions du débat.

**Critères observables.** Chronologie ; grâce/réhabilitation ; presse plurielle ; rôle ambivalent expliqué.

**Reprise ciblée.** R1 pour les dates ; R2 pour les deux actes juridiques.

### P04-E5 — Vietnam et contrôle de l’information {#corr-P04-E5}

Un gouvernement produit un récit et peut contrôler certaines informations, mais journalistes, soldats, témoins et chercheurs disposent aussi de sources. Les Pentagon Papers sont une étude interne sur l’implication américaine au Vietnam, rendue publique par des fuites et publications en 1971 ; ils ne sont pas un sondage. Leur intérêt tient notamment à la confrontation entre analyses internes et discours publics.

Les images de la guerre peuvent transformer les perceptions et contribuer à la mobilisation, mais elles ne suffisent pas à expliquer seules la politique. Les pertes, les objectifs stratégiques, les rapports institutionnels et les mouvements sociaux interviennent également. Une correction rigoureuse remplace donc trois certitudes abusives par une analyse des producteurs, des contenus, de leur circulation et de leurs effets possibles.

**Critères observables.** Trois erreurs corrigées ; nature de l’étude ; plusieurs facteurs ; effet médiatique non automatique.

**Reprise ciblée.** R3 : ne pas substituer un déterminisme médiatique au déterminisme gouvernemental.

### P04-E6 — Le Web : horizontalité et nouveaux intermédiaires {#corr-P04-E6}

Problématique : comment l’élargissement de la publication individuelle s’articule-t-il à la concentration de nouveaux pouvoirs d’intermédiation ? I. Le réseau facilite la production, la circulation et la confrontation de contenus par de nombreux acteurs : témoins, chercheurs, journalistes, associations et citoyens. II. La visibilité dépend de plateformes, de modèles économiques, de règles de classement et de compétences inégalement réparties ; les agences et médias ne disparaissent pas.

On peut conclure que l’horizontalité décrit une possibilité de circulation, non une égalité complète des positions. Le plan doit traiter la vérification : la multiplicité des reprises ne crée pas autant de sources indépendantes. Une troisième partie sur les pratiques critiques est recevable si elle ne devient pas un catalogue de conseils sans lien avec les rapports de pouvoir.

**Critères observables.** Publication/visibilité distinguées ; acteurs multiples ; mécanismes de plateforme ; vérification.

**Reprise ciblée.** R5 : tester si chaque partie répond au mot « entièrement ».

### P04-E7 — Composition : l’information à l’heure d’Internet {#corr-P04-E7}

**Démarche.** Une question recevable est : comment l’élargissement des possibilités d’informer et de s’informer s’accompagne-t-il de nouveaux pouvoirs et de nouvelles exigences critiques ? Deux parties peuvent examiner les ouvertures, puis les conditions et limites de leur usage.

**Introduction modèle.** Internet permet à des individus et à des groupes de publier et de partager rapidement des contenus. Cette ouverture modifie les circuits traditionnels de l’information sans supprimer les intermédiaires. Les libertés nouvelles doivent donc être étudiées avec les défis de visibilité, de fiabilité et de contrôle qui les accompagnent.

**Développement modèle condensé.** Les réseaux facilitent le témoignage, l’enquête collective et la circulation de documents. Les lanceurs d’alerte peuvent rendre publics des éléments jusque-là soustraits au débat, au prix de risques personnels et de controverses sur le secret. Ces possibilités élargissent le contrôle des pouvoirs, mais ne garantissent pas que tout contenu publié soit exact ou d’intérêt public.

La diffusion dépend aussi d’acteurs concentrés. Les plateformes organisent la visibilité par leurs règles et leurs modèles économiques ; les agences et médias continuent de produire des informations reprises en ligne. Les utilisateurs ne disposent pas tous des mêmes ressources. La circulation horizontale peut ainsi coexister avec des hiérarchies fortes.

Enfin, la vitesse de partage favorise parfois la diffusion de contenus trompeurs ou conspirationnistes. Le doute critique recherche des preuves et accepte la réfutation ; le conspirationnisme tend à interpréter toute contradiction comme confirmation d’un complot. La vérification demande de retrouver la source originale, de contextualiser et de confronter des éléments indépendants. Elle protège la liberté d’informer plutôt qu’elle ne s’y oppose.

**Conclusion modèle.** Internet accroît les possibilités d’accès et de publication, mais ne supprime ni les rapports de pouvoir ni le besoin de méthodes. Les libertés nouvelles deviennent effectives lorsque les publics peuvent comprendre les conditions de production et de diffusion des informations.

Une copie plus développée doit préciser les exemples du cours, notamment les alertes sur la surveillance, sans attribuer aux documents des affirmations non vérifiées.

**Critères observables.** Trois jalons OTC ; mécanismes ; critique/conspirationnisme ; exemples et achèvement.

**Reprise ciblée.** R3 si récit technique ; R6 si conclusion absente.

### P04-E8 — Une image virale : expliquer une vérification {#corr-P04-E8}

La réponse doit distinguer le fichier et l’affirmation qui l’accompagne. Une image peut être authentique mais ancienne, localisée ailleurs ou utilisée pour illustrer un événement différent. Il faut retrouver une publication antérieure ou la source originale, vérifier les indices de lieu et de date, examiner la légende et confronter des informations indépendantes.

Dix comptes reprenant une même publication ne constituent pas dix confirmations autonomes. L’absence de preuve immédiate ne permet pas non plus de déclarer automatiquement l’image fausse. À l’oral, exposer successivement l’affirmation à vérifier, les opérations de contrôle et la conclusion provisoire : partager, attendre ou signaler l’incertitude selon les éléments. La correction ne demande pas une enquête technique réelle sur la fiction, mais une procédure qui respecte les niveaux de preuve.

**Critères observables.** Cinq dimensions ; reprise/source indépendante ; conclusion proportionnée ; durée.

**Reprise ciblée.** R4 : distinguer ce qui est visible et ce qui est affirmé par la légende.

## QCM : comprendre chaque proposition

### P04-Q1 — Réponse B {#corr-P04-Q1}

**A.** La proximité ne supprime ni l’erreur ni le point de vue.

**B.** Le statut dépend de la relation de la source à la question posée.

**C.** Un article récent peut être secondaire pour un événement ancien.

### P04-Q2 — Réponse A {#corr-P04-Q2}

**A.** 1898 est la date de l’intervention de Zola dans L’Aurore.

**B.** 1906 correspond à la réhabilitation de Dreyfus.

**C.** 1971 renvoie aux Pentagon Papers.

### P04-Q3 — Réponse C {#corr-P04-Q3}

**A.** Internet est l’infrastructure de réseaux ; le Web est un système de ressources et de navigation qui l’utilise.

**B.** 1450 renvoie approximativement aux développements de l’imprimerie européenne.

**C.** La distinction évite de confondre réseau et service.

### P04-Q4 — Réponse B {#corr-P04-Q4}

**A.** Le nombre de reprises ne crée pas l’indépendance.

**B.** Il faut remonter à l’agence ou au producteur initial.

**C.** La dépendance commune ne prouve pas la fausseté.

### P04-Q5 — Réponse A {#corr-P04-Q5}

**A.** Il ajuste la conclusion à des preuves discutables.

**B.** Cette fermeture à la réfutation caractérise une logique conspirationniste.

**C.** Une source institutionnelle doit être critiquée, non rejetée automatiquement.

## P04-RT — Corrigé du nouveau test {#corr-P04-RT}

Une information attribuée porte sur un fait vérifiable ; une opinion exprime une évaluation qui peut être argumentée. « J’accuse…! » est publié en 1898 et intervient dans une controverse sur l’erreur judiciaire et la responsabilité des institutions. Trois reprises peuvent toutes dépendre du même document ou de la même agence : il faut identifier leurs chaînes de production, non compter seulement les publications.

**Validation.** Réussite : trois réponses justifiées, avec notions distinguées et exemples situés. Une erreur de date appelle R1 ; une confusion de notion R2 ; une relation non expliquée R3. Refaire le point faible à J+2.

**À distance.** J+7 : Refaire la chronologie 1894/1898/1899/1906 en précisant grâce et réhabilitation. J+21 : Analyser comment une information scientifique de T06 peut être simplifiée ou déformée dans sa diffusion.

# P05 — Corriger et progresser {#corr-P05}

## P05-D — Diagnostic : réponses et orientation

L’absence de religion officielle ne signifie pas l’absence de croyants. La laïcité peut comporter des relations administratives avec les cultes selon l’histoire du pays ; elle ne se réduit pas à leur invisibilité. Une majorité religieuse ne vote ni ne pense nécessairement d’une seule manière. Reprendre les notions séparation, sécularisation et pluralisme sans les utiliser comme synonymes.

## P05-A — Activité du cours : éléments de correction

La Turquie républicaine articule une politique de laïcisation et un encadrement public du religieux, illustré par le Diyanet : séparation et retrait de l’État ne se confondent pas. Aux États-Unis, le premier amendement distingue non-établissement et libre exercice, tandis que les références religieuses restent présentes dans la société et la politique. En Inde, le cadre constitutionnel organise des libertés dans une société pluraliste, mais les rapports majorités/minorités et les mobilisations identitaires produisent des tensions. Les trois paragraphes doivent associer principe, exemple et limite, non classer les pays selon une échelle unique de religiosité.

## Exercices : démarches, réponses et critères

### P05-E1 — Distinguer trois modèles {#corr-P05-E1}

Une religion officielle bénéficie d’un statut reconnu par le pouvoir politique. La séparation concerne l’organisation des rapports entre institutions publiques et religieuses. La sécularisation désigne des transformations de la place du religieux dans la société et les pratiques ; elle ne se déduit pas directement d’un article constitutionnel.

Une société peut connaître une forte pratique religieuse sans religion d’État, comme le montre le cas américain étudié dans le cours. Inversement, un statut officiel ne prouve pas une adhésion unanime. La réponse doit distinguer norme, institution et comportement. Les modèles historiques combinent ces dimensions de façons diverses ; les classer ne signifie pas attribuer automatiquement une valeur morale à tous les habitants.

**Critères observables.** Trois définitions ; droit/pratique ; exemple situé ; absence d’équivalence automatique.

**Reprise ciblée.** R2 : construire trois colonnes droit/institutions/pratiques.

### P05-E2 — Pouvoirs médiévaux : comparer sans confondre {#corr-P05-E2}

Charlemagne est couronné empereur à Rome en 800 dans une cérémonie où intervient le pape ; le lien politique et religieux nourrit la légitimation sans supprimer tous les rapports de force. Le calife abbasside revendique une autorité sur la communauté musulmane ; les relations avec les savants, les juristes et les pouvoirs régionaux limitent l’image d’un pouvoir religieux et politique parfaitement unifié. L’Empire byzantin associe empereur chrétien et institutions ecclésiastiques dans une coopération traversée de conflits, notamment autour des images.

La comparaison doit donc identifier des conceptions de l’autorité et leurs pratiques. Elle ne doit pas appeler indistinctement les trois systèmes « théocraties » sans explication. Des repères comme 800, la période abbasside et la fin de l’iconoclasme en 843 servent à situer des relations, pas à construire une synchronie artificielle de tous les faits.

**Critères observables.** Trois cas ; titres et institutions ; repères ; limites et différences.

**Reprise ciblée.** R1 pour les périodes ; R2 pour les catégories de pouvoir.

### P05-E3 — Le premier amendement américain {#corr-P05-E3}

Le premier amendement constitue une norme constitutionnelle. Le non-établissement limite l’instauration d’une religion par le Congrès ; le libre exercice protège la pratique religieuse dans le cadre juridique applicable. Les deux garanties distinguent l’action publique et les convictions, sans imposer l’absence de religion dans la société.

Le texte ne mesure pas la pratique des citoyens ni l’usage de références religieuses dans les discours politiques. Les symboles publics, les mobilisations et les débats judiciaires doivent être étudiés séparément. La limite du document n’enlève rien à son importance : il organise un cadre dont l’interprétation devient elle-même un enjeu. La correction doit donc éviter les deux excès « religion officielle » et « société sans religion ».

**Critères observables.** Nature et date ; deux garanties ; droit/pratiques ; limite précise.

**Reprise ciblée.** R4 : ne pas déduire une sociologie de la seule norme.

### P05-E4 — La Turquie : une laïcité qui organise aussi le religieux {#corr-P05-E4}

L’abolition du califat en 1924 fait partie de la rupture républicaine engagée après la fin de l’Empire ottoman. Elle ne signifie pas l’abolition des croyances ni de toute institution liée au religieux. La création de la Diyanet la même année montre une organisation et un contrôle publics de certaines affaires religieuses.

La laïcité turque doit donc être replacée dans un projet de construction étatique et de transformation sociale. Elle ne reproduit pas à l’identique tous les autres modèles de séparation. Les évolutions ultérieures montrent des tensions et des réinterprétations. Une comparaison avec les États-Unis ou la France doit expliciter les institutions et les pratiques, pas supposer que le même mot implique les mêmes dispositifs.

**Critères observables.** 1924 ; califat/Diyanet ; croyances/institutions ; modèles distincts.

**Reprise ciblée.** R2 : associer chaque institution à sa fonction.

### P05-E5 — L’Inde : majorité, pluralisme et droits {#corr-P05-E5}

La majorité religieuse désigne une répartition démographique ; elle ne constitue pas un acteur politiquement unanime. Le nationalisme hindou est un projet idéologique et politique qui définit la nation selon une certaine relation à l’hindouité. L’État indien est un ensemble d’institutions régi par un cadre constitutionnel et traversé de rapports de force.

Les garanties constitutionnelles ne démontrent pas que toutes les minorités bénéficient partout de la même sécurité ou de la même égalité effective. Il faut étudier décisions, discriminations, mobilisations et variations territoriales. Inversement, des tensions ne permettent pas d’effacer toute existence de garanties juridiques. La correction distingue donc norme, démographie, idéologie et pratiques sans attribuer une position unique à tous les hindous ou à tous les citoyens.

**Critères observables.** Trois objets distingués ; 1950/1976 ; portée normative ; pluralité des acteurs.

**Reprise ciblée.** R2 puis R4 : définir les objets avant de discuter la source.

### P05-E6 — Religion et conflit : éviter la cause unique {#corr-P05-E6}

Problématique : comment des identités religieuses s’articulent-elles à des rivalités territoriales et étatiques dans les tensions indo-pakistanaises ? I. La partition de 1947 et les constructions nationales donnent une place majeure aux identités religieuses, avec violences et déplacements. II. Les conflits portent aussi sur des territoires, des souverainetés et des stratégies, notamment au Cachemire ; les guerres et la nucléarisation en 1998 ne se réduisent pas à une opposition de croyances.

Le Bangladesh, indépendant en 1971, rappelle que des populations partageant une religion peuvent être opposées par des rapports politiques, linguistiques et territoriaux. Une conclusion rigoureuse ne nie pas la dimension religieuse, mais refuse d’en faire une explication exclusive. Un plan en trois parties peut distinguer héritages, territorialisation et stratégies, à condition de les relier.

**Critères observables.** Religion ni effacée ni exclusive ; 1947 ; Cachemire ; État/territoire/stratégie ; exemple de 1971.

**Reprise ciblée.** R3 : remplacer « parce qu’ils n’ont pas la même religion » par plusieurs mécanismes situés.

### P05-E7 — Composition : États et religions aux États-Unis {#corr-P05-E7}

**Problématique :** comment l’absence d’établissement religieux se combine-t-elle avec une présence importante de références et de mobilisations religieuses dans la vie publique ?

**Introduction modèle.** Le premier amendement américain protège le libre exercice et interdit au Congrès d’établir une religion. Pourtant, le religieux apparaît dans des symboles, des discours et des mobilisations politiques. Cette coexistence invite à distinguer le cadre institutionnel et les pratiques sociales plutôt qu’à conclure à une contradiction simple.

**Développement modèle condensé.** La séparation organise d’abord un cadre de liberté et de pluralisme. La norme constitutionnelle ne prescrit pas une croyance commune ; son interprétation fait l’objet de débats et de décisions judiciaires. L’absence de religion officielle n’implique donc pas que les convictions individuelles doivent disparaître de toute expression publique.

Le religieux intervient ensuite dans la construction de références collectives. Des symboles et des formules peuvent être utilisés dans la vie politique, tandis que les organisations religieuses participent à des mobilisations. Les engagements ne vont pas tous dans le même sens : les références chrétiennes peuvent nourrir les luttes pour les droits civiques comme d’autres projets politiques. Il faut identifier les acteurs et les contextes, non parler d’un bloc religieux unique.

Enfin, cette articulation produit des tensions sur les limites entre liberté, neutralité institutionnelle et influence. Les controverses sur l’école ou les politiques publiques montrent que les règles doivent être interprétées. La sécularisation des pratiques et la séparation juridique ne suivent pas nécessairement le même rythme.

**Conclusion modèle.** Le modèle américain combine une garantie institutionnelle de liberté et une présence publique du religieux. Sa compréhension exige de distinguer droit, pratiques et mobilisations, puis d’étudier les conflits qui redéfinissent leur relation. Une comparaison brève avec la Turquie peut éclairer la spécificité du modèle, mais ne doit pas remplacer l’analyse américaine demandée.

**Critères observables.** Cas américain central ; premier amendement ; pluralité des mobilisations ; articulation et tensions ; devoir complet.

**Reprise ciblée.** R2 si séparation=sécularisation ; R5 si les deux parties se contredisent sans explication.

### P05-E8 — Comparer trois modèles à l’oral {#corr-P05-E8}

La réponse doit partir d’une distinction : les modèles de relation entre État et religions combinent des normes et des histoires différentes. La Turquie républicaine associe rupture avec des institutions ottomanes et administration de certaines affaires religieuses. Les États-Unis articulent non-établissement, libre exercice et présence publique de mobilisations religieuses. L’Inde associe un cadre constitutionnel de pluralisme et des tensions liées aux rapports majoritaires et minoritaires.

Les trois critères évitent une simple liste de pays. La limite principale est l’écart entre modèle juridique et diversité des pratiques, qui changent selon les périodes et les territoires. On peut aussi préciser que la traduction d’un même terme ne garantit pas l’identité des concepts. Terminer par une conclusion comparative, non par un classement moral des populations.

**Critères observables.** Trois pays ; critères communs ; normes/pratiques ; limite historique et territoriale.

**Reprise ciblée.** R3 : préparer une phrase de comparaison pour chaque critère.

## QCM : comprendre chaque proposition

### P05-Q1 — Réponse A {#corr-P05-Q1}

**A.** Elle porte sur des pratiques et des relations sociales.

**B.** Une transformation n’équivaut pas à une disparition universelle.

**C.** Le statut institutionnel n’épuise pas les pratiques sociales.

### P05-Q2 — Réponse B {#corr-P05-Q2}

**A.** 1453 renvoie à la prise de Constantinople par les Ottomans.

**B.** 800 situe la cérémonie étudiée dans le jalon.

**C.** 1924 renvoie à l’abolition du califat en Turquie.

### P05-Q3 — Réponse C {#corr-P05-Q3}

**A.** Sa création contredit l’idée d’absence de toute administration.

**B.** Les histoires et les dispositifs institutionnels sont différents.

**C.** Elle illustre un contrôle et une organisation dans le cadre républicain.

### P05-Q4 — Réponse B {#corr-P05-Q4}

**A.** Il limite précisément l’établissement d’une religion par le Congrès.

**B.** Les deux garanties doivent être lues ensemble.

**C.** Il protège le libre exercice, sans abolir les convictions.

### P05-Q5 — Réponse A {#corr-P05-Q5}

**A.** Le Cachemire, les États et la nucléarisation complètent l’analyse identitaire.

**B.** La partition et les guerres sont des éléments indispensables.

**C.** Les populations et les projets politiques sont pluriels.

## P05-RT — Corrigé du nouveau test {#corr-P05-RT}

La séparation concerne les institutions ; la sécularisation les transformations sociales du religieux. En 1924, l’abolition du califat et la création de la Diyanet montrent une rupture et une réorganisation, pas l’abolition des croyances. Les tensions indo-pakistanaises comportent des enjeux territoriaux, notamment au Cachemire, des constructions nationales, des rapports militaires et des stratégies nucléaires ; ces facteurs s’articulent aux identités religieuses.

**Validation.** Réussite : trois réponses justifiées, avec notions distinguées et exemples situés. Une erreur de date appelle R1 ; une confusion de notion R2 ; une relation non expliquée R3. Refaire le point faible à J+2.

**À distance.** J+7 : Comparer 800, 1924 et 1947 sans mélanger les espaces. J+21 : Relier les identités et les territoires de P05 aux conflits de T02 en refusant une cause unique.

# T01 — Corriger et progresser {#corr-T01}

## T01-D — Diagnostic : réponses et orientation

Un drapeau n’établit pas à lui seul une propriété territoriale dans l’espace. Un SNLE contribue à la dissuasion nucléaire, tandis qu’un porte-avions permet notamment la projection aéronavale ; leurs fonctions ne sont pas interchangeables. Une coopération technique peut coexister avec des rivalités. Reprendre le cours sur les régimes juridiques et les instruments de puissance.

## T01-A — Activité du cours : éléments de correction

Pour une mission spatiale, l’investissement finance des équipes et des équipements ; la capacité obtenue peut produire des données et du prestige, sans garantir une domination générale. Pour un port, des infrastructures peuvent améliorer une connexion commerciale et fournir une capacité logistique. Les effets dépendent de l’usage, des accords et des relations avec l’État hôte. Le passage investissement → capacité → effet n’est pas automatique. Il faut distinguer propriété d’un équipement, gestion commerciale, accès militaire et souveraineté sur un territoire.

## Exercices : démarches, réponses et critères

### T01-E1 — Conquête et appropriation {#corr-T01-E1}

Le traité de l’espace de 1967 pose un principe de non-appropriation nationale de l’espace extra-atmosphérique, y compris la Lune et les autres corps célestes. Un drapeau manifeste une présence ou une réussite ; il ne suffit pas à créer une souveraineté. Dans une ZEE, l’État côtier dispose de droits souverains sur certaines ressources et de compétences définies, sans souveraineté intégrale sur toute circulation. La haute mer relève de libertés et d’obligations internationales et ne peut être appropriée par un État.

Les trois cas montrent qu’une capacité matérielle, une activité et un droit sont distincts. La correction doit éviter de présenter l’espace ou la mer comme des zones sans règles, mais aussi de leur appliquer automatiquement le modèle du territoire terrestre.

**Critères observables.** Trois régimes ; traité de 1967 ; droit/capacité ; aucune appropriation automatique.

**Reprise ciblée.** R2 : refaire la différence souveraineté/droits souverains/libertés.

### T01-E2 — Une chronologie spatiale explicative {#corr-T01-E2}

1957 : Spoutnik montre une capacité soviétique de mise en orbite et possède une portée stratégique et symbolique. 1961 : le vol de Gagarine renforce cette démonstration. 1969 : Apollo 11 permet aux États-Unis une réussite majeure dans la compétition lunaire. 1998 puis 2000 : assemblage de l’ISS et présence humaine continue illustrent une coopération durable. 2024 : le retour d’échantillons de la face cachée par Chang’e 6 montre une capacité chinoise spécifique.

Chaque repère associe recherche, technique, prestige et choix politiques selon des proportions variables. L’histoire ne se résume pas à une compétition identique entre les mêmes acteurs : les coopérations, entreprises et nouvelles puissances modifient les configurations. Les dates ne prouvent pas que chaque programme a tous les mêmes objectifs ou les mêmes résultats.

**Critères observables.** Cinq repères exacts ; fonctions ; 1998/2000 distingués ; configurations évolutives.

**Reprise ciblée.** R1 : construire une ligne du temps avec un verbe d’action par date.

### T01-E3 — Dissuasion et projection navales {#corr-T01-E3}

Le sous-marin nucléaire lanceur d’engins participe à la dissuasion en rendant crédible une capacité de riposte difficile à neutraliser. Sa discrétion est une condition importante. Le porte-avions offre des capacités aériennes mobiles et de projection ; sa présence peut également envoyer un signal politique. Les deux instruments n’ont donc pas le même rapport à la visibilité ni le même emploi.

Leur efficacité dépend de personnels, de renseignement, de logistique, d’escortes, de maintenance, de doctrines et de décisions politiques. Les adversaires disposent de moyens de contestation, et l’espace maritime est immense. Posséder un bâtiment prestigieux ne garantit pas la liberté d’action partout ni la réalisation d’un objectif politique. La comparaison doit porter sur les fonctions et les systèmes, pas sur un classement abstrait du navire « le plus puissant ».

**Critères observables.** Fonctions et visibilité ; chaîne de moyens ; deux limites ; résultat non automatique.

**Reprise ciblée.** R3 : relier chaque caractéristique à un effet stratégique.

### T01-E4 — L’ISS : une coopération sous conditions {#corr-T01-E4}

La coopération permet de partager des coûts élevés, de combiner des compétences et de réaliser des expériences qui nécessitent une infrastructure durable. Elle produit aussi des échanges et une visibilité internationale. Les contraintes comprennent la coordination technique, la dépendance réciproque, les calendriers, les financements et les décisions politiques.

Le document est une présentation institutionnelle d’un dispositif de coopération. Il ne démontre pas l’absence de rivalités entre les États partenaires ni leur accord sur toutes les autres questions. Une coopération sectorielle peut subsister dans un contexte de tensions. La conclusion recevable est donc que l’ISS organise une interdépendance maîtrisée dans un domaine précis, non qu’elle ferait disparaître la géopolitique.

**Critères observables.** Deux raisons ; deux contraintes ; nature institutionnelle ; coopération sectorielle/rivalité générale distinguées.

**Reprise ciblée.** R4 : préciser le champ de la conclusion autorisée par le document.

### T01-E5 — Droit maritime et coopération {#corr-T01-E5}

La convention de 1982 organise un cadre général des espaces maritimes, des droits et des obligations. L’accord BBNJ porte sur la conservation et l’utilisation durable de la biodiversité marine au-delà des juridictions nationales, avec notamment des outils de gestion par zone, des évaluations d’impact, le partage des avantages liés aux ressources génétiques et le renforcement des capacités. Il complète un cadre plutôt qu’il ne transforme toute la mer en espace sans juridictions.

Son entrée en vigueur le 17 janvier 2026 marque une étape juridique. L’application dépend ensuite des parties, des institutions, des moyens, de la coordination et du contrôle. Les rivalités de souveraineté, de ressources et de puissance navale ne disparaissent pas. Il faut donc distinguer adoption d’une règle, effectivité et résolution de tous les conflits.

**Critères observables.** Objets et espaces ; complémentarité ; date ; application et rivalités.

**Reprise ciblée.** R2 pour les régimes ; R3 pour la différence entrée en vigueur/résultat.

### T01-E6 — La Chine : capacités et effets de puissance {#corr-T01-E6}

I. Construire des capacités scientifiques, techniques et militaires : programmes spatiaux, missions comme Chang’e 6, développement naval et compétences industrielles. II. Transformer ces capacités en influence et en sécurité : présence, accès aux routes, prestige, partenariats et infrastructures. III, facultative : des effets limités ou contestés par le droit, les coûts et les réactions d’autres acteurs.

La problématique peut demander comment des investissements dans deux espaces stratégiques modifient la position internationale de la Chine sans lui garantir une maîtrise incontestée. Un port financé ou exploité commercialement n’est pas automatiquement une base militaire ; une revendication maritime n’est pas automatiquement reconnue. Le plan doit articuler les océans et l’espace plutôt que produire deux inventaires séparés. Une structure en deux parties capacités/limites est recevable si les effets sont expliqués.

**Critères observables.** Deux espaces ; quatre éléments imposés ; chaîne capacité/effet ; statut des infrastructures.

**Reprise ciblée.** R5 : remplacer les titres « mer » et « espace » par des relations explicatives.

### T01-E7 — Dissertation de formation hors rotation écrite 2027 {#corr-T01-E7}

**Problématique :** pourquoi la conquête d’espaces stratégiques alimente-t-elle des rivalités tout en imposant des formes de coopération ?

**Introduction modèle.** Océans et espace offrent des ressources, des possibilités scientifiques et des positions stratégiques. Leur maîtrise nécessite des capacités importantes et rencontre des règles juridiques. Ils ne sont donc ni des espaces vides à partager librement ni de simples lieux d’entente universelle.

**Développement modèle condensé.** La compétition porte sur la présence, l’accès et la démonstration de puissance. La course spatiale de la guerre froide transforme des réussites techniques en symboles politiques. Les capacités navales permettent dissuasion, projection et sécurisation de circulations. La Chine illustre une affirmation qui articule programmes scientifiques, infrastructures et capacités stratégiques. Mais la ressource possédée ne garantit pas l’effet recherché : coûts, compétences, contestations et réactions adverses interviennent.

Les contraintes favorisent aussi la coopération. L’ISS associe des partenaires qui partagent des capacités et des coûts. En mer, les règles de la convention de 1982 et les accords relatifs à la biodiversité organisent des droits et des responsabilités. La connaissance des milieux et la protection de ressources communes demandent des échanges. Ces dispositifs n’effacent pas les souverainetés ni les intérêts : ils encadrent certaines relations et rendent possibles des actions collectives.

La rivalité et la coopération peuvent donc coexister. Un État participe à une station commune tout en développant ses propres programmes ; il accepte des règles maritimes tout en défendant des revendications. Les résultats dépendent de la confiance, des moyens et des mécanismes d’application.

**Conclusion modèle.** Les nouveaux espaces de conquête concentrent des rapports de puissance, mais leur complexité crée aussi des interdépendances. Les analyser demande de relier capacités, droit et coopération, sans supposer que l’un de ces registres annule les autres.

**Critères observables.** Deux espaces ; rivalités et coopérations ; exemples ; droit ; distinction formation/écrit 2027.

**Reprise ciblée.** R3 si catalogue ; R5 si un seul espace est traité.

### T01-E8 — Présenter un schéma de conquête {#corr-T01-E8}

Pour une mission spatiale : financement et recherche → capacité de lancement et d’exploration → connaissances, prestige ou services → limites de coût, fiabilité et coopération. Pour un équipement naval : construction et formation → capacité de présence, de projection ou de dissuasion → influence sur un rapport stratégique → limites de logistique, vulnérabilité et décision politique.

Les chaînes sont des raisonnements, pas des preuves quantitatives du succès. Elles doivent être illustrées par des exemples du cours, comme Chang’e 6 et un système naval de dissuasion ou de projection. L’oral compare la nature de l’effet et la temporalité. Une réponse qui ne décrit que des performances techniques sans expliquer leur signification géopolitique manque la tâche.

**Critères observables.** Deux chaînes ; exemples ; effets ; limites ; trois minutes.

**Reprise ciblée.** R3 : ajouter « cela permet de… à condition que… » à chaque capacité.

## QCM : comprendre chaque proposition

### T01-Q1 — Réponse B {#corr-T01-Q1}

**A.** La présence ne crée pas un titre de souveraineté.

**B.** Le principe concerne notamment la Lune et les autres corps célestes.

**C.** Le traité ne supprime pas les possibilités de coopération.

### T01-Q2 — Réponse A {#corr-T01-Q2}

**A.** Novembre 2000 est le repère de la présence continue.

**B.** 1957 correspond à Spoutnik.

**C.** 1969 correspond à Apollo 11.

### T01-Q3 — Réponse C {#corr-T01-Q3}

**A.** Projection et dissuasion ne sont pas identiques.

**B.** Un moyen militaire ne garantit pas un résultat politique.

**C.** Leurs fonctions, visibilité et conditions d’emploi diffèrent.

### T01-Q4 — Réponse B {#corr-T01-Q4}

**A.** 2023 correspond à son adoption, pas à son entrée en vigueur.

**B.** Cette date est confirmée par le dépositaire des Nations unies.

**C.** 1982 est l’année d’adoption de la convention générale sur le droit de la mer.

### T01-Q5 — Réponse A {#corr-T01-Q5}

**A.** Il faut examiner propriété, droits, usages et capacités.

**B.** Un investissement n’équivaut pas à un transfert de souveraineté.

**C.** Les infrastructures peuvent avoir des effets stratégiques sans devenir toutes des bases.

## T01-RT — Corrigé du nouveau test {#corr-T01-RT}

La projection permet d’agir loin de ses bases ; la dissuasion cherche à empêcher une action adverse par la crédibilité d’un coût ou d’une riposte. L’ISS partage coûts et compétences mais crée des interdépendances techniques et politiques. Les espaces sont régis par des règles : non-appropriation spatiale, droits maritimes et délimitations. Une présence matérielle ou une revendication doit être distinguée d’un titre juridique reconnu.

**Validation.** Réussite : trois réponses justifiées, avec notions distinguées et exemples situés. Une erreur de date appelle R1 ; une confusion de notion R2 ; une relation non expliquée R3. Refaire le point faible à J+2.

**À distance.** J+7 : Restituer 1957, 1967, 1969, 1998/2000 et 2026 avec leur fonction. J+21 : Utiliser l’ISS pour expliquer la production collective des connaissances de T06.

# T02 — Corriger et progresser {#corr-T02}

## T02-D — Diagnostic : réponses et orientation

Une rivalité peut rester économique ou diplomatique sans devenir guerre. Un acteur non étatique peut poursuivre des objectifs politiques ; il n’est pas par définition irrationnel. Une victoire militaire ne garantit ni un accord durable ni une paix sociale. Reprendre Clausewitz et la distinction cessation des combats/construction de la paix.

## T02-A — Activité du cours : éléments de correction

Les traités de Westphalie organisent une sortie de guerres par la négociation entre acteurs, avec des compromis et des garanties ; ils ne suppriment pas toutes les guerres européennes. L’ONU introduit un cadre multilatéral de sécurité collective, dont l’action dépend notamment du Conseil de sécurité. En 1991, l’intervention contre l’Irak s’inscrit dans des résolutions autorisant l’usage de la force après l’invasion du Koweït. L’invasion de 2003 se déroule dans un contexte et avec une légitimité internationale contestés. Une comparaison de 250 mots doit montrer la différence entre cadre normatif, décision d’agir et résultats politiques, sans écrire que la victoire produit mécaniquement la paix.

## Exercices : démarches, réponses et critères

### T02-E1 — Nommer un conflit {#corr-T02-E1}

Une rivalité peut rester politique, économique ou diplomatique sans combat armé. Une guerre interétatique oppose des États ; une guerre civile se déroule principalement au sein d’un État, mais peut être internationalisée. Le terrorisme désigne un mode d’action violent visant notamment à produire un effet de peur sur un public plus large que les victimes immédiates, dans un but politique ; ses définitions juridiques varient selon les cadres.

Un groupe non étatique peut combattre sur un territoire, commettre des attentats et recevoir des appuis extérieurs. Il faut alors préciser chaque dimension plutôt que choisir une étiquette qui efface les autres. La correction ne doit pas assimiler une population à une organisation ni considérer tout conflit comme une guerre mondiale.

**Critères observables.** Quatre notions ; niveaux distingués ; combinaison expliquée ; acteurs non essentialisés.

**Reprise ciblée.** R2 : classer acteurs, méthodes et échelles dans trois colonnes.

### T02-E2 — Clausewitz sans formule simpliste {#corr-T02-E2}

Clausewitz relie la guerre à des fins politiques, mais ne prétend pas que chaque action serait parfaitement calculée. La friction désigne notamment les obstacles, incertitudes et difficultés qui éloignent l’action réelle du plan. Sa réflexion sur la montée aux extrêmes et la guerre absolue ne doit pas être confondue avec l’idée que toute guerre réelle serait une guerre totale mobilisant intégralement une société.

Les rapports entre passions, hasard et raison politique permettent d’interroger des configurations diverses. Appliquer ce cadre à des acteurs non étatiques demande des adaptations, mais ne justifie pas de les déclarer sans objectifs politiques. La correction doit donc conserver la fécondité du modèle tout en reconnaissant les différences historiques et les limites d’une transposition mécanique.

**Critères observables.** Politique ; friction ; absolue/totale ; acteurs non étatiques ; modèle non universalisé sans examen.

**Reprise ciblée.** R2 : refaire trois distinctions avant de rédiger.

### T02-E3 — De la guerre de Sept Ans aux guerres révolutionnaires {#corr-T02-E3}

La guerre de Sept Ans, de 1756 à 1763, associe rivalités européennes et affrontements coloniaux, notamment entre puissances britanniques et françaises. Elle ne se réduit donc pas à un conflit local. Les guerres révolutionnaires et napoléoniennes mobilisent de nouveaux ressorts politiques et des effectifs importants, notamment avec la levée en masse de 1793, dans un contexte de diffusion et de contestation de la Révolution puis de l’Empire.

La comparaison porte sur la relation entre buts politiques, société et moyens. Parler de guerre limitée peut éclairer certains objectifs dynastiques ou certaines pratiques, mais ne signifie pas absence de violence ni faible extension géographique. Parler de guerre totale pour toute la période napoléonienne serait également trop global. Il faut préciser ce qui change et selon quel critère.

**Critères observables.** Deux périodes ; dimension mondiale ; mobilisation ; critères et nuances.

**Reprise ciblée.** R1 pour les repères ; R3 pour les critères comparatifs.

### T02-E4 — Al-Qaïda et Daech : ressemblances et différences {#corr-T02-E4}

Les deux organisations mobilisent une idéologie djihadiste et des méthodes terroristes, mais leurs trajectoires et leurs organisations diffèrent. Al-Qaïda se développe comme un réseau transnational ; Daech combine notamment expansion territoriale en Irak et en Syrie, proclamation d’un « califat » en 2014, administration coercitive et attentats. Les liens entre centres et affiliés doivent être étudiés sans supposer une unité parfaite.

La perte de l’essentiel de l’emprise territoriale de Daech en 2019 détruit une capacité importante, mais ne supprime pas automatiquement des cellules, des réseaux, des ressources ou des mobilisations. Il faut distinguer territoire, organisation et capacité d’action. La correction ne présente ni ces groupes comme apolitiques ni leurs violences comme représentatives de tous les musulmans.

**Critères observables.** Comparaison ; territoire/réseau ; 2014/2019 ; persistance possible ; aucune assimilation collective.

**Reprise ciblée.** R2 sur organisation/territoire ; R3 sur la transformation des capacités.

### T02-E5 — Westphalie et sécurité collective {#corr-T02-E5}

Westphalie est un ensemble de règlements négociés dans une configuration européenne précise. Il contribue à réorganiser des relations politiques et confessionnelles, sans créer d’un coup toutes les caractéristiques de l’État moderne ni mettre fin à toutes les guerres européennes. La Charte de 1945 établit une organisation et des procédures de sécurité collective à vocation plus large, fondées sur des engagements d’États souverains.

Les objectifs de stabilisation se rejoignent, mais les instruments, les échelles et les contextes diffèrent. La mise en œuvre dépend de la coopération et des rapports de force. Les textes renseignent sur des règles et des objectifs, pas sur une paix automatiquement réalisée. La critique doit donc porter sur l’écart possible entre architecture et effectivité, sans réduire tout droit à un simple décor.

**Critères observables.** Deux contextes ; règlement/institution ; acteurs ; limites ; anachronismes évités.

**Reprise ciblée.** R4 : distinguer prescription, dispositif et résultat.

### T02-E6 — Construire la paix au Moyen-Orient {#corr-T02-E6}

I. Une opération militaire peut modifier un rapport de force sans régler les causes et les institutions. En 1991, l’objectif de libération du Koweït et le cadre de l’ONU doivent être distingués de l’invasion de 2003, de ses justifications et de la gestion de l’occupation. II. La paix exige un règlement politique, des garanties de sécurité, des institutions légitimes et des conditions de vie ; le conflit israélo-palestinien montre la persistance de questions territoriales, de droits, de reconnaissance et de sécurité malgré des accords ou des rapports militaires asymétriques.

Un plan en trois parties peut ajouter le rôle et les limites des acteurs extérieurs. Il faut éviter d’assimiler toutes les guerres de la région ou de réduire les populations à leurs gouvernements. La conclusion précise que victoire, cessation des combats, accord et paix durable sont des étapes distinctes, sans supposer qu’une seule mesure les produirait toutes.

**Critères observables.** 1991/2003 distincts ; conflit israélo-palestinien situé ; politique/sécurité/droits ; populations non assimilées.

**Reprise ciblée.** R5 si le plan devient un récit de toutes les guerres sans réponse à « suffit-elle ».

### T02-E7 — Dissertation : faire la paix {#corr-T02-E7}

**Problématique :** comment les acteurs organisent-ils la paix par des accords et des institutions, et pourquoi ces dispositifs restent-ils dépendants de conditions politiques ?

**Introduction modèle.** Faire la paix ne consiste pas seulement à arrêter les combats. Il faut établir des règles, traiter des différends et rendre crédibles des garanties. Des traités négociés aux dispositifs de sécurité collective, les formes de pacification se transforment sans supprimer les intérêts et les rapports de force.

**Développement modèle condensé.** Les traités de Westphalie de 1648 illustrent un règlement négocié de conflits européens. Les acteurs recherchent un ordre acceptable dans un contexte de violences et de divisions politiques et confessionnelles. Ce règlement ne crée pas instantanément un monde d’États identiques et ne met pas fin à toutes les guerres. Sa portée doit être définie historiquement.

La Charte des Nations unies de 1945 vise une organisation plus permanente de la sécurité collective. Le Conseil de sécurité dispose de responsabilités particulières, mais son fonctionnement dépend des États et des rapports entre grandes puissances. Sous Kofi Annan, les débats sur la protection des populations et les opérations de paix montrent à la fois des ambitions et des difficultés. Un mandat ne suffit pas sans moyens, consentement lorsque requis, coordination et stratégie politique.

Les conflits du Moyen-Orient permettent de tester cette différence entre instrument et résultat. La guerre de 1991 libère le Koweït dans un cadre international spécifique, mais ne règle pas tous les problèmes régionaux. En 2003, le renversement du régime irakien ne produit pas automatiquement des institutions stables. Dans le conflit israélo-palestinien, les négociations et accords ne suppriment pas les questions de territoires, de droits et de sécurité. La paix exige donc des conditions politiques et sociales durables.

**Conclusion modèle.** Accords et sécurité collective sont des instruments essentiels mais non autosuffisants. Leur efficacité dépend de la légitimité du règlement, des garanties, des moyens et de l’engagement des acteurs. La démonstration doit évaluer ces conditions plutôt qu’opposer naïvement « traités inutiles » et « paix garantie par le droit ».

**Critères observables.** Westphalie/ONU/cas régional ; instruments et effectivité ; dates ; réponse structurée.

**Reprise ciblée.** R3 pour les mécanismes ; R6 pour l’achèvement des deux grandes étapes.

### T02-E8 — Une objection à l’oral {#corr-T02-E8}

La réponse doit refuser une conclusion fondée sur un critère impossible : l’ONU n’est pas un gouvernement mondial disposant de moyens indépendants illimités. Elle fournit un cadre de négociation, des normes, des décisions de sécurité collective et des opérations dont les fonctions doivent être précisées. Des missions peuvent protéger, surveiller ou soutenir un processus sans résoudre seules toutes les causes du conflit.

Les limites comprennent les désaccords entre États, le veto, les moyens disponibles, la coopération des acteurs et l’absence de règlement politique. Un exemple comme l’action internationale autour de 1991 ou une opération étudiée dans le cours permet de montrer un effet concret et sa portée. La conclusion n’est ni une défense inconditionnelle ni un rejet total : l’utilité se juge fonction par fonction et cas par cas.

**Critères observables.** Deux fonctions ; exemple ; deux limites ; États/organisation ; réponse à l’objection.

**Reprise ciblée.** R3 : remplacer un jugement global par une évaluation située.

## QCM : comprendre chaque proposition

### T02-Q1 — Réponse C {#corr-T02-Q1}

**A.** Elle complique l’action sans supprimer toute finalité politique.

**B.** La notion est plus large que son sens mécanique.

**C.** Elle renvoie aux incertitudes, difficultés et effets du réel.

### T02-Q2 — Réponse A {#corr-T02-Q2}

**A.** Les affrontements européens s’articulent à des espaces coloniaux.

**B.** Cette réduction efface son extension.

**C.** Elle se déroule de 1756 à 1763.

### T02-Q3 — Réponse B {#corr-T02-Q3}

**A.** La portée des traités n’est pas universelle ni définitive.

**B.** Il faut situer acteurs, conflits et compromis.

**C.** L’ONU est créée en 1945.

### T02-Q4 — Réponse C {#corr-T02-Q4}

**A.** Territoire et réseau ne disparaissent pas automatiquement ensemble.

**B.** Les dimensions idéologiques et politiques demeurent à analyser.

**C.** Cette distinction permet d’étudier les transformations de l’organisation.

### T02-Q5 — Réponse A {#corr-T02-Q5}

**A.** Le cadre de 1991 et les justifications de 2003 diffèrent.

**B.** L’identité de mandat est une erreur majeure.

**C.** Les objectifs et les conséquences politiques sont centraux.

## T02-RT — Corrigé du nouveau test {#corr-T02-RT}

Une victoire modifie un rapport militaire ; un cessez-le-feu suspend les combats ; une paix durable demande un règlement et des garanties. Clausewitz aide à relier guerre et politique et à penser la friction, mais sa transposition à chaque conflit exige un examen historique. Westphalie organise des règlements négociés ; l’ONU fournit une institution et des procédures de sécurité collective. Aucun instrument n’agit sans acteurs, moyens et conditions politiques.

**Validation.** Réussite : trois réponses justifiées, avec notions distinguées et exemples situés. Une erreur de date appelle R1 ; une confusion de notion R2 ; une relation non expliquée R3. Refaire le point faible à J+2.

**À distance.** J+7 : Restituer 1648, 1945, 1991 et 2003 avec ce qu’ils changent. J+21 : Relier la destruction patrimoniale de T04 aux violences et à la reconstruction de la paix.

# T03 — Corriger et progresser {#corr-T03}

## T03-D — Diagnostic : réponses et orientation

Une erreur de mémoire n’est pas nécessairement un mensonge intentionnel. Un jugement traite des responsabilités dans le périmètre d’une procédure, non l’histoire entière d’un événement. Respecter les mémoires n’oblige pas à déclarer toutes leurs affirmations factuelles également exactes. En cas de confusion, reprendre M3 et la distinction faits/interprétations/usages.

## T03-A — Activité du cours : éléments de correction

Un procès apporte une qualification, une procédure et des faits établis dans son champ ; il ne constitue pas un récit total ni une garantie de réconciliation. Un mémorial transmet une reconnaissance publique et un rapport sensible au passé ; sa forme et son contexte doivent être expliqués. Un témoignage rend une expérience accessible ; il demande contextualisation et confrontation. Les trois contributions se complètent sans être substituables. La comparaison réussit si elle présente pour chacune un apport et une limite spécifique, plutôt que la même formule vague « il peut être subjectif ».

## Exercices : démarches, réponses et critères

### T03-E1 — Trois rapports au passé {#corr-T03-E1}

L’historien construit une connaissance critique à partir de sources confrontées et rend ses interprétations discutables. Une association entretient et transmet une mémoire située, susceptible de conserver des témoignages indispensables mais de sélectionner certains aspects du passé. Un tribunal statue dans un cadre procédural sur des faits et des responsabilités qualifiés juridiquement. Il ne tranche pas toutes les questions historiques.

Les trois peuvent utiliser des témoignages et des archives. Un procès rend des pièces accessibles ; une mémoire attire l’attention sur une expérience oubliée ; l’histoire contextualise une affirmation. Leur coopération suppose de ne pas confondre un jugement avec une histoire exhaustive ni une reconnaissance mémorielle avec la preuve automatique de chaque souvenir. Une réponse qui opposerait un historien toujours neutre à des témoins nécessairement trompeurs serait également erronée.

**Critères observables.** Trois finalités ; un point de coopération ; deux limites ; distinction entre preuve et reconnaissance.

**Reprise ciblée.** R2 : définir histoire, mémoire, justice avec un verbe d’action différent.

### T03-E2 — La responsabilité de 1914 : poser une controverse {#corr-T03-E2}

L’ouvrage de Fritz Fischer publié en 1961 réévalue la place des ambitions allemandes et la continuité de certains objectifs. Christopher Clark, dans Les Somnambules publié en 2012, déplace l’attention vers l’enchaînement de décisions et les interactions entre plusieurs acteurs. Ces orientations ne sont pas deux listes interchangeables de coupables : elles mobilisent des perspectives et des choix d’enquête.

Reconnaître des décisions serbes, austro-hongroises, allemandes, russes ou françaises n’impose pas de leur attribuer le même poids. Une explication examine les informations disponibles, les alternatives, les calendriers et les capacités d’action. Le jugement politique inscrit dans un traité de paix doit être distingué de ce travail. Il faut enfin éviter de prétendre avoir réfuté une œuvre entière à partir de son titre : le manuel présente ici une entrée dans une controverse, non une recension exhaustive.

**Critères observables.** Deux approches situées ; au moins deux critères d’enquête ; absence de partage égal automatique.

**Reprise ciblée.** R3 : remplacer « tous responsables » par deux mécanismes précisément attribués.

### T03-E3 — Nommer la guerre d’Algérie {#corr-T03-E3}

La loi modifie une désignation institutionnelle et participe à la reconnaissance d’une guerre longtemps décrite dans le langage officiel comme des opérations. Elle peut avoir une portée juridique et symbolique pour les personnes concernées. Le conflit, ses violences et ses conséquences avaient cependant déjà fait l’objet de témoignages, de recherches et de débats avant 1999.

Les expériences des indépendantistes, appelés, militaires de carrière, pieds-noirs, harkis et civils ne se réduisent pas à une mémoire commune. Les relations entre la France et l’Algérie pèsent aussi sur les usages du passé. Nommer une guerre ne règle donc pas toutes les questions de responsabilité, d’accès aux archives ou de reconnaissance. La formulation du document doit être située : elle renvoie à une loi française précise, et non à une décision imposant la même lecture à toutes les sociétés.

**Critères observables.** 1999 ; changement institutionnel ; savoir antérieur ; au moins deux groupes et une limite.

**Reprise ciblée.** R1 : établir une chronologie séparant conflit, indépendance et reconnaissance.

### T03-E4 — Deux justices, deux échelles {#corr-T03-E4}

Les gacaca sont des juridictions rwandaises mises en place pour traiter un très grand nombre d’affaires liées au génocide des Tutsi de 1994. Elles mobilisent une justice de proximité et des témoignages locaux. Elles répondent à une situation d’engorgement, mais soulèvent des questions de garanties procédurales, de pression sociale et de protection des témoins. Elles ne sont ni une institution de l’ONU ni un simple retour inchangé à une tradition.

Le TPIY, créé en 1993 par le Conseil de sécurité, juge des individus pour des crimes commis dans l’ex-Yougoslavie. Il contribue à établir des faits et à individualiser les responsabilités ; son éloignement, sa durée et sa réception politique limitent sa capacité à réconcilier directement les sociétés. Les différences n’interdisent pas la comparaison : elles montrent que juger, établir une vérité judiciaire et reconstruire des liens sociaux sont des objectifs liés mais non identiques.

**Critères observables.** Deux contextes ; statut exact ; responsabilité individuelle ; deux limites différentes.

**Reprise ciblée.** R2 : distinguer justice internationale, nationale et réconciliation.

### T03-E5 — Un lieu de mémoire n’explique pas tout seul {#corr-T03-E5}

Auschwitz-Birkenau conserve des traces du système concentrationnaire et du meurtre de masse. Leur force documentaire et sensible ne suffit pas : il faut expliquer la chronologie, les fonctions des espaces, les catégories de victimes et les politiques nazies. Un mémorial berlinois est une construction postérieure qui révèle aussi les choix de la société commémorante : implantation, dédicace, forme et date d’inauguration.

Le mémorial aux Juifs assassinés d’Europe inauguré en 2005 et celui consacré aux Sinti et Roms victimes du nazisme inauguré en 2012 n’ont pas la même histoire de reconnaissance. Les rapprocher permet d’examiner les temporalités mémorielles, sans rendre identiques des persécutions dont les modalités doivent être étudiées. Une médiation évite de transformer l’émotion en connaissance supposée complète. Elle peut expliquer ce qui est conservé, reconstruit, absent ou symbolique.

**Critères observables.** Distinction site/mémorial ; deux dates situées ; médiation ; génocides distingués.

**Reprise ciblée.** R3 : ajouter à chaque observation une explication de sa portée et une limite.

### T03-E6 — Écrire un plan sur justice et histoire {#corr-T03-E6}

Un plan recevable distingue deux opérations. I. Les procès rendent des crimes établissables et publiquement discutables : rassemblement d’archives et qualification à Nuremberg ; place des témoignages au procès Eichmann en 1961 ; mise en lumière de responsabilités françaises dans les procès Barbie, Touvier ou Papon. II. La connaissance et la transmission dépassent nécessairement le procès : champ limité à des accusés, règles de preuve, sélection des faits et réception politique ; travail historique, école, musées et œuvres assurent d’autres formes d’intelligibilité.

Une organisation en trois parties est aussi possible si elle distingue établissement des faits, transformation des mémoires et limites. La correction n’impose pas ce nombre. L’essentiel est d’éviter « pour/contre les procès » sans mécanisme. Un procès ne condamne pas juridiquement une société entière ; les analyses de ses structures relèvent d’un autre niveau d’enquête.

**Critères observables.** Problématique ; progression ; trois exemples situés ; limites du périmètre judiciaire.

**Reprise ciblée.** R5 : vérifier que chaque titre répond au verbe « permettent ».

### T03-E7 — Dissertation d’entraînement : des mémoires à l’histoire {#corr-T03-E7}

**Modèle condensé de correction.** Une commémoration, un témoignage et une enquête d’archives peuvent porter sur le même événement sans poursuivre la même finalité. Les mémoires transmettent des expériences et des appartenances ; l’histoire cherche une connaissance argumentée du passé. Pourquoi leur pluralité ne suffit-elle pas à établir cette connaissance ? Les mémoires sont des ressources irremplaçables, mais leur confrontation et leur contextualisation exigent des opérations qui les dépassent.

D’abord, les mémoires rendent perceptibles des expériences que les institutions peuvent avoir minorées. Les récits des rescapés, des familles ou des anciens combattants conservent des traces et suscitent de nouvelles questions. Les mémoires de la guerre d’Algérie révèlent ainsi des vécus qui ne se laissent pas ramener à un récit national unique. Les ignorer appauvrirait l’enquête historique.

Cependant, une expérience située ne donne pas spontanément accès à l’ensemble d’un événement. Le souvenir peut sélectionner, recomposer ou réinterpréter à partir du présent. L’historien interroge l’auteur, la date et les conditions de production, puis confronte le témoignage à d’autres pièces. Cela ne revient pas à traiter chaque témoin comme un suspect : la critique est une méthode appliquée à toutes les sources. La controverse sur les causes de 1914 montre également que le savoir avance par des questions, des archives et des interprétations discutées, non par addition de souvenirs.

Enfin, la reconnaissance publique et la qualification judiciaire contribuent à cette élaboration sans la clore. Un mémorial signale une volonté de transmission ; il doit être expliqué. Un procès établit des responsabilités dans son champ ; il ne produit pas une histoire totale. La coexistence des mémoires doit donc s’accompagner d’institutions, d’enquêtes et de débats capables de distinguer les faits établis, les interprétations et les usages politiques.

Les mémoires nourrissent ainsi l’histoire, mais leur seule juxtaposition ne remplace pas un savoir critique. Respecter les personnes n’oblige pas à tenir toutes les affirmations factuelles pour également fondées. Inversement, rechercher la vérité historique n’autorise pas à effacer la pluralité des expériences.

**Critères observables.** Définitions ; problématique ; exemples argumentés ; différence pluralité/relativisme ; conclusion.

**Reprise ciblée.** R4 : sélectionner un témoignage et expliquer ce qu’il prouve et ne prouve pas.

### T03-E8 — Présenter une œuvre sans la transformer en archive transparente {#corr-T03-E8}

Pour Shoah, on peut présenter le film de Claude Lanzmann sorti en 1985, fondé notamment sur des entretiens et des images de lieux filmés après les faits. L’œuvre fait entendre des paroles et confronte le présent des paysages à la destruction passée. Sa durée et ses choix de mise en scène participent à une expérience de transmission.

La limite n’est pas « un film est faux », mais son caractère construit et non exhaustif. Il ne dispense pas d’une chronologie ni d’autres sources. Pour Si c’est un homme, il faut distinguer l’expérience de Primo Levi, la rédaction et la première publication en 1947. Pour Nuit et Brouillard, sorti en 1955, il faut analyser montage, commentaire et contexte mémoriel. Une présentation honnête précise qu’elle repose sur l’étude du manuel et non sur une réception intégrale qui n’a pas eu lieu.

**Critères observables.** Œuvre précisément identifiée ; forme analysée ; apport ; limite et périmètre de consultation.

**Reprise ciblée.** R4 : remplacer le résumé du contenu par l’analyse d’un choix de forme.

## QCM : comprendre chaque proposition

### T03-Q1 — Réponse A {#corr-T03-Q1}

**A.** Elle sélectionne et transmet à partir d’une expérience ou d’un groupe.

**B.** La sélection et l’émotion n’impliquent pas automatiquement la fausseté.

**C.** Un témoignage doit être contextualisé et confronté.

### T03-Q2 — Réponse B {#corr-T03-Q2}

**A.** La CPI est une autre institution, avec une autre compétence.

**B.** Leur ancrage national et local doit être distingué du TPIR.

**C.** Cette proposition renvoie au TPIY, non aux gacaca.

### T03-Q3 — Réponse C {#corr-T03-Q3}

**A.** La responsabilité pénale ne s’étend pas automatiquement à un groupe.

**B.** Une décision judiciaire n’unifie pas toutes les mémoires.

**C.** Il juge des individus pour des crimes relevant de sa compétence.

### T03-Q4 — Réponse A {#corr-T03-Q4}

**A.** Son choix, sa date et sa forme appartiennent à une politique de mémoire.

**B.** Il porte également la marque du contexte de sa création.

**C.** Sa médiation et sa confrontation avec d’autres sources restent nécessaires.

### T03-Q5 — Réponse B {#corr-T03-Q5}

**A.** Le respect des personnes ne rend pas toutes les assertions exactes.

**B.** La confrontation des preuves reste une exigence de connaissance.

**C.** Les témoignages sont des sources, à critiquer comme les autres.

## T03-RT — Corrigé du nouveau test {#corr-T03-RT}

Les opérations attendues sont enquêter et confronter, se souvenir et transmettre, établir et juger une responsabilité. Exemples : Eichmann, 1961 ; mémorial berlinois aux Juifs assassinés d’Europe, 2005. La procédure peut établir des faits sans produire une reconnaissance partagée ; les acteurs peuvent contester la légitimité de l’institution et les tensions sociales demeurer. Cela ne rend pas le procès inutile : il faut distinguer ses effets et ses limites.

**Validation.** Réussite : trois réponses justifiées, avec notions distinguées et exemples situés. Une erreur de date appelle R1 ; une confusion de notion R2 ; une relation non expliquée R3. Refaire le point faible à J+2.

**À distance.** J+7 : Comparez deux usages publics d’un même événement. J+21 : Transférez la distinction mémoire/histoire à une commémoration locale.

# T04 — Corriger et progresser {#corr-T04}

## T04-D — Diagnostic : réponses et orientation

L’ancienneté n’entraîne pas automatiquement une patrimonialisation : des acteurs sélectionnent et reconnaissent. L’inscription UNESCO ne transfère pas la propriété. Restaurer suppose des choix d’état, de matériaux et d’usages ; il n’existe pas toujours un état originel unique accessible. Reprendre introduction et Doc1 avant le diagnostic suivant.

## T04-A — Activité du cours : éléments de correction

Pour l’atelier fictif, trois critères possibles sont sa valeur pour l’histoire du travail, les usages sociaux à maintenir et la faisabilité d’une conservation documentée. Deux risques sont l’effacement des traces et l’exclusion des habitants par une valorisation seulement touristique. Le bassin minier montre qu’une reconversion peut transmettre des héritages industriels ; Venise invite à intégrer la fonction résidentielle et les effets du tourisme. La décision doit préciser acteurs consultés et éléments conservés. Plusieurs solutions sont recevables dès lors que leurs coûts et leurs limites sont assumés.

## Exercices : démarches, réponses et critères

### T04-E1 — Patrimonialiser : une sélection {#corr-T04-E1}

On peut examiner la valeur documentaire du bâtiment pour l’histoire du travail, ses qualités architecturales ou techniques et la mémoire qu’y attachent les habitants. L’état de conservation, les usages possibles et les coûts doivent également être instruits. Anciens salariés, riverains, propriétaires, collectivités et spécialistes n’ont pas nécessairement la même priorité.

L’ancienneté seule ne prouve pas un intérêt patrimonial particulier ; inversement, un héritage récent peut être significatif. La rentabilité touristique ne mesure ni la transmission ni l’utilité sociale. Une décision argumentée suppose donc des critères explicites et une consultation. Elle peut retenir une conservation intégrale, partielle ou une réutilisation documentée, sans faire de l’une de ces réponses une solution automatique.

**Critères observables.** Trois critères ; deux acteurs ; sélection expliquée ; pas de solution automatique.

**Reprise ciblée.** R2 : définir patrimonialisation comme processus et non comme qualité naturelle.

### T04-E2 — Versailles : continuité et discontinuité {#corr-T04-E2}

En 1837, Louis-Philippe inaugure les galeries historiques pour inscrire des épisodes et des traditions dans un récit national. En 1871, la proclamation de l’Empire allemand dans la galerie des Glaces transforme un symbole français en théâtre d’une victoire allemande. En 1919, la signature du traité réinvestit ce même espace dans un rapport de force inversé.

Le bâtiment reste reconnaissable mais les acteurs, les publics et les récits changent. Le patrimoine fournit des ressources symboliques que des régimes réinterprètent. Une bonne réponse n’écrit pas que Versailles aurait toujours exprimé une même puissance française : précisément, 1871 contredit cette lecture. La conservation de la matière permet la superposition de mémoires, parfois antagonistes.

**Critères observables.** Trois repères exacts ; acteurs ; mécanisme de réinterprétation ; contre-exemple à la permanence.

**Reprise ciblée.** R1 : une frise à trois lignes séparant date, acteur et usage.

### T04-E3 — Parthénon : attribuer les arguments {#corr-T04-E3}

A privilégie la cohérence d’un ensemble monumental et son ancrage territorial. B privilégie la collection internationale et le titre d’acquisition revendiqué. La première position doit expliquer le traitement d’héritages aujourd’hui dispersés ; la seconde ne peut écarter les conditions historiques et les asymétries dans lesquelles les objets ont été déplacés. Les présenter fidèlement ne signifie pas les déclarer moralement équivalentes.

Un prêt organise une circulation temporaire et suppose souvent une formulation sur le propriétaire. Le retour matériel temporaire d’une sculpture ne résout donc pas nécessairement la reconnaissance du titre. L’analyse distingue appropriation historique, légalité alléguée, restitution et coopération muséale. Elle n’annonce pas un accord définitif absent du dossier.

**Critères observables.** Deux arguments attribués ; deux échelles ; statut éditorial ; différence prêt/propriété.

**Reprise ciblée.** R4 : souligner les verbes « revendique », « défend » et « conteste ».

### T04-E4 — Mali : reconstruire quoi ? {#corr-T04-E4}

Reconstruire les mausolées de Tombouctou ne revient pas seulement à remplacer des murs. Détruits en 2012, ces lieux participaient à des pratiques et à des appartenances que la violence cherchait à atteindre. Les habitants, artisans et autorités locales apportent des connaissances indispensables ; l’État et les partenaires internationaux, dont l’UNESCO, peuvent soutenir la documentation et les travaux. La restauration réactive ainsi une capacité collective de transmission.

La CPI a condamné Al Mahdi en 2016 pour le crime de guerre d’attaques contre des bâtiments religieux et historiques. Son rôle est judiciaire, non architectural. La reconnaissance du crime et la reconstruction peuvent se compléter, mais aucune ne supprime la perte ni toutes les tensions. Un paragraphe solide identifie ces fonctions au lieu d’attribuer l’ensemble des opérations à une organisation internationale unique.

**Critères observables.** 2012/2016 ; acteurs locaux ; usages ; rôles UNESCO/CPI distingués.

**Reprise ciblée.** R3 : relier chaque acteur à une opération concrète.

### T04-E5 — Venise : construire un indicateur pertinent {#corr-T04-E5}

Les visiteurs augmentent de 20 %, les résidents diminuent de 4 % et les logements permanents de 10 %. Les trois indicateurs évoluent donc dans des directions dont la signification sociale diffère. Une hausse de recettes ou de visibilité pourrait accompagner une réduction de la fonction résidentielle ; elle ne démontre pas, à elle seule, une transmission réussie.

À Venise, le cours invite à étudier tourisme, logement, mobilités, risques physiques et conservation. Les chiffres fictifs servent uniquement à apprendre un calcul et une prudence interprétative. On ne peut pas les citer comme une statistique vénitienne. Pour établir un diagnostic réel, il faudrait des données datées, un périmètre, la distinction excursionnistes/séjours et des informations sur les habitants.

**Critères observables.** 20 %, −4 %, −10 % ; évaluation multicritère ; fiction explicitement maintenue.

**Reprise ciblée.** R2 : écrire sous chaque taux son dénominateur et son périmètre.

### T04-E6 — Une politique française à plusieurs échelles {#corr-T04-E6}

I. L’État organise des instruments durables : services, protections juridiques et politique culturelle, notamment les monuments historiques et les secteurs sauvegardés. Il définit des cadres, apporte une expertise et peut financer. II. La patrimonialisation et la transmission reposent sur un réseau d’acteurs : collectivités, associations, habitants et professionnels contribuent à la reconversion du bassin minier ; familles et praticiens transmettent le repas gastronomique, inscrit au patrimoine immatériel en 2010. L’UNESCO ajoute une reconnaissance internationale sans se substituer aux acteurs.

Ce plan en deux parties est recevable s’il évite de réduire les autres acteurs à de simples exécutants. On peut également organiser la réponse par étapes : sélectionner, protéger, transmettre. Le nombre de parties est secondaire ; la répartition des fonctions et les exemples doivent démontrer une action à plusieurs échelles.

**Critères observables.** Fonctions distinguées ; trois exemples ; habitants/praticiens ; rôle limité du label.

**Reprise ciblée.** R5 : remplacer une liste d’institutions par une répartition des opérations.

### T04-E7 — Dissertation : conserver ou transformer ? {#corr-T04-E7}

**Modèle condensé de correction.** Une ville patrimoniale continue d’être habitée ; un savoir-faire ne survit que s’il est pratiqué. Protéger le patrimoine paraît pourtant exiger le maintien de traces contre les destructions. Faut-il donc empêcher toute transformation ? La protection impose des limites au changement, mais sa réussite repose souvent sur des transformations encadrées et socialement discutées.

D’abord, conserver suppose de résister à des destructions irréversibles. Les protections des monuments et des ensembles urbains reconnaissent que la seule décision d’un propriétaire ou la rentabilité immédiate ne suffisent pas. Les attaques contre les mausolées de Tombouctou montrent également que détruire un héritage peut viser une société et ses transmissions. Documenter, protéger et restaurer répondent à cette vulnérabilité.

Cependant, la fixité absolue est souvent impossible et parfois contraire à l’objectif. Les bâtiments vieillissent ; les normes d’accessibilité et les usages évoluent. À Paris, une politique patrimoniale doit articuler conservation et vie urbaine. Dans le bassin minier, la réutilisation de lieux industriels peut transmettre l’histoire du travail tout en leur donnant de nouvelles fonctions. La transformation ne signifie donc pas nécessairement l’effacement, à condition que les traces et leur interprétation soient préservées.

Enfin, les arbitrages concernent les communautés qui vivent avec ces héritages. À Venise, une conservation accompagnée d’une disparition des fonctions résidentielles poserait un problème de transmission sociale. Le repas gastronomique rappelle, pour sa part, qu’un patrimoine immatériel ne se protège pas comme une façade : il doit pouvoir être transmis et réapproprié. La qualité d’une politique se mesure donc à plusieurs critères, non au seul nombre de visiteurs.

Protéger ne revient ainsi ni à tout figer ni à autoriser toute conversion. Il faut déterminer les valeurs, les traces et les usages essentiels, documenter les changements et associer les acteurs concernés. La tension entre conservation et transformation est constitutive de la politique patrimoniale ; elle appelle des décisions argumentées plutôt qu’une solution universelle.

**Critères observables.** Définitions ; tension analysée ; trois jalons ; acteurs ; conclusion conditionnelle argumentée.

**Reprise ciblée.** R5 : transformer chaque partie en réponse distincte à la question.

### T04-E8 — Conseil municipal : défendre un arbitrage {#corr-T04-E8}

Une combinaison d’espace de mémoire et d’usages quotidiens peut être défendue si elle conserve des éléments significatifs, permet un financement réaliste et répond aux besoins des habitants. Le bassin minier fournit un exemple de changement de regard sur les héritages du travail. Venise invite à ne pas confondre attractivité et maintien d’une ville habitée.

Deux risques possibles sont l’effacement des traces par une rénovation trop radicale et l’exclusion sociale provoquée par la hausse des coûts. Il faut consulter anciens salariés, riverains, propriétaire, collectivité et spécialistes. D’autres choix sont recevables : un musée intégral peut être justifié par une valeur exceptionnelle et un financement soutenable ; des logements peuvent préserver une partie documentée du bâti. L’oral doit rendre l’arbitrage explicite et reconnaître ce qu’il sacrifie.

**Critères observables.** Décision ; critères ; risques ; acteurs ; deux comparaisons pertinentes.

**Reprise ciblée.** R3 : expliquer le coût ou la limite de votre propre proposition.

## QCM : comprendre chaque proposition

### T04-Q1 — Réponse A {#corr-T04-Q1}

**A.** Elle résulte d’acteurs, de critères et de décisions.

**B.** L’ancienneté n’entraîne pas automatiquement une protection.

**C.** L’inscription ne fait pas de l’UNESCO le propriétaire.

### T04-Q2 — Réponse B {#corr-T04-Q2}

**A.** Louis XIV est mort en 1715 ; il s’agit d’un réemploi ultérieur.

**B.** La monarchie de Juillet investit le lieu dans un récit national.

**C.** Le traité de 1919 constitue un autre usage du lieu.

### T04-Q3 — Réponse C {#corr-T04-Q3}

**A.** L’inscription ne prescrit pas un menu unique à tous.

**B.** Elle ne se réduit pas à un droit de marque.

**C.** Le patrimoine immatériel repose sur des pratiques reconnues et transmises.

### T04-Q4 — Réponse A {#corr-T04-Q4}

**A.** La condamnation de 2016 porte sur un crime de guerre.

**B.** Les inscriptions patrimoniales relèvent d’un autre dispositif.

**C.** La restauration relève d’acteurs locaux et de partenaires spécialisés.

### T04-Q5 — Réponse B {#corr-T04-Q5}

**A.** La fréquentation ne mesure pas tous les effets.

**B.** Une évaluation patrimoniale doit intégrer les habitants et la transmission.

**C.** Le tourisme peut contribuer à la protection ; ses effets dépendent des conditions.

## T04-RT — Corrigé du nouveau test {#corr-T04-RT}

Patrimonialiser est sélectionner et reconnaître un héritage à transmettre ; valoriser est le rendre accessible, intelligible ou utile, avec des effets à évaluer. Versailles superpose des usages politiques ; le bassin minier transforme un héritage industriel en ressource mémorielle et territoriale. Conservation des traces, transmission des savoir-faire et maintien d’usages pour les habitants sont des critères recevables. Leur choix doit être justifié.

**Validation.** Réussite : trois réponses justifiées, avec notions distinguées et exemples situés. Une erreur de date appelle R1 ; une confusion de notion R2 ; une relation non expliquée R3. Refaire le point faible à J+2.

**À distance.** J+7 : Analysez les acteurs d’un patrimoine de votre environnement. J+21 : Construisez un paragraphe sur une tension conservation/usage sans exemple appris par cœur.

# T05 — Corriger et progresser {#corr-T05}

## T05-D — Diagnostic : réponses et orientation

Une forêt exploitée peut être gérée pour son renouvellement, sans que cette intention garantisse toujours le résultat. Une semaine froide locale ne réfute pas une tendance climatique mondiale. La signature d’un accord ne démontre pas son application ni l’atteinte des objectifs. Reprendre les échelles et la chaîne norme → politique → résultat.

## T05-A — Activité du cours : éléments de correction

Le +1,1 °C porte sur une moyenne mondiale de 2011–2020 relativement à 1850–1900, non sur la température de chaque lieu. Une semaine froide est une observation météorologique locale ; la comparaison directe serait invalide. Réduire des émissions énergétiques relève de l’atténuation ; adapter un quartier aux fortes chaleurs relève de l’adaptation. Certaines mesures peuvent combiner les deux fonctions, mais elles doivent être expliquées. La qualité de la réponse tient à la précision des périodes et des mécanismes, non à une profession de foi climatique.

## Exercices : démarches, réponses et critères

### T05-E1 — Exploiter n’est pas nécessairement détruire {#corr-T05-E1}

Exploiter consiste à utiliser une ressource ; conserver peut viser son renouvellement et la continuité d’un usage ; préserver insiste sur la limitation d’interventions ; protéger désigne un ensemble de mesures contre des risques. Ces termes se recouvrent partiellement selon les contextes : il faut les définir dans la situation étudiée.

L’ordonnance de 1669 sous Colbert encadre les usages forestiers dans une logique de ressources, de puissance et d’administration. Elle n’est pas une politique climatique contemporaine. Une réglementation peut ainsi limiter certaines coupes pour garantir du bois à long terme. Les politiques forestières ultérieures intègrent d’autres objectifs, dont biodiversité, loisirs et risques. L’exemple évite deux erreurs : toute exploitation serait destruction ; toute protection ancienne aurait déjà la même motivation écologique qu’aujourd’hui.

**Critères observables.** Quatre notions ; 1669 ; finalité productive ; évolution historique.

**Reprise ciblée.** R2 : écrire pour chaque mot une opération et une finalité.

### T05-E2 — Deux transformations, pas une cause unique {#corr-T05-E2}

La néolithisation est un processus long et inégal selon les régions, associant notamment agriculture, domestication et transformations des paysages. Elle modifie les sols, les habitats et les relations aux ressources. L’industrialisation, à partir de foyers particuliers, change les échelles de production, d’extraction et de circulation, avec un rôle majeur des énergies fossiles.

Affirmer une action humaine ancienne ne démontre pas l’identité de tous ses effets. Le réchauffement contemporain exige d’expliquer l’accumulation de gaz à effet de serre, les usages énergétiques et les responsabilités différenciées. Les sociétés n’ont ni les mêmes techniques ni les mêmes volumes d’émission. Une explication historique évite donc une culpabilité abstraite et intemporelle de « l’homme » ; elle identifie des systèmes et leurs changements.

**Critères observables.** Deux temporalités ; techniques ; énergie fossile ; absence de déterminisme intemporel.

**Reprise ciblée.** R1 : construire une frise avec des durées et non seulement deux dates.

### T05-E3 — Lire un indicateur climatique {#corr-T05-E3}

L’indicateur est une variation de température moyenne de surface à l’échelle mondiale. La période 2011–2020 est comparée à la référence 1850–1900. Le nombre ne désigne ni une température absolue ni une hausse identique en tout lieu. Il doit être accompagné de ces précisions pour être interprétable.

Une semaine froide locale concerne une autre échelle spatiale et temporelle. Elle ne suffit donc pas à réfuter une tendance moyenne mondiale. Cela ne signifie pas que toute observation locale serait sans intérêt : les séries locales contribuent à la connaissance lorsqu’elles sont traitées et confrontées selon une méthode. La correction attend la distinction météo/climat, pas un rejet des données qui dérangent une opinion.

**Critères observables.** Quatre éléments de lecture ; météo/climat ; aucune généralisation à chaque lieu.

**Reprise ciblée.** R2 : accompagner chaque nombre de son unité, périmètre et période.

### T05-E4 — Le Petit Âge glaciaire : raisonner sans monocausalité {#corr-T05-E4}

Des variations climatiques peuvent affecter les rendements, les calendriers agricoles et les approvisionnements. Dans des sociétés où une grande partie des ressources dépend des récoltes, une série de mauvaises années peut accroître les tensions sur les prix. Mais la transformation d’un aléa en catastrophe dépend aussi des réserves, des transports, de la fiscalité, des conflits et des inégalités d’accès à la nourriture.

Le Petit Âge glaciaire désigne des tendances variables selon les espaces et les périodes, non plusieurs siècles uniformément froids. Une révolte ne peut donc être déduite mécaniquement d’une baisse de température. L’analyse doit confronter indices climatiques et sources sociales. La notion de vulnérabilité permet de comprendre pourquoi des populations exposées à des aléas comparables peuvent subir des effets différents.

**Critères observables.** Chaîne causale ; deux médiations sociales ; variabilité ; notion de vulnérabilité.

**Reprise ciblée.** R3 : insérer au moins deux étapes entre aléa et conséquence politique.

### T05-E5 — Accord, contribution et application {#corr-T05-E5}

L’objectif collectif donne une direction commune ; les contributions nationales permettent une participation différenciée ; la révision et la transparence cherchent à soutenir une progression. Cette architecture tient compte de souverainetés et de situations économiques différentes. Elle ne crée pas une autorité mondiale capable de décider et de faire appliquer seule toutes les politiques énergétiques.

L’adoption d’un texte n’est pas son entrée en vigueur, et une contribution annoncée n’est pas encore une baisse constatée des émissions. Il faut examiner les lois, les investissements, les financements et les trajectoires mesurées. La limite n’implique pas que l’accord serait sans effet : il fournit un cadre de comparaison, de négociation et de mobilisation. La réponse doit tenir ensemble production de normes et dépendance à leur mise en œuvre.

**Critères observables.** Architecture expliquée ; quatre étapes distinguées ; intérêt et limite.

**Reprise ciblée.** R2 : quatre colonnes « texte », « engagement », « politique », « résultat ».

### T05-E6 — États-Unis : pluralité des acteurs {#corr-T05-E6}

I. Le niveau fédéral dispose d’instruments puissants : parcs, lois, agences et diplomatie. Les choix présidentiels et législatifs orientent les normes et les engagements internationaux. II. Les politiques résultent néanmoins de tensions entre niveaux et acteurs : États fédérés et villes peuvent agir selon leurs compétences ; entreprises, associations et groupes professionnels défendent des intérêts différents ; les décisions peuvent être contestées en justice.

Les retraits et retours dans l’accord de Paris montrent une alternance fédérale, non une disparition de tous les acteurs américains de l’action climatique. Le second retrait de Paris prend effet le 27 janvier 2026. La notification distincte de retrait de la Convention-cadre, reçue le 27 février 2026, prévoit un effet au 27 février 2027 : au 8 septembre 2026, cette seconde échéance est future. Une copie doit dater ses informations et ne pas fusionner les deux traités.

**Critères observables.** Deux échelles au minimum ; compétences ; intérêts ; chronologie et traités distingués.

**Reprise ciblée.** R1 : deux frises séparées Paris/Convention-cadre.

### T05-E7 — Dissertation : une gouvernance à l’épreuve {#corr-T05-E7}

**Modèle condensé de correction.** Une émission atmosphérique, un cours d’eau ou un écosystème ne s’arrêtent pas nécessairement à la frontière. Pourtant, les décisions de production et de protection restent largement prises par des acteurs dotés de compétences territoriales. Pourquoi une coopération nécessaire est-elle si difficile ? Les interdépendances imposent des coordinations, tandis que les responsabilités, les moyens et les intérêts divergent.

D’abord, les problèmes environnementaux articulent plusieurs échelles. La gestion d’une forêt peut relever de décisions locales et nationales, tout en contribuant à des enjeux plus larges de biodiversité et de climat. Pour les gaz à effet de serre, l’accumulation mondiale rend insuffisante une action isolée. La connaissance scientifique, produite et discutée collectivement, permet d’établir ces interdépendances. Le GIEC ne gouverne pas les États : il évalue des travaux qui éclairent leurs décisions.

Ensuite, la coopération bute sur des asymétries. Les contributions historiques aux émissions, les besoins de développement, la dépendance aux ressources et les capacités de financement diffèrent. Les coûts d’une transition ne sont pas répartis de manière spontanément acceptée. À l’intérieur même des États, des territoires, entreprises et groupes sociaux peuvent défendre des intérêts divergents. L’exemple américain montre que ni un pays ni son gouvernement ne constituent une volonté durablement homogène.

Enfin, les institutions tentent d’organiser une action sans abolir ces différences. Les conférences internationales, les conventions et les contributions nationales produisent des objectifs et des procédures. L’accord de Paris de 2015 illustre une coopération large reposant sur des engagements différenciés et révisables. Son existence ne prouve pas que les politiques et les financements atteignent déjà l’objectif ; elle permet néanmoins de rendre les engagements comparables et discutables.

La difficulté de la coopération n’invalide donc pas sa nécessité. Elle oblige à examiner précisément les instruments, les rapports de force et les résultats. Protéger l’environnement requiert une articulation entre savoirs, règles, financements et décisions locales, plutôt que l’attente d’une solution mondiale unique et instantanée.

**Critères observables.** Échelles ; causalités ; responsabilités différenciées ; instruments ; limites sans fatalisme.

**Reprise ciblée.** R3 : transformer chaque difficulté citée en mécanisme expliqué.

### T05-E8 — Contredire une objection à l’oral {#corr-T05-E8}

La possibilité de retrait révèle une limite réelle de la coopération entre États souverains. Elle ne démontre pas l’absence de fonction des accords : ceux-ci fixent des objectifs, organisent la transparence, rendent des engagements comparables et peuvent soutenir des financements ou des mobilisations. Les effets doivent être examinés, non présumés.

Deux limites sont l’insuffisance des politiques d’application et leur instabilité politique. Le retrait américain de Paris devenu effectif en janvier 2026 illustre cette dernière, sans faire disparaître l’accord pour les autres parties ni toutes les actions des États fédérés, villes et entreprises. Une réponse solide conclut que l’efficacité d’un accord est graduée et dépend de mécanismes précis. Elle ne remplace pas l’assertion « rien » par une promesse inverse selon laquelle le texte suffirait à résoudre la crise.

**Critères observables.** Objection reconnue ; deux fonctions ; deux limites ; exemple exact ; conclusion nuancée.

**Reprise ciblée.** R5 : construire « fait admis → inférence contestée → réponse étayée ».

## QCM : comprendre chaque proposition

### T05-Q1 — Réponse B {#corr-T05-Q1}

**A.** Cette lecture projetterait des catégories actuelles sans contexte.

**B.** La gestion forestière participe à des besoins économiques et de puissance.

**C.** Encadrer les usages ne signifie pas supprimer toute exploitation.

### T05-Q2 — Réponse C {#corr-T05-Q2}

**A.** Les échelles et les périodes ne sont pas comparables.

**B.** Une observation ponctuelle ne démontre pas la stabilité à long terme.

**C.** Il faut distinguer météo locale et indicateur climatique global.

### T05-Q3 — Réponse A {#corr-T05-Q3}

**A.** Réduire les émissions ou renforcer les puits agit sur les causes.

**B.** L’adaptation vise davantage la réduction de vulnérabilité aux effets.

**C.** Aucune politique ne vise à rendre la météo parfaitement constante.

### T05-Q4 — Réponse B {#corr-T05-Q4}

**A.** L’annonce doit être distinguée du résultat constaté.

**B.** Son effectivité exige une analyse de mise en œuvre.

**C.** L’architecture de Paris repose sur des contributions différenciées.

### T05-Q5 — Réponse C {#corr-T05-Q5}

**A.** Janvier 2026 concerne l’accord de Paris, autre instrument.

**B.** Les deux textes et leurs procédures doivent être distingués.

**C.** La notification du 27 février 2026 prévoit cette échéance future ; une veille reste nécessaire.

## T05-RT — Corrigé du nouveau test {#corr-T05-RT}

Une exploitation encadrée peut chercher le renouvellement d’une ressource ; ses effets doivent être évalués. L’atténuation agit sur les causes, par exemple la réduction d’émissions liées à une production ; l’adaptation réduit la vulnérabilité, par exemple un aménagement contre les chaleurs. Une difficulté de coopération peut venir de coûts de transition inégalement supportés, de dépendances économiques ou d’un désaccord sur les financements. L’explication doit relier intérêt, décision et conséquence.

**Validation.** Réussite : trois réponses justifiées, avec notions distinguées et exemples situés. Une erreur de date appelle R1 ; une confusion de notion R2 ; une relation non expliquée R3. Refaire le point faible à J+2.

**À distance.** J+7 : Analysez une mesure en distinguant objectif, instrument et effet. J+21 : Appliquez le raisonnement d’échelle à un problème d’eau ou de biodiversité.

# T06 — Corriger et progresser {#corr-T06}

## T06-D — Diagnostic : réponses et orientation

Des données deviennent connaissance par leur mise en relation, leur interprétation et leur validation. Une découverte peut associer l’intuition d’une personne et des instruments, institutions et savoirs collectifs. La localisation d’un serveur ne prouve pas la responsabilité de son gouvernement : les infrastructures peuvent être détournées. Reprendre la différence indice, hypothèse et attribution.

## T06-A — Activité du cours : éléments de correction

La note sur le rançongiciel doit séparer les faits fournis — indisponibilité, demande de rançon ou indices techniques effectivement mentionnés — des hypothèses sur l’auteur et le mobile. Il faut rechercher journaux techniques, chronologie, sauvegardes et périmètre des données touchées. L’université peut partager des indicateurs avec une autorité nationale ; un partenaire étranger peut aider à identifier une infrastructure ou une campagne similaire. Ce partage pose des limites de confidentialité, de fiabilité et de compétence juridique. Il ne faut ni accuser un État sur la seule adresse d’un serveur ni promettre une attribution certaine à partir du dossier fictif.

## Exercices : démarches, réponses et critères

### T06-E1 — Du document au savoir {#corr-T06-E1}

Une donnée peut être un nombre issu d’une observation. Elle devient informative lorsqu’on précise ce qu’elle mesure : par exemple un taux d’alphabétisation pour une population, une année et une définition données. Construire une connaissance suppose ensuite de comparer les séries, de comprendre les méthodes et d’expliquer les mécanismes sociaux et scolaires susceptibles de rendre compte de l’évolution.

Un moteur de recherche facilite l’accès à des contenus, mais ne garantit ni leur exactitude ni leur compréhension. Il faut lire les sources, identifier les dénominateurs, distinguer corrélation et causalité et mobiliser des repères. La disponibilité de l’information ne remplace pas l’apprentissage des méthodes qui permettent de l’évaluer. Une autre chaîne est recevable si elle conserve ces trois niveaux et ne présente pas toute interprétation comme une connaissance validée.

**Critères observables.** Trois niveaux ; exemple d’alphabétisation ; définition et période ; rôle de l’apprentissage.

**Reprise ciblée.** R2 : reformuler donnée/information/connaissance avec le même exemple.

### T06-E2 — Qui produit une découverte ? {#corr-T06-E2}

Une chaîne recevable comporte : 1896, Becquerel observe des rayonnements de sels d’uranium ; 1898, Marie et Pierre Curie identifient polonium et radium par des recherches et mesures ; 1934, Irène et Frédéric Joliot-Curie mettent en évidence la radioactivité artificielle ; fin des années 1930, les travaux de Hahn et Strassmann et l’interprétation de Meitner et Frisch éclairent la fission.

Les instruments, laboratoires, matériaux, publications et échanges permettent ces avancées. La chaîne ne signifie pas que chaque étape aurait été inévitable ni que seuls les noms cités auraient contribué. Rutherford, Soddy, Chadwick et de nombreux techniciens et institutions interviennent également. Le développement d’applications militaires et civiles mobilise ensuite des organisations et des moyens de grande ampleur. La correction distingue donc découverte, explication d’un phénomène, dispositif technique et choix d’application.

**Critères observables.** Quatre étapes datées ; radioactivité artificielle/fission distinguées ; au moins trois conditions collectives.

**Reprise ciblée.** R1 pour les dates et acteurs ; R3 pour expliquer le rôle des échanges.

### T06-E3 — Lire les dénominateurs {#corr-T06-E3}

Le taux global passe de 60 % à 75 % : hausse de 15 points. La hausse relative du taux est (75−60)/60 = 0,25, soit 25 %. À la seconde date, 250 adultes sur 1 000 ne sont pas alphabétisés, ce qui correspond bien au complément de 75 %.

La proportion de femmes parmi les adultes non alphabétisés est 150/250 = 60 %. La proportion d’adultes non alphabétisés parmi les femmes est 150/500 = 30 %. Les numérateurs sont identiques, mais les dénominateurs diffèrent : toutes les personnes non alphabétisées dans le premier cas, toutes les femmes dans le second.

La conclusion correcte est limitée à la population fictive décrite. Il serait faux d’attribuer ces taux à l’UNESCO, à un pays ou au monde. Le remplacement des données n’a pas reconstitué les nombres illisibles de l’original ; il a conservé l’objectif de raisonnement sur les proportions.

**Critères observables.** 15 points ; 25 % de hausse relative ; 60 % et 30 % ; dénominateurs et caractère fictif explicités.

**Reprise ciblée.** R2 pour proportion/population ; M4 : refaire chaque fraction avant sa conversion en pourcentage.

### T06-E4 — Comparer circulation et rétention {#corr-T06-E4}

Dans les deux cas, le savoir accroît une capacité d’action : innover, produire, négocier ou apprécier une menace. Les circulations étudiantes et les réseaux de diaspora peuvent transmettre compétences, contacts et possibilités d’investissement. Le renseignement organise une collecte et une analyse orientées vers les besoins d’une décision stratégique.

Les différences sont essentielles. Les mobilités académiques reposent souvent sur des échanges ouverts et des trajectoires individuelles, même lorsqu’elles ont des effets géopolitiques. Le renseignement peut mobiliser des méthodes secrètes et des informations protégées ; il répond à une demande institutionnelle spécifique. Les étudiants ne doivent pas être collectivement assimilés à des agents.

Dans les deux situations, la possession d’informations ne suffit pas. Un territoire doit pouvoir absorber les compétences ; un service doit évaluer ses sources et interpréter les données. Une comparaison pertinente montre ainsi un mécanisme commun — convertir des savoirs en capacité — et des finalités, droits et pratiques distincts.

**Critères observables.** Point commun explicatif ; trois critères de différence ; absence d’assimilation étudiants/espions ; limite de conversion.

**Reprise ciblée.** R3 : organiser la comparaison par critères, pas par deux récits séparés.

### T06-E5 — Le cloud n’est pas hors du monde {#corr-T06-E5}

Les données du cloud sont stockées et traitées sur des équipements matériels, notamment dans des centres de données reliés par des réseaux. Ces infrastructures occupent des territoires, consomment de l’énergie, appartiennent à des acteurs et relèvent de règles juridiques. Le terme cloud décrit une organisation de services, pas une absence de localisation.

Une adresse IP étrangère observée lors d’un incident est un indice technique. Le serveur peut être compromis, loué ou utilisé comme relais. Il faut confronter cet indice à d’autres éléments pour identifier un opérateur, et davantage encore pour attribuer une responsabilité politique. La correction ne doit pas remplacer une certitude injustifiée par « on ne peut jamais rien savoir » : elle ajuste le niveau de confiance aux preuves et distingue observation, hypothèse et attribution publique.

**Critères observables.** Matérialité et droit ; IP comme indice ; explication de deux scénarios ; conclusion prudente mais non relativiste.

**Reprise ciblée.** R2 sur couches du cyberespace ; R4 sur la portée d’un indice.

### T06-E6 — Construire une réponse sur la souveraineté {#corr-T06-E6}

Problématique : comment renforcer une capacité souveraine dans un espace techniquement et économiquement interdépendant ?

I. Maîtriser des dépendances essentielles. Identifier infrastructures, compétences, fournisseurs, données et règles. La sécurité exige d’évaluer les vulnérabilités, de disposer de capacités de réponse et de préserver des fonctions critiques. Une souveraineté proclamée sans maîtrise technique reste limitée.

II. Coopérer pour rendre cette maîtrise effective. Les incidents traversent les frontières ; partager des alertes, coordonner des réponses et définir des exigences communes peut renforcer les capacités nationales. L’ANSSI et les cadres européens, dont ENISA et NIS2, illustrent cette articulation. La coopération pose toutefois des problèmes de secret, de confiance et d’intérêts industriels.

La conclusion refuse l’alternative absolue : se fermer entièrement n’est ni la seule forme de souveraineté ni une garantie de sécurité ; coopérer n’implique pas de renoncer à toute autonomie. Un plan en trois parties infrastructures/normes/cooperation est possible s’il montre leurs relations et ne devient pas une liste technique.

**Critères observables.** Quatre dimensions demandées ; acteurs français/européens ; dépendance expliquée ; fermeture/cooperation non binaires.

**Reprise ciblée.** R5 : faire apparaître une tension et des conditions dans chaque partie.

### T06-E7 — Dissertation autonome {#corr-T06-E7}

**Problématique possible :** comment la production et la diffusion des connaissances élargissent-elles les capacités des individus et des sociétés tout en créant de nouveaux rapports de puissance ?

**Introduction modèle.** L’accès à l’écrit, la recherche scientifique et les réseaux numériques rendent disponibles des savoirs toujours plus nombreux. Mais disponibilité, compréhension et maîtrise ne se confondent pas. Produire et diffuser la connaissance peut émanciper tout en renforçant le pouvoir de ceux qui organisent ses conditions d’accès et d’utilisation.

**Développement modèle condensé.** L’alphabétisation élargit d’abord les possibilités de comprendre des droits, de participer au débat et d’accéder à des formations. L’histoire des femmes montre des progrès graduels et inégaux, dont les lois scolaires françaises constituent des repères situés. L’accès à l’écrit ne supprime cependant pas toutes les discriminations : il crée des capacités dont l’exercice dépend aussi de rapports sociaux.

La production scientifique repose ensuite sur des collectifs. Les recherches sur la radioactivité, de Becquerel aux Curie et aux travaux sur la fission, associent individus, instruments, institutions et échanges. La circulation des résultats permet de nouvelles découvertes, tandis que les applications mobilisent des choix économiques et politiques. La connaissance ne possède pas un usage unique : médecine, énergie et armement illustrent des orientations différentes.

Enfin, la maîtrise des savoirs devient une ressource géopolitique. Les réseaux étudiants et la diaspora indienne peuvent faciliter des transferts, à condition que des institutions et des entreprises puissent les utiliser. Le renseignement et le cyberespace montrent la valeur stratégique de l’information et de son interprétation. Le contrôle des infrastructures ou des accès peut créer des dépendances ; la coopération reste pourtant nécessaire pour innover et se protéger.

**Conclusion modèle.** Émancipation et puissance ne sont pas deux effets séparés. Elles dépendent des conditions de production, de validation, d’accès et de circulation. Une politique de connaissance doit donc être analysée à partir de ses acteurs, de ses bénéficiaires et de ses limites, plutôt que de la seule quantité d’informations disponible.

**Autre démarche recevable :** organiser le devoir par production, diffusion et contrôle, en traitant dans chaque partie les effets émancipateurs et les asymétries. Le sujet ne justifie pas de réciter un seul jalon pendant tout le devoir.

**Critères observables.** Alphabétisation, sciences et géopolitique ; mécanismes ; accès/appropriation ; réponse organisée et achevée.

**Reprise ciblée.** R3 si inventaire de découvertes ; R5 si la question émancipation/puissance n’organise pas le plan.

### T06-E8 — Mini-projet de cartographie d’un service {#corr-T06-E8}

Trajet plausible : terminal de l’utilisateur → réseau local et fournisseur d’accès → réseaux d’interconnexion → infrastructure d’hébergement → service qui autorise ou refuse l’accès au document. Des échanges de résolution de noms et des mécanismes de sécurité interviennent également ; le dessin n’est pas un relevé exhaustif de paquets.

Ce que l’on sait dans une description générale : le service dépend d’équipements, de logiciels et de règles d’accès. Ce que l’on suppose : l’emplacement précis du centre de données, le chemin emprunté et les sous-traitants, tant qu’aucune documentation ne l’établit. Ce qui demanderait une enquête autorisée : architecture déclarée, conditions du service, localisation contractuelle des données et observations techniques licites. Le trajet peut changer et des copies peuvent exister dans plusieurs lieux.

La conclusion relie technique et politique : droits de l’utilisateur, juridictions, propriété des infrastructures et dépendances participent au fonctionnement du service. Il ne faut pas confondre le pays de l’entreprise, celui du serveur et la nationalité de tous les opérateurs.

**Critères observables.** Chaîne complète ; savoir/supposition/enquête séparés ; droits et acteurs ; aucun trajet fictif présenté comme mesuré.

**Reprise ciblée.** R4 : attribuer un statut de preuve à chaque élément du schéma.

## QCM : comprendre chaque proposition

### T06-Q1 — Réponse B {#corr-T06-Q1}

**A.** A confond un indice historique de signature et l’ensemble des compétences de lecture et d’écriture.

**B.** B exprime l’élargissement des possibilités sans promettre la disparition automatique des discriminations.

**C.** C est faux : accès à l’éducation, genre et ressources sociales influencent fortement l’alphabétisation.

### T06-Q2 — Réponse A {#corr-T06-Q2}

**A.** 1896 correspond aux observations de Becquerel sur les rayonnements de l’uranium.

**B.** 1648 renvoie aux traités de Westphalie, sans rapport avec cette découverte.

**C.** 2015 est notamment la date de l’accord de Paris, pas celle de Becquerel.

### T06-Q3 — Réponse A {#corr-T06-Q3}

**A.** A décrit des transferts possibles de compétences, de contacts et de ressources.

**B.** B transforme une possibilité de retour en obligation universelle, absente de la notion.

**C.** C nie les liens qui peuvent précisément caractériser une diaspora.

### T06-Q4 — Réponse B {#corr-T06-Q4}

**A.** A oublie câbles, antennes, serveurs et centres de données.

**B.** B distingue les couches matérielles, logiques et informationnelles qui interagissent.

**C.** C est faux : propriété, accès, données et responsabilités relèvent aussi de règles de droit.

### T06-Q5 — Réponse C {#corr-T06-Q5}

**A.** A transforme abusivement une localisation technique en preuve de commandement politique.

**B.** B est trop absolu : l’IP peut contribuer à une enquête lorsqu’elle est confrontée à d’autres indices.

**C.** C distingue correctement indice technique et attribution politique, avec un niveau de confiance.

## T06-RT — Corrigé du nouveau test {#corr-T06-RT}

1. Une information renseigne ; une connaissance suppose interprétation, organisation et validation. 2. La radioactivité est étudiée par des individus reliés à des instruments, institutions, publications et échanges : citer Becquerel, les Curie et une étape ultérieure. 3. Câbles ou centres de données constituent un ancrage territorial ; une IP observée ne suffit pas à désigner un gouvernement, car elle peut relever d’un relais ou d’une infrastructure compromise.

**Validation.** Réussite : trois réponses justifiées, avec notions distinguées et exemples situés. Une erreur de date appelle R1 ; une confusion de notion R2 ; une relation non expliquée R3. Refaire le point faible à J+2.

**À distance.** J+7 : Rappeler 1896, 1934 et 2009 avec acteur et fonction. J+21 : Relier la coopération scientifique à T01 ou l’accès aux savoirs aux libertés de P01.

# Corrigés des micro-tests de remédiation {#corr-remediations}

## R1-T — Reconstituer les repères

1972 : convention concernant le patrimoine mondial culturel et naturel. 2003 : convention pour la sauvegarde du patrimoine culturel immatériel. 1993 : création du Tribunal pénal international pour l’ex-Yougoslavie, le TPIY. 1994 : génocide des Tutsi au Rwanda. Les deux dernières entrées ne renvoient ni au même territoire ni à la même nature d’événement. Le TPIY n’est pas créé pour juger un crime ultérieur commis au Rwanda ; un autre tribunal, le TPIR, est créé en 1994. Une réponse satisfaisante associe les quatre dates, nomme les objets et explique cette distinction. Reprendre les repères de T03 et T04 en cas de confusion.

## R2-T — Distinguer contrainte et attraction

Une sanction économique peut imposer un coût pour faire modifier une conduite : elle relève alors de la contrainte, même sans emploi de l’armée. Le soft power repose sur l’attraction, et ne désigne pas tous les moyens non militaires. Un film apprécié peut accroître une familiarité culturelle ou l’attractivité d’un pays, mais ne démontre pas un soutien à son gouvernement. Il faut donc distinguer instrument, réception et résultat politique. La réussite suppose ces deux distinctions, pas seulement deux réponses négatives. Reprendre P02, introduction et axe 2.

## R3-T — Expliquer le rôle de l’ONU

**Un paragraphe recevable en six phrases.** L’ONU, fondée en 1945, a notamment pour fonction de contribuer au maintien de la paix et de la sécurité internationales. Le Conseil de sécurité dispose d’instruments comme les sanctions et, dans les conditions de la Charte, l’autorisation du recours à la force. Leur mise en œuvre dépend cependant des décisions des États, des moyens engagés et des rapports de puissance, notamment du veto des membres permanents. L’intervention autorisée contre l’Irak en 1991 après l’invasion du Koweït montre la possibilité d’une action collective. À l’inverse, l’intervention de 2003 ne peut pas être présentée comme une nouvelle opération explicitement autorisée selon le même schéma. La persistance des guerres établit donc les limites du système, non l’absence de toute fonction diplomatique, juridique ou opérationnelle.

D’autres exemples du cours sont recevables s’ils distinguent clairement instrument, décision et effets. Éviter de confondre l’ONU et une armée mondiale indépendante des États.

## R4-T — Analyser sans paraphraser

**Appui.** Le document décrit les contributions nationales comme un instrument de l’accord de Paris. **Explication.** Les États formulent des engagements dans un cadre collectif, plutôt qu’une autorité mondiale imposant une même politique à tous. L’efficacité dépend notamment de l’ambition des contributions, des mesures réellement mises en œuvre et des capacités de financement. **Limite.** La présentation du dispositif ne prouve pas à elle seule une baisse effective des émissions.

Pour apprécier les résultats, confronter des séries d’émissions datées et comparables, les politiques réalisées, les bilans de mise en œuvre et les financements ; distinguer une promesse, une trajectoire projetée et un résultat observé. Une réponse qui écrit uniquement « le document est subjectif » ne satisfait pas le critère de critique.

## R5-T — Construire un plan adapté

**I. Les frontières peuvent limiter et sélectionner les échanges.** Le contrôle, les interdictions et les tensions politiques peuvent réduire les circulations ; la frontière intercoréenne fournit un exemple de fermeture particulièrement forte, dans un contexte d’armistice.

**II. Les frontières peuvent aussi organiser des échanges et des interfaces.** Dans certains espaces rhénans européens, les accords et les infrastructures rendent possibles des mobilités transfrontalières. L’existence d’une frontière ne signifie donc pas l’absence d’échanges ; les effets varient selon les flux, les acteurs, la date et le régime de contrôle.

Les titres « histoire / géographie / géopolitique » désignent des approches, mais n’apportent pas à eux seuls une réponse progressive à la question. Un autre plan est recevable si ses parties démontrent des conditions ou des mécanismes distincts, sans effacer le rôle des choix politiques.

## R6-T — Contrôler l’achèvement

Ce test évalue un processus, pas une réponse unique. Vérifiez que les 25 minutes ont produit un plan utile, une introduction avec question directrice, un paragraphe contenant argument et exemple, puis une conclusion et une relecture. Notez ce qui manque réellement : exemple non situé, lien logique absent, réponse finale omise. Une phrase de conclusion n’efface pas l’absence du développement ; inversement, recopier tout le cours au brouillon n’est pas un progrès si la copie demeure vide.

Pour la tentative suivante, conservez une seule priorité mesurable : par exemple, terminer le paragraphe avec son exemple dans les quinze minutes. Ajustez ensuite la durée avant de passer à l’épreuve entière. Les repères 5 / 15 / 5 sont un entraînement pédagogique, non un découpage réglementaire de l’examen.

# Références et provenance documentaire {#references}

Les codes sont des repères locaux, non des identifiants ministériels. **S** désigne le cadre officiel ; **R** les ressources d’accompagnement ; **D** des documents de référence ; **B** une source spécifique ou un renvoi thématique à une ressource, selon la qualification indiquée. Un renvoi à une ressource pédagogique ne signifie pas que les ouvrages originaux qu’elle cite ont tous été lus intégralement.

Les documents du cours sont des synthèses éditoriales sauf indication expresse contraire. Les adaptations ne sont pas des citations verbatim. Les jeux fictifs ne sont pas des statistiques historiques. Les liens permettent une vérification complémentaire ; aucun exercice ne suppose qu’un document absent soit téléchargé pour être résolu.

**Actualisation : 8 septembre 2026.** Les règles de session et les faits contemporains demandent une nouvelle veille avant l’examen. Ce manuel ne vaut ni homologation ministérielle ni conseil individuel d’inscription.

## Cadre officiel

[**([S01](#ref-S01)) Éduscol — Programmes et ressources HGGSP**]{#ref-S01} — Texte ou information officielle. [Consulter la source](https://eduscol.education.gouv.fr/5802/programmes-et-ressources-en-histoire-geographie-geopolitique-et-sciences-politiques-voie-g).

[**([S02](#ref-S02)) Programme de Première — BO spécial du 22 janvier 2019**]{#ref-S02} — Texte ou information officielle. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/spe576annexe1062925pdf-83244.pdf).

[**([S03](#ref-S03)) Programme de Terminale — BO spécial du 25 juillet 2019**]{#ref-S03} — Texte ou information officielle. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/spe254annexe1159180pdf-83247.pdf).

[**([S04](#ref-S04)) Note du 27 août 2025, NOR MENE2521923N — Épreuve HGGSP à compter de 2026**]{#ref-S04} — Texte ou information officielle. [Consulter la source](https://www.education.gouv.fr/bo/2025/Hebdo33/MENE2521923N).

[**([S05](#ref-S05)) Évaluation ponctuelle de la spécialité non poursuivie — version consolidée juin 2025, HGGSP pages 3–4**]{#ref-S05} — Texte ou information officielle. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ndsevaluations-ponctuelleseds-non-poursuivivoie-gjuin-2025pdf-100575.pdf).

[**([S06](#ref-S06)) Éduscol — Candidats individuels au baccalauréat**]{#ref-S06} — Texte ou information officielle. [Consulter la source](https://eduscol.education.gouv.fr/5694/candidats-individuels-au-baccalaureat-general-et-au-baccalaureat-technologique).

[**([S07](#ref-S07)) Note du 25 août 2025 — Modalités d’évaluation à compter de 2026**]{#ref-S07} — Texte ou information officielle. [Consulter la source](https://www.education.gouv.fr/bo/2025/Hebdo32/MENE2523743N).

[**([S08](#ref-S08)) Éduscol — Grand oral, présentation actualisée en février 2026**]{#ref-S08} — Texte ou information officielle. [Consulter la source](https://eduscol.education.gouv.fr/5661/presentation-du-grand-oral).

[**([S09](#ref-S09)) Éduscol — Épreuves terminales et coefficients du baccalauréat général**]{#ref-S09} — Texte ou information officielle. [Consulter la source](https://eduscol.education.gouv.fr/5706/les-epreuves-terminales-du-baccalaureat-general).

[**([S10](#ref-S10)) Déclaration des droits de l’homme et du citoyen de 1789 — Légifrance**]{#ref-S10} — Texte ou information officielle. [Consulter la source](https://www.legifrance.gouv.fr/loda/id/JORFTEXT000000697056).

## Accompagnement par thème

[**([R-P01](#ref-R-P01)) Éduscol — Ressource d’accompagnement : Comprendre un régime politique : la démocratie**]{#ref-R-P01} — Accompagnement disciplinaire officiel. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra19lyceegspe1hggsptheme1democratie1169458pdf-83250.pdf). Source d’appui aux jalons et à leur problématisation ; ne vaut pas validation du présent manuel.

[**([R-P02](#ref-R-P02)) Éduscol — Ressource d’accompagnement : Analyser les dynamiques des puissances internationales**]{#ref-R-P02} — Accompagnement disciplinaire officiel. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra19lyceegspe1hggsptheme2puissancesinter1169460pdf-83253.pdf). Source d’appui aux jalons et à leur problématisation ; ne vaut pas validation du présent manuel.

[**([R-P03](#ref-R-P03)) Éduscol — Ressource d’accompagnement : Étudier les divisions politiques du monde : les frontières**]{#ref-R-P03} — Accompagnement disciplinaire officiel. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra19lyceegspe1hggsptheme3frontieres1206062pdf-83256.pdf). Source d’appui aux jalons et à leur problématisation ; ne vaut pas validation du présent manuel.

[**([R-P04](#ref-R-P04)) Éduscol — Ressource d’accompagnement : S’informer : un regard critique sur les sources et modes de communication**]{#ref-R-P04} — Accompagnement disciplinaire officiel. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra20lyceeg1histgeogeopolitique-sciencespotheme4-sinformer-regard-critique1293847pdf-83259.pdf). Source d’appui aux jalons et à leur problématisation ; ne vaut pas validation du présent manuel.

[**([R-P05](#ref-R-P05)) Éduscol — Ressource d’accompagnement : Analyser les relations entre États et religions**]{#ref-R-P05} — Accompagnement disciplinaire officiel. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra20lyceeg1histgeogeopolitique-sciencespoanalyser-relations-etats-religions1293914pdf-83262.pdf). Source d’appui aux jalons et à leur problématisation ; ne vaut pas validation du présent manuel.

[**([R-T01](#ref-R-T01)) Éduscol — Ressource d’accompagnement : De nouveaux espaces de conquête**]{#ref-R-T01} — Accompagnement disciplinaire officiel. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra20lyceegtspehgeotheme1espacesconquetes0021329089pdf-83265.pdf). Source d’appui aux jalons et à leur problématisation ; ne vaut pas validation du présent manuel.

[**([R-T02](#ref-R-T02)) Éduscol — Ressource d’accompagnement : Faire la guerre, faire la paix : formes de conflits et modes de résolution**]{#ref-R-T02} — Accompagnement disciplinaire officiel. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra22lycee-gthggsptheme-2faire-la-guerre-et-faire-la-paix-93786.pdf). Source d’appui aux jalons et à leur problématisation ; ne vaut pas validation du présent manuel.

[**([R-T03](#ref-R-T03)) Éduscol — Ressource d’accompagnement : Histoire et mémoires**]{#ref-R-T03} — Accompagnement disciplinaire officiel. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra22lycee-gthggsphistoire-et-memoires-93783.pdf). Source d’appui aux jalons et à leur problématisation ; ne vaut pas validation du présent manuel.

[**([R-T04](#ref-R-T04)) Éduscol — Ressource d’accompagnement : Identifier, protéger et valoriser le patrimoine : enjeux géopolitiques**]{#ref-R-T04} — Accompagnement disciplinaire officiel. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra25lyceegthggspidentifierprotegervaloriserpatrimoine-enjeuxgeopolitiques0pdf-121241.pdf). Source d’appui aux jalons et à leur problématisation ; ne vaut pas validation du présent manuel.

[**([R-T05](#ref-R-T05)) Éduscol — Ressource d’accompagnement : L’environnement, entre exploitation et protection : un enjeu planétaire**]{#ref-R-T05} — Accompagnement disciplinaire officiel. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra23lyceegthggspenvironnementexploitationprotectionenjeupdf-102786.pdf). Source d’appui aux jalons et à leur problématisation ; ne vaut pas validation du présent manuel.

[**([R-T06](#ref-R-T06)) Éduscol — Ressource d’accompagnement : L’enjeu de la connaissance**]{#ref-R-T06} — Accompagnement disciplinaire officiel. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra24lyceegthggspenjeuxconnaissancepdf-104487.pdf). Source d’appui aux jalons et à leur problématisation ; ne vaut pas validation du présent manuel.

## Documents de référence

[**([D01](#ref-D01)) Traité sur l’Union européenne, article 10**]{#ref-D01} — Document institutionnel de référence. [Consulter la source](https://eur-lex.europa.eu/legal-content/FR/TXT/?uri=CELEX:12012M010).

[**([D02](#ref-D02)) Convention des Nations unies sur le droit de la mer, 1982**]{#ref-D02} — Document institutionnel de référence. [Consulter la source](https://www.un.org/depts/los/convention_agreements/texts/unclos/unclos_f.pdf).

[**([D03](#ref-D03)) Accord BBNJ — Dépositaire ONU : entrée en vigueur le 17 janvier 2026**]{#ref-D03} — Document institutionnel de référence. [Consulter la source](https://treaties.un.org/Pages/ViewDetails.aspx?src=TREATY&mtdsg_no=XXI-10&chapter=21&clang=_en).

[**([D04](#ref-D04)) Conseil de l’UE — Espace Schengen**]{#ref-D04} — Document institutionnel de référence. [Consulter la source](https://www.consilium.europa.eu/en/policies/schengen-area/).

[**([D06](#ref-D06)) Archives nationales américaines — Bill of Rights, premier amendement**]{#ref-D06} — Document institutionnel de référence. [Consulter la source](https://www.archives.gov/founding-docs/bill-of-rights-transcript).

[**([D07](#ref-D07)) OTAN — Pays membres et dates d’adhésion**]{#ref-D07} — Document institutionnel de référence. [Consulter la source](https://www.nato.int/en/about-us/organization/nato-member-countries).

[**([D08](#ref-D08)) UNOOSA — Traité de l’espace de 1967**]{#ref-D08} — Document institutionnel de référence. [Consulter la source](https://www.unoosa.org/oosa/en/ourwork/spacelaw/treaties/introouterspacetreaty.html).

[**([D09](#ref-D09)) Nations unies — Charte de 1945**]{#ref-D09} — Document institutionnel de référence. [Consulter la source](https://treaties.un.org/doc/source/docs/charter-all-lang.pdf).

[**([D10](#ref-D10)) CCNUCC — Accord de Paris**]{#ref-D10} — Document institutionnel de référence. [Consulter la source](https://unfccc.int/process-and-meetings/the-paris-agreement).

[**([D10a](#ref-D10a)) Dépositaire ONU — Retrait américain de la CCNUCC, notification du 27 février 2026, effet prévu le 27 février 2027**]{#ref-D10a} — Document institutionnel de référence. [Consulter la source](https://treaties.un.org/doc/Publication/CN/2026/CN.102.2026-Eng.pdf).

[**([D11](#ref-D11)) UNESCO — Convention du patrimoine mondial de 1972**]{#ref-D11} — Document institutionnel de référence. [Consulter la source](https://whc.unesco.org/fr/conventiontexte/).

[**([D12](#ref-D12)) UNESCO — Convention pour la sauvegarde du patrimoine culturel immatériel, 2003**]{#ref-D12} — Document institutionnel de référence. [Consulter la source](https://ich.unesco.org/fr/convention). Le dispositif de 2003 est distinct de la convention de 1972. Aucun passage présenté comme transcription littérale.

[**([D13](#ref-D13)) GIEC — AR6, rapport de synthèse 2023, résumé pour décideurs**]{#ref-D13} — Document institutionnel de référence. [Consulter la source](https://www.ipcc.ch/report/ar6/syr/summary-for-policymakers/).

[**([D14](#ref-D14)) Banque mondiale / UNESCO-UIS — Indicateur d’alphabétisation des femmes adultes**]{#ref-D14} — Document institutionnel de référence. [Consulter la source](https://data.worldbank.org/indicator/SE.ADT.LITR.FE.ZS). Aucune valeur illisible de l’ancienne banque n’est reconstituée à partir de cette page ; T06-E3 est un jeu fictif explicitement nouveau.

[**([D15](#ref-D15)) Décret n° 2009-834 du 7 juillet 2009 créant l’ANSSI**]{#ref-D15} — Document institutionnel de référence. [Consulter la source](https://www.legifrance.gouv.fr/loda/id/JORFTEXT000020828212).

[**([D16](#ref-D16)) ENISA — Directive NIS 2 et coopération européenne**]{#ref-D16} — Document institutionnel de référence. [Consulter la source](https://www.enisa.europa.eu/topics/state-of-cybersecurity-in-the-eu/cybersecurity-policies/nis-directive-2).

[**([D17](#ref-D17)) ONU — Convention de 1948 pour la prévention et la répression du crime de génocide**]{#ref-D17} — Document institutionnel de référence. [Consulter la source](https://www.ohchr.org/en/instruments-mechanisms/instruments/convention-prevention-and-punishment-crime-genocide).

## Appuis documentaires et approfondissements

[**([B01](#ref-B01)) Citoyenneté athénienne — appui dans la ressource P01**]{#ref-B01} — Renvoi thématique à un accompagnement officiel. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra19lyceegspe1hggsptheme1democratie1169458pdf-83250.pdf). Le code désigne un point d’appui de la ressource Éduscol, pas une édition intégrale d’un ouvrage original. Voir le jalon correspondant.

[**([B02](#ref-B02)) Benjamin Constant : libertés des Anciens et des Modernes — appui dans la ressource P01**]{#ref-B02} — Renvoi thématique à un accompagnement officiel. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra19lyceegspe1hggsptheme1democratie1169458pdf-83250.pdf). Le code désigne un point d’appui de la ressource Éduscol, pas une édition intégrale d’un ouvrage original. Voir le jalon correspondant.

[**([B03](#ref-B03)) Tocqueville et les tensions de la démocratie — appui dans la ressource P01**]{#ref-B03} — Renvoi thématique à un accompagnement officiel. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra19lyceegspe1hggsptheme1democratie1169458pdf-83250.pdf). Le code désigne un point d’appui de la ressource Éduscol, pas une édition intégrale d’un ouvrage original. Voir le jalon correspondant.

[**([B04](#ref-B04)) Sénat américain — Covert Action in Chile, 1963–1973, rapport de 1975**]{#ref-B04} — Source institutionnelle. [Consulter la source](https://www.intelligence.senate.gov/wp-content/uploads/2024/08/sites-default-files-94chile.pdf).

[**([B05](#ref-B05)) Assemblée de la République portugaise — Construção da democracia, 1974–1976**]{#ref-B05} — Source institutionnelle. [Consulter la source](https://www.parlamento.pt/Parlamento/Paginas/construcao-democracia_1974-1976.aspx).

[**([B06](#ref-B06)) Transition et Constitution espagnoles — appui dans la ressource P01**]{#ref-B06} — Renvoi thématique à un accompagnement officiel. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra19lyceegspe1hggsptheme1democratie1169458pdf-83250.pdf). Le code désigne un point d’appui de la ressource Éduscol, pas une édition intégrale d’un ouvrage original. Voir le jalon correspondant.

[**([B07](#ref-B07)) Empire ottoman : essor et déclin — appui dans la ressource P02**]{#ref-B07} — Renvoi thématique à un accompagnement officiel. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra19lyceegspe1hggsptheme2puissancesinter1169460pdf-83253.pdf). Le code désigne un point d’appui de la ressource Éduscol, pas une édition intégrale d’un ouvrage original. Voir le jalon correspondant.

[**([B08](#ref-B08)) ONU — Agression contre l’Ukraine, résolution ES-11/1 du 2 mars 2022**]{#ref-B08} — Source institutionnelle. [Consulter la source](https://docs.un.org/fr/A/RES/ES-11/1).

[**([B09](#ref-B09)) Langues, attraction et soft power — appui dans la ressource P02**]{#ref-B09} — Renvoi thématique à un accompagnement officiel. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra19lyceegspe1hggsptheme2puissancesinter1169460pdf-83253.pdf). Le code désigne un point d’appui de la ressource Éduscol, pas une édition intégrale d’un ouvrage original. Voir le jalon correspondant.

[**([B10](#ref-B10)) Conseil de l’UE — Paquet sur les services et marchés numériques**]{#ref-B10} — Source institutionnelle. [Consulter la source](https://www.consilium.europa.eu/en/policies/digital-services-package/).

[**([B11](#ref-B11)) Routes de la soie et connectivité — appui dans la ressource P02**]{#ref-B11} — Renvoi thématique à un accompagnement officiel. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra19lyceegspe1hggsptheme2puissancesinter1169460pdf-83253.pdf). Le code désigne un point d’appui de la ressource Éduscol, pas une édition intégrale d’un ouvrage original. Voir le jalon correspondant.

[**([B12](#ref-B12)) Lieux et instruments de la puissance américaine — appui dans la ressource P02**]{#ref-B12} — Renvoi thématique à un accompagnement officiel. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra19lyceegspe1hggsptheme2puissancesinter1169460pdf-83253.pdf). Le code désigne un point d’appui de la ressource Éduscol, pas une édition intégrale d’un ouvrage original. Voir le jalon correspondant.

[**([B13](#ref-B13)) UNESCO — Frontières de l’Empire romain : limes de Germanie inférieure**]{#ref-B13} — Source institutionnelle. [Consulter la source](https://whc.unesco.org/en/list/1631/).

[**([B14](#ref-B14)) Conférence et acte de Berlin de 1885 — appui dans la ressource P03**]{#ref-B14} — Renvoi thématique à un accompagnement officiel. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra19lyceegspe1hggsptheme3frontieres1206062pdf-83256.pdf). Le code désigne un point d’appui de la ressource Éduscol, pas une édition intégrale d’un ouvrage original. Voir le jalon correspondant.

[**([B15](#ref-B15)) Commandement des Nations unies — Négociations de l’armistice coréen, 1951–1953**]{#ref-B15} — Source institutionnelle. [Consulter la source](https://www.unc.mil/History/1951-1953-Armistice-Negotiations/).

[**([B16](#ref-B16)) Frontière germano-polonaise et traités — appui dans la ressource P03**]{#ref-B16} — Renvoi thématique à un accompagnement officiel. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra19lyceegspe1hggsptheme3frontieres1206062pdf-83256.pdf). Le code désigne un point d’appui de la ressource Éduscol, pas une édition intégrale d’un ouvrage original. Voir le jalon correspondant.

[**([B17](#ref-B17)) Coopération dans le Rhin supérieur — appui dans la ressource P03**]{#ref-B17} — Renvoi thématique à un accompagnement officiel. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra19lyceegspe1hggsptheme3frontieres1206062pdf-83256.pdf). Le code désigne un point d’appui de la ressource Éduscol, pas une édition intégrale d’un ouvrage original. Voir le jalon correspondant.

[**([B18](#ref-B18)) Histoire des médias de masse — appui dans la ressource P04**]{#ref-B18} — Renvoi thématique à un accompagnement officiel. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra20lyceeg1histgeogeopolitique-sciencespotheme4-sinformer-regard-critique1293847pdf-83259.pdf). Le code désigne un point d’appui de la ressource Éduscol, pas une édition intégrale d’un ouvrage original. Voir le jalon correspondant.

[**([B19](#ref-B19)) Presse et affaire Dreyfus — appui dans la ressource P04**]{#ref-B19} — Renvoi thématique à un accompagnement officiel. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra20lyceeg1histgeogeopolitique-sciencespotheme4-sinformer-regard-critique1293847pdf-83259.pdf). Le code désigne un point d’appui de la ressource Éduscol, pas une édition intégrale d’un ouvrage original. Voir le jalon correspondant.

[**([B20](#ref-B20)) Agences de presse, Havas et AFP — appui dans la ressource P04**]{#ref-B20} — Renvoi thématique à un accompagnement officiel. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra20lyceeg1histgeogeopolitique-sciencespotheme4-sinformer-regard-critique1293847pdf-83259.pdf). Le code désigne un point d’appui de la ressource Éduscol, pas une édition intégrale d’un ouvrage original. Voir le jalon correspondant.

[**([B20a](#ref-B20a)) Loi du 29 juillet 1881, article 1 — Légifrance**]{#ref-B20a} — Source institutionnelle. [Consulter la source](https://www.legifrance.gouv.fr/loda/article_lc/LEGIARTI000006419657).

[**([B21a](#ref-B21a)) DARPA — Histoire d’ARPANET**]{#ref-B21a} — Source institutionnelle. [Consulter la source](https://www.darpa.mil/news/features/arpanet).

[**([B21b](#ref-B21b)) CERN — Naissance du Web**]{#ref-B21b} — Source institutionnelle. [Consulter la source](https://home.cern/science/computing/the-birth-of-the-web/).

[**([B22](#ref-B22)) Archives nationales américaines — Pentagon Papers**]{#ref-B22} — Source institutionnelle. [Consulter la source](https://www.archives.gov/research/pentagon-papers).

[**([B23](#ref-B23)) Information numérique, vérification et lanceurs d’alerte — appui dans la ressource P04**]{#ref-B23} — Renvoi thématique à un accompagnement officiel. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra20lyceeg1histgeogeopolitique-sciencespotheme4-sinformer-regard-critique1293847pdf-83259.pdf). Le code désigne un point d’appui de la ressource Éduscol, pas une édition intégrale d’un ouvrage original. Voir le jalon correspondant.

[**([B24](#ref-B24)) Charlemagne et pouvoirs religieux — appui dans la ressource P05**]{#ref-B24} — Renvoi thématique à un accompagnement officiel. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra20lyceeg1histgeogeopolitique-sciencespoanalyser-relations-etats-religions1293914pdf-83262.pdf). Le code désigne un point d’appui de la ressource Éduscol, pas une édition intégrale d’un ouvrage original. Voir le jalon correspondant.

[**([B25](#ref-B25)) Empereurs byzantins et califes abbassides — appui dans la ressource P05**]{#ref-B25} — Renvoi thématique à un accompagnement officiel. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra20lyceeg1histgeogeopolitique-sciencespoanalyser-relations-etats-religions1293914pdf-83262.pdf). Le code désigne un point d’appui de la ressource Éduscol, pas une édition intégrale d’un ouvrage original. Voir le jalon correspondant.

[**([B26](#ref-B26)) Turquie : laïcisation et Diyanet — appui dans la ressource P05**]{#ref-B26} — Renvoi thématique à un accompagnement officiel. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra20lyceeg1histgeogeopolitique-sciencespoanalyser-relations-etats-religions1293914pdf-83262.pdf). Le code désigne un point d’appui de la ressource Éduscol, pas une édition intégrale d’un ouvrage original. Voir le jalon correspondant.

[**([B27](#ref-B27)) Religion et politique aux États-Unis — appui dans la ressource P05**]{#ref-B27} — Renvoi thématique à un accompagnement officiel. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra20lyceeg1histgeogeopolitique-sciencespoanalyser-relations-etats-religions1293914pdf-83262.pdf). Le code désigne un point d’appui de la ressource Éduscol, pas une édition intégrale d’un ouvrage original. Voir le jalon correspondant.

[**([B28](#ref-B28)) Constitution et pluralisme en Inde — appui dans la ressource P05**]{#ref-B28} — Renvoi thématique à un accompagnement officiel. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra20lyceeg1histgeogeopolitique-sciencespoanalyser-relations-etats-religions1293914pdf-83262.pdf). Le code désigne un point d’appui de la ressource Éduscol, pas une édition intégrale d’un ouvrage original. Voir le jalon correspondant.

[**([B29](#ref-B29)) Inde, Pakistan et Cachemire — appui dans la ressource P05**]{#ref-B29} — Renvoi thématique à un accompagnement officiel. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra20lyceeg1histgeogeopolitique-sciencespoanalyser-relations-etats-religions1293914pdf-83262.pdf). Le code désigne un point d’appui de la ressource Éduscol, pas une édition intégrale d’un ouvrage original. Voir le jalon correspondant.

[**([B30](#ref-B30)) Jalons de la conquête spatiale — appui dans la ressource T01**]{#ref-B30} — Renvoi thématique à un accompagnement officiel. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra20lyceegtspehgeotheme1espacesconquetes0021329089pdf-83265.pdf). Le code désigne un point d’appui de la ressource Éduscol, pas une édition intégrale d’un ouvrage original. Voir le jalon correspondant.

[**([B31](#ref-B31)) Dissuasion et projection navale — appui dans la ressource T01**]{#ref-B31} — Renvoi thématique à un accompagnement officiel. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra20lyceegtspehgeotheme1espacesconquetes0021329089pdf-83265.pdf). Le code désigne un point d’appui de la ressource Éduscol, pas une édition intégrale d’un ouvrage original. Voir le jalon correspondant.

[**([B32](#ref-B32)) NASA — International Space Station, facts and figures**]{#ref-B32} — Source institutionnelle. [Consulter la source](https://www.nasa.gov/international-space-station/space-station-facts-and-figures/).

[**([B33](#ref-B33)) CNSA — Retour d’échantillons de Chang’e 6, juin 2024**]{#ref-B33} — Source institutionnelle. [Consulter la source](https://www.cnsa.gov.cn/english/n6465652/n6465653/c10573102/content.html).

[**([B34](#ref-B34)) Chine et enjeux maritimes — appui dans la ressource T01**]{#ref-B34} — Renvoi thématique à un accompagnement officiel. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra20lyceegtspehgeotheme1espacesconquetes0021329089pdf-83265.pdf). Le code désigne un point d’appui de la ressource Éduscol, pas une édition intégrale d’un ouvrage original. Voir le jalon correspondant.

[**([B35](#ref-B35)) Clausewitz — On War, livre I, traduction historique anglophone**]{#ref-B35} — Source institutionnelle. [Consulter la source](https://clausewitzstudies.org/readings/OnWar1873/BK1ch01.html).

[**([B35a](#ref-B35a)) Guerre de Sept Ans et guerres napoléoniennes — appui dans la ressource T02**]{#ref-B35a} — Renvoi thématique à un accompagnement officiel. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra22lycee-gthggsptheme-2faire-la-guerre-et-faire-la-paix-93786.pdf). Le code désigne un point d’appui de la ressource Éduscol, pas une édition intégrale d’un ouvrage original. Voir le jalon correspondant.

[**([B36](#ref-B36)) Yale, Avalon Project — Traité de Westphalie, 1648**]{#ref-B36} — Source institutionnelle. [Consulter la source](https://avalon.law.yale.edu/17th_century/westphal.asp).

[**([B36a](#ref-B36a)) Al-Qaïda et Daech : formes et objectifs de la violence — appui dans la ressource T02**]{#ref-B36a} — Renvoi thématique à un accompagnement officiel. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra22lycee-gthggsptheme-2faire-la-guerre-et-faire-la-paix-93786.pdf). Le code désigne un point d’appui de la ressource Éduscol, pas une édition intégrale d’un ouvrage original. Voir le jalon correspondant.

[**([B37](#ref-B37)) ONU et construction de la paix sous Kofi Annan — appui dans la ressource T02**]{#ref-B37} — Renvoi thématique à un accompagnement officiel. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra22lycee-gthggsptheme-2faire-la-guerre-et-faire-la-paix-93786.pdf). Le code désigne un point d’appui de la ressource Éduscol, pas une édition intégrale d’un ouvrage original. Voir le jalon correspondant.

[**([B37a](#ref-B37a)) ONU — Responsabilité de protéger**]{#ref-B37a} — Source institutionnelle. [Consulter la source](https://www.un.org/en/genocide-prevention/responsibility-protect/about).

[**([B38](#ref-B38)) Conflits et tentatives de paix au Moyen-Orient — appui dans la ressource T02**]{#ref-B38} — Renvoi thématique à un accompagnement officiel. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra22lycee-gthggsptheme-2faire-la-guerre-et-faire-la-paix-93786.pdf). Le code désigne un point d’appui de la ressource Éduscol, pas une édition intégrale d’un ouvrage original. Voir le jalon correspondant.

[**([B38a](#ref-B38a)) Résolution 242 et diplomatie régionale — appui dans la ressource T02**]{#ref-B38a} — Renvoi thématique à un accompagnement officiel. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra22lycee-gthggsptheme-2faire-la-guerre-et-faire-la-paix-93786.pdf). Le code désigne un point d’appui de la ressource Éduscol, pas une édition intégrale d’un ouvrage original. Voir le jalon correspondant.

[**([B38b](#ref-B38b)) ONU — Situation à Gaza et processus politique, point daté du 26 août 2026**]{#ref-B38b} — Actualisation institutionnelle. [Consulter la source](https://www.un.org/unispal/document/gazas-recovery-and-reconstruction-and-the-broader-political-process-are-mutually-dependent-un-acting-special-coordinator-for-the-middle-east-peace-process-briefs-the-security-council/). Le code désigne un point d’appui de la ressource Éduscol, pas une édition intégrale d’un ouvrage original. Voir le jalon correspondant.

[**([B38c](#ref-B38c)) Cour internationale de justice — Avis consultatif du 19 juillet 2024, affaire 186**]{#ref-B38c} — Source institutionnelle. [Consulter la source](https://www.icj-cij.org/case/186).

[**([B38d](#ref-B38d)) ONU — Briefing du coordinateur spécial par intérim au Conseil de sécurité, 26 août 2026**]{#ref-B38d} — Source institutionnelle. [Consulter la source](https://www.un.org/unispal/document/gazas-recovery-and-reconstruction-and-the-broader-political-process-are-mutually-dependent-un-acting-special-coordinator-for-the-middle-east-peace-process-briefs-the-security-council/).

[**([B39](#ref-B39)) Résolutions 678 et 687, guerre de 1991 — appui dans la ressource T02**]{#ref-B39} — Renvoi thématique à un accompagnement officiel. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra22lycee-gthggsptheme-2faire-la-guerre-et-faire-la-paix-93786.pdf). Le code désigne un point d’appui de la ressource Éduscol, pas une édition intégrale d’un ouvrage original. Voir le jalon correspondant.

[**([B39a](#ref-B39a)) Conseil de sécurité — Répertoire des pratiques, 2000–2003, chapitre XII**]{#ref-B39a} — Source institutionnelle. [Consulter la source](https://www.un.org/fr/sc/repertoire/00-03/00-03_12.pdf).

[**([B40](#ref-B40)) Controverse sur les responsabilités de 1914 : Fischer et Clark — appui dans la ressource T03**]{#ref-B40} — Renvoi thématique à un accompagnement officiel. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra22lycee-gthggsphistoire-et-memoires-93783.pdf). Le code désigne un point d’appui de la ressource Éduscol, pas une édition intégrale d’un ouvrage original. Voir le jalon correspondant.

[**([B40a](#ref-B40a)) Traité de Versailles et responsabilité — appui dans la ressource T03**]{#ref-B40a} — Renvoi thématique à un accompagnement officiel. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra22lycee-gthggsphistoire-et-memoires-93783.pdf). Le code désigne un point d’appui de la ressource Éduscol, pas une édition intégrale d’un ouvrage original. Voir le jalon correspondant.

[**([B41](#ref-B41)) Histoire et mémoires de la guerre d’Algérie — appui dans la ressource T03**]{#ref-B41} — Renvoi thématique à un accompagnement officiel. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra22lycee-gthggsphistoire-et-memoires-93783.pdf). Le code désigne un point d’appui de la ressource Éduscol, pas une édition intégrale d’un ouvrage original. Voir le jalon correspondant.

[**([B41a](#ref-B41a)) Loi du 18 octobre 1999 — Reconnaissance de la guerre d’Algérie**]{#ref-B41a} — Source institutionnelle. [Consulter la source](https://www.legifrance.gouv.fr/loda/id/JORFTEXT000000578132).

[**([B42](#ref-B42)) Rwanda : gacaca et justice après le génocide — appui dans la ressource T03**]{#ref-B42} — Renvoi thématique à un accompagnement officiel. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra22lycee-gthggsphistoire-et-memoires-93783.pdf). Le code désigne un point d’appui de la ressource Éduscol, pas une édition intégrale d’un ouvrage original. Voir le jalon correspondant.

[**([B43](#ref-B43)) TPIY : justice internationale et responsabilités — appui dans la ressource T03**]{#ref-B43} — Renvoi thématique à un accompagnement officiel. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra22lycee-gthggsphistoire-et-memoires-93783.pdf). Le code désigne un point d’appui de la ressource Éduscol, pas une édition intégrale d’un ouvrage original. Voir le jalon correspondant.

[**([B44](#ref-B44)) United States Holocaust Memorial Museum — Génocide des Roms européens, 1939–1945**]{#ref-B44} — Source institutionnelle. [Consulter la source](https://encyclopedia.ushmm.org/content/en/article/genocide-of-european-roma-gypsies-1939-1945).

[**([B44a](#ref-B44a)) Lieux de mémoire des génocides — appui dans la ressource T03**]{#ref-B44a} — Renvoi thématique à un accompagnement officiel. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra22lycee-gthggsphistoire-et-memoires-93783.pdf). Le code désigne un point d’appui de la ressource Éduscol, pas une édition intégrale d’un ouvrage original. Voir le jalon correspondant.

[**([B45](#ref-B45)) Procès après Nuremberg — appui dans la ressource T03**]{#ref-B45} — Renvoi thématique à un accompagnement officiel. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra22lycee-gthggsphistoire-et-memoires-93783.pdf). Le code désigne un point d’appui de la ressource Éduscol, pas une édition intégrale d’un ouvrage original. Voir le jalon correspondant.

[**([B46](#ref-B46)) Littérature, cinéma et transmission — appui dans la ressource T03**]{#ref-B46} — Renvoi thématique à un accompagnement officiel. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra22lycee-gthggsphistoire-et-memoires-93783.pdf). Le code désigne un point d’appui de la ressource Éduscol, pas une édition intégrale d’un ouvrage original. Voir le jalon correspondant.

[**([B47](#ref-B47)) Château de Versailles — Inauguration des galeries historiques**]{#ref-B47} — Source institutionnelle. [Consulter la source](https://www.chateauversailles.fr/decouvrir/histoire/les-grandes-dates/inauguration-galeries-historiques).

[**([B47a](#ref-B47a)) Versailles, 1871, 1919 et usages républicains — appui dans la ressource T04**]{#ref-B47a} — Renvoi thématique à un accompagnement officiel. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra25lyceegthggspidentifierprotegervaloriserpatrimoine-enjeuxgeopolitiques0pdf-121241.pdf). Le code désigne un point d’appui de la ressource Éduscol, pas une édition intégrale d’un ouvrage original. Voir le jalon correspondant.

[**([B48](#ref-B48)) British Museum — Position institutionnelle sur les sculptures du Parthénon**]{#ref-B48} — Source institutionnelle. [Consulter la source](https://www.britishmuseum.org/about-us/british-museum-story/contested-objects-collection/parthenon-sculptures). Position d’une partie à la controverse ; ne vaut pas arbitrage neutre de la propriété.

[**([B48a](#ref-B48a)) Musée de l’Acropole — Galerie du Parthénon**]{#ref-B48a} — Source institutionnelle. [Consulter la source](https://www.theacropolismuseum.gr/en/exhibit-halls/parthenon-gallery). Présentation institutionnelle de la muséographie ; pour la revendication, déclaration de réunification du 24 mars 2023.

[**([B49](#ref-B49)) UNESCO — Paris, rives de la Seine**]{#ref-B49} — Source institutionnelle. [Consulter la source](https://whc.unesco.org/en/list/600/).

[**([B50](#ref-B50)) UNESCO — Sauvegarde du patrimoine de Tombouctou**]{#ref-B50} — Source institutionnelle. [Consulter la source](https://whc.unesco.org/en/canopy/timbuktu/).

[**([B50a](#ref-B50a)) CPI — Affaire Al Mahdi**]{#ref-B50a} — Source institutionnelle. [Consulter la source](https://www.icc-cpi.int/mali/al-mahdi).

[**([B51](#ref-B51)) UNESCO — Venise et sa lagune**]{#ref-B51} — Source institutionnelle. [Consulter la source](https://whc.unesco.org/en/list/394/).

[**([B52](#ref-B52)) Ministère de la Culture — Grandes dates des monuments historiques**]{#ref-B52} — Source institutionnelle. [Consulter la source](https://www.culture.gouv.fr/thematiques/monuments-sites/monuments-historiques-sites-patrimoniaux/un-peu-d-histoire/les-grandes-dates-des-monuments-historiques).

[**([B53](#ref-B53)) UNESCO — Bassin minier du Nord-Pas-de-Calais**]{#ref-B53} — Source institutionnelle. [Consulter la source](https://whc.unesco.org/en/list/1360/).

[**([B54](#ref-B54)) UNESCO — Repas gastronomique des Français, inscription 2010**]{#ref-B54} — Source institutionnelle. [Consulter la source](https://ich.unesco.org/en/RL/gastronomic-meal-of-the-french-00437).

[**([B55](#ref-B55)) ONF — Ordonnance de Colbert de 1669 et forêt de Tronçais**]{#ref-B55} — Source institutionnelle. [Consulter la source](https://www.onf.fr/onf/%2B/ff6%3A%3Ala-grande-histoire-des-forets-episode-ordonnance-de-colbert-en-1669-la-gestion-forestiere-en-foret-de-troncais.html).

[**([B55a](#ref-B55a)) ONF — Histoire des forêts**]{#ref-B55a} — Source institutionnelle. [Consulter la source](https://www.onf.fr/vivre-la-foret/fonctionnement-gestion-foret/histoire-des-forets).

[**([B56](#ref-B56)) Inrap — Le Néolithique**]{#ref-B56} — Source institutionnelle. [Consulter la source](https://www.inrap.fr/periodes/neolithique).

[**([B56a](#ref-B56a)) Industrialisation, énergie et transformations des milieux — appui dans la ressource T05**]{#ref-B56a} — Renvoi thématique à un accompagnement officiel. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra23lyceegthggspenvironnementexploitationprotectionenjeupdf-102786.pdf). Le code désigne un point d’appui de la ressource Éduscol, pas une édition intégrale d’un ouvrage original. Voir le jalon correspondant.

[**([B57](#ref-B57)) Collège de France — Petit Âge glaciaire et passage à la modernité**]{#ref-B57} — Source institutionnelle. [Consulter la source](https://www.college-de-france.fr/fr/agenda/cours/histoire-societe-climat-entre-fragilite-et-resilience/le-petit-age-glaciaire-et-le-passage-la-modernite).

[**([B58](#ref-B58)) Stockholm, Rio et Kyoto — appui dans la ressource T05**]{#ref-B58} — Renvoi thématique à un accompagnement officiel. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra23lyceegthggspenvironnementexploitationprotectionenjeupdf-102786.pdf). Le code désigne un point d’appui de la ressource Éduscol, pas une édition intégrale d’un ouvrage original. Voir le jalon correspondant.

[**([B58a](#ref-B58a)) CCNUCC — Contributions déterminées au niveau national**]{#ref-B58a} — Source institutionnelle. [Consulter la source](https://unfccc.int/process-and-meetings/the-paris-agreement/nationally-determined-contributions-ndcs).

[**([B59](#ref-B59)) National Park Service — Histoire et interprétation des parcs**]{#ref-B59} — Source institutionnelle. [Consulter la source](https://www.nps.gov/articles/history-under-construction.htm).

[**([B59a](#ref-B59a)) USDA — Conservation versus preservation**]{#ref-B59a} — Source institutionnelle. [Consulter la source](https://www.usda.gov/about-usda/news/blog/conservation-versus-preservation).

[**([B59b](#ref-B59b)) L’action fédérale américaine et l’EPA — appui dans la ressource T05**]{#ref-B59b} — Renvoi thématique à un accompagnement officiel. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra23lyceegthggspenvironnementexploitationprotectionenjeupdf-102786.pdf). Le code désigne un point d’appui de la ressource Éduscol, pas une édition intégrale d’un ouvrage original. Voir le jalon correspondant.

[**([B60](#ref-B60)) Pluralité des acteurs environnementaux américains — appui dans la ressource T05**]{#ref-B60} — Renvoi thématique à un accompagnement officiel. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra23lyceegthggspenvironnementexploitationprotectionenjeupdf-102786.pdf). Le code désigne un point d’appui de la ressource Éduscol, pas une édition intégrale d’un ouvrage original. Voir le jalon correspondant.

[**([B61](#ref-B61)) Société de la connaissance : définition et enjeux — appui dans la ressource T06**]{#ref-B61} — Renvoi thématique à un accompagnement officiel. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra24lyceegthggspenjeuxconnaissancepdf-104487.pdf). Le code désigne un point d’appui de la ressource Éduscol, pas une édition intégrale d’un ouvrage original. Voir le jalon correspondant.

[**([B62](#ref-B62)) Histoire de l’alphabétisation des femmes — appui dans la ressource T06**]{#ref-B62} — Renvoi thématique à un accompagnement officiel. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra24lyceegthggspenjeuxconnaissancepdf-104487.pdf). Le code désigne un point d’appui de la ressource Éduscol, pas une édition intégrale d’un ouvrage original. Voir le jalon correspondant.

[**([B62a](#ref-B62a)) Sénat — Loi du 21 décembre 1880 sur l’enseignement secondaire des jeunes filles**]{#ref-B62a} — Source institutionnelle. [Consulter la source](https://www.senat.fr/connaitre-le-senat/lhistoire-du-senat/dossiers-dhistoire/les-lois-scolaires-de-jules-ferry/les-lois-scolaires-de-jules-ferry-la-loi-du-21-decembre-1880-sur-lenseignement-secondaire-des-jeunes-filles.html).

[**([B63](#ref-B63)) Musée Curie — Chronologie de Pierre et Marie Curie**]{#ref-B63} — Source institutionnelle. [Consulter la source](https://musee.curie.fr/decouvrir/la-famille-curie/pierre-et-marie-curie-chronologie).

[**([B63a](#ref-B63a)) Communautés scientifiques et découvertes — appui dans la ressource T06**]{#ref-B63a} — Renvoi thématique à un accompagnement officiel. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra24lyceegthggspenjeuxconnaissancepdf-104487.pdf). Le code désigne un point d’appui de la ressource Éduscol, pas une édition intégrale d’un ouvrage original. Voir le jalon correspondant.

[**([B63b](#ref-B63b)) Fission nucléaire et applications stratégiques — appui dans la ressource T06**]{#ref-B63b} — Renvoi thématique à un accompagnement officiel. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra24lyceegthggspenjeuxconnaissancepdf-104487.pdf). Le code désigne un point d’appui de la ressource Éduscol, pas une édition intégrale d’un ouvrage original. Voir le jalon correspondant.

[**([B64](#ref-B64)) Office of the Historian — Crise des missiles de Cuba, 1962**]{#ref-B64} — Source institutionnelle. [Consulter la source](https://history.state.gov/milestones/1961-1968/cuban-missile-crisis).

[**([B65](#ref-B65)) NSF/NCSES — Immigration and the science and engineering workforce, 2019**]{#ref-B65} — Source institutionnelle. [Consulter la source](https://ncses.nsf.gov/pubs/nsb20198/immigration-and-the-s-e-workforce).

[**([B65a](#ref-B65a)) NSF — Arrangement de coopération États-Unis–Inde, annonce du 1er février 2023**]{#ref-B65a} — Source institutionnelle. [Consulter la source](https://www.nsf.gov/news/nsf-signs-us-india-implementation-arrangement-streamline). Page archivée : exemple historique de 2023, non affirmation de la politique actuelle. Date corrigée après réouverture de la source.

[**([B66](#ref-B66)) Cyberespace : couches, acteurs et dépendances — appui dans la ressource T06**]{#ref-B66} — Renvoi thématique à un accompagnement officiel. [Consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra24lyceegthggspenjeuxconnaissancepdf-104487.pdf). Le code désigne un point d’appui de la ressource Éduscol, pas une édition intégrale d’un ouvrage original. Voir le jalon correspondant.

## Droits, adaptations et limites

Les textes historiques du domaine public et les actes officiels sont identifiés ; les autres ressources ne sont pas reproduites intégralement. Les synthèses, tableaux, exercices et schémas nouveaux sont des créations éditoriales de cette édition. Aucun fichier de police n’est livré. Les textes du kit et les fragments récupérés restent conservés séparément avec leurs empreintes ; les nouveaux développements ne sont pas présentés comme le manuscrit ancien retrouvé.

Les vérifications effectuées portent sur la couverture, les correspondances, les points réglementaires, les données explicites et la fabrication. Elles ne constituent pas une relecture disciplinaire indépendante de l’ensemble de l’ouvrage. Le registre JSON précise les accès protégés et les renvois documentaires indirects.
