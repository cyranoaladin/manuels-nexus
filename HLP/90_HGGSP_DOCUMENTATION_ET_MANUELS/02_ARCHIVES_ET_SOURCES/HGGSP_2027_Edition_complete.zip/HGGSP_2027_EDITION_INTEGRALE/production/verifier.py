#!/usr/bin/env python3
"""Contrôles exécutables de couverture, banque, séparation et exports.
Ne constitue pas une relecture disciplinaire indépendante.
"""
from __future__ import annotations
import json,re,hashlib,csv,sys,unicodedata
from pathlib import Path
from collections import Counter
from html.parser import HTMLParser
R=Path(__file__).resolve().parents[1];S=R/'sources';V=R/'verification'
checks=[]
def check(name,ok,detail=''):
 checks.append({'controle':name,'resultat':'PASS' if ok else 'FAIL','detail':detail})
def load(p):return json.loads(p.read_text(encoding='utf-8'))
def words(s):return len(re.findall(r"\b[\wÀ-ÿ]+(?:[’'-][\wÀ-ÿ]+)*\b",s))
class Links(HTMLParser):
 def __init__(self):super().__init__();self.ids=[];self.refs=[];self.imgs=[]
 def handle_starttag(self,t,a):
  d=dict(a)
  if 'id' in d:self.ids.append(d['id'])
  if t=='a' and 'href' in d:self.refs.append(d['href'])
  if t=='img' and 'src' in d:self.imgs.append(d['src'])
def main():
 V.mkdir(exist_ok=True);prog=load(S/'referentiel/programme.json');b=load(S/'banques/banque_pedagogique.json');exams=load(S/'examens/examens_originaux.json');reg=load(S/'referentiel/registre_sources.json')
 matrix=[];titles={};coursewords=0
 sourceids={x['id'] for x in reg['sources']}
 check('REFERENCES_IDENTIFIANTS_UNIQUES',len(sourceids)==len(reg['sources']),str(len(sourceids)))
 check('THEMES_11',len(prog['themes'])==11)
 unknown={}
 for p in S.rglob('*'):
  if p.suffix not in ['.md','.json'] or 'originaux' in p.parts or 'referentiel' in p.parts:continue
  found=set(re.findall(r'(?<![\w-])(?:R-[PT]\d{2}|[SDB]\d{2}[a-z]?)(?!\w)',p.read_text()))
  if found-sourceids:unknown[str(p.relative_to(R))]=sorted(found-sourceids)
 check('TOUS_CODES_SOURCES_RESOLUS',not unknown,str(unknown))
 for t in prog['themes']:
  tid=t['id'];titles[tid]=t['title'];course=S/'chapitres'/f'{tid}.md';text=course.read_text();coursewords+=words(text)
  check(f'{tid}_GROUPES_2_AXES_OTC',sorted(x['kind'] for x in t['groups'])==['axe1','axe2','otc'])
  exids=[x['id'] for x in b['exercices'] if x['theme']==tid]
  for group in t['groups']:
   for j in group['jalons']:
    jid=j['id'];m=re.search(r'^### .*?\{#'+re.escape(jid)+r'\}\s*\n(.*?)(?=^#{1,3} |\Z)',text,re.S|re.M)
    body=m[1] if m else '';n=words(body)
    check(jid+'_ANCRE_CONTENU',bool(m) and n>=70,f'{n} mots sous le jalon ; critère de présence, non certification scientifique.')
    j.update(content_status='redige' if m else 'absent',review_status='revue_editoriale_interne_sans_validation_independante',course_object_ids=[jid],exercise_object_ids=exids)
    matrix.append({'theme':tid,'rubrique':group['kind'],'jalon_id':jid,'jalon':j['label_abrege'],'source_officielle':j['source_id'],'page_pdf_programme':j['source_pdf_page'],'ancre':jid,'mots_sous_jalon':n,'source_cours':str(course.relative_to(R)),'documents_cours':f'{tid}-Doc1 ; {tid}-Doc2','entrainements_theme':' ; '.join(exids),'corrections':f'Compagnon / {tid}','evaluation':f'{tid}-RT','statut':'REDIGE ; REVUE INTERNE, NON INDEPENDANTE'})
  t['content_status']='redige';t['review_status']='revue_editoriale_interne_sans_validation_independante'
  check(f'{tid}_DOCUMENTS_INTEGRES',f'{tid}-Doc1' in text and f'{tid}-Doc2' in text)
  check(f'{tid}_DIAGNOSTIC_ACTIVITE_CORRIGES',set(b['diagnostics_activites'].get(tid,{}))=={'diagnostic','activite'})
  check(f'{tid}_EXERCICES_8',len(exids)==8)
  check(f'{tid}_QCM_5',sum(x['theme']==tid for x in b['qcm'])==5)
  check(f'{tid}_RETEST_1',sum(x['theme']==tid for x in b['nouveaux_tests'])==1)
 check('JALONS_78',len(matrix)==78)
 prog['full_manual_status']='COUVERTURE_REDIGEE_COMPLETE_REVUE_INTERNE';prog['schema_version']='1.0';prog['verification_note']='Présence et correspondance des 78 jalons contrôlées. Les tests ne remplacent pas une relecture scientifique indépendante.'
 (S/'referentiel/programme.json').write_text(json.dumps(prog,ensure_ascii=False,indent=2))
 (V/'MATRICE_COUVERTURE.json').write_text(json.dumps(matrix,ensure_ascii=False,indent=2))
 with (V/'MATRICE_COUVERTURE.csv').open('w',encoding='utf-8-sig',newline='') as f:w=csv.DictWriter(f,fieldnames=list(matrix[0]));w.writeheader();w.writerows(matrix)
 md=['# Matrice de couverture des 78 jalons','Les libellés sont les formes éditoriales du référentiel. Les exercices indiqués dans le JSON/CSV sont rattachés au thème, non présentés comme huit exercices spécifiques à chaque jalon. Un cours développé ne se réduit pas à ses titres ; le contrôle de présence ci-dessous doit être distingué d’une validation disciplinaire indépendante.','| Jalon local | Rubrique | Contenu et ancre | Mots sous la rubrique |','|---|---|---|---|']
 md += [f"| {x['jalon_id']} | {x['rubrique']} | {x['jalon']} | {x['mots_sous_jalon']} |" for x in matrix]
 (V/'MATRICE_COUVERTURE.md').write_text('\n\n'.join(md[:3])+'\n'+'\n'.join(md[3:]))
 for key,n in [('exercices',88),('qcm',55),('nouveaux_tests',11)]:
  arr=b[key];check(key+'_NOMBRE',len(arr)==n,str(len(arr)));check(key+'_IDS_UNIQUES',len({x['id'] for x in arr})==n)
 for e in b['exercices']:
  check(e['id']+'_DOSSIER_COMPLET',all(isinstance(e.get(k),str) and e[k].strip() for k in ['enonce','aide','correction','criteres','remediation','method']),f"Corrigé : {words(e['correction'])} mots")
  check(e['id']+'_DIFFICULTE',e['niveau_difficulte'] in [1,2,3])
 for q in b['qcm']:
  check(q['id']+'_REPONSE_EXPLICATIONS',set(q['options'])=={'A','B','C'} and q['reponse_correcte'] in q['options'] and set(q['explications'])==set(q['options']) and all(q['explications'].values()))
 for rt in b['nouveaux_tests']:check(rt['id']+'_CORRIGE_REACTIVATION',all(rt.get(k) for k in ['enonce','correction','validation','reactivation']))
 methods=(S/'methodes/03_methodes.md').read_text();rem=(S/'methodes/04_remediations.md').read_text();rc=(S/'methodes/06_remediations_corrige.md').read_text()
 check('METHODES_M1_M12',all('{#M'+str(i)+'}' in methods for i in range(1,13)))
 check('REMEDIATIONS_R1_R6',all('{#R'+str(i)+'}' in rem for i in range(1,7)))
 check('MICROTESTS_R1T_R6T_CORRIGES',all(f'## R{i}-T' in rc for i in range(1,7)))
 check('EXAMENS_5_N1_4_N2',Counter(e['niveau'] for e in exams)=={'N1':5,'N2':4})
 for e in exams:
  eid=e['id'];sujet=(S/'examens'/e['sujet']).read_text();corr=(S/'examens'/e['corrige']).read_text()
  check(eid+'_SUJET_CORRIGE_PRESENTS',len(sujet)>200 and len(corr)>200)
  if e['niveau']=='N1':check(eid+'_FORMAT_N1',e['duree_minutes']==120 and e['note']==20)
  else:
   themes=e.get('themes_dissertations',[])+[e.get('theme_etude')]
   check(eid+'_TROIS_THEMES_2027',len(set(themes))==3 and set(themes)<= {'T02','T04','T05','T06'},str(themes))
   check(eid+'_FORMAT_N2',e['duree_minutes']==240)
 for o in load(V/'ORIGINAUX.json'):
  p=R/o['fichier'];check('ORIGINAL_'+p.name,hashlib.sha256(p.read_bytes()).hexdigest()==o['sha256'])
 for i in range(1,10):check(f'ATLAS_A{i:02}_PNG_PDF',all((R/'illustrations'/f'A{i:02}.{ext}').is_file() for ext in ['png','pdf']))
 for p in (R/'html').glob('*.html'):
  h=Links();h.feed(p.read_text());idset=set(h.ids);missing=[x for x in h.refs if x.startswith('#') and x[1:] not in idset]
  check(p.stem+'_LIENS_INTERNES',not missing,str(missing[:8]));check(p.stem+'_ID_UNIQUES',len(h.ids)==len(idset))
  check(p.stem+'_IMAGES',all((p.parent/x).is_file() for x in h.imgs))
 loglist=list((R/'production/build').glob('*/*.log'))
 if not loglist:loglist=list((V/'journaux').glob('*.log'))
 for log in loglist:
  if log.name=='commands.log':continue
  txt=log.read_text(errors='replace')
  check(log.stem+'_JOURNAL_GLYPHES', 'Missing character:' not in txt)
  check(log.stem+'_JOURNAL_LIENS', 'undefined references' not in txt and 'multiply defined' not in txt)
  widths=[float(x) for x in re.findall(r'Overfull \\hbox \(([0-9.]+)pt',txt)]
  check(log.stem+'_JOURNAL_DEBORDEMENTS',not widths,'Débordements horizontaux : '+str(widths))
 pdfstats=[]
 try:
  import fitz
  for p in (R/'pdf').glob('*.pdf'):
   d=fitz.open(p);text='\n'.join(pg.get_text() for pg in d);links=[l for pg in d for l in pg.get_links()];toc=d.get_toc()
   invalid=[l for l in links if l.get('kind')==1 and not (0<=l.get('page',-1)<len(d))]
   check(p.stem+'_PDF_OUVERT',len(d)>1 and len(text)>1000)
   outside=[]
   for page in d:
    for block in page.get_text('dict')['blocks']:
     for line in block.get('lines',[]):
      for span in line['spans']:
       box=span['bbox']
       if box[0]<-1 or box[1]<-1 or box[2]>page.rect.width+1 or box[3]>page.rect.height+1:outside.append(page.number+1)
   check(p.stem+'_TEXTE_DANS_LA_PAGE',not outside,str(sorted(set(outside))))
   check(p.stem+'_SOMMAIRE_SIGNETS',len(toc)>5)
   def norm(z):return re.sub(r'[^a-z0-9]','',unicodedata.normalize('NFKD',z.lower()))
   misplaced=[]
   for level,title,page_number in toc:
    if norm(title) not in norm(d[page_number-1].get_text()):misplaced.append({'titre':title,'page':page_number})
   check(p.stem+'_SIGNETS_VERS_BON_TITRE',not misplaced,str(misplaced[:8]))
   check(p.stem+'_LIENS_PDF',not invalid)
   check(p.stem+'_GLYPHES_REPLACEMENT','\ufffd' not in text)
   fonts={f[0]:f for pg in d for f in pg.get_fonts(full=True)};embed=[]
   for xref,f in fonts.items():
    try:embed.append(bool(d.extract_font(xref)[3]))
    except Exception:embed.append(False)
   check(p.stem+'_POLICES_INCORPOREES',all(embed),str(len(fonts)))
   pdfstats.append({'fichier':str(p.relative_to(R)),'pages':len(d),'signets':len(toc),'liens':len(links),'taille_octets':p.stat().st_size,'polices':len(fonts),'polices_incorporees':all(embed),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()})
   if 'Sujets_seuls' in p.name:
    check('SUJETS_SEULS_PAS_CORRIGES',not re.search(r'Proposition de correction|Corrigé de la dissertation|Proposition rédigée|Réponse correcte',text,re.I))
   d.close()
 except ImportError:check('PYMUPDF_DISPONIBLE',False,'Installer pymupdf pour contrôler les exports PDF.')
 check('CINQ_PDF_PRESENTS',len(pdfstats)==5)
 summary={'date':'2026-09-08','tests_executes':len(checks),'reussites':sum(c['resultat']=='PASS' for c in checks),'echecs':sum(c['resultat']=='FAIL' for c in checks),'mots_cours':coursewords,'jalons':len(matrix),'exercices':len(b['exercices']),'qcm':len(b['qcm']),'retests':len(b['nouveaux_tests']),'references':len(sourceids),'pdf':pdfstats,'limite':'Contrôles structurels, correspondances et contrôles techniques. Pas de validation scientifique indépendante ni certification PDF/UA.','controles':checks}
 (V/'CONTROLES_FINAUX.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2));print(json.dumps({k:v for k,v in summary.items() if k not in ['controles','pdf']},ensure_ascii=False,indent=2))
 fails=[c for c in checks if c['resultat']=='FAIL'];print(json.dumps(fails,ensure_ascii=False,indent=2))
 if fails:raise SystemExit(1)
if __name__=='__main__':main()
