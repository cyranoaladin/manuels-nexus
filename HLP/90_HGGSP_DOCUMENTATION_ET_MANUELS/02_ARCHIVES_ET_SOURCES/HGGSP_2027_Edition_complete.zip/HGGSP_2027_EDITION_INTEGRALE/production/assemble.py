#!/usr/bin/env python3
"""Assemble les cinq volumes depuis les seules sources canoniques du paquet.
Aucun accès au réseau ; aucune modification des sources ou des originaux.
"""
from __future__ import annotations
import json, re
from pathlib import Path
R=Path(__file__).resolve().parents[1]
S=R/'sources'; OUT=R/'production'/'assemblages'
THEMES=[f'P{i:02}' for i in range(1,6)]+[f'T{i:02}' for i in range(1,7)]
NAMES={
'manuel_cycle':('HGGSP — Cycle terminal','Manuel du candidat individuel · Parcours N1 et N2','HGGSP_2027_Manuel_Cycle_terminal'),
'manuel_niveau1':('HGGSP — Première','Parcours N1 · Spécialité non poursuivie','HGGSP_2027_Niveau_1_Premiere'),
'compagnon':('HGGSP — Autocorrection','Compagnon du manuel · Comprendre, corriger, reprendre','HGGSP_2027_Compagnon_Autocorrection'),
'epreuves':('HGGSP — Épreuves blanches','Cinq compositions N1 et quatre écrits N2 · Sujets et corrigés','HGGSP_2027_Epreuves_blanches_et_corriges'),
'sujets_seuls':('HGGSP — Sujets seuls','Cinq compositions N1 et quatre écrits N2 · Sans corrigés','HGGSP_2027_Epreuves_Sujets_seuls')}
def read(rel:str)->str:return (S/rel).read_text(encoding='utf-8').strip()
def bank_questions(b:dict,t:str)->str:
 out=[f'## Entraînements — {t} {{#{t}-entrainements}}',
 'Les degrés 1, 2 et 3 désignent la difficulté, non les parcours N1/N2. Commencez sans aide ; consultez ensuite l’indice si nécessaire. Les corrections, les critères détaillés et les remédiations sont dans le compagnon, sous les mêmes identifiants.']
 for e in b['exercices']:
  if e['theme']!=t:continue
  out += [f"### {e['id']} — {e['title']} {{#{e['id']}}}",f"**Degré {e['niveau_difficulte']} · {e['minutes']} minutes · Méthode {e['method']}**",e['enonce'],f"**Aide, après une première tentative.** {e['aide']}"]
 out += [f'### {t} — QCM de vérification {{#{t}-qcm}}','Une seule proposition correcte par question. Notez votre réponse et justifiez-la en une phrase ; la correction explique aussi pourquoi les autres propositions ne conviennent pas.']
 for q in b['qcm']:
  if q['theme']==t:
   out += [f"**{q['id']}.** {q['enonce']}"]+[f"**{k}.** {v}" for k,v in q['options'].items()]
 rt=next(x for x in b['nouveaux_tests'] if x['theme']==t)
 out += [f"### {rt['id']} — Nouveau test et réactivation {{#{rt['id']}}}",f"**{rt['duree_minutes']} minutes, sans cours, à distance du premier entraînement.**",rt['enonce'],f"**Vérifier la maîtrise.** {rt['validation']}",f"**Réactivation espacée.** {rt['reactivation']}",
 f'**Trace de progression.** Date : … · Je restitue : oui / à reprendre · J’explique : oui / à reprendre · Je mobilise dans un sujet nouveau : oui / à reprendre · Erreur prioritaire : … · Nouvelle tentative prévue : …']
 return '\n\n'.join(out)
def corrections(b:dict,t:str)->str:
 out=[f'# {t} — Corriger et progresser {{#corr-{t}}}',
 f"## {t}-D — Diagnostic : réponses et orientation",b['diagnostics_activites'][t]['diagnostic'],
 f"## {t}-A — Activité du cours : éléments de correction",b['diagnostics_activites'][t]['activite'],
 '## Exercices : démarches, réponses et critères']
 for e in b['exercices']:
  if e['theme']!=t:continue
  out += [f"### {e['id']} — {e['title']} {{#corr-{e['id']}}}",e['correction'],f"**Critères observables.** {e['criteres']}",f"**Reprise ciblée.** {e['remediation']}"]
 out+=['## QCM : comprendre chaque proposition']
 for q in b['qcm']:
  if q['theme']!=t:continue
  out+=[f"### {q['id']} — Réponse {q['reponse_correcte']} {{#corr-{q['id']}}}"]+[f"**{k}.** {v}" for k,v in q['explications'].items()]
 rt=next(x for x in b['nouveaux_tests'] if x['theme']==t)
 out += [f"## {rt['id']} — Corrigé du nouveau test {{#corr-{rt['id']}}}",rt['correction'],f"**Validation.** {rt['validation']}",f"**À distance.** {rt['reactivation']}"]
 return '\n\n'.join(out)
def decorate_sources(text:str,ids:set[str])->str:
 # Ancre de chaque référence, sans modifier les URL ni leur libellé.
 text=re.sub(r'^\*\*\[([^\]]+)\] ([^\n]*?)\*\*',lambda m:'[**['+m[1]+'] '+m[2]+'**]{#ref-'+m[1]+'}' if m[1] in ids else m[0],text,flags=re.M)
 def group(m):
  raw=m[1]
  if not re.fullmatch(r'[A-Z0-9a-z ;,–-]+',raw):return m[0]
  codes=re.findall(r'R-[PT]\d{2}|[SDB]\d{2}[a-z]?',raw)
  if not codes or any(c not in ids for c in codes):return m[0]
  # Les plages de codes sont développées explicitement.
  r=re.fullmatch(r'([SD])([0-9]{2})[–-]([SD])([0-9]{2})',raw)
  if r and r[1]==r[3]:codes=[r[1]+f'{i:02}' for i in range(int(r[2]),int(r[4])+1) if r[1]+f'{i:02}' in ids]
  if r and r[1]==r[3]:return '('+' ; '.join(f'[{c}](#ref-{c})' for c in codes)+')'
  # Conserver les renvois au thème et à une méthode, présents dans le même groupe.
  linked=re.sub(r'R-[PT]\d{2}|[SDB]\d{2}[a-z]?',lambda z:f'[{z[0]}](#ref-{z[0]})',raw)
  return '('+linked+')'
 # Ne pas prendre les intitulés bibliographiques doubles ni les liens markdown existants.
 text=re.sub(r'(?<!\[)\[([^\[\]\n]+)\](?![({\]])',group,text)
 return text

def main()->dict:
 OUT.mkdir(parents=True,exist_ok=True)
 b=json.loads((S/'banques/banque_pedagogique.json').read_text())
 reg=json.loads((S/'referentiel/registre_sources.json').read_text()); ids={x['id'] for x in reg['sources']}
 refs=read('annexes/references.md')
 common=[read('methodes/03_methodes.md'),read('methodes/04_remediations.md')]
 start=[read('methodes/00_mode_emploi.md'),read('methodes/01_module00.md')]
 courses={t:read(f'chapitres/{t}.md')+'\n\n'+bank_questions(b,t) for t in THEMES}
 atlas=read('annexes/atlas.md')
 atlas1=re.split(r'(?=^## A\d\d)',atlas.replace('\\clearpage\n\n',''),flags=re.M)
 atlas1='\n\n'.join(x for x in atlas1 if not x.startswith('## A') or x[3:6] in ['A01','A02','A03','A04','A06'])
 atlas1=re.sub(r'^## (A0[2-9])',lambda m:'\\clearpage\n\n## '+m[1],atlas1,flags=re.M)
 volumes={
 'manuel_cycle':start+[courses[t] for t in THEMES]+common+[read('methodes/05_oraux.md'),atlas,read('annexes/lexique.md'),refs],
 'manuel_niveau1':["# Lire le volume Première\n\nCe volume rassemble le parcours N1 : les cinq thèmes de Première, leurs entraînements et les méthodes nécessaires à la composition de deux heures. Les premières pages situent aussi N2 pour éviter une confusion de parcours ; les cours de Terminale ne sont pas inclus. Utiliser les corrigés P01 à P05 du compagnon commun et les sujets N1-1 à N1-5 du volume d’épreuves."]+start+[courses[t] for t in THEMES[:5]]+common+[atlas1,read('annexes/lexique.md'),refs],
 'compagnon':["# Utiliser l’autocorrection\n\nRédigez d’abord votre réponse, même incomplète. Comparez ensuite la démarche, les faits mobilisés et la conclusion. Une formulation différente peut être recevable si elle respecte le sujet et les sources ; un plan proposé n’est pas un plan obligatoire. Notez une erreur précise, réalisez la remédiation indiquée, puis le nouveau test sans le corrigé.\n\nLes identifiants du manuel sont conservés. Toutes les corrections du corpus avancé sont une rédaction nouvelle de cette édition. Les énoncés récupérés sont identifiés dans les sources JSON. Les corrigés du module 00 viennent du kit fondateur, avec adaptation des identifiants. Les corrigés des neuf épreuves blanches sont dans un volume distinct.",read('methodes/02_module00_corrige.md')]+[corrections(b,t) for t in THEMES]+[read('methodes/06_remediations_corrige.md'),refs],
 'epreuves':["# Passer une épreuve, puis l’analyser\n\nCe volume contient neuf sujets originaux d’entraînement et leurs corrections : cinq compositions N1, puis quatre écrits N2. Ce ne sont pas des sujets officiels annoncés pour 2027. Les barèmes détaillés et les répartitions temporelles sont pédagogiques, sauf les durées et notes prescrites indiquées comme telles.\n\nPour un premier essai en temps limité, utilisez le volume « Sujets seuls ». Dans chaque N2, choisissez une seule des deux dissertations ; traitez aussi l’étude critique. Les deux dissertations proposées sont corrigées pour permettre une reprise ultérieure. Lire les deux corrigés avant la première tentative enlève au sujet sa fonction diagnostique.\n\nLes documents adaptés et les tableaux éditoriaux sont identifiés dans chaque dossier. Ils sont fournis intégralement dans le sujet. Les corrigés sont des propositions argumentées, non une grille officielle exclusive. [S04 ; S05]"],
 'sujets_seuls':["# Consignes de passation\n\nCes neuf sujets originaux d’entraînement ne sont pas des sujets officiels de la session 2027. Aucun corrigé n’est inclus dans ce volume. Écrivez sur une copie séparée et conservez votre brouillon pour analyser votre démarche après l’épreuve.\n\n**N1 :** composition de deux heures, sur 20 ; traiter le sujet indiqué. **N2 :** quatre heures ; choisir une dissertation parmi les deux proposées, puis traiter l’étude critique ; chaque exercice est noté sur 10. La répartition du temps entre exercices relève de votre méthode.\n\nLes documents nécessaires aux études critiques sont intégrés et leur nature est précisée. Les tableaux éditoriaux ne sont pas des données statistiques authentiques sauf mention expresse. Les durées et le format sont fondés sur les textes applicables ; les corrigés et barèmes pédagogiques sont dans le volume séparé. [S04 ; S05]"]}
 for eid in [f'N1-{i}' for i in range(1,6)]+[f'N2-{i}' for i in range(1,5)]:
  sujet=read(f'examens/{eid}_sujet.md');corr=read(f'examens/{eid}_corrige.md')
  volumes['epreuves'] += [sujet,corr];volumes['sujets_seuls'] +=[sujet]
 for key in ['epreuves','sujets_seuls']:
  used=set(re.findall(r'R-[PT]\d{2}|\b[SDB]\d{2}[a-z]?', '\n'.join(volumes[key])))|{'S02','S03','S04','S05'}
  paragraphs=refs.split('\n\n'); chosen=[]
  for para in paragraphs:
   m=re.match(r'\*\*\[([^\]]+)\]',para)
   if not m or m[1] in used:chosen.append(para)
  volumes[key] +=['\n\n'.join(chosen)]
 stats={}
 for key,parts in volumes.items():
  title,subtitle,filename=NAMES[key]
  meta={'title':title,'subtitle':subtitle,'author':'Nexus Réussite — Collection Manuels scolaires','date':'Session 2027 · Édition pédagogique 1.0 · 8 septembre 2026','lang':'fr-FR'}
  # JSON est une syntaxe YAML valide, préservant tous les accents.
  header='---\n'+'\n'.join(k+': '+json.dumps(v,ensure_ascii=False) for k,v in meta.items())+'\n---\n\n'
  body=decorate_sources('\n\n'.join(parts),ids)
  (OUT/(key+'.md')).write_text(header+body+'\n',encoding='utf-8')
  stats[key]={'fichier':filename,'mots_assemblage':len(re.findall(r"\b[\wÀ-ÿ]+(?:[’'-][\wÀ-ÿ]+)*\b",body))}
 (R/'verification/ASSEMBLAGES.json').write_text(json.dumps(stats,ensure_ascii=False,indent=2))
 return stats
if __name__=='__main__':print(json.dumps(main(),ensure_ascii=False,indent=2))
