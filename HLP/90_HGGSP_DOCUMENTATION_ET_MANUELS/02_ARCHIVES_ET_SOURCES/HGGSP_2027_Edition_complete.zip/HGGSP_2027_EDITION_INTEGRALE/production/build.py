#!/usr/bin/env python3
"""Construction portable des PDF et HTML, depuis les sources canoniques.
Dépendances : Python 3.10+, Pandoc, LuaLaTeX, Noto Serif, Lato,
DejaVu Sans Mono. Aucun réseau, téléchargement ou remplacement des originaux.
"""
from __future__ import annotations
import argparse, concurrent.futures, json, shutil, subprocess, time, re
from pathlib import Path
from assemble import main as assemble, NAMES
R=Path(__file__).resolve().parents[1]
def run(args:list[str],log:Path,cwd:Path=R)->None:
 with log.open('a',encoding='utf-8') as f:
  f.write('\n$ '+' '.join(args)+'\n');f.flush()
  p=subprocess.run(args,cwd=cwd,stdout=f,stderr=subprocess.STDOUT,text=True)
 if p.returncode:raise RuntimeError(f'Commande échouée ({p.returncode}) ; voir {log.relative_to(R)}')
def volume(key:str)->dict:
 title,sub,filename=NAMES[key];md=R/'production/assemblages'/f'{key}.md'
 work=R/'production/build'/key;work.mkdir(parents=True,exist_ok=True)
 log=work/'commands.log';log.write_text('',encoding='utf-8')
 tex=work/(key+'.tex')
 common=['pandoc',str(md),'--standalone','--toc','--toc-depth=2','--top-level-division=chapter','--resource-path='+str(R),'-M','lang=fr-FR']
 run(common+['-t','latex','-V','documentclass=report','-V','fontsize=11pt','-V','mainfont=Noto Serif','-V','sansfont=Lato','-V','monofont=DejaVu Sans Mono','-V','link-citations=true','--include-in-header='+str(R/'production/style.tex'),'-o',str(tex)],log)
 tx=tex.read_text();tx=re.sub(r'\\title\{.*?\}\n\\author',lambda m:'\\title{'+title.split(' — ',1)[-1]+'}\n\\subtitle{'+sub+'}\n\\author',tx,count=1,flags=re.S)
 tx=tx.replace('→',r'\ensuremath{\rightarrow}').replace('−',r'\ensuremath{-}')
 tx=re.sub(r'\s+(?=[;:!?])','~',tx)
 tx=tx.replace(r'\textbf{Document ',r'\Needspace{8\baselineskip}'+ '\n' + r'\textbf{Document ')
 tex.write_text(tx,encoding='utf-8')
 for _ in range(3):run(['lualatex','-interaction=nonstopmode','-halt-on-error','-file-line-error','-output-directory='+str(work),str(tex)],log)
 dest=R/'pdf'/f'{filename}.pdf';shutil.copy2(work/(key+'.pdf'),dest)
 htmlmd=work/'web.md';htmlmd.write_text(md.read_text().replace('(illustrations/','(../illustrations/'),encoding='utf-8')
 run(['pandoc',str(htmlmd),'--standalone','--toc','--toc-depth=2','--section-divs','--metadata','lang=fr-FR','--css=style.css','-o',str(R/'html'/f'{filename}.html')],log)
 return {'volume':key,'pdf':str(dest.relative_to(R)),'taille':dest.stat().st_size}
def main()->None:
 ap=argparse.ArgumentParser();ap.add_argument('--volumes',nargs='*',choices=list(NAMES));ap.add_argument('--jobs',type=int,default=2);args=ap.parse_args()
 for name in ['pandoc','lualatex']:
  if not shutil.which(name):raise SystemExit(f'Dépendance absente : {name}')
 for d in ['pdf','html','verification']:(R/d).mkdir(exist_ok=True)
 assemble();shutil.copy2(R/'production/style.css',R/'html/style.css')
 names=args.volumes or list(NAMES);start=time.time();results=[]
 with concurrent.futures.ThreadPoolExecutor(max_workers=max(1,min(args.jobs,3))) as ex:
  fs={ex.submit(volume,k):k for k in names}
  for f in concurrent.futures.as_completed(fs):
   result=f.result();results.append(result);print(json.dumps(result,ensure_ascii=False),flush=True)
 (R/'verification/BUILD.json').write_text(json.dumps({'duree_secondes':round(time.time()-start,1),'volumes':results},ensure_ascii=False,indent=2))
if __name__=='__main__':main()
