# Pack d’audit HGGSP — 9 septembre 2026

## Lire

Ouvrir `RAPPORT_AUDIT_ET_FINALISATION.md`. Il distingue la liste locale fournie des fichiers de référence réellement inspectés dans la conversation.

`PREUVES_TESTS_VERIFICATEUR.json` documente trois essais effectués sur trois copies distinctes : référence intacte, ancre de jalon absente, cinq HTML absents. Les copies de test modifiées ne sont pas distribuées et ne doivent pas servir à la production.

`VOLUMES_ET_COUPLAGES_PROPOSES.json` et `PLAN_CLASSEMENT_21_ENTREES.json` sont des propositions, pas la preuve d’un rangement déjà réalisé. Les cinq nouvelles couvertures de l’utilisateur n’ont pas été inspectées.

## Inventorier le poste local sans réorganiser les fichiers

Après avoir placé le script dans un dossier choisi, exécuter, en adaptant seulement le chemin vers le script si nécessaire :

```bash
python3 auditer_dossier_hggsp.py "$HOME/Documents/Manuels_Nexus/HGGSP"
```

Le script utilise uniquement la bibliothèque standard de Python 3.10 ou ultérieur. Il ne lance aucun script du projet, ne suit pas les liens symboliques, n’extrait pas d’archive et ne déplace, supprime ou renomme aucun fichier analysé. Il crée un nouveau dossier de rapport **à côté** de HGGSP, jamais dedans. Aucun rapport existant n’est écrasé.

Les résultats sont `AUDIT_LOCAL.md` et `AUDIT_LOCAL.json`. Le second contient tailles, empreintes, doublons binaires, chemins de sources et dimensions PNG. Il ne rend pas les PDF, ne valide pas les images et ne certifie pas le contenu pédagogique.

Une empreinte différente de la référence 1.0 peut indiquer une modification légitime, notamment l’ajout des nouvelles couvertures. Elle nécessite un rapprochement, pas une suppression.

Le script a été exécuté sur les cinq PDF fournis dans la conversation : cinq correspondances aux empreintes de référence, aucune erreur de lecture. Cette exécution ne constitue pas un audit du disque de l’utilisateur.

## Préserver

L’archive originale `HGGSP_2027_Edition_complete.zip` n’est pas recopiée dans ce pack. Conserver cette archive complète indépendamment. Son SHA-256 contrôlé est :

```text
47c37f71ae08d352c2bc44d88994cf56ab7e91b5eff39e2987459902019478c8
```

Aucun fichier de police n’est inclus. Aucun document de cette livraison ne remplace le logo officiel ou les couvertures originales.
