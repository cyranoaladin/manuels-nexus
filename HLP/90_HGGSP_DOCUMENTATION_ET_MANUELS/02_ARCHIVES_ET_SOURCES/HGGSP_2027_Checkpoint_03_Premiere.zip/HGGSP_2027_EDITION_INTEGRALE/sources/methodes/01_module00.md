# Entrer en HGGSP — Module 00 du candidat individuel

Module fondateur conservé ; identifiants préfixés « 00- » pour éviter les collisions avec ceux du manuel.

## Entrer en HGGSP

**Comprendre • analyser • argumenter**
Module 00 — Première et entrée en Terminale

**POUR LE CANDIDAT INDIVIDUEL**

Un premier parcours autonome, avant les onze thèmes du cycle. Ce livret apprend à travailler un document, à distinguer un principe d’une pratique, à utiliser une donnée et à construire une réponse argumentée.

### À la fin du module, vous saurez…

Identifier les quatre approches de la spécialité ; poser une question précise ; présenter une source ; limiter vos conclusions à ce que les pièces permettent ; organiser un paragraphe et vérifier votre travail.

| Parcours conseillé | Durée de travail indicative |
| --- | --- |
| Se situer, découvrir la discipline, apprendre à lire une source | Deux heures, avec prise de notes et premiers exercices. |
| Argumenter, traiter un dossier, se tester et reprendre | Deux heures, puis une courte réactivation à distance. |

Le livret d’autocorrection est séparé : écrivez une première réponse avant de l’ouvrir. Vous pourrez ensuite identifier votre erreur, reprendre une méthode et tenter un nouvel exercice. Les espaces prévus servent à prendre des notes ; rédigez les productions longues sur une feuille ou dans votre cahier.

Nexus Réussite • Version pédagogique 0.1 • 8 septembre 2026. Les cas « Rivage » et les situations de test sont fictifs ; le document de 1789 est réel et référencé. Ce module n’est pas le cours complet du thème « Démocratie ».

## Mon itinéraire vers le baccalauréat

| Mon cas | Ce que je dois préparer en HGGSP |
| --- | --- |
| J’arrête HGGSP après la Première. | Les cinq thèmes de Première et la composition de deux heures de l’évaluation ponctuelle : coefficient 8. |
| Je conserve HGGSP en Terminale. | Les six thèmes de Terminale et leurs liens avec la Première. Pour l’écrit, une dissertation et une étude critique, en quatre heures : coefficient 16. |
| Je prépare le Grand oral. | Deux questions couvrant mes deux spécialités conservées ; 20 min de préparation, puis 10 min de présentation et 10 min d’échange. Coefficient 8 en voie générale à partir de 2027. |

Pour la Terminale, les thèmes de l’écrit varient selon la session : **2027 : 2, 4, 5 et 6 ; 2028 : 1, 2, 3 et 5.** Cette sélection de révision ne supprime pas les deux autres thèmes du cours. [S04–S09]

**À NE PAS CONFONDRE**

HGGSP ne remplace pas l’histoire-géographie du tronc commun. Le Grand oral n’est pas l’oral de contrôle. Une préparation à une épreuve ne vaut pas inscription au baccalauréat.

### Mon carnet de bord

| Information | À compléter |
| --- | --- |
| Session du diplôme |  |
| Spécialité conservée ou non poursuivie |  |
| Autre spécialité conservée, le cas échéant |  |
| Service des examens / notice consultée |  |
| Créneaux réguliers de travail personnel |  |

Sources S04–S09. Vérifiez vos choix et dates sur votre confirmation d’inscription et les documents du service des examens. Les calendriers locaux ne sont pas fixés par ce livret.

## Diagnostic : ce que je sais déjà faire

**15 minutes, sans recherche.** Répondez en quelques mots, sauf indication contraire. Un doute est une information utile : ne devinez pas uniquement pour remplir la page.

**00-D1.** Rangez ces dates de la plus ancienne à la plus récente : 1992, 1648, 1789.

*Répondez dans votre cahier.*

**00-D2.** Un texte rédigé en 1789 est reproduit sur Légifrance en 2026. Quelle date utilisez-vous pour le contexte de production ? Quel rôle joue le site ?

*Répondez dans votre cahier.*

**00-D3.** « L’événement B a suivi l’événement A ; donc A est la cause de B. » La conclusion est-elle certaine ? Justifiez.

*Répondez dans votre cahier.*

**00-D4.** Une consultation en ligne reçoit 100 réponses volontaires, dont 80 favorables. Peut-on affirmer que 80 % de tous les habitants sont favorables ?

*Répondez dans votre cahier.*

**00-D5.** Un règlement proclame l’égalité de tous. Ce document prouve-t-il que tous sont effectivement traités de façon égale ?

*Répondez dans votre cahier.*

**00-D6.** Un message très partagé est-il nécessairement exact ? Indiquez une vérification à faire.

*Répondez dans votre cahier.*

**00-D7.** Classez du plus local au plus large : commune, monde, État.

*Répondez dans votre cahier.*

**00-D8.** « Ce projet est excellent. » Est-ce une donnée mesurée ou un jugement ? Que faudrait-il ajouter pour construire une argumentation ?

*Répondez dans votre cahier.*

Orientation : 00-D1–00-D2 fragiles → 00-R1 ; 00-D3 et 00-D8 → 00-R2 ; 00-D4 et 00-D7 → 00-R3 ; 00-D5–00-D6 → 00-R4. Les fiches de reprise figurent dans ce livret ; le corrigé détaillé est dans le compagnon.

## Quatre regards sur une même question

HGGSP associe quatre approches. Elles ne sont pas quatre cours indépendants et l’on ne doit pas les confondre. [S02–S03]

| Approche | Questions caractéristiques |
| --- | --- |
| Histoire | Comment une situation s’est-elle construite ? Quelles ruptures, continuités et temporalités permettent de la comprendre ? |
| Géographie | Comment les sociétés organisent-elles les espaces ? Où se répartissent activités, populations et ressources ? À quelles échelles ? |
| Géopolitique | Quels acteurs rivalisent ou coopèrent pour des territoires, des ressources et des positions ? Quels sont leurs moyens et leurs représentations ? |
| Sciences politiques | Comment le pouvoir est-il organisé, exercé et contesté ? Comment fonctionnent institutions, participation et décision collective ? |

**CAS D’ENTRAÎNEMENT FICTIF**

Deux communes discutent de l’extension d’un port commun. Des entreprises espèrent de nouveaux débouchés ; une association souhaite préserver une zone humide ; des habitants réclament une consultation. Aucune commune réelle n’est désignée.

### Exercice 00-E1 — Reconnaître une approche

Associez chaque question à l’approche dominante, puis justifiez une association. Plusieurs approches peuvent ensuite être articulées.

a. Comment la fonction du port a-t-elle changé en trente ans ?
b. Où se trouvent la zone humide et les quartiers exposés aux flux ?
c. Comment les deux communes négocient-elles le contrôle des revenus ?
d. Qui est habilité à décider et comment les habitants participent-ils ?

*Répondez dans votre cahier.*

### Exercice 00-E2 — Construire sa question

À partir de ce cas, écrivez une question qui articule deux approches. Évitez « Que pensez-vous du port ? », qui appelle une opinion sans préciser ce qu’il faut expliquer.

*Répondez dans votre cahier.*

## Des mots pour penser précisément

| Notion de travail | Définition et vigilance |
| --- | --- |
| Acteur | Individu, groupe, institution ou organisation qui intervient dans une situation. Préciser ses objectifs, moyens et contraintes. |
| Territoire | Espace approprié et organisé par des acteurs. Ne pas le réduire à une surface sur une carte. |
| Échelle | Niveau spatial de l’analyse : local, national, régional ou mondial. Une explication peut changer quand on change d’échelle. |
| Institution | Organisation ou ensemble de règles qui stabilise l’exercice d’une activité ou d’un pouvoir. |
| Puissance | Capacité d’un acteur à agir, influencer ou imposer dans une relation donnée. Identifier ses moyens et ses limites. |
| Démocratie | Régime fondé sur la souveraineté du peuple ; son étude examine participation, représentation, libertés, institutions et pratiques. |
| Source | Trace ou document à partir duquel on construit une connaissance. Sa valeur dépend notamment de la question posée. |
| Preuve / élément de preuve | Information qui permet d’étayer une proposition dans un raisonnement explicite. Une source doit être interrogée, non invoquée seulement par son titre. |
| Interprétation | Explication argumentée de faits et de sources. Elle peut être discutée à partir d’éléments vérifiables. |
| Contexte | Ensemble des circonstances pertinentes pour comprendre la production d’un document ou une situation. |
| Problématique | Question directrice qui identifie un problème à expliquer et organise la réponse. |
| Document normatif | Texte qui énonce une règle, un droit ou un principe. Il ne décrit pas automatiquement les pratiques effectives. |

Ces formulations sont des définitions de travail pour débuter. Elles seront précisées dans les thèmes. Les notions et approches sont rattachées aux programmes S02–S03 et aux ressources R-P01 à R-P05.

### Exercice 00-E3

Choisissez deux notions et formulez une phrase qui les emploie à propos du port fictif. La phrase doit montrer leur sens, pas seulement juxtaposer les mots.

*Répondez dans votre cahier.*

## Lire une source : un texte de 1789

**DOCUMENT A — SOURCE RÉELLE**

Déclaration du 26 août 1789 des droits de l’homme et du citoyen, article 16 :
« Toute société dans laquelle la garantie des droits n’est pas assurée, ni la séparation des pouvoirs déterminée, n’a point de constitution. »

**Identification.** Le texte est adopté par les représentants constitués en Assemblée nationale. Il énonce des principes. La transcription consultée est diffusée par Légifrance. La date de consultation du site, le 8 septembre 2026, n’est pas la date de rédaction du document. [S10]

**Vocabulaire.** Garantir signifie ici assurer la protection ; les pouvoirs renvoient à l’organisation de l’autorité politique. Pour analyser cette phrase, recherchez les deux conditions associées à l’existence d’une constitution au sens du texte.

### Exercice 00-E4 — Lecture guidée

1. Présentez la nature, l’origine et la date du document en une phrase.

*Répondez dans votre cahier.*

2. Quelles sont les deux exigences énoncées ? Reformulez-les sans recopier toute la phrase.

*Répondez dans votre cahier.*

3. Expliquez pourquoi il s’agit d’un texte normatif.

*Répondez dans votre cahier.*

4. Un candidat écrit : « Ce texte prouve que ces deux exigences sont partout respectées en France dès 1789. » Peut-on conclure cela à partir du document ?

*Répondez dans votre cahier.*

5. Quel autre type de source permettrait d’étudier l’application d’un de ces principes ?

*Répondez dans votre cahier.*

Source S10, article 16 ; transcription typographique, sans coupe dans la phrase citée. Le texte intégral est accessible par le lien donné en fin de livret. Ce document de méthode ne remplace pas les jalons officiels de P01.

## 00-M04 — Faire une étude critique

**Critiquer un document ne signifie pas le dénigrer.** Il s’agit d’en comprendre l’apport et les limites en fonction de la question posée.

| Étape | Action à effectuer |
| --- | --- |
| 1. Situer | Identifier auteur, date, nature, destinataire et circonstances pertinentes. Un site de publication n’est pas nécessairement l’auteur. |
| 2. Comprendre | Déterminer le sujet et l’idée principale. Repérer les mots qui commandent le sens. |
| 3. Prélever | Sélectionner un passage court ou une donnée utile pour répondre à la question. |
| 4. Expliquer | Reformuler et relier à une connaissance précise ; éviter la simple répétition. |
| 5. Examiner les limites | Demander ce que le document montre, ce qu’il laisse de côté et ce qu’il ne peut pas prouver. |
| 6. Conclure | Répondre à la question avec une portée proportionnée aux informations disponibles. |

**DU MAUVAIS AU MEILLEUR**

Insuffisant : « L’auteur parle des droits. »
Plus précis : « L’article associe l’existence d’une constitution à des garanties concernant les droits et l’organisation des pouvoirs. Il établit donc un critère normatif, sans fournir une observation de son application. »

### Exercice 00-E5 — Distinguer trois opérations

Pour le document A, écrivez : une information tirée du texte ; une explication de cette information ; une limite du document. Trois phrases suffisent, mais elles doivent remplir trois fonctions différentes.

*Répondez dans votre cahier.*

L’étude critique de l’écrit de Terminale exige des documents et des connaissances, une organisation et une réponse à la problématique. Le présent exercice en isole une étape, sans reproduire tout le format de l’épreuve. [S04]

## 00-M08 — Passer de l’idée à l’argument

Un argument n’est ni un slogan, ni une suite de noms propres. Pour commencer, utilisez quatre opérations : **affirmer une idée, apporter un élément précis, expliquer son intérêt, limiter la conclusion**.

**QUESTION DE MÉTHODE**

Un texte proclamant des principes suffit-il à démontrer leur application ?

**Idée.** Un texte normatif ne suffit pas, à lui seul, à établir les pratiques.
**Élément précis.** Le document A formule deux conditions relatives aux droits et à l’organisation des pouvoirs.
**Explication.** Il définit ce qui devrait caractériser un ordre constitutionnel, mais ne décrit ni des décisions ni leur exécution.
**Limite et conclusion.** Il renseigne donc sur un idéal formulé dans le texte ; l’étude de son application demande d’autres sources.

### Exercice 00-E6 — Un raisonnement à réparer

« Il y a une consultation, donc le projet est démocratique. Les gens peuvent répondre. Cela prouve que tout le monde est d’accord. »

Identifiez deux sauts de raisonnement. Réécrivez le passage en quatre phrases, en signalant les informations qu’il faudrait connaître pour conclure davantage.

*Répondez dans votre cahier.*

### Se relire

Ma première phrase répond-elle à la question ? Mon exemple est-il précis ? Ai-je expliqué le lien ? Ai-je généralisé sans preuve ? Une phrase de nuance est utile lorsqu’elle corrige réellement la portée d’une affirmation.

Cette grille est une aide pédagogique. Elle n’impose pas quatre phrases par paragraphe ni un plan unique pour les compositions.

## Dossier Rivage : les pièces

**Tout le dossier ci-dessous est fictif et créé pour cet exercice.** Il sert à apprendre la lecture critique ; ce n’est ni une étude de cas historique, ni une annale du baccalauréat.

**F1 — COMMUNIQUÉ DE L’EXÉCUTIF MUNICIPAL**

« L’extension du port représente une chance pour Rivage. Elle pourrait créer 200 emplois. Notre consultation montre un soutien massif. Nous invitons le conseil municipal à approuver le projet le mois prochain. »
Document d’exercice daté du 12 avril, année fictive.

**F2 — NOTE SUR LA CONSULTATION**

Le questionnaire a été publié sur le site municipal du 1er au 10 avril. Répondre était volontaire. Deux cents réponses ont été enregistrées : 156 favorables et 44 défavorables. La note ne décrit ni la représentativité des répondants, ni un contrôle empêchant une même personne de répondre plusieurs fois.

**F3 — COMPTE RENDU D’UNE ASSOCIATION LOCALE**

L’association signale que le projet concerne aussi une zone humide et demande une étude sur les effets de l’extension. Elle estime que les documents techniques disponibles ne permettent pas encore de comparer le projet avec des solutions alternatives. Sa méthode d’expertise n’est pas précisée dans l’extrait.

### Informations de contexte fournies pour le cas

Le communiqué défend le projet ; la note décrit le recueil des réponses ; l’association formule des réserves. Aucun résultat d’étude d’impact, aucun décompte de la population et aucune décision finale ne sont fournis. Vous ne devez pas les inventer.

Les trois pièces ont été rédigées pour le présent module. Il serait incorrect de les citer comme documents d’une collectivité réelle. Vous pouvez résoudre les exercices suivants sans recherche sur Internet.

## Exploiter les pièces sans les surinterpréter

### Exercice 00-E7 — Consolidation (degré 1)

1. Présentez la nature et la fonction des trois pièces.
2. Dans F1, les 200 emplois sont-ils observés ou annoncés comme une possibilité ?
3. Calculez la part des réponses favorables parmi les réponses enregistrées. Écrivez une phrase avec le bon dénominateur.
4. Donnez deux informations manquantes qui empêchent de conclure sur l’opinion de tous les habitants.

*Répondez dans votre cahier.*

### Exercice 00-E8 — Maîtrise (degré 2)

Rédigez 120 à 150 mots répondant à la question : **Que permettent d’affirmer ces documents sur le soutien et les enjeux du projet ?** Mobilisez au moins deux pièces et distinguez constat, promesse et réserve.

*Répondez dans votre cahier.*

### Exercice 00-E9 — Approfondissement (degré 3)

Une personne affirme : « F1 vient de la mairie, donc il est neutre ; F3 vient d’une association, donc il est inutilisable. » Discutez cette affirmation. Proposez deux documents supplémentaires de nature différente et expliquez leur utilité.

*Répondez dans votre cahier.*

Aides graduées, à utiliser après une tentative : 1. Cherchez les verbes et le dénominateur. 2. Séparez ce qui est compté et ce qui est promis. 3. Organisez une réponse en deux idées : soutien recueilli ; limites et enjeux restant à examiner.

## 00-M09 — Construire un plan qui répond au sujet

En HGGSP, le plan organise une réponse. Il n’est pas une récitation automatique de trois chapitres. À l’écrit de Terminale, le texte officiel demande une introduction, plusieurs parties structurées et une conclusion ; il ne fixe pas un modèle « trois fois trois ». [S04]

### Une méthode en cinq étapes

**1. Délimiter.** Souligner les notions, les acteurs, l’espace et la période.
**2. Comprendre.** Reformuler ce que le sujet demande d’expliquer.
**3. Chercher.** Sélectionner les connaissances et exemples pertinents, sans tout conserver.
**4. Organiser.** Regrouper les idées en parties qui répondent à la même question.
**5. Vérifier.** S’assurer que la conclusion répondra au sujet et que les exemples prouvent réellement les idées.

**EXERCICE 00-E10 — UN PLAN DE TRAVAIL**

Question d’entraînement : « La consultation des habitants suffit-elle à établir le caractère démocratique d’une décision ? »
À partir du module, proposez une problématique et deux ou trois grandes idées. Ce n’est pas un sujet officiel de composition et il ne demande pas une dissertation de quatre heures.

*Répondez dans votre cahier.*

Pour l’introduction, définir le problème est plus important qu’ajouter une citation décorative. Une citation incertaine ou un chiffre inventé affaiblit le travail. Pour la conclusion, répondre précisément vaut mieux qu’une ouverture sans lien.

La méthode complète sera reprise avec des connaissances historiques et géopolitiques de chaque thème. Les cas fictifs de ce module ne sont pas des exemples à réutiliser comme faits réels dans une copie de bac.

## 00-M03 — Construire une fiche utile

Une fiche de jalon doit permettre de **retrouver un raisonnement**, pas seulement de réduire le cours en petites lettres. Voici une structure de travail à réutiliser quand vous étudierez un véritable jalon du programme.

| Rubrique | Votre question de contrôle |
| --- | --- |
| Titre et rattachement | Quel thème et quel axe ce jalon éclaire-t-il ? |
| Période, espace, acteurs | Puis-je expliquer chaque repère choisi ? |
| Trois à cinq idées essentielles | Ai-je distingué idée générale et fait précis ? |
| Un exemple analysé | Quel mécanisme ou quelle évolution montre-t-il ? |
| Une source | Est-elle identifiée et l’ai-je effectivement consultée ? |
| Une limite ou une nuance | Que dois-je éviter de généraliser ? |
| Deux questions de rappel | Puis-je y répondre sans regarder la fiche ? |

### Exercice 00-E11 — Une fiche de document, pas encore de jalon

Complétez pour le document A : son origine ; sa date ; son apport ; sa limite ; une question de rappel. Ne présentez pas cet article comme l’un des jalons officiels du thème démocratie.

*Répondez dans votre cahier.*

### La banque personnelle d’exemples

Plus tard, chaque exemple historique devra être daté, situé, sourcé et associé à un argument. Une mention comme « l’Union européenne » est trop générale : il faut choisir un cas et expliquer son utilité dans la réponse.

Les fiches n’effacent pas le cours. Si vous ne comprenez plus les liens entre les rubriques, reprenez l’explication rédigée puis refaites la fiche sans la recopier.

## 00-R1 et 00-R2 — Reprendre les bases du raisonnement

### 00-R1 — Dater et contextualiser

Distinguez la date d’un événement, celle de rédaction d’un document et celle de publication de sa copie numérique. Elles peuvent être différentes. Avant de comparer deux situations, précisez la période et l’espace.

**ENTRAÎNEMENT 00-R1**

Un discours prononcé en 1950 est publié dans une revue en 1951, puis numérisé en 2020. Quelle date sert à contextualiser les propos ? Quelles autres dates indiquez-vous pour décrire la transmission du document ?

*Répondez dans votre cahier.*

### 00-R2 — Ne pas transformer une succession en cause

Constater qu’un fait survient après un autre permet de décrire un ordre, pas d’établir à lui seul une causalité. Il faut chercher un mécanisme et examiner d’autres explications possibles.

**ENTRAÎNEMENT 00-R2**

Cas fictif : après l’ouverture d’une nouvelle route, la fréquentation du port augmente. Une entreprise conclut que la route explique à elle seule toute la hausse. Quelles informations faudrait-il examiner avant d’accepter cette conclusion ?

*Répondez dans votre cahier.*

### Une phrase à améliorer

« Cette réforme est bonne car elle est moderne. » Identifiez les termes imprécis. Proposez une question d’analyse et un critère vérifiable à la place du jugement général.

*Répondez dans votre cahier.*

Les corrigés indiquent des réponses possibles. Une proposition différente peut être recevable si elle identifie réellement une date, un mécanisme ou un critère pertinent.

## 00-R3 et 00-R4 — Limiter correctement ses conclusions

### 00-R3 — Vérifier l’échelle et le dénominateur

Une commune relève de l’échelle locale ; l’État, de l’échelle nationale ; le monde, de l’échelle mondiale. Un constat local ne décrit pas automatiquement l’ensemble du pays. Reprenez le lexique « Échelle » et les questions de l’exercice 00-E1.

Une proportion doit dire **parmi qui ou parmi quoi** elle est calculée. L’opinion des personnes qui répondent volontairement à une enquête ne décrit pas automatiquement celle d’une population entière.

**ENTRAÎNEMENT 00-R3**

Cas fictif : une association recueille 60 réponses, dont 45 favorables à un projet. Calculez la proportion de réponses favorables. Rédigez une phrase exacte, puis une phrase qui serait abusive.

*Répondez dans votre cahier.*

### 00-R4 — Examiner la nature d’une source

Un texte normatif renseigne sur des règles ou des principes. Un discours renseigne aussi sur les objectifs et la présentation d’un acteur. Une statistique dépend de sa méthode. Aucune de ces natures ne dispense d’examiner le document.

**ENTRAÎNEMENT 00-R4**

Cas fictif : une charte affirme que toutes les réunions sont ouvertes. Un extrait de calendrier donne les dates de trois réunions mais ne décrit pas l’accès. Peut-on affirmer que tous les habitants ont pu assister à chaque réunion ? Quel complément demander ?

*Répondez dans votre cahier.*

### Avant de consulter la correction

Soulignez le mot qui limite votre conclusion : « parmi les réponses », « dans cet extrait », « à cette date », « selon cet acteur ». Vérifiez ensuite que cette limitation correspond réellement à votre source.

Une formulation prudente ne doit pas devenir une esquive. Quand une donnée est établie, affirmez-la précisément ; limitez seulement ce que la preuve ne permet pas de généraliser.

## Bilan A — Analyser un petit dossier

**30 minutes. Travail individuel.** Ce bilan est formatif et original ; il n’imite pas toutes les exigences d’une épreuve officielle.

**NOUVEAU CAS FICTIF : CLAIRVAL**

Une charte municipale de l’année 2000 affirme que les décisions budgétaires doivent être rendues publiques. En 2025, un communiqué annonce : « Notre ville garantit désormais une transparence totale. » Une note jointe indique que 24 comptes rendus sur les 30 prévus pour l’année ont été publiés ; elle ne précise ni leur contenu ni les conditions d’accès. Ces informations sont inventées pour l’entraînement.

**A1.** Distinguez une règle, une affirmation d’acteur et une donnée de la note.
**A2.** Calculez la part des comptes rendus publiés, en écrivant le dénominateur.
**A3.** Expliquez ce que la note permet de conclure et ce qu’elle ne permet pas d’affirmer.
**A4.** Rédigez un paragraphe répondant : « Les pièces fournies suffisent-elles à établir une transparence totale ? »
**A5.** Proposez un document supplémentaire utile et une question relevant des sciences politiques.

*Répondez dans votre cahier.*

### Critères de réussite

Je distingue les types d’information ; je calcule et formule correctement ; je relie une pièce à un argument ; je signale une limite pertinente ; je propose une vérification adaptée. La correction donne une grille pédagogique, non une note officielle.

Consultez le compagnon seulement après avoir terminé. Identifiez ensuite une reprise prioritaire avant le bilan B.

## Bilan B — Revalider après la reprise

**30 minutes, à distance du bilan A.** Reprendre un format comparable sur d’autres données permet de vérifier votre méthode, plutôt que de restituer un corrigé mémorisé.

**NOUVEAU CAS FICTIF : BELRIVE**

Un règlement de 2010 prévoit l’accès aux pièces préparatoires avant chaque réunion du conseil. En 2025, le service municipal affirme que « l’information a toujours été intégralement disponible ». Le registre fourni compte 21 dossiers disponibles avant la réunion sur 28 dossiers examinés. Il ne précise pas les raisons des absences ni le nombre d’habitants ayant consulté les pièces.

**B1.** Distinguez une règle, une affirmation d’acteur et une donnée du registre.
**B2.** Calculez la part des dossiers disponibles avant la réunion.
**B3.** Expliquez la tension entre l’affirmation et les données, sans inventer d’intention.
**B4.** Rédigez un paragraphe répondant : « Peut-on parler d’une information toujours intégralement disponible ? »
**B5.** Proposez une vérification complémentaire et une question relevant de la géographie.

*Répondez dans votre cahier.*

Après correction, comparez les **méthodes** utilisées dans A et B : avez-vous réutilisé le bon dénominateur ? Distingué règle et application ? Répondu à la question sans généraliser ?

Ces bilans publiés dans le livret sont des exercices d’autoévaluation. Ils ne conviennent pas à une évaluation surveillée « non connue » après distribution intégrale.

## Organiser la suite de mon apprentissage

### Une séance autonome en cinq gestes

Lire la question de départ ; étudier le cours en cherchant les liens ; fermer le support et restituer ; produire un travail ; comparer à la correction et programmer une reprise. Gardez une trace de ce que vous avez effectivement écrit ou expliqué.

| Acquisition du module | Première tentative | Après reprise | Preuve conservée |
| --- | --- | --- | --- |
| Distinguer les approches HGGSP |  |  |  |
| Présenter une source |  |  |  |
| Séparer règle et pratique |  |  |  |
| Utiliser une proportion à bon escient |  |  |  |
| Construire un argument |  |  |  |
| Identifier une limite et une vérification |  |  |  |

Utilisez les mentions « à reprendre », « en cours » ou « réalisé sans aide », accompagnées d’une date. Ne cochez pas une compétence seulement parce que vous avez lu la correction.

### Réactivation suggérée

**À J+2** : présentez le document A et sa limite sans regarder le livret.
**À J+7** : expliquez pourquoi une consultation volontaire ne décrit pas automatiquement toute une population.
**À J+21** : prenez un document du premier thème étudié et refaites la grille 00-M04.

**PROCHAINE ÉTAPE**

Commencer le thème de Première « Comprendre un régime politique : la démocratie », avec ses deux axes et son objet de travail conclusif sur l’Union européenne. Le module vous donne une méthode de départ ; il ne dispense pas d’étudier les connaissances, les documents et les jalons de ce thème. [S02]

Les intervalles de réactivation sont des repères proposés. Adaptez-les à votre progression et à vos dates d’évaluation.

## Sources et usage du livret

Les définitions de travail et les exercices sont des rédactions pédagogiques originales. Le cas du port, Rivage, Clairval, Belrive et les situations de reprise sont explicitement fictifs. Ils ne doivent pas être cités comme des faits historiques ou des enquêtes réelles.

### Le document réel du module

**S10 — Déclaration du 26 août 1789 des droits de l’homme et du citoyen**, article 16. Transcription consultée sur Légifrance. Le site diffuse la source ; il n’en est pas l’auteur historique.

[Consulter le texte sur Légifrance](https://www.legifrance.gouv.fr/loda/id/JORFTEXT000000697056)

### Programme et épreuves

**S01–S03.** Éduscol, programmes de Première et de Terminale HGGSP, BO du 22 janvier et du 25 juillet 2019.

[Éduscol — programmes et ressources HGGSP](https://eduscol.education.gouv.fr/5802/programmes-et-ressources-en-histoire-geographie-geopolitique-et-sciences-politiques-voie-g)

**S04–S05.** Épreuve terminale HGGSP, note du 27 août 2025 ; évaluation ponctuelle de la spécialité non poursuivie, version consolidée de juin 2025.

[BO — épreuve terminale HGGSP à compter de 2026](https://www.education.gouv.fr/bo/2025/Hebdo33/MENE2521923N)

[Éduscol — évaluation ponctuelle, HGGSP pages 3–4](https://eduscol.education.gouv.fr/sites/default/files/document/ndsevaluations-ponctuelleseds-non-poursuivivoie-gjuin-2025pdf-100575.pdf)

**S06–S09.** Éduscol et BO : candidats individuels, Grand oral et coefficients. Les notices locales précisent l’inscription et l’organisation matérielle.

[Éduscol — candidats individuels](https://eduscol.education.gouv.fr/5694/candidats-individuels-au-baccalaureat-general-et-au-baccalaureat-technologique)

[Éduscol — Grand oral](https://eduscol.education.gouv.fr/5661/presentation-du-grand-oral)

Références consultées le 8 septembre 2026. Le registre complet est joint au kit. Les règles peuvent évoluer : consulter les sources pour votre session. Le livret de correction est accessible au candidat, après une première production.

