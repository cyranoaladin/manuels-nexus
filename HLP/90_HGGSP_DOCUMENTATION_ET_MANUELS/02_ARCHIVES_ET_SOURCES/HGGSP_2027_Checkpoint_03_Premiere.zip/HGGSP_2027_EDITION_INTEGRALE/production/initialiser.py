from pathlib import Path
import json, hashlib, shutil, re
ROOT=Path(__file__).resolve().parents[1]
FOND=Path('/mnt/data/_fondation/HGGSP_Cycle_terminal')
REC=Path('/mnt/data/HGGSP_RECUPERATION_20260908/transcriptions_visuelles')
items=[]
for source in [FOND/'documents/HGGSP_Module_00_Candidat.md',FOND/'documents/HGGSP_Module_00_Autocorrection.md',FOND/'referentiel/programme_cycle_terminal.json',FOND/'sources/registre_sources.json',REC/'BANQUE_PARTIELLE_TRANSCRITE.json',REC/'P01_OUVERTURE_COURS_FRAGMENT.md',REC/'SOMMAIRE_RELEVE.md']:
 dest=ROOT/'sources/originaux'/source.name
 shutil.copy2(source,dest)
 items.append({'fichier':str(dest.relative_to(ROOT)),'sha256':hashlib.sha256(dest.read_bytes()).hexdigest(),'taille':dest.stat().st_size,'provenance':str(source),'statut':'ORIGINAL_RECUPERE_INCHANGE'})
(ROOT/'verification/ORIGINAUX.json').write_text(json.dumps(items,ensure_ascii=False,indent=2))
for typ in ['Candidat','Autocorrection']:
 s=(FOND/f'documents/HGGSP_Module_00_{typ}.md').read_text()
 # Namespace fixes are editorial adaptations; original unmodified files remain archived.
 s=re.sub(r'(?<![\w-])(D\d+|E\d+|M\d\d|R[1-4])(?![\w-])',r'00-\1',s)
 s=s.replace('Version 0.1 — 8 septembre 2026.','Module fondateur conservé ; identifiants préfixés « 00- » pour éviter les collisions avec ceux du manuel.')
 s=s.replace('◆◆◆','(degré 3)').replace('◆◆','(degré 2)').replace('◆','(degré 1)')
 s=s.replace('_Espace de réponse._','*Répondez dans votre cahier.*')
 dest=ROOT/'sources/methodes'/('01_module00.md' if typ=='Candidat' else '02_module00_corrige.md')
 dest.write_text(s)
p=json.loads((FOND/'referentiel/programme_cycle_terminal.json').read_text())
p['full_manual_status']='EN_CONSTRUCTION';p['edition']='1.0';p['as_of']='2026-09-08'
(ROOT/'sources/referentiel/programme.json').write_text(json.dumps(p,ensure_ascii=False,indent=2))
