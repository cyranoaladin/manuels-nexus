# Passage de relais HGGSP 2027

Joindre cette archive à la nouvelle conversation, puis y coller le contenu de `PROMPT_REPRISE_HGGSP_2027.md`.

Lire `ETAT_REPRISE.md` avant de qualifier la récupération. Le paquet conserve le kit fondateur et dix images du manuscrit interrompu. **Il ne contient pas le manuscrit complet ni les cinq PDF avancés.** Les noms de ces fichiers figurent comme pistes dans le prompt et dans les notes historiques.

Le fichier `Inventaire_recuperation.json` détaille les matériaux vérifiés. `MANIFESTE_SHA256.json` donne les empreintes des fichiers du paquet autres que lui-même. Le kit fondateur est fourni dans sa version ZIP originale, sans modification.

Aucun fichier de police, donnée nominative d'élève ni contenu des autres matières n'est inclus. La présence d'un document dans le kit fondateur ne constitue pas une nouvelle vérification de son contenu ni une mise à jour réglementaire.
