# État de reprise — Manuel HGGSP du cycle terminal, session 2027

## 1. Portée de ce dossier

Ce dossier est un passage de relais, pas une livraison du manuel complet. Il rassemble les fichiers matériels encore accessibles lors de la préparation du prompt de reprise, ainsi qu'une synthèse factuelle des traces de production consultées. Il ne contient pas de copie complète des onze chapitres du manuscrit interrompu.

Deux niveaux de preuve sont séparés : **existence actuelle vérifiée sur disque** et **existence ou opération attestée dans une trace historique**. L'existence passée d'un PDF ne rend pas ses octets disponibles dans le nouvel environnement. Le récit de sa compilation ne certifie pas son contenu.

## 2. Fichiers effectivement sauvegardés dans cette archive

### Fondation

`fondation/HGGSP_Cycle_terminal_Kit_fondateur.zip` est une copie binaire du kit livré précédemment, non modifiée. Ses 27 entrées sont inventoriées dans `Inventaire_recuperation.json`. Elles comprennent notamment :

- `documents/Dossier_fondateur.json` ;
- `documents/HGGSP_Cycle_terminal_Dossier_fondateur.md`, `.docx`, `.pdf` ;
- les documents candidat et autocorrection du module 00, avec leurs sources JSON/Markdown ;
- `referentiel/programme_cycle_terminal.json`, `profils_examens.json`, `module00_objets.json`, `Carte_complete_programme.md` ;
- `sources/registre_sources.json`, `REGISTRE_SOURCES.md` ;
- `production/MISSION_CONSTRUCTION_MANUEL_HGGSP.md`, `CONTRAT_OBJETS.md`, `generer_documents.py` ;
- les pièces de vérification du kit et son manifeste.

Les chemins à l'intérieur de cette archive sont précédés de `HGGSP_Cycle_terminal/`. Le kit précise expressément qu'il ne contient pas les cours des onze thèmes. Ses anciens résultats de vérification concernent ce kit, pas le futur manuel intégral.

### Images du travail de rédaction et de fabrication

Dix fichiers sont conservés dans `indices_visuels/`, sans modification de leurs octets :

| Chemin relatif | Nature |
|---|---|
| `HGGSP_2027_Manuel/illustrations/A1_democraties.png` | Illustration de localisation |
| `HGGSP_2027_Manuel/illustrations/A2_europe.png` | Illustration de localisation |
| `HGGSP_2027_Manuel/illustrations/A3_moyen_orient.png` | Illustration de localisation |
| `HGGSP_2027_Manuel/illustrations/A6_mer.png` | Schéma pédagogique |
| `_hggsp_work/renders/HGGSP_2027_Manuel_Cycle_terminal_001.png` | Couverture du manuscrit de travail |
| `_hggsp_work/renders/HGGSP_2027_Manuel_Cycle_terminal_028.png` | Rendu d'une page du manuscrit |
| `_hggsp_work/rendus_finaux/Manuel_Cycle_terminal/contact_001-018.jpg` | Planche de vignettes de pages |
| `_hggsp_work/rendus_finaux/Manuel_Cycle_terminal/contact_019-036.jpg` | Planche de vignettes de pages |
| `_hggsp_work/rendus_finaux/Manuel_Cycle_terminal/contact_037-054.jpg` | Planche de vignettes de pages |
| `_hggsp_work/rendus_finaux/Manuel_Cycle_terminal/contact_127-144.jpg` | Planche de vignettes de pages |

Les noms de planches ne permettent pas de déterminer la pagination totale du livre ni de déclarer toutes ses pages inspectées. Le nom `rendus_finaux` n'est pas une autorisation de publication. Une référence ou une validation imprimée sur une couverture doit être contrôlée dans les pièces correspondantes.

Ces images avaient été remontées dans l'espace courant sous une racine imbriquée de la forme `/mnt/data/user-…/…/mnt/data/`. Le manifeste conserve leurs chemins constatés. Les retrouver exigeait une recherche dans les sous-répertoires, pas uniquement un `ls` à la racine de `/mnt/data`.

## 3. Fichiers non retrouvés dans l'espace monté actuel

La recherche ciblée dans `/mnt/data` n'a pas retrouvé les chapitres `P01.md` à `P05.md` et `T01.md` à `T06.md`, les générateurs du manuscrit, ses données de banque, ses sources assemblées ni les cinq PDF intégraux décrits ci-dessous.

Cette conclusion porte sur l'espace inspecté dans cette session. Elle ne prouve pas l'absence de toute copie dans une bibliothèque, une archive conservée par l'utilisateur ou un autre environnement autorisé. Ces emplacements ne doivent pas être supposés accessibles : leur accès doit être vérifié.

## 4. Traces historiques utiles à la recherche

Les informations de cette section sont des résumés de traces de fichiers, de commandes et de sorties consultées pendant la préparation du passage de relais. Elles ne sont pas de nouveaux résultats de tests.

### Racines et organisation

Le projet de travail était situé dans `/mnt/data/HGGSP_2027_Manuel/`, avec les répertoires `chapitres`, `corrections`, `entrainements`, `examens`, `illustrations`, `methodes`, `pdf`, `production`, `referentiel`, `sources_textes` et `verification`.

Le répertoire `/mnt/data/_hggsp_work/` contenait notamment les générateurs `banque.py`, `examens.py`, `assemble.py` et `atlas.py`. L'assembleur en copiait des versions dans `HGGSP_2027_Manuel/production/`. Il faut donc rapprocher ces deux emplacements avant de choisir une version.

### Chapitres repérés dans les traces

| Source historique | Thème abrégé | Nombre de mots indiqué par une ancienne sortie |
|---|---|---:|
| `chapitres/P01.md` | Démocratie | 4 173 |
| `chapitres/P02.md` | Puissances | 4 245 |
| `chapitres/P03.md` | Frontières | 3 931 |
| `chapitres/P04.md` | Information | 4 302 |
| `chapitres/P05.md` | États et religions | 3 590 |
| `chapitres/T01.md` | Nouveaux espaces de conquête | 3 231 |
| `chapitres/T02.md` | Guerre et paix | 3 840 |
| `chapitres/T03.md` | Histoire et mémoires | 3 544 |
| `chapitres/T04.md` | Patrimoine | 3 585 |
| `chapitres/T05.md` | Environnement | 3 215 |
| `chapitres/T06.md` | Connaissance | 3 249 |

Le total de cette sortie était de 40 905 mots. Ce comptage employait un découpage par espaces. Des sources assemblées plus larges ont ensuite été comptées avec une expression régulière ; une sortie indiquait 60 208 mots. Il ne faut ni comparer ces nombres comme des mesures strictement identiques ni en déduire une couverture pédagogique complète.

Les titres portaient des ancres telles que `{#P01}`, `{#P01-AXE1}` et `{#P01-AXE1-J01}`. Une modification ultérieure a ajouté le code du thème au titre principal, par exemple `P01 — Première : …`, tout en conservant les ancres. Ces formes sont des termes de recherche utiles.

### Banque et méthodes

Les traces de générateurs décrivent huit exercices et cinq QCM par thème : 88 exercices et 55 QCM au total. Les exercices comportaient notamment `id`, `title`, `question`, `correction`, `method`, `parcours`, `minutes`, `aide` et `source_cours`. Les QCM avaient trois options, une clé et une explication. Les identifiants utilisaient les formes `P01-E1`, `P01-Q1` et `P01-RT`.

Les fichiers structurants à rechercher sont `referentiel/banque_pedagogique.json`, `examens_originaux.json`, `couverture_redaction.json` et `registre_sources.json`. Une sortie historique recensait 56 références dans ce dernier registre ; leur disponibilité et leur pertinence doivent être revérifiées.

`methodes/00_mode_emploi.md` contenait les parcours, deux progressions sur 32 semaines, les méthodes M1 à M12, les remédiations R1 à R6 et des rappels à J+2, J+7 et J+21. Les propositions horaires étaient des choix éditoriaux, pas des prescriptions officielles.

`methodes/13_oral_et_evaluation.md` concernait l'oral, l'auto-évaluation et le lexique. `methodes/14_atlas.md` accompagnait les illustrations. Ces deux fichiers ne sont pas matériellement récupérés dans ce paquet.

### Assemblage et sorties

L'assembleur écrivait :

    production/manuel_cycle.md
    production/manuel_niveau1.md
    production/compagnon.md
    production/epreuves.md
    production/sujets_seuls.md

Les traces montrent une chaîne Pandoc → TeX → LuaLaTeX, avec `production/build.py`, `template.latex` et `style.tex`. La configuration consultée utilisait notamment KOMA-Script, un format A4, Noto Serif pour le corps, Lato pour les titres et DejaVu Sans Mono pour le code. Cette configuration était autonome et ne constituait pas une charte commune approuvée.

Les cinq noms d'exports dans `pdf/` étaient :

    HGGSP_2027_Manuel_Cycle_terminal.pdf
    HGGSP_2027_Niveau_1_Premiere.pdf
    HGGSP_2027_Compagnon_Autocorrection.pdf
    HGGSP_2027_Epreuves_blanches_et_corriges.pdf
    HGGSP_2027_Epreuves_Sujets_seuls.pdf

Une liste historique affichait ces cinq PDF, et des sorties de construction indiquaient notamment `manuel_cycle built`. Cela étaye leur existence dans l'ancien environnement, pas leur présence dans le paquet actuel ni leur validation finale.

Les fichiers intermediaries étaient sous `verification/build/`, avec des noms tels que `manuel_cycle.tex`, `.pdf`, `.log`, `.aux`, `.toc`, `.out` et des fichiers `.stdout` par passage. Les journaux `final_build.log` et `build_status.txt` se trouvaient aussi sous `_hggsp_work/`.

## 5. Derniers ajustements et risques de reprise à vérifier

Les traces consultées montrent des changements portant sur le maintien des blocs QCM sur une même page, la désactivation d'une numérotation automatique de titres, l'affichage de la flèche Unicode, la largeur du folio dans le sommaire et la profondeur des signets. Leur effet ne doit pas être présumé acquis dans tous les exports.

Le générateur d'atlas a été modifié pour utiliser un fond de littoraux plus détaillé, ajouter des noms de mers et un neuvième schéma de relations maritimes. Un ajustement concernait une étiquette sur la carte du Moyen-Orient. Le schéma A6 a fait l'objet d'une correction de libellé distinguant plateau continental et Zone selon la situation du fond marin. Quatre illustrations seulement sont matériellement conservées ici ; les autres ne sont pas récupérées.

Le mode d'emploi a été modifié pour expliciter une condition relative au regroupement des épreuves anticipées et terminales. La reprise doit contrôler directement la disposition officielle et ne pas prendre la formulation historique pour une consultation réglementaire actuelle.

Certaines commandes longues de construction ont dépassé le temps imparti. Une relance avec un journal et un fichier PID figure dans les traces. Une construction courante ne doit pas être déduite d'un ancien PID, et une relance ne doit pas écraser les pièces récupérées.

Les scripts utilisaient encore des chemins absolus vers l'ancien environnement. Leur présence dans `production/` ne garantit donc pas leur portabilité. Inspecter les variables de racine, les copies et les dépendances avant exécution.

## 6. Portée des vérifications historiques

Le script `verification/verifier.py` vérifiait surtout les nombres d'objets, les ancres, certaines longueurs minimales, les références, quelques calculs et les contraintes des sujets. Un premier passage comportait sept échecs sur les explications de QCM : `P03-Q3`, `T02-Q1`, `T02-Q2`, `T04-Q3`, `T05-Q3`, `T06-Q2`, `T06-Q4`.

Une sortie ultérieure indiquait 730 vérifications réussies et zéro échec. Ces seuils structurels n'établissent ni l'exactitude de tous les faits, ni la qualité de tous les corrigés, ni la lecture complète des sources. Aucun de ces 730 contrôles du manuscrit n'a été réexécuté pour constituer le présent paquet, car ses sources ne sont pas disponibles sur disque.

Il faudra particulièrement réexaminer l'autonomie réelle des dossiers documentaires, les aides trop génériques, l'équilibre des thèmes et les corrigés des sujets alternatifs. Ne pas confondre signalement d'une piste de contrôle et constat confirmé d'erreur.

## 7. Ordre de reprise recommandé

Ouvrir et vérifier ce paquet ; inventorier la fondation ; rechercher les fichiers avancés par les noms indiqués ; sauvegarder immédiatement toute récupération ; établir l'état réel du manuscrit ; poursuivre sur les unités manquantes ou insuffisantes ; reconstruire dans une destination distincte ; contrôler les contenus et rendus ; fournir des checkpoints portables avant la livraison finale.

En cas d'absence persistante du manuscrit, le résultat est une **récupération partielle**. Le travail nouveau doit alors être enregistré comme **reconstruction**, sans prétendre retrouver à l'identique des textes absents. Le prompt de reprise maintient l'objectif du manuel complet tout en rendant cette distinction obligatoire.
