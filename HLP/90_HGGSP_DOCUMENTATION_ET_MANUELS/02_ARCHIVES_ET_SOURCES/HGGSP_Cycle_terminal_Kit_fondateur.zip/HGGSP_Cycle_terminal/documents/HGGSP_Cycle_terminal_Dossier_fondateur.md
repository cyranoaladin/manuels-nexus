# HGGSP — Dossier fondateur du manuel du cycle terminal

Version 0.1 — 8 septembre 2026.

## HGGSP — Première & Terminale

**Le manuel du candidat individuel**
Comprendre le monde, construire une analyse, préparer les épreuves.

**DOSSIER FONDATEUR • VERSION 0.1**

Architecture pédagogique et éditoriale du cycle terminal. Référentiel complet des thèmes et jalons, profils d’examen, parcours autonomes et cadre de production.

Ce lot met en place le projet et fournit un module d’entrée utilisable par le candidat, avec son livret de correction. Il ne contient pas encore les cours complets des onze thèmes du programme.

### Trois distinctions qui structurent le manuel

**Programme enseigné / programme d’examen.** Les contenus du cycle sont conservés ; les priorités de révision sont paramétrées par session.

**Apprendre / s’évaluer.** Le candidat reçoit des explications et des corrections guidées, sans disposer à l’avance des sujets réservés à une évaluation externe.

**Information / preuve.** Chaque document et chaque affirmation vérifiable doivent être rattachés à une source identifiée et à un contexte.

Projet Manuels Nexus Réussite • Voie générale • Références consultées le 8 septembre 2026. La mise en page de ce dossier est une proposition autonome, non une intégration de la classe LaTeX du dépôt.

## Sommaire et mode d’emploi

Ce dossier sert à construire et à contrôler le manuel. Les onze fiches de thème définissent les contenus à rédiger ; le module 00, livré séparément, constitue le premier support candidat.

### Cadre, public et programme

Périmètre exact de la livraison — voir « 1. Ce qui est livré et ce qui reste à produire ».

Épreuves, sessions et inscription — voir « 2. Les épreuves : choisir la bonne route ».

Architecture des volumes et des compagnons — voir « 5. Une architecture commune pour tout le cycle ».

Les cinq thèmes de Première — voir « Comprendre un régime politique : la démocratie ».

Les six thèmes de Terminale — voir « De nouveaux espaces de conquête ».

### Modèle pédagogique

Contrat du thème et cahier des charges du jalon — voir « 6. Le contrat pédagogique d’un thème ».

Méthodes et entraînements — voir « 8. Une progression explicite des méthodes ».

Autocorrection et remédiation — voir « 10. Des corrections réellement accessibles ».

Proposition de progression sur les deux années — voir « 11. Proposition de parcours en Première ».

Fiche d’exemple et transfert — voir « 13. La fiche d’exemple : un outil de transfert ».

### Production et qualité

Sources, preuve et honnêteté intellectuelle — voir « 14. Sources, preuve et honnêteté intellectuelle ».

Charte et organisation des fichiers — voir « 15. Charte graphique : continuité et spécificités ».

Contrôles et ordre de production — voir « 17. Les contrôles de qualité adaptés à HGGSP ».

Références documentaires — voir « Références documentaires — 1 ».

**LIRE SELON SON RÔLE**

Équipe éditoriale : lire l’ensemble du dossier et les registres. Candidat : utiliser le module 00 puis ses corrections. Agent de production : commencer par la mission, les sources et les statuts réels ; ne pas transformer ce dossier en manuel « terminé » par simple changement d’étiquette.

## 1. Ce qui est livré et ce qui reste à produire

Le périmètre est la **spécialité histoire-géographie, géopolitique et sciences politiques (HGGSP)** des classes de Première et Terminale. Ce manuel ne remplace ni l’histoire-géographie du tronc commun, ni l’EMC, ni la préparation des autres épreuves du baccalauréat.

| Livré dans ce lot | Statut exact |
| --- | --- |
| Dossier fondateur et architecture du cycle | Rédigés ; proposition éditoriale. |
| Référentiel des cinq thèmes de Première et six de Terminale | Onze introductions de thème, vingt-deux axes, onze objets de travail conclusifs et soixante-dix-huit entrées de jalons recensés. |
| Profils d’examen 2027 et 2028 | Paramètres documentés d’après les textes consultés ; pas de dates locales d’inscription inventées. |
| Module 00 et correction guidée | Contenu pédagogique rédigé ; corpus réel court et cas fictifs explicitement signalés. |
| Kit de production et contrôles de structure | Registres, mission et vérificateur ; aucun verdict de validation scientifique humaine du manuel. |
| Cours complets et banques de tous les thèmes | À rédiger, documenter, relire et mettre en page. Aucun statut « publié » attribué. |

### Organisation des pièces

Le dossier décrit le futur manuel. Le fichier **Carte_complete_programme.md** et le JSON associé en sont le registre de couverture. Le **module 00** est destiné au candidat ; sa correction est distribuable séparément. Le dossier **production/** s’adresse à l’équipe éditoriale.

**PAS DE CERTIFICATION HÉRITÉE**

La présence de composants et de rapports d’audit dans la collection mathématiques/NSI ne valide aucun contenu HGGSP. Le relevé d’arborescence fourni ne contient pas de cours HGGSP à transposer. Les références de cette nouvelle discipline proviennent de la recherche institutionnelle indiquée en bibliographie.

Fondements : sources S01–S03. Organisation du projet : S11–S12. Les noms d’enseignants donnés pour les supports de NSI ne sont pas réemployés comme crédits HGGSP.

## 2. Les épreuves : choisir la bonne route

| Situation | Épreuve et périmètre | Conséquence pour le manuel |
| --- | --- | --- |
| HGGSP suivie seulement en Première | Évaluation ponctuelle écrite : composition, 2 h, /20, coefficient 8. Programme de Première ; sujet sur un axe ou un objet de travail conclusif. | Préparer les cinq thèmes et une rédaction autonome de deux heures. Ne pas annoncer un choix de sujets non prévu dans la définition actuelle. |
| HGGSP conservée en Terminale | Écrit de spécialité : 4 h, coefficient 16. Dissertation /10 et étude critique de document(s) /10. | Travailler connaissances, problématisation et analyse critique ; régler les révisions sur la session. |
| Grand oral, voie générale, à partir de 2027 | Coefficient 8 ; 20 min de préparation, puis 10 min de présentation et 10 min d’échange. | Construire les deux questions en couvrant les deux spécialités conservées. La préparation ne se limite pas aux quatre thèmes de l’écrit HGGSP. |
| HGGSP choisie à l’oral de contrôle | Préparation 20 min ; passage 20 min (10 + 10). Programme identique à celui de l’écrit de la session. | Prévoir un entraînement spécifique à une question de cours problématisée ; ne pas le confondre avec le Grand oral. |

**ÉVITER LE DOUBLE COMPTAGE**

Pour une même spécialité HGGSP conservée en Terminale, on ne prépare pas en plus l’évaluation ponctuelle réservée à la spécialité abandonnée. Les coefficients 8 et 16 ci-dessus correspondent à des situations différentes, pas à un coefficient HGGSP de 24.

Les anciennes fiches d’épreuve doivent être vérifiées avant réemploi. La note HGGSP du 27 août 2025 **remplace celle de 2020**. Un support de Grand oral antérieur à 2027 peut encore afficher le coefficient 10 : il ne doit pas piloter le profil 2027.

Sources S04–S09. Ces informations concernent les formats nationaux consultés ; les aménagements individuels et instructions du centre restent à prendre en compte.

## 3. Session d’examen et programme intégral

Le programme de Terminale compte six thèmes. La rotation détermine ceux qui peuvent être évalués dans l’écrit de spécialité et l’oral de contrôle ; elle ne transforme pas le manuel du cycle en sélection définitive de quatre thèmes.

| Session | Thèmes évaluables à l’écrit HGGSP |
| --- | --- |
| 2027 — année impaire | 2. Guerre et paix ; 4. Patrimoine ; 5. Environnement ; 6. Connaissance. |
| 2028 — année paire | 1. Nouveaux espaces de conquête ; 2. Guerre et paix ; 3. Histoire et mémoires ; 5. Environnement. |

### La composition exacte d’un sujet de Terminale

Le candidat choisit une dissertation parmi **deux sujets relevant de deux thèmes distincts**. L’étude critique, d’un ou deux documents, relève d’un **troisième thème**, différent de chacun des deux thèmes de dissertation. Cette contrainte doit être testée lors de la fabrication des sujets blancs.

Les notions étudiées en Première restent mobilisables. L’étude critique doit faire travailler le contenu des documents et les connaissances personnelles ; elle ne consiste ni à recopier les documents ni à réciter un cours détaché du dossier.

### Deux règles méthodologiques à ne pas déformer

La dissertation comporte une introduction, plusieurs parties structurées et une conclusion. **Le plan systématique en trois parties et trois sous-parties n’est pas une obligation réglementaire.** Le plan répond au sujet.

Une illustration graphique peut appuyer la dissertation et être valorisée. Elle n’est pas obligatoire et son absence ne doit pas être pénalisée. Le manuel enseigne les cartes et schémas comme outils d’analyse, sans inventer une épreuve obligatoire de croquis propre à HGGSP.

**USAGE DU MANUEL SUR DEUX ANS**

Un candidat qui commence la Première en 2026–2027 et vise le bac 2028 utilisera le profil de session 2028. Le millésime d’une année scolaire ne suffit pas à déterminer le périmètre de l’épreuve terminale.

Sources S04 et S09. Les deux profils sont des applications de la rotation actuellement définie, à recontrôler avant une nouvelle édition.

## 4. L’autonomie ne remplace pas l’inscription

Un candidat individuel doit être accompagné dans l’identification de son statut, de sa session et de ses enseignements. Les modalités de ses évaluations ponctuelles ne se déduisent pas d’un emploi du temps de centre de soutien. [S06–S07]

### Une fiche d’orientation administrative séparée

| À renseigner par le candidat | Document de preuve à conserver |
| --- | --- |
| Session du diplôme et centre organisateur | Confirmation d’inscription ou convocation. |
| Statut scolaire ou individuel ; régime CNED le cas échéant | Document d’inscription précisant le régime, et non le seul nom du prestataire. |
| Spécialités conservées et spécialité non poursuivie | Confirmation des choix enregistrés. |
| Choix global : évaluations ponctuelles annuelles ou en fin de cycle | Option effectivement enregistrée à l’inscription. |
| Dates, pièces exigées et éventuels aménagements | Notice actuelle de l’académie ou du service des examens compétent. |

Les candidats individuels peuvent présenter leurs évaluations ponctuelles suivant une organisation annuelle ou en fin de cycle. Ce choix est global pour les évaluations concernées ; les modalités de modification sont encadrées. Pour la spécialité non poursuivie, le contenu évalué demeure celui de Première. [S05–S07]

**NE PAS PROMETTRE « TOUT LE BAC EN UN AN »**

Le regroupement d’évaluations ponctuelles ne crée pas automatiquement un droit de passer la même année toutes les épreuves, notamment celles normalement anticipées. La situation individuelle doit être vérifiée avec le service des examens. Le présent dossier ne détermine pas l’admissibilité administrative d’une personne.

À l’étranger, s’appuyer sur le service des examens compétent et les notices de la session. Pour un candidat en Tunisie, le manuel prévoit une annexe locale actualisable, mais ne fixe ici **aucune date d’inscription 2027 ou 2028** non vérifiée. [S06]

Pour le Grand oral, le candidat individuel constitue lui-même le document présentant ses deux questions, conformément au cadre applicable. Ne pas fabriquer de visa d’établissement ou de signature d’enseignant. [S08]

## 5. Une architecture commune pour tout le cycle

| Ensemble éditorial proposé | Fonction pour le candidat |
| --- | --- |
| Manuel Première | Cinq thèmes complets, repères, méthodes progressives et préparation de la composition si la spécialité est arrêtée. |
| Manuel Terminale | Six thèmes complets, passerelles avec la Première, dissertation et étude critique. |
| Compagnon Méthodes & Bac | Méthodes transversales, fiches d’épreuve paramétrées par session, entraînement oral et organisation du travail. |
| Livrets d’autocorrection | Corrections expliquées et remédiations, accessibles au candidat après une première production. |
| Dossier du tuteur / de l’enseignant | Progressions, critères, traces de suivi et banque de sujets réservés à une passation différée. |

Les mêmes sources structurées permettent un export complet « cycle terminal », des volumes séparés et des fascicules de révision. Il ne faut pas maintenir plusieurs copies divergentes du même cours.

### Trois entrées, pas trois programmes

**Consolidation ◆** : vocabulaire expliqué, repères, textes courts, questions séquencées et aides. **Maîtrise ◆◆** : choix d’exemples, argumentation, confrontation et rédaction autonome. **Approfondissement ◆◆◆** : comparaison exigeante, discussion historiographique et transfert. Les faits et les objectifs disciplinaires demeurent communs.

### Ce que le candidat doit toujours trouver

Un itinéraire pour commencer ; une définition de ce qu’il doit retenir ; des exemples permettant de comprendre ; un travail à produire ; des critères de réussite ; une correction accessible ; un itinéraire de reprise et un nouveau test.

**REPÈRE SUR LES HORAIRES**

Les horaires scolaires sont de 4 heures par semaine en Première et 6 heures en Terminale. Le programme de Première indique 128 heures, avec une introduction de 4 à 5 heures et 24 à 25 heures par thème ; les thèmes de Terminale sont prévus pour 26 à 28 heures. Ces références ne constituent pas une estimation automatique du travail total en autonomie. [S01–S03]

## Comprendre un régime politique : la démocratie

**Introduction du thème.** Caractéristiques des démocraties contemporaines ; comparaison avec les régimes autoritaires ; libertés, institutions et alternance.

### Axe 1 — Penser la démocratie : démocratie directe et démocratie représentative

• Être citoyen à Athènes au Ve siècle avant J.-C. : une démocratie directe mais limitée.

• Participer ou être représenté : Benjamin Constant et les libertés des Anciens et des Modernes.

### Axe 2 — Avancées et reculs des démocraties

• Tocqueville : inquiétudes sur la démocratie et le risque de tyrannie.

• Crises et fin de la démocratie au Chili de 1970 à 1973.

• Du régime autoritaire à la démocratie : Portugal et Espagne de 1974 à 1982.

### Objet de travail conclusif — L’Union européenne et la démocratie

• Fonctionnement de l’Union européenne : démocratie représentative et démocratie déléguée.

• L’Union européenne face aux citoyens et aux États : remises en question depuis 1992.

**VIGILANCE ÉDITORIALE PROPOSÉE**

Distinguer principes, dispositifs et pratiques. Ne réduire ni Athènes à ses exclusions ni la démocratie contemporaine au seul scrutin. Enseigner la comparaison sans anachronisme.

**Passerelle de cycle.** Connaissance et information ; construction de la paix ; pluralité des mémoires.

Source : S02, p. 5 ; accompagnement : R-P01. Jalons abrégés pour navigation ; le registre renvoie au libellé intégral du BO. Tous ces contenus thématiques restent à rédiger dans le projet.

## Analyser les dynamiques des puissances internationales

**Introduction du thème.** Fondements et manifestations de la puissance : diplomatie, armée, économie, finance et culture, à partir d’exemples contemporains.

### Axe 1 — Essor et déclin des puissances : un regard historique

• L’Empire ottoman : de l’essor au déclin.

• La Russie depuis 1991 : reconstruire une puissance après l’éclatement d’un empire.

### Axe 2 — Formes indirectes de la puissance : une approche géopolitique

• La langue comme instrument : anglais, français, francophonie et instituts Confucius.

• Les nouvelles technologies : géants du numérique (GAFAM, BATX), États et organisations internationales.

• Maîtriser les voies de communication : les nouvelles routes de la soie.

### Objet de travail conclusif — La puissance des États-Unis aujourd’hui

• Lieux et formes de la puissance : siège de l’ONU, Hollywood, MIT notamment.

• Unilatéralisme et multilatéralisme : un débat international.

• Points d’appui et zones d’influence dans un monde multipolaire.

**VIGILANCE ÉDITORIALE PROPOSÉE**

Raisonner sur les moyens, les objectifs, les résultats et les limites. Dater toutes les données contemporaines ; ne pas assimiler puissance, domination et influence.

**Passerelle de cycle.** Conquête spatiale et maritime ; guerres et paix ; savoirs et cyberespace.

Source : S02, p. 6 ; accompagnement : R-P02. Jalons abrégés pour navigation ; le registre renvoie au libellé intégral du BO. Tous ces contenus thématiques restent à rédiger dans le projet.

## Étudier les divisions politiques du monde : les frontières

**Introduction du thème.** Des frontières plus nombreuses, plus ou moins marquées et des espaces transfrontaliers ; distinguer limite, contrôle et interface.

### Axe 1 — Tracer des frontières, approche géopolitique

• Se protéger : le limes rhénan.

• Se partager des territoires : la conférence de Berlin et le partage de l’Afrique.

• Séparer deux systèmes politiques : la frontière entre les deux Corées.

### Axe 2 — Les frontières en débat

• Reconnaître une frontière : la frontière germano-polonaise de 1939 à 1990.

• Dépasser les frontières : le droit de la mer.

### Objet de travail conclusif — Les frontières internes et externes de l’Union européenne

• Schengen : venir en Europe, passer la frontière, logiques et modalités de contrôle.

• Les frontières d’un État adhérent.

• Les espaces transfrontaliers intra-européens : passer et dépasser la frontière au quotidien.

**VIGILANCE ÉDITORIALE PROPOSÉE**

Faire travailler la carte comme une construction datée. Distinguer tracé, reconnaissance et contrôle. Ne pas raconter Berlin comme une unique opération instantanée de dessin de toutes les frontières.

**Passerelle de cycle.** Souveraineté des espaces de conquête ; conflits territoriaux ; cyberespace.

Source : S02, p. 7 ; accompagnement : R-P03. Jalons abrégés pour navigation ; le registre renvoie au libellé intégral du BO. Tous ces contenus thématiques restent à rédiger dans le projet.

## S’informer : un regard critique sur les sources et modes de communication

**Introduction du thème.** Diversité des médias et des supports ; pratiques d’information différenciées des individus, groupes et générations.

### Axe 1 — Les grandes révolutions techniques de l’information

• De l’imprimerie à la presse à grand tirage.

• La radio et la télévision au XXe siècle.

• Naissance et extension du réseau Internet.

### Axe 2 — Liberté ou contrôle de l’information : un débat politique fondamental

• Presse et opinion publique dans l’affaire Dreyfus.

• L’information entre marché et État : Havas et l’AFP.

• Information et propagande en temps de guerre : les médias et la guerre du Vietnam.

### Objet de travail conclusif — L’information à l’heure d’Internet

• Une information fragmentée et horizontale.

• Témoignages et lanceurs d’alerte.

• Les théories du complot : une nouvelle jeunesse à l’heure d’Internet.

**VIGILANCE ÉDITORIALE PROPOSÉE**

Séparer publication, source, preuve et interprétation. Vérifier origine, contexte et recoupement ; ne pas confondre pluralité des points de vue et équivalence de leur solidité.

**Passerelle de cycle.** Production des connaissances ; histoire et mémoires ; conflits informationnels.

Source : S02, p. 8 ; accompagnement : R-P04. Jalons abrégés pour navigation ; le registre renvoie au libellé intégral du BO. Tous ces contenus thématiques restent à rédiger dans le projet.

## Analyser les relations entre États et religions

**Introduction du thème.** Diversité juridique des liens entre État et religion ; religion officielle, séparation, liberté de conscience et liberté religieuse.

### Axe 1 — Pouvoir et religion : des liens historiques traditionnels

• Le pape et l’empereur : le couronnement de Charlemagne.

• Pouvoir politique et magistère religieux : calife et empereur byzantin aux IXe et Xe siècles.

### Axe 2 — États et religions : une inégale sécularisation

• La laïcité en Turquie : l’abolition du califat en 1924 par Mustapha Kemal.

• États et religions dans la politique intérieure des États-Unis depuis la Seconde Guerre mondiale.

### Objet de travail conclusif — État et religions en Inde

• Sécularisme et dimension politique de la religion.

• Les minorités religieuses.

• Enjeux géopolitiques : l’Inde et le Pakistan.

**VIGILANCE ÉDITORIALE PROPOSÉE**

Distinguer laïcité, sécularisation et sécularisme. Éviter d’attribuer une volonté uniforme à une religion ou à l’ensemble de ses fidèles ; identifier les acteurs et les périodes.

**Passerelle de cycle.** Conflits et paix ; patrimoines ; pluralité des identités et des mémoires.

Source : S02, p. 9 ; accompagnement : R-P05. Jalons abrégés pour navigation ; le registre renvoie au libellé intégral du BO. Tous ces contenus thématiques restent à rédiger dans le projet.

## De nouveaux espaces de conquête

**Introduction du thème.** Spécificités des océans et de l’espace ; connaître, maîtriser et redéfinir les frontières de l’exploration.

### Axe 1 — Conquêtes, affirmations de puissance et rivalités

• Enjeux géopolitiques de la conquête spatiale : guerre froide, nouveaux États et acteurs privés.

• Affirmation de puissance à partir des mers : dissuasion nucléaire et forces de projection maritimes.

### Axe 2 — Enjeux diplomatiques et coopérations

• Coopérer pour développer la recherche : la Station spatiale internationale.

• Rivalités et coopérations dans le partage, l’exploitation et la préservation des mers : Montego Bay, ZEE et biodiversité marine.

### Objet de travail conclusif — La Chine : à la conquête de l’espace, des mers et des océans

• Affirmer une volonté politique : discours, investissements et appropriations.

• Enjeux économiques et géopolitiques considérables pour la Chine et le reste du monde.

**VIGILANCE ÉDITORIALE PROPOSÉE**

Distinguer souveraineté, droits souverains et libertés de circulation. Actualiser séparément les accords maritimes et programmes spatiaux sans réécrire silencieusement le jalon officiel.

**Passerelle de cycle.** Première : puissances et frontières.

Source : S03, p. 5 ; accompagnement : R-T01. Jalons abrégés pour navigation ; le registre renvoie au libellé intégral du BO. Tous ces contenus thématiques restent à rédiger dans le projet.

## Faire la guerre, faire la paix : formes de conflits et modes de résolution

**Introduction du thème.** Panorama des conflits ; types, acteurs et modes de résolution ; distinguer guerre, conflit, violence et paix.

### Axe 1 — La dimension politique de la guerre : des conflits interétatiques aux enjeux transnationaux

• La guerre comme continuation de la politique : de la guerre de Sept Ans aux guerres napoléoniennes, à partir de Clausewitz.

• Le modèle de Clausewitz à l’épreuve des guerres irrégulières : d’Al-Qaïda à Daech.

### Axe 2 — Le défi de la construction de la paix

• La paix par les traités : les traités de Westphalie en 1648.

• La paix par la sécurité collective : l’ONU sous les mandats de Kofi Annan (1997–2006).

### Objet de travail conclusif — Le Moyen-Orient : conflits régionaux et tentatives de paix impliquant des acteurs internationaux (étatiques et non étatiques)

• Du conflit israélo-arabe au conflit israélo-palestinien : tentatives de résolution de 1948 à nos jours.

• Les guerres du Golfe (1991 et 2003) et leurs prolongements : de l’interétatique à l’asymétrique.

**VIGILANCE ÉDITORIALE PROPOSÉE**

Éviter les explications monocausales et les catégories figées. Dater les mises à jour ; distinguer qualification juridique, récit d’un acteur et analyse scientifique.

**Passerelle de cycle.** Première : puissances, frontières, États et religions.

Source : S03, p. 6 ; accompagnement : R-T02. Jalons abrégés pour navigation ; le registre renvoie au libellé intégral du BO. Tous ces contenus thématiques restent à rédiger dans le projet.

## Histoire et mémoires

**Introduction du thème.** Différencier histoire, mémoire et justice ; comprendre l’apparition des notions de crime contre l’humanité et de génocide.

### Axe 1 — Histoire et mémoires des conflits

• Les causes de la Première Guerre mondiale : un débat historique et ses implications politiques.

• Mémoires et histoire de la guerre d’Algérie.

### Axe 2 — Histoire, mémoire et justice

• La justice à l’échelle locale : les tribunaux gacaca face au génocide des Tutsis.

• La justice pénale internationale face aux conflits : le Tribunal pénal international pour l’ex-Yougoslavie.

### Objet de travail conclusif — L’histoire et les mémoires du génocide des Juifs et des Tsiganes

• Les lieux de mémoire.

• Juger les crimes nazis après Nuremberg.

• Les génocides dans la littérature et le cinéma.

**VIGILANCE ÉDITORIALE PROPOSÉE**

Contextualiser les témoignages et respecter les victimes. Ne pas mettre le négationnisme au rang d’une interprétation historiographique recevable. Expliquer les usages de catégories et leurs sources.

**Passerelle de cycle.** Première : démocratie, information, puissance ; Terminale : justice et patrimoine.

Source : S03, p. 7 ; accompagnement : R-T03. Jalons abrégés pour navigation ; le registre renvoie au libellé intégral du BO. Tous ces contenus thématiques restent à rédiger dans le projet.

## Identifier, protéger et valoriser le patrimoine : enjeux géopolitiques

**Introduction du thème.** Construction historique de la notion de patrimoine ; du legs familial au patrimoine mondial et à ses acteurs.

### Axe 1 — Usages sociaux et politiques du patrimoine

• Réaménager la mémoire : les usages de Versailles de l’Empire à nos jours.

• Conflits de patrimoine : les frises du Parthénon depuis le XIXe siècle.

### Axe 2 — Patrimoine, la préservation entre tensions et concurrences

• Urbanisation, développement et préservation : Paris entre protection et nouvel urbanisme.

• Destructions, protection et restauration du patrimoine au Mali.

• Le tourisme culturel, entre valorisation et protection : Venise.

### Objet de travail conclusif — La France et le patrimoine, des actions majeures de valorisation et de protection

• La gestion du patrimoine français : évolutions d’une politique publique.

• Valorisation et reconversion : le bassin minier du Nord-Pas-de-Calais.

• Patrimoine, rayonnement et diplomatie : le repas gastronomique des Français.

**VIGILANCE ÉDITORIALE PROPOSÉE**

Analyser les arbitrages entre usages plutôt qu’opposer mécaniquement protection et économie. Distinguer inscription UNESCO, propriété, conservation et attractivité.

**Passerelle de cycle.** Première : puissance et religions ; Terminale : environnement et mémoires.

Source : S03, p. 8 ; accompagnement : R-T04. Jalons abrégés pour navigation ; le registre renvoie au libellé intégral du BO. Tous ces contenus thématiques restent à rédiger dans le projet.

## L’environnement, entre exploitation et protection : un enjeu planétaire

**Introduction du thème.** Définir l’environnement comme notion historique, sociale et politique ; repères d’histoire environnementale.

### Axe 1 — Exploiter, préserver et protéger

• Exploiter et protéger une ressource : la forêt française depuis Colbert.

• Les sociétés face à leur environnement : ruptures du Néolithique et de la révolution industrielle.

### Axe 2 — Le changement climatique : approches historique et géopolitique

• Les fluctuations climatiques et leurs effets en Europe, du Moyen Âge au XIXe siècle.

• Le climat dans les relations internationales : sommets de la Terre et COP.

### Objet de travail conclusif — Les États-Unis et la question environnementale : tensions et contrastes

• L’environnement aux États-Unis depuis le XIXe siècle : État fédéral, États fédérés, protection et exploitation.

• Les États-Unis dans les négociations environnementales internationales : État, firmes et ONG.

**VIGILANCE ÉDITORIALE PROPOSÉE**

Distinguer variabilité ancienne et réchauffement contemporain ; ne pas produire de faux équilibre sur les résultats scientifiques. Dater les politiques et séparer échelles et acteurs.

**Passerelle de cycle.** Première : puissances ; Terminale : patrimoine, espaces maritimes et savoirs.

Source : S03, p. 9 ; accompagnement : R-T05. Jalons abrégés pour navigation ; le registre renvoie au libellé intégral du BO. Tous ces contenus thématiques restent à rédiger dans le projet.

## L’enjeu de la connaissance

**Introduction du thème.** Société de la connaissance ; communautés savantes et scientifiques ; produire, communiquer et circuler.

### Axe 1 — Produire et diffuser des connaissances

• L’alphabétisation des femmes, du XVIe siècle à nos jours dans le monde.

• La radioactivité, de 1896 aux années 1950 : échanges, coopération et rôle des individus.

### Axe 2 — La connaissance, enjeu politique et géopolitique

• Le renseignement au service des États : services soviétiques et américains durant la guerre froide.

• La circulation des étudiants et les transferts de technologie : l’exemple de l’Inde.

### Objet de travail conclusif — Le cyberespace : conflictualité et coopération entre les acteurs

• Le cyberespace entre réseaux, territoires, infrastructures, acteurs, liberté et contrôle des données.

• Cyberdéfense française : souveraineté nationale et coopération européenne.

**VIGILANCE ÉDITORIALE PROPOSÉE**

Ne pas confondre information, savoir et connaissance validée. Cartographier les infrastructures et compétences ; analyser les asymétries sans réduire le sujet au piratage.

**Passerelle de cycle.** Première : information, puissance et frontières.

Source : S03, p. 10 ; accompagnement : R-T06. Jalons abrégés pour navigation ; le registre renvoie au libellé intégral du BO. Tous ces contenus thématiques restent à rédiger dans le projet.

## 6. Le contrat pédagogique d’un thème

Conserver l’architecture disciplinaire : **introduction, axe 1, axe 2, objet de travail conclusif**. Un objet de travail conclusif est un nouveau terrain de mobilisation et d’articulation, pas une page facultative de résumé. [S02–S03]

| Temps de travail | Pièce concrète attendue |
| --- | --- |
| Se situer | Objectifs en langage candidat, diagnostic court des prérequis et orientation. |
| Comprendre | Cours rédigé, acteurs, contextes, échelles, notions, repères et relations entre les jalons. |
| Observer une démarche experte | Exemple commenté : lire un document, choisir un exemple ou construire un paragraphe. |
| Faire avec un guidage décroissant | Une tâche très guidée, une tâche partiellement guidée, une tâche autonome. |
| Vérifier une acquisition | Question de rappel, restitution, argumentation ou analyse de document avec critère observable. |
| Reprendre et revalider | Diagnostic de l’erreur, reprise ciblée et tâche parallèle nouvelle. |
| Relier et transférer | Objet conclusif, sujet de synthèse, rappel différé et passerelle avec un autre thème. |

### Trois couches de cours, sans réduire le cours à des fiches

**Essentiel** : une explication continue et structurée, pas une collection de dates. **Appui** : vocabulaire, repères chronologiques, localisation, acteurs et éclaircissement d’une difficulté. **Approfondissement** : débat scientifique documenté, nuance ou comparaison, explicitement signalés.

Chaque jalon reçoit un rôle dans le raisonnement du thème : ce qu’il permet de comprendre, les faits nécessaires, les liens avec les autres jalons et une limite à ne pas franchir. Les quatre approches disciplinaires doivent s’articuler là où elles éclairent l’objet ; il ne s’agit pas de remplir mécaniquement quatre cases à chaque paragraphe.

Les quantités d’activités sont des choix de production à calibrer. La règle quantitative des manuels de mathématiques ne se transpose pas automatiquement à un thème HGGSP.

## 7. Le cahier des charges d’un jalon

| Composant | Critère d’acceptation proposé |
| --- | --- |
| Question directrice | Elle relie le jalon à l’axe ; elle n’est ni une simple reprise du titre ni une question factice. |
| Mise en contexte | Période, espace, acteurs, notions et prérequis explicités. |
| Cours substantiel | Les relations causales, les évolutions et les limites sont expliquées ; un plan seul n’est pas un cours. |
| Appareil documentaire | Document réel disponible dans le support, provenance complète, lecture possible sans recherche extérieure imposée. |
| Argument mobilisable | Au moins une idée argumentée par des faits contextualisés ; pas un « exemple passe-partout ». |
| Travail du candidat | Tâche réalisable à partir du cours et des pièces disponibles, avec compétence et résultat attendus identifiés. |
| Correction et reprise | Réponse expliquée, variantes recevables, erreurs typiques et tâche de revalidation. |
| Liens | Renvois vers la méthode, l’axe, l’objet conclusif et une réactivation ultérieure. |

Un jalon peut nécessiter plusieurs documents et activités. À l’inverse, une même tâche de synthèse peut mobiliser plusieurs jalons. Le registre doit rendre ces relations visibles, sans compter la même occurrence plusieurs fois comme des acquisitions indépendantes.

**EXEMPLE : LA PRESSE DANS L’AFFAIRE DREYFUS**

Il ne suffit pas d’énumérer des journaux. Il faut contextualiser leurs interventions, identifier auteurs et publics, étudier la mise en circulation de l’information et confronter les usages de la presse. La tâche autonome doit obliger à relier une pièce précise à une analyse, et la correction doit expliquer les limites de cette pièce. Cette description est un contrat de rédaction, pas le cours du jalon. [S02, R-P04]

Les identifiants P01-A1-J01, etc., sont locaux. Les données du kit utilisent AXE1/AXE2/OTC pour éviter toute ambiguïté de chemin ; ce ne sont pas des codes officiels du ministère.

## 8. Une progression explicite des méthodes

| Méthode locale | Acquisition observable |
| --- | --- |
| M01 — Lire une consigne | Identifier le travail demandé, le périmètre et les contraintes. |
| M02 — Contextualiser | Placer un acteur ou un événement dans une période, un espace et des enjeux. |
| M03 — Construire une fiche de jalon | Hiérarchiser notions, faits, exemple argumenté et limite. |
| M04 — Analyser un document | Identifier sa nature, sa production, son intention, son apport et ses limites. |
| M05 — Lire carte, image ou statistique | Prendre en compte date, échelle, unités, légende, cadrage et méthode. |
| M06 — Confronter | Comparer des informations en répondant à une même question, sans juxtaposer. |
| M07 — Problématiser | Faire apparaître une tension ou un problème précis à traiter. |
| M08 — Argumenter | Associer une idée, un fait contextualisé, une explication et une nuance utile. |
| M09 — Composer / disserter | Construire un plan adapté, rédiger et relier les parties à la question. |
| M10 — Étude critique | Articuler documents et connaissances ; analyser et non paraphraser. |
| M11 — Prendre la parole | Exposer sans réciter, répondre, justifier et reconnaître une limite. |
| M12 — Vérifier et réviser | Contrôler une source, corriger une erreur et réactiver sans le cours. |

Chaque fiche méthode comprendra : quand l’utiliser, étapes, exemple annoté, erreur reconstituée, critères de relecture, exercice guidé et exercice autonome. La liste ci-dessus est un choix éditorial, non un référentiel officiel de douze capacités.

En Première, commencer par la phrase et le paragraphe, puis construire introductions et plans. En Terminale, faire produire des compositions longues et des études critiques complètes. Les critères exigeants sont conservés ; le guidage diminue.

Les finalités disciplinaires et capacités générales sont rattachées à S02–S03 ; la forme des épreuves à S04–S05. Les grilles de travail locales ne doivent pas se présenter comme des barèmes nationaux.

## 9. Exercices, entraînements et sujets blancs

La banque proposée distingue des **tâches élémentaires** et des **productions longues**. Cinquante petits items de rappel ne remplacent ni une dissertation ni une étude critique. À l’inverse, demander trop tôt une dissertation entière empêche d’identifier la difficulté précise.

| Échelle | Cible éditoriale initiale, à ajuster après essai |
| --- | --- |
| Chaque jalon | Rappel actif ; application documentaire ou argumentative ; tâche parallèle de revalidation. |
| Chaque axe | Une progression guidée vers une rédaction autonome ; travail de mise en relation de ses jalons. |
| Chaque thème de Première | Au moins deux sujets de composition avec itinéraires, dont une production intégrale corrigée ; une activité de synthèse sur l’objet conclusif. |
| Chaque thème de Terminale | Deux sujets de dissertation, deux dossiers critiques exploitables et une production longue de chaque format ; l’objet conclusif est intégré. |
| Échelle annuelle | Plusieurs entraînements chronométrés répartis dans l’année ; sujets A/B comparables mais non identiques. |
| Après remédiation | Nouveau sujet ou dossier : mesurer le transfert, pas la mémorisation du corrigé. |

### Fabriquer un sujet de Terminale recevable

En profil 2027, un sujet blanc peut proposer deux dissertations sur les thèmes 2 et 4 et une étude critique sur le thème 5. Un autre peut proposer les thèmes 5 et 6 et une étude critique sur le thème 2. Ce sont des **combinaisons de conception**, pas des prédictions de sujets. [S04]

La difficulté d’une étude critique dépend de la densité, du vocabulaire, du contexte et des tensions entre les pièces, pas seulement de la longueur des documents. Si deux pièces sont utilisées, respecter la diversité de nature prescrite. [S04]

**STATUT DES SUJETS**

Une annale reste identifiée par session, centre et source. Un sujet fabriqué est étiqueté « entraînement original », jamais « sujet officiel ». Les corrections du manuel ne sont pas des corrigés ministériels.

## 10. Des corrections réellement accessibles

Un candidat individuel ne peut pas apprendre seul avec un manuel qui lui cache toutes les corrections. La séparation des usages doit empêcher le dévoilement prématuré des réponses sans priver l’apprenant de retour.

| Variante | Accessible au candidat ? | Règle de diffusion |
| --- | --- | --- |
| Cours et exercices | Oui | Exemples résolus du cours autorisés ; réponses des exercices non placées à côté de l’énoncé. |
| Autocorrection et remédiation | Oui | Livret distinct, à ouvrir après la production et l’autoanalyse. |
| Méthodes et copies commentées | Oui | Différencier modèle de raisonnement, copie reconstituée et exemple de formulation. |
| Banque d’évaluation réservée | Non avant la passation | Envoi différé par l’enseignant ou le tuteur. |
| Guide du tuteur | Selon utilité | Ne pas y enfermer une explication indispensable à la compréhension du candidat. |

### Une correction en cinq temps

Reprendre la demande ; expliciter le raisonnement ; proposer une réponse recevable ; expliquer les erreurs importantes ; orienter vers un travail de reprise. En dissertation, signaler les autres problématiques ou organisations pertinentes, sans donner l’illusion d’un plan unique obligatoire.

Pour une étude de document, la correction distingue **ce que dit la pièce**, **ce qu’apportent les connaissances** et **ce qu’on ne peut pas conclure**. La simple accumulation de citations ne vaut pas analyse.

**FEUILLE DE SUIVI**

Après chaque correction : mon erreur principale ; sa cause probable ; l’action de reprise ; la preuve de réussite sur une tâche nouvelle. Une autoévaluation n’est ni une note officielle ni une attestation d’inscription ou de scolarité.

Ce choix adapte la séparation élève/professeur de la collection au public spécifique des candidats individuels.

## 11. Proposition de parcours en Première

Le calendrier ci-dessous est un **exemple éditorial de 32 semaines**, à décaler selon la date des évaluations, le niveau de départ et les contraintes du candidat. Il ne modifie pas les horaires ou le programme officiels.

| Période indicative | Travail principal | Production de référence |
| --- | --- | --- |
| Semaine 1 | Module 00 ; diagnostic ; dossier personnel de sources et d’erreurs. | Analyse brève d’un document et paragraphe argumenté. |
| Semaines 2–6 | Démocratie : introduction, axes, objet conclusif. | Comparer, contextualiser et justifier une qualification. |
| Semaines 7–11 | Puissances : formes, trajectoires, États-Unis. | Fiche d’exemple argumenté et plan de composition. |
| Semaines 12–16 | Frontières : tracés, débats, Europe. | Lecture critique de carte et composition guidée. |
| Semaines 17–21 | S’informer : transformations et contrôle. | Confronter des documents et corriger une surinterprétation. |
| Semaines 22–26 | États et religions : modèles et Inde. | Comparaison raisonnée et composition autonome. |
| Semaines 27–29 | Reprises ciblées et compositions de deux heures si spécialité non poursuivie. | Productions chronométrées, correction puis réécriture. |
| Semaines 30–32 | Transferts, revalidation et passerelles vers la Terminale. | Bilan des acquis documenté, sans promesse de note. |

### Un rythme autonome à tester, puis ajuster

Répartir le travail en séances : découverte du cours ; rappel sans support ; travail documentaire ; rédaction ; correction et reprise. Le temps de lecture d’un cours ne mesure pas sa maîtrise. Une séance d’accompagnement doit s’ajouter à des productions personnelles, non s’y substituer.

Pour une spécialité conservée, le parcours de Première construit les prérequis sans ajouter une épreuve ponctuelle HGGSP qui ne correspondrait pas au statut. Pour une spécialité arrêtée, préparer tous les axes et objets conclusifs susceptibles d’être évalués. [S05–S07]

## 12. Proposition de parcours en Terminale

Autre exemple de **32 semaines de travail**, non calendrier officiel. Les six thèmes sont étudiés. Le calendrier réel doit placer la préparation ciblée avant les dates de convocation du candidat ; il peut nécessiter un début plus précoce ou une cadence différente.

| Période indicative | Travail principal |
| --- | --- |
| Semaine 1 | Diagnostic des acquis de Première ; reprise de M04, M07 et M08 ; choix de la session. |
| Semaines 2–5 | Thème 1 : nouveaux espaces de conquête ; oral bref et première étude critique. |
| Semaines 6–9 | Thème 2 : faire la guerre, faire la paix ; dissertation structurée. |
| Semaines 10–13 | Thème 3 : histoire et mémoires ; analyse des usages et des statuts de sources. |
| Semaines 14–17 | Thème 4 : patrimoine ; dossier à échelles emboîtées et dissertation. |
| Semaines 18–21 | Thème 5 : environnement ; confrontation et explication des causalités. |
| Semaines 22–25 | Thème 6 : connaissance ; documents et argumentation géopolitique. |
| Semaines 26–28 | Révisions ciblées sur les quatre thèmes de la session et sujets blancs de quatre heures. |
| Semaines 29–32 | Correction, nouvelles passations, entraînement Grand oral et préparation de l’oral de contrôle selon les besoins. |

L’ordre des thèmes peut changer. En profil 2027, anticiper davantage les thèmes 2, 4, 5 et 6 ; en profil 2028, les thèmes 1, 2, 3 et 5. **Aucun thème n’est supprimé de la base du manuel.** [S04]

### Préparer l’oral tout au long de l’année

Dès le premier trimestre : repérer des questions, sélectionner des sources et tenir un carnet d’arguments. Alterner exposés brefs et réponses à une objection. La version finale des deux questions doit prendre en compte la seconde spécialité conservée ; un parcours HGGSP seul ne règle pas cette articulation. [S08]

Ne pas commercialiser ce planning comme équivalent garanti de 6 heures hebdomadaires de cours accompagnés. Le diagnostic, la vitesse de lecture et la qualité des productions commandent les ajustements.

## 13. La fiche d’exemple : un outil de transfert

La difficulté n’est pas seulement de mémoriser : elle est de choisir un exemple pertinent et de l’utiliser pour démontrer quelque chose. Chaque exemple doit donc être organisé pour servir un raisonnement.

| Rubrique de la fiche | Question à se poser |
| --- | --- |
| Objet, période, espace | De quel cas est-il question ? Quelles bornes sont pertinentes ? |
| Acteurs et objectifs | Qui agit, au nom de quoi, avec quels moyens et quelles contraintes ? |
| Faits vérifiés | Quelles informations précises puis-je mobiliser ? D’où viennent-elles ? |
| Mécanisme | Quel processus l’exemple permet-il d’expliquer ? |
| Argument | À quelle idée répond-il ? Quelle phrase l’introduit ? |
| Limite | Ce cas prouve-t-il vraiment la proposition générale ? |
| Réemploi | Dans quels sujets ou thèmes cet exemple serait-il pertinent ? |

### Des passerelles utiles, sans exemple universel

Les frontières de Première peuvent être reprises dans les enjeux de souveraineté maritime ; la puissance dans la conquête spatiale ; l’information dans la connaissance ; les religions dans les conflits et les usages du patrimoine. Ces renvois sont des aides d’étude, pas l’affirmation que tous ces objets sont interchangeables.

**ERREUR À TRAITER**

Une copie ne devient pas argumentée en ajoutant un nom propre à une généralité. Le candidat doit préciser ce que son exemple montre et expliquer le lien. « La Chine, par exemple » n’a pas la même valeur qu’un fait daté, situé et analysé.

Chaque fin de thème comprend une question de transfert vers un chapitre déjà travaillé. La réactivation commence par un rappel sans le cours, suivi seulement ensuite d’une vérification. Les rappels peuvent être programmés à J+2, J+7 et J+21 : ce sont des repères pédagogiques proposés, non des prescriptions officielles.

## 14. Sources, preuve et honnêteté intellectuelle

### Hiérarchie et pluralité

Le BO définit le programme et les épreuves. Éduscol accompagne leur mise en œuvre. Les connaissances du cours reposent ensuite sur des travaux scientifiques et des sources documentaires identifiés. Un site institutionnel peut établir la position d’un acteur sans constituer à lui seul une analyse indépendante de ses actions.

### Chaque pièce documentaire possède une fiche de provenance

Auteur ou organisme ; nature ; titre ; date de production ; lieu ; destinataire ; publication ou fonds ; page ; URL stable si disponible ; date de consultation ; langue et traducteur ; coupes signalées ; droits et conditions de reproduction. Pour une statistique : périmètre, méthode, unité, dénominateur et date des données.

### Ce qui est interdit dans le manuel

Inventer une citation ou sa pagination ; transformer une synthèse en extrait d’archive ; faire passer un texte généré pour un discours historique ; masquer une adaptation ; présenter une carte fabriquée comme une carte ancienne ; utiliser une référence bibliographique non vérifiée.

Un cas fictif est permis pour apprendre une méthode **s’il est identifié comme tel**. Il ne remplace pas les études historiques et géopolitiques réelles exigées par les jalons. Une illustration générée ne sert jamais de preuve historique.

### Débats et sujets sensibles

Distinguer faits établis, interprétations scientifiques, qualification juridique et discours des acteurs. Expliquer les désaccords pertinents sans créer un équilibre artificiel entre recherche et négationnisme, ou entre résultat scientifique et affirmation dénuée de preuve. Traiter guerres, religions et génocides avec précision, sans assigner une responsabilité collective à une population.

**ACTUALISATION**

Toute situation décrite « aujourd’hui » reçoit une date de clôture documentaire. Les actualisations récentes sont isolées du cours historique stable, avec leurs sources. Une nouvelle édition n’efface pas la trace de la version précédente.

La présence d’un document sur Internet ne vaut pas autorisation de réédition. Le registre des droits doit être vérifié avant diffusion commerciale.

## 15. Charte graphique : continuité et spécificités

L’arborescence fournie montre un socle partagé **gabarits/common/** et des extensions disciplinaires. La proposition consiste à ajouter une extension HGGSP, non à copier les classes communes dans une nouvelle branche parallèle. Le chargement effectif des composants devra être vérifié lors de l’intégration. [S11–S12]

| Objet HGGSP | Règle de présentation proposée |
| --- | --- |
| Cours | Colonne principale confortable ; hiérarchie stable ; notions distinguées sans surlignage systématique. |
| Source | Numéro, nature, auteur, date et provenance au même endroit ; texte lisible et lignes repérables. |
| Carte | Titre problématisé, date, échelle, légende organisée, source ; territoires contestés représentés avec précaution. |
| Chronologie | Échelle temporelle cohérente ; rupture d’échelle explicitée ; événements sélectionnés selon la question. |
| Méthode / copie commentée | Étapes et commentaires identifiés ; ne pas confondre modèle avec réponse obligatoire. |
| Appui marginal | Vocabulaire ou repère court ; repli dans le flux principal si la marge est saturée. |
| Révision | Fiche de repères distincte du cours complet ; rappel des sources et des limites. |

Une couleur d’accent disciplinaire peut être proposée, mais son adoption doit être validée dans la charte de collection. Dans ce lot autonome, l’encre sombre et l’accent brun sont des choix de présentation, **pas une nouvelle référence canonique imposée au dépôt**.

Les versions numériques doivent offrir sommaire, signets, liens, métadonnées et ordre de lecture cohérent. Les informations ne reposent pas sur la couleur seule. Les cartes et encadrés sont testés en niveaux de gris ; une version adaptée peut séquencer les consignes sans retirer les objectifs.

Les PDF de ce lot ne prétendent pas disposer d’une certification PDF/UA. Aucun fichier de police n’est inclus dans les archives.

## 16. Une seule base, plusieurs publications

Arborescence cible **proposée** pour une future intégration contrôlée :

```text
HGGSP/
  CAHIER_DES_CHARGES.md
  referentiel/           # programme et profils de session
  sources/              # bibliographie, provenance, droits
  premiere/P00/          # entrée dans la discipline
  premiere/P01/ ... P05/ # cinq thèmes
  terminale/T01/ ... T06/# six thèmes
  methodes/             # sources uniques réutilisables
  entrainements/        # exercices, documents, aides
  autocorrection/       # livrets accessibles au candidat
  evaluations/          # banques à diffusion maîtrisée
  manifests/            # listes exactes des objets publiés
  audit/                # preuves et décisions de revue
  scripts/              # contrôles et assemblage

gabarits/hggsp/nexus-hggsp.sty  # extension du socle partagé
```

### Relations à conserver dans les données

Chaque objet possède un identifiant stable, un type, un public, un niveau, un thème, un axe ou objet conclusif, les jalons mobilisés, les sources, la date des informations évolutives, les droits, les renvois, le statut de rédaction et le statut de revue. Une correction indique précisément les questions auxquelles elle répond.

Le PDF est un résultat d’assemblage, pas le seul lieu où vit le contenu. Les différentes versions sont générées à partir d’un manifeste explicite ; aucune recherche floue par nom de fichier ne doit décider silencieusement ce qui entre dans le livre.

**PÉRIMÈTRE DE CETTE LIVRAISON**

Aucun fichier n’a été écrit dans le dépôt GitHub ni sur le disque local du commanditaire. Le kit remis constitue une proposition d’intégration à relire ; son existence ne prouve pas une synchronisation avec le projet local.

## 17. Les contrôles de qualité adaptés à HGGSP

| Domaine | Preuve attendue avant publication |
| --- | --- |
| Programme | Chaque introduction, axe, jalon et objet conclusif est rattaché à des contenus réellement présents dans le PDF. |
| Connaissances | Dates, acteurs, notions, citations, interprétations et actualisations vérifiés par une revue disciplinaire documentée. |
| Documents | Fidélité à l’original, contexte, provenance, disponibilité et droits vérifiés. |
| Pédagogie | Parcours testable : diagnostic, cours, guidage, autonomie, correction, reprise et revalidation. |
| Épreuves | Version réglementaire correcte ; format et périmètre de session ; distinction des publics. |
| Cartes / statistiques | Légendes, échelles, dates, unités, dénominateurs et limites contrôlés. |
| Éditorial | Renvois, numérotation, lexique, index, crédits et séparation des variantes cohérents. |
| Rendu | Inspection de toutes les pages ; aucun élément masqué, illisible ou mal associé. |
| Production | Sources identifiées, dépendances et empreintes de build, PDF de diffusion rattaché au bon assemblage. |

Des scripts peuvent détecter des références manquantes, des liens cassés, une rotation incohérente ou un décompte faux. Ils ne valident pas à eux seuls une analyse historique, un débat historiographique ou la pertinence d’un document.

**STATUTS SÉPARÉS**

Inventorié → rédigé → relu disciplinairement → relu pédagogiquement → contrôlé éditorialement → vérifié visuellement → autorisé à diffuser. Chaque étape demande une preuve adaptée. Un auteur ne s’attribue pas une validation humaine indépendante.

Ne pas résumer ces dimensions dans une moyenne globale rassurante. Une erreur historique centrale, une fausse citation ou une épreuve mal définie peut bloquer une publication, même si toutes les pages sont bien composées.

## 18. Ordre de production et décision de lancement

| Lot | Résultat attendu | Condition de passage |
| --- | --- | --- |
| 0 — Fondations | Le présent dossier, le référentiel, les profils, les sources et le module d’entrée. | Validation éditoriale du périmètre et du modèle. |
| 1 — Pilote disciplinaire | Thème P01 complet, avec toutes ses composantes, autocorrection et évaluation. | Revue experte et essai d’autonomie avec critères documentés. |
| 2 — Première | P02 à P05 ; harmonisation des méthodes ; sujets de composition. | Couverture réelle des 39 jalons et revue des cinq objets conclusifs. |
| 3 — Terminale | T01 à T06 ; écrit et oral ; les deux profils de session. | Couverture des 39 jalons ; formats d’examen vérifiés. |
| 4 — Compagnons | Méthodes, atlas de repères, corrections, révisions, guide du tuteur. | Pas de doublons divergents ni de correction inaccessible au candidat. |
| 5 — Publication | Assemblages, contrôle de tous les types de pages sensibles, droits et revue finale. | Décision de diffusion documentée sur les PDF exacts. |

Le pilote P01 est proposé parce qu’il permet de tester l’articulation histoire/sciences politiques, la comparaison, les documents normatifs et les passages entre institutions et pratiques. Sa production complète **n’est pas annoncée comme déjà réalisée** dans le module 00.

### Arbitrages éditoriaux recommandés

Privilégier deux volumes maniables plutôt qu’un unique ouvrage massif ; conserver un export cycle complet. Donner les corrections au candidat dans un compagnon séparé. Définir une date de clôture documentaire. Réserver une revue indépendante aux sujets politiquement et historiographiquement sensibles.

Il s’agit d’un ordre de travail proposé, sans promesse de réalisation en arrière-plan. Les délais et volumes définitifs se fixent après le pilote, et non par gonflement d’un nombre de pages.

## Références documentaires — 1

Les références réglementaires fixent le cadre ; les ressources d’accompagnement et les choix éditoriaux restent distingués. Les liens et le registre complet sont fournis dans le dossier sources/.

### S01 — Programmes et ressources HGGSP — voie générale

Programmes en vigueur et ressources disciplinaires ; page mise à jour en mars 2026.

[Éduscol — consulter la source](https://eduscol.education.gouv.fr/5802/programmes-et-ressources-en-histoire-geographie-geopolitique-et-sciences-politiques-voie-g)

### S02 — Programme HGGSP de Première — BO spécial n° 1 du 22 janvier 2019

Programme prescriptif : cinq thèmes ; tableaux thématiques aux pages 5 à 9.

[Ministère de l’Éducation nationale — consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/spe576annexe1062925pdf-83244.pdf)

### S03 — Programme HGGSP de Terminale — BO spécial n° 8 du 25 juillet 2019

Programme prescriptif : six thèmes ; tableaux thématiques aux pages 5 à 10.

[Ministère de l’Éducation nationale — consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/spe254annexe1159180pdf-83247.pdf)

### S04 — Épreuve terminale HGGSP à compter de la session 2026 — note du 27 août 2025, NOR MENE2521923N

Texte actuel : écrit, oral de contrôle et rotation des thèmes ; remplace la note de 2020.

[BO n° 33 du 4 septembre 2025 — consulter la source](https://www.education.gouv.fr/bo/2025/Hebdo33/MENE2521923N)

### S05 — Évaluations ponctuelles : spécialité non poursuivie — version consolidée de juin 2025

HGGSP aux pages 3–4 : composition de deux heures ; coefficient commun indiqué page 2.

[Éduscol — consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ndsevaluations-ponctuelleseds-non-poursuivivoie-gjuin-2025pdf-100575.pdf)

### S06 — Candidats individuels au baccalauréat général et technologique

Statut, inscription, évaluations ponctuelles et articulation du cycle ; page mise à jour en mars 2026.

[Éduscol — consulter la source](https://eduscol.education.gouv.fr/5694/candidats-individuels-au-baccalaureat-general-et-au-baccalaureat-technologique)

### S07 — Modalités d’évaluation des candidats individuels — note du 25 août 2025, NOR MENE2523743N

Évaluations ponctuelles annuelles ou en fin de cycle ; choix global à l’inscription.

[BO n° 32 du 28 août 2025 — consulter la source](https://www.education.gouv.fr/bo/2025/Hebdo32/MENE2523743N)

### S08 — Présentation du Grand oral

Déroulement, questions et candidats individuels ; coefficient 8 en voie générale à partir de 2027.

[Éduscol — consulter la source](https://eduscol.education.gouv.fr/5661/presentation-du-grand-oral)

### S09 — Les épreuves terminales du baccalauréat général

HGGSP : écrit, quatre heures, coefficient 16 ; tableau des coefficients actualisé.

[Éduscol — consulter la source](https://eduscol.education.gouv.fr/5706/les-epreuves-terminales-du-baccalaureat-general)

Consultation : 8 septembre 2026. Les pages web et documents évolutifs devront être contrôlés lors de chaque édition.

## Références documentaires — 2

Les références réglementaires fixent le cadre ; les ressources d’accompagnement et les choix éditoriaux restent distingués. Les liens et le registre complet sont fournis dans le dossier sources/.

### S10 — Déclaration du 26 août 1789 des droits de l’homme et du citoyen

Document primaire : article 16 utilisé dans le module 00 ; distinguer texte normatif et application.

[Légifrance — consulter la source](https://www.legifrance.gouv.fr/loda/id/JORFTEXT000000697056)

### S11 — SOURCE_DE_VERITE.md — collection Manuels Nexus

Document d’organisation daté du 11 août 2026, consulté en lecture seule ; ne certifie pas l’état local actuel.

[Dépôt manuels-nexus — consulter la source](https://github.com/cyranoaladin/manuels-nexus/blob/main/SOURCE_DE_VERITE.md)

### R-P01 — Première, thème 1 — Démocratie

Ressource d’accompagnement : éclaire la mise en œuvre, sans remplacer le programme officiel.

[Éduscol — consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra19lyceegspe1hggsptheme1democratie1169458pdf-83250.pdf)

### R-P02 — Première, thème 2 — Puissances

Ressource d’accompagnement : éclaire la mise en œuvre, sans remplacer le programme officiel.

[Éduscol — consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra19lyceegspe1hggsptheme2puissancesinter1169460pdf-83253.pdf)

### R-P03 — Première, thème 3 — Frontières

Ressource d’accompagnement : éclaire la mise en œuvre, sans remplacer le programme officiel.

[Éduscol — consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra19lyceegspe1hggsptheme3frontieres1206062pdf-83256.pdf)

### R-P04 — Première, thème 4 — S’informer

Ressource d’accompagnement : éclaire la mise en œuvre, sans remplacer le programme officiel.

[Éduscol — consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra20lyceeg1histgeogeopolitique-sciencespotheme4-sinformer-regard-critique1293847pdf-83259.pdf)

Consultation : 8 septembre 2026. Les pages web et documents évolutifs devront être contrôlés lors de chaque édition.

## Références documentaires — 3

Les références réglementaires fixent le cadre ; les ressources d’accompagnement et les choix éditoriaux restent distingués. Les liens et le registre complet sont fournis dans le dossier sources/.

### R-P05 — Première, thème 5 — États et religions

Ressource d’accompagnement : éclaire la mise en œuvre, sans remplacer le programme officiel.

[Éduscol — consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra20lyceeg1histgeogeopolitique-sciencespoanalyser-relations-etats-religions1293914pdf-83262.pdf)

### R-T01 — Terminale, thème 1 — Nouveaux espaces de conquête

Ressource d’accompagnement : éclaire la mise en œuvre, sans remplacer le programme officiel.

[Éduscol — consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra20lyceegtspehgeotheme1espacesconquetes0021329089pdf-83265.pdf)

### R-T02 — Terminale, thème 2 — Guerre et paix

Ressource d’accompagnement : éclaire la mise en œuvre, sans remplacer le programme officiel.

[Éduscol — consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra22lycee-gthggsptheme-2faire-la-guerre-et-faire-la-paix-93786.pdf)

### R-T03 — Terminale, thème 3 — Histoire et mémoires

Ressource d’accompagnement : éclaire la mise en œuvre, sans remplacer le programme officiel.

[Éduscol — consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra22lycee-gthggsphistoire-et-memoires-93783.pdf)

### R-T04 — Terminale, thème 4 — Patrimoine

Ressource d’accompagnement : éclaire la mise en œuvre, sans remplacer le programme officiel.

[Éduscol — consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra25lyceegthggspidentifierprotegervaloriserpatrimoine-enjeuxgeopolitiques0pdf-121241.pdf)

### R-T05 — Terminale, thème 5 — Environnement

Ressource d’accompagnement : éclaire la mise en œuvre, sans remplacer le programme officiel.

[Éduscol — consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra23lyceegthggspenvironnementexploitationprotectionenjeupdf-102786.pdf)

### R-T06 — Terminale, thème 6 — Connaissance

Ressource d’accompagnement : éclaire la mise en œuvre, sans remplacer le programme officiel.

[Éduscol — consulter la source](https://eduscol.education.gouv.fr/sites/default/files/document/ra24lyceegthggspenjeuxconnaissancepdf-104487.pdf)

### S12 — Arborescence locale fournie par le commanditaire

Fichier « Texte collé(3).txt » : organisation apparente, gabarits communs et disciplines ; aucun contenu HGGSP identifié dans ce relevé. Ne constitue pas une lecture exhaustive des sources locales.

Consultation : 8 septembre 2026. Les pages web et documents évolutifs devront être contrôlés lors de chaque édition.

