# HGGSP — Mise en place du manuel du cycle terminal

**Version 0.1 — 8 septembre 2026 — Projet Manuels Nexus Réussite**

## Périmètre réel de cette livraison

Ce kit établit le cadre réglementaire, la cartographie du programme des deux années, les règles pédagogiques et éditoriales et la proposition d'intégration technique. Il comprend aussi un **module introductif rédigé, avec ses exercices et son autocorrection**.

**Il ne contient pas encore les cours développés des onze thèmes, les dossiers documentaires de leurs 78 jalons, ni les banques complètes de sujets du baccalauréat.** Le recensement des jalons n'est pas une preuve de rédaction ou de validation de ces contenus. Le référentiel les maintient au statut `a_rediger`.

Les pièces jointes antérieures du projet renseignent son organisation ; elles ne sont pas des sources historiques HGGSP. Les références disciplinaires et d'examen ont été recherchées séparément et sont identifiées dans le registre. Aucun nom d'enseignant fourni pour les documents de NSI n'est attribué automatiquement à ce nouveau manuel.

## Lecture conseillée

| Document | Rôle | Pages PDF |
|---|---|---:|
| `documents/HGGSP_Cycle_terminal_Dossier_fondateur.pdf` | Conception complète, publics, programme, examens, parcours, rédaction et contrôles | 34 |
| `documents/HGGSP_Module_00_Candidat.pdf` | Entrer en HGGSP : source, argument, données, limites et premier entraînement autonome | 18 |
| `documents/HGGSP_Module_00_Autocorrection.pdf` | Réponses expliquées, formulations modèles, reprises et bilans | 8 |

Chaque document existe aussi en `.docx` modifiable et en `.md` lisible. Les PDF sont les rendus de cette version ; les DOCX peuvent changer de pagination selon le logiciel et les polices disponibles.

Le compagnon d'autocorrection est **accessible au candidat**, après une première réponse personnelle. Il n'est pas réservé à un enseignant. Les bilans A/B du module sont formatifs : une fois diffusés avec leurs réponses, ils ne constituent pas une banque d'évaluations inconnues du candidat.

## Repères réglementaires à conserver

- HGGSP non poursuivie après la Première : évaluation ponctuelle sur le programme de Première, composition de deux heures, coefficient 8.
- HGGSP conservée en Terminale : épreuve écrite de quatre heures, coefficient 16 ; pas de seconde évaluation ponctuelle HGGSP de Première à ajouter au seul titre du statut individuel.
- Session 2027 : thèmes terminaux 2, 4, 5 et 6 évaluables à l'écrit. Session 2028 : thèmes 1, 2, 3 et 5. Les six thèmes restent dans le manuel et dans le parcours d'apprentissage.
- Grand oral : coefficient 8 en voie générale à compter de la session 2027 ; vingt minutes de préparation puis vingt minutes d'épreuve, en deux temps de dix minutes. Les deux questions présentées couvrent les deux spécialités conservées.
- Le Grand oral n'est pas l'oral de contrôle. HGGSP ne remplace pas l'histoire-géographie du tronc commun. Le statut de candidat individuel ne transforme pas toutes les composantes du diplôme en une unique épreuve terminale.

Ces éléments sont documentés par les sources S04 à S09. Vérifier leur maintien pour chaque nouvelle édition et la convocation du candidat. Ce kit ne fixe aucune date d'inscription ou de passation locale en Tunisie ou ailleurs.

## Contenu structuré

`referentiel/programme_cycle_terminal.json` recense 11 thèmes, 22 axes, 11 objets de travail conclusifs et 78 jalons (39 par année). Les identifiants sont locaux. Les formulations de jalons sont explicitement abrégées pour l'inventaire : consulter le BO et sa page indiquée pour le libellé intégral.

`referentiel/profils_examens.json` sépare les publics, les formats et les sessions. `referentiel/module00_objets.json` relie 25 objets pédagogiques du module à leurs corrections. `sources/registre_sources.json` décrit 23 références de nature différente : réglementation, accompagnement, document primaire et organisation du projet.

`production/MISSION_CONSTRUCTION_MANUEL_HGGSP.md` définit la suite du travail pour un agent de production indépendant. `production/CONTRAT_OBJETS.md` précise les informations à conserver pour chaque contenu.

## Modifier ou reconstruire

Pour une modification ponctuelle, ouvrir le DOCX dans Word ou un logiciel compatible, puis enregistrer une nouvelle version. Relire les pages après export PDF.

Pour conserver la source structurée unique, modifier le JSON de contenu concerné dans `documents/`, puis lancer depuis la racine extraite du kit :

```bash
python3 production/generer_documents.py
python3 verification/verifier_kit.py
```

Le générateur nécessite `python-docx`. Les tests utilisent seulement la bibliothèque standard de Python. Le générateur **remplace les trois DOCX et les trois Markdown** dans le dossier `documents/` ; une modification manuelle du DOCX n'est pas réimportée automatiquement dans le JSON.

L'export PDF se fait ensuite avec un logiciel de traitement de texte. Aucun script fourni n'installe des dépendances, n'accède au réseau ni ne modifie le dépôt GitHub. Les références bibliographiques sont des liens, pas des copies incorporées des ressources tierces. Aucun fichier de police n'est distribué.

## Vérifications et limites

Les 24 tests de cohérence du kit ont réussi. Les trois PDF totalisent 60 pages ; leurs rendus ont été inspectés. Le contrôle technique constate des signets, des métadonnées et des polices incorporées, ainsi qu'une absence de mots extraits hors du format de page. Les pages modifiées lors de la relecture ont été rendues et examinées de nouveau.

Ces résultats ne sont **ni une validation humaine indépendante de tous les contenus historiques, ni une certification PDF/UA, ni une preuve de complétude du futur manuel**. Le rapport détaille le périmètre dans `verification/RAPPORT_VERIFICATION.md`.

## Intégration au projet

Le dossier remis est autonome. L'arborescence cible proposée est une extension HGGSP du socle partagé, non un nouveau jeu concurrent de classes communes. Aucune opération de copie, fusion, commit ou publication n'a été exécutée dans `manuels-nexus` ou sur la machine du commanditaire. L'intégration exige une revue des dépendances réelles et une décision explicite de diffusion.
