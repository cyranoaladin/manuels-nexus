# Mission de construction — Manuel HGGSP du cycle terminal

Version 0.1 — sources réglementaires consultées au 8 septembre 2026.

## 1. Mandat et limites de départ

Construire un véritable manuel autonome de spécialité HGGSP pour les classes de Première et Terminale de la voie générale, destiné prioritairement aux candidats individuels. Conserver la logique d’apprentissage et l’identité de la collection Manuels Nexus, en adaptant les objets, les sources et les contrôles à cette discipline.

Le présent kit fournit un dossier de conception, une cartographie de programme, des profils d’examen et un module d’entrée rédigé. Il **ne contient pas les cours des onze thèmes**. Aucun rapport automatisé de ce kit ne vaut validation historique, juridique, pédagogique ou éditoriale indépendante.

Ne pas transformer ce kit en ouvrage « terminé » en modifiant simplement son statut ou en recopiant la liste des jalons dans des fichiers de cours. Ne pas attribuer de crédits HGGSP aux enseignants nommés antérieurement pour les documents de NSI.

## 2. Reprise du projet et protection des travaux existants

Avant toute écriture dans le dépôt réel : lire les instructions locales applicables, l’état Git, les modifications non validées et les registres d’autorité. Le relevé d’arborescence est une pièce de contexte, pas la preuve des dépendances actuellement chargées. Lire les fichiers qui définissent ces dépendances.

Repérer un éventuel contenu HGGSP ajouté depuis le relevé transmis et l’auditer avant de créer un doublon. Ne rien supprimer, restaurer ou déplacer automatiquement. Ne pas lancer une compilation qui écraserait les preuves de production existantes. Utiliser une destination de travail explicitement autorisée et des sorties identifiables ; respecter les règles de branche et de validation du dépôt.

Ce mandat de rédaction n’autorise ni publication commerciale, ni fusion sur la branche principale, ni modification de l’infrastructure ou de projets voisins. Les opérations Git engageantes restent soumises aux autorisations du commanditaire.

## 3. Hiérarchie des sources et vérification réglementaire

1. Textes officiels du programme et des épreuves applicables à la session.
2. Règles du projet approuvées, sans contradiction avec les textes officiels.
3. Ressources d’accompagnement Éduscol et publications scientifiques vérifiées.
4. Sources primaires, documents et données contextualisés pour chaque sujet.
5. Rapports de travail et traces de génération : preuves de processus, non autorités scientifiques.

Relire S01 à S09, et vérifier leur actualité avant d’annoncer une édition de session. La note HGGSP du 27 août 2025 remplace la note de 2020. Les coefficients du Grand oral publiés dans un ancien document consolidé ne doivent pas supplanter le coefficient actuel applicable à partir de 2027.

Profils à préserver :

- **Spécialité non poursuivie après Première** : composition de deux heures, coefficient 8, programme de Première ; axe ou objet conclusif. Ne pas inventer un nombre de sujets au choix.
- **Spécialité conservée en Terminale** : écrit de quatre heures, coefficient 16 ; dissertation et étude critique /10 chacune. Deux dissertations au choix sur deux thèmes distincts ; étude critique sur un troisième thème.
- **Grand oral** : pour la voie générale à partir de 2027, coefficient 8 ; 20 minutes de préparation, puis 10 minutes de présentation et 10 minutes d’échange. Les deux questions doivent couvrir les deux spécialités conservées.
- **Oral de contrôle HGGSP** : programme de l’écrit de la session ; 20 minutes de préparation et 20 minutes de passage. Ce n’est pas le Grand oral.

La rotation actuelle donne 2/4/5/6 pour 2027 et 1/2/3/5 pour 2028. Le manuel couvre néanmoins les six thèmes de Terminale. Un candidat HGGSP conservée ne passe pas en plus l’évaluation réservée à HGGSP abandonnée.

Ne pas annoncer d’inscription, de délai local ou de regroupement de toutes les épreuves du bac sur une seule année sans source applicable au candidat. Les contenus du tronc commun et de l’EMC demeurent distincts.

## 4. Transformer le référentiel en matrice de contenu

Le registre fourni contient 11 thèmes, 22 axes, 11 objets de travail conclusifs et 78 entrées de jalons. Les libellés des jalons sont des abrégés éditoriaux et les identifiants sont locaux. Pour chaque entrée, consulter le tableau officiel indiqué avant rédaction. Ne pas transformer les codes locaux en prétendues capacités ministérielles.

Conserver les onze introductions thématiques et l’entrée générale dans la discipline. L’objet de travail conclusif n’est pas une synthèse facultative : il doit être étudié comme terrain de mobilisation et d’articulation.

Pour chaque jalon, renseigner au fur et à mesure les identifiants réels du cours, des documents, des exercices, de la correction et de la revalidation. Ne jamais cocher une couverture sur la seule existence d’un fichier. Une rubrique contenant seulement un titre ou trois phrases génériques ne constitue pas un cours.

Préserver des statuts distincts : contenu à rédiger, rédigé, revu sur le fond, revu pédagogiquement, contrôlé éditorialement, vérifié visuellement, autorisé à diffuser. Les transitions sont attachées à une version précise et à une preuve.

## 5. Contenu attendu dans chaque thème

Un thème doit comprendre : contrat d’apprentissage, prérequis, diagnostic et orientation ; cours rédigé et substantiel ; vocabulaire, chronologie, localisation et acteurs ; documents exploitables ; méthodes en contexte ; tâches de difficulté graduée ; correction guidée ; bilan ; remédiation ; nouveau test ; rappel différé ; objets de synthèse et transfert.

Chaque jalon explicite sa question, son rôle dans l’axe, ses contextes et ses mécanismes. Sélectionner les faits utiles et expliquer leurs liens ; ne pas produire une simple liste de dates et de personnages. Mettre en relation les jalons sans en fusionner silencieusement les obligations.

Articuler histoire, géographie, géopolitique et sciences politiques en fonction de l’objet. Ne pas faire semblant de mobiliser les quatre approches dans chaque paragraphe. Ne pas réduire la géopolitique aux guerres, les sciences politiques aux opinions personnelles ou l’histoire à une chronologie.

Les parcours ◆/◆◆/◆◆◆ modifient le guidage et la difficulté des tâches, non la vérité des faits ou le programme à apprendre. Les exigences quantitatives proposées dans le dossier sont à tester ; ne pas importer sans adaptation le quota d’exercices des mathématiques.

## 6. Source réelle, source adaptée et fiction

Tout document historique ou contemporain reproduit doit être réel, lisible dans le support, identifié et référencé. Une ressource facultative peut être externalisée ; une pièce nécessaire à un exercice ne doit pas être remplacée par un lien inaccessible ou un simple titre.

Pour chaque document : auteur, nature, titre, date, contexte, destinataire, fonds ou publication, page, URL, langue et traduction, coupes et adaptations, droits. Un document institutionnel peut exprimer une position ; il ne devient pas neutre parce que son émetteur est public.

Interdictions : citations inventées ; pagination non vérifiée ; bibliographie reconstituée de mémoire ; propos générés présentés comme un discours réel ; fausses archives ; images synthétiques utilisées comme preuves historiques ; graphiques sans données vérifiables ; cartes anciennes fabriquées sans mention de reconstruction.

Les cas fictifs du module 00 restent limités à l’apprentissage méthodologique. Ils ne peuvent servir de matériau factuel pour les jalons, de statistiques réelles ou d’exemples historiques dans les copies de bac.

Distinguer faits établis, interprétations, discours d’acteurs et qualifications juridiques. Contextualiser les controverses sans faux équilibre entre résultat scientifique et affirmation sans preuve. Respecter la dignité des victimes dans les chapitres sur guerres, génocides et mémoires. Éviter les formulations qui attribuent une position unique à une population, une religion ou une communauté.

## 7. Actualisation et cartes

Datation obligatoire des états contemporains, des statistiques, des rapports de force et des accords en évolution. Maintenir une couche historique stable et une couche d’actualisation versionnée. Un indicateur doit préciser son année, son unité, son périmètre et son dénominateur.

Pour une carte : période représentée, échelle, source du fond, légende, projection utile, acteurs et limites. Les frontières contestées, zones de contrôle et reconnaissances juridiques doivent être distinguées. Une date de consultation ne remplace pas la date des données représentées.

Pour le climat, séparer évolution du phénomène, résultats de la recherche et débats sur les politiques. Pour les conflits, distinguer événements documentés, allégations, décisions de justice et positions diplomatiques.

## 8. Correction et autonomie du candidat

Produire des livrets d’autocorrection accessibles au candidat, séparés des énoncés. Ne pas conserver une explication indispensable uniquement dans le guide enseignant. Les exemples résolus sont permis dans le cours ; ils ne constituent pas une fuite de corrigé.

Chaque correction reprend la demande, explique les choix, propose une réponse recevable, signale les erreurs typiques et oriente vers un nouveau travail. Indiquer les autres plans pertinents lorsque plusieurs réponses argumentées sont possibles. Une copie reconstituée est étiquetée comme telle.

La banque d’évaluation réservée reste distincte et sa diffusion est différée. Une évaluation déjà publiée dans un livret candidat devient un entraînement connu, pas un sujet secret.

## 9. Assemblage et styles partagés

Ajouter une extension disciplinaire dans la structure commune après lecture de la charte réellement en vigueur. Ne pas créer une copie divergente de `nexus-manuel.cls` ou des styles communs. La couleur proposée dans ce kit n’est pas une nouvelle autorité graphique.

Créer des manifestes explicites pour Première, Terminale, export cycle, méthodes, autocorrection et versions de session. Vérifier les références, l’ordre, l’unicité des objets et la séparation des publics. Un fichier réutilisé garde une seule source ; les sorties ne sont pas éditées pour compenser un défaut en amont.

Conserver les traces de compilation et les dépendances réellement résolues. Comparer les PDF diffusés et les sorties autorisées. Inspecter toutes les pages : ouvertures, cartes, documents, légendes, marges, chronologies, exercices, corrigés, sommaires et fins de chapitres.

## 10. Pilote, revue et publication

Produire d’abord P01 complet, en conservant ses sept jalons et son objet conclusif. Vérifier le fonctionnement réel de l’autonomie sur un parcours : diagnostic → cours → exemple → exercice → correction → remédiation → nouvelle tâche. L’essai ne remplace pas une revue historique et pédagogique indépendante.

Étendre ensuite à P02–P05 et T01–T06. Une vérification exhaustive de présence ne dispense pas de lire et de résoudre les exercices. Les générateurs doivent produire des sujets blancs compatibles avec la session ; les évaluations A/B doivent être comparables sans être des copies.

Rapport de fin de lot : fichiers rédigés, sources consultées, objets couverts, objets encore à produire, corrections effectuées, contrôles exécutés, limites des contrôles, décisions humaines requises. Ne jamais écrire « complet », « validé » ou « publiable » sans matrice de preuves attachée aux sources et PDF exacts.
