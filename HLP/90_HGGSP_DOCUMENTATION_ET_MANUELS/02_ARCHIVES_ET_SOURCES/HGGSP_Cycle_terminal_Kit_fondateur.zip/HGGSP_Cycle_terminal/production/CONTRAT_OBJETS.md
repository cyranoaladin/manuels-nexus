# Contrat de données proposé

Les registres livrés ont un format de lancement simple. Ils ne prétendent pas satisfaire les schémas internes du dépôt, qui doivent être lus et adaptés avant intégration.

## Objet pédagogique à produire

Champs attendus : `id`, `type`, `niveau`, `theme`, `rubrique`, `jalon_ids`, `capacites_locales`, `public`, `parcours`, `source_ids`, `document_ids`, `method_ids`, `correction_ids`, `retest_ids`, `as_of`, `rights_status`, `content_status`, `reviews`, `published_in`.

Les champs de référence contiennent des identifiants effectivement existants, pas des noms devinés. La liste `reviews` enregistre une personne ou un processus identifié, sa compétence, son périmètre, sa date, le hash de l’objet revu et la décision. Un test mécanique ne renseigne pas la revue historique.

## Source documentaire

Séparer : création du document, édition consultée, reproduction dans le manuel, traduction et adaptation. Une consultation réussie ne vaut pas autorisation de reproduction d’une photographie ou d’une carte. Un même document peut éclairer plusieurs jalons, sans être compté comme plusieurs sources indépendantes.

## Épreuve

Séparer `officielle` et `entrainement_original`. En Terminale, enregistrer séparément le thème des deux choix de dissertation et celui de l’étude critique, la session, le nombre de documents et leurs natures. La correction a son propre public et son propre manifeste.

## Mesure de couverture

Rapporter au moins quatre grandeurs distinctes : entrées de programme recensées ; entrées disposant d’un cours rédigé ; entrées disposant d’un parcours autonome ; entrées effectivement revues et publiées. Le kit initial a 78 jalons recensés, **zéro cours thématique rédigé** et **zéro jalon thématique autorisé à publier**. Le module 00 est un contenu distinct de lancement méthodologique.
