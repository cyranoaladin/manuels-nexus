#!/usr/bin/env python3
"""Build the three editable DOCX and Markdown files from the delivered content JSON.

Requires python-docx. Does not access a repository or the network.
Output files are replaced only inside the package's documents/ directory.
"""
from pathlib import Path
import json
import re
from docx import Document
from docx.shared import Cm, Pt, RGBColor
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.enum.table import WD_TABLE_ALIGNMENT, WD_CELL_VERTICAL_ALIGNMENT

ROOT=Path(__file__).resolve().parents[1]
INK='16233B'; ACCENT='704D2C'; LIGHT='F3EEE7'; HAIR='DAD4CB'
DOCNAMES={'Dossier_fondateur':'HGGSP_Cycle_terminal_Dossier_fondateur',
          'Module_00_Candidat':'HGGSP_Module_00_Candidat',
          'Module_00_Autocorrection':'HGGSP_Module_00_Autocorrection'}
TITLES={'Dossier_fondateur':'HGGSP — Dossier fondateur du manuel du cycle terminal',
        'Module_00_Candidat':'Entrer en HGGSP — Module 00 du candidat individuel',
        'Module_00_Autocorrection':'Entrer en HGGSP — Autocorrection du module 00'}

def shade(el,fill):
    pr=el.get_or_add_tcPr() if hasattr(el,'get_or_add_tcPr') else el
    x=OxmlElement('w:shd');x.set(qn('w:fill'),fill);pr.append(x)

def inline(par,text,size=None,color=None):
    for i,s in enumerate(re.split(r'\*\*(.*?)\*\*',text,flags=re.S)):
        r=par.add_run(s);r.bold=bool(i%2)
        if size:r.font.size=Pt(size)
        if color:r.font.color.rgb=RGBColor.from_string(color)
    return par

def link(par,text,url):
    rel=par.part.relate_to(url,'http://schemas.openxmlformats.org/officeDocument/2006/relationships/hyperlink',is_external=True)
    e=OxmlElement('w:hyperlink');e.set(qn('r:id'),rel)
    r=OxmlElement('w:r');pr=OxmlElement('w:rPr')
    col=OxmlElement('w:color');col.set(qn('w:val'),ACCENT);pr.append(col)
    u=OxmlElement('w:u');u.set(qn('w:val'),'single');pr.append(u)
    r.append(pr);t=OxmlElement('w:t');t.text=text;r.append(t);e.append(r);par._p.append(e)

def init(name):
    doc=Document();sec=doc.sections[0]
    sec.page_height=Cm(29.7);sec.page_width=Cm(21)
    sec.top_margin=Cm(1.75);sec.bottom_margin=Cm(1.75)
    sec.left_margin=Cm(2.05);sec.right_margin=Cm(1.95)
    sec.header_distance=Cm(.7);sec.footer_distance=Cm(.7)
    styles=doc.styles
    for n in ['Normal','Body Text']:
        st=styles[n];st.font.name='Aptos';st.font.size=Pt(10.5);st.font.color.rgb=RGBColor.from_string(INK)
        st.paragraph_format.line_spacing=1.07;st.paragraph_format.space_after=Pt(5)
    # Common fonts present in runtime; do not distribute font files.
    for n in ['Normal','Body Text']:
        styles[n].font.name='DejaVu Sans'
    for n,sz,col in [('Title',32,INK),('Heading 1',18.5,INK),('Heading 2',11.6,ACCENT)]:
        styles[n].font.name='DejaVu Sans';styles[n].font.size=Pt(sz);styles[n].font.bold=True;styles[n].font.color.rgb=RGBColor.from_string(col)
        styles[n].paragraph_format.space_before=Pt(8 if n=='Heading 2' else 0)
        styles[n].paragraph_format.space_after=Pt(5 if n=='Heading 2' else 12)
        styles[n].paragraph_format.keep_with_next=True
    for border in styles['Title'].element.xpath('.//w:pBdr/w:bottom'):
        border.set(qn('w:color'),ACCENT)
        border.attrib.pop(qn('w:themeColor'),None)
    for nm,sz in [('Caption',8.5),('Header',8),('Footer',7.6)]:
        styles[nm].font.name='DejaVu Sans';styles[nm].font.size=Pt(sz);styles[nm].font.color.rgb=RGBColor.from_string(INK)
    styles['Caption'].paragraph_format.space_before=Pt(4)
    styles['Caption'].paragraph_format.space_after=Pt(5)
    # Set French language for all text.
    default=styles['Normal'].element.get_or_add_rPr()
    lang=OxmlElement('w:lang');lang.set(qn('w:val'),'fr-FR');default.append(lang)
    head=sec.header.paragraphs[0]
    inline(head,'NEXUS RÉUSSITE  /  HGGSP',8,ACCENT)
    head.paragraph_format.space_after=Pt(4)
    pp=head._p.get_or_add_pPr();b=OxmlElement('w:pBdr');bt=OxmlElement('w:bottom');bt.set(qn('w:val'),'single');bt.set(qn('w:sz'),'7');bt.set(qn('w:color'),ACCENT);b.append(bt);pp.append(b)
    f=sec.footer.paragraphs[0];f.alignment=WD_ALIGN_PARAGRAPH.RIGHT
    label='Dossier fondateur • v0.1' if name=='Dossier_fondateur' else 'Module 00 • Autocorrection' if name.endswith('Autocorrection') else 'Module 00 • Candidat'
    inline(f,label+'   |   ',7.6)
    for code in ['PAGE','NUMPAGES']:
        if code=='NUMPAGES':inline(f,' / ',7.6)
        fld=OxmlElement('w:fldSimple');fld.set(qn('w:instr'),code);f._p.append(fld)
    cp=doc.core_properties;cp.title=TITLES[name];cp.subject='HGGSP — cycle terminal — candidats individuels';cp.author='Projet Manuels Nexus Réussite';cp.keywords='HGGSP, Première, Terminale, candidats individuels, autonomie';cp.comments='Document de travail. Sources consultées le 8 septembre 2026. Aucun visa de validation humaine indépendante.'
    return doc

def addtable(doc,ob):
    n=len(ob['headers']);tab=doc.add_table(rows=1,cols=n);tab.alignment=WD_TABLE_ALIGNMENT.CENTER;tab.autofit=False
    ws=ob.get('widths') or [17/n]*n
    # Normalize to 17 cm printable width.
    ws=[w*17/sum(ws) for w in ws]
    for c,w in zip(tab.columns,ws):c.width=Cm(w)
    hr=tab.rows[0]._tr.get_or_add_trPr();tag=OxmlElement('w:tblHeader');hr.append(tag)
    for i,t in enumerate(ob['headers']):
        c=tab.cell(0,i);c.width=Cm(ws[i]);shade(c._tc,INK)
        par=c.paragraphs[0];par.paragraph_format.space_after=Pt(4);par.paragraph_format.space_before=Pt(4)
        r=par.add_run(t);r.bold=True;r.font.size=Pt(9.2);r.font.color.rgb=RGBColor(255,255,255)
    for rid,row in enumerate(ob['rows']):
        cells=tab.add_row().cells
        for i,t in enumerate(row):
            c=cells[i];c.width=Cm(ws[i]);c.vertical_alignment=WD_CELL_VERTICAL_ALIGNMENT.CENTER
            if rid%2==0:shade(c._tc,'F5F3F0')
            pr=c._tc.get_or_add_tcPr();m=OxmlElement('w:tcMar')
            for key,v in [('top','55'),('bottom','55'),('left','85'),('right','85')]:
                x=OxmlElement('w:'+key);x.set(qn('w:w'),v);x.set(qn('w:type'),'dxa');m.append(x)
            pr.append(m)
            par=c.paragraphs[0];par.paragraph_format.space_after=Pt(0);par.paragraph_format.line_spacing=1.02
            inline(par,t,size=9.35)
        trpr=tab.rows[-1]._tr.get_or_add_trPr();nr=OxmlElement('w:cantSplit');trpr.append(nr)
    # Minimal border only, no heavy grid.
    pr=tab._tbl.tblPr;border=OxmlElement('w:tblBorders')
    for edge in ['top','left','bottom','right','insideH','insideV']:
        x=OxmlElement('w:'+edge);x.set(qn('w:val'),'single' if edge=='insideH' else 'nil');x.set(qn('w:sz'),'3');x.set(qn('w:color'),HAIR);border.append(x)
    pr.append(border)
    par=doc.add_paragraph();par.paragraph_format.space_after=Pt(1);par.paragraph_format.space_before=Pt(0);par.paragraph_format.line_spacing=Pt(2);par.add_run().font.size=Pt(1)


def addbox(doc,ob):
    title=doc.add_paragraph();title.paragraph_format.space_before=Pt(7);title.paragraph_format.space_after=Pt(3);title.paragraph_format.keep_with_next=True
    inline(title,ob['title'],9.4,ACCENT)
    title.runs[0].bold=True
    par=doc.add_paragraph();par.paragraph_format.left_indent=Cm(.22);par.paragraph_format.right_indent=Cm(.12)
    par.paragraph_format.space_after=Pt(8);par.paragraph_format.line_spacing=1.04
    inline(par,ob['text'],10.0)
    pp=par._p.get_or_add_pPr();sh=OxmlElement('w:shd');sh.set(qn('w:fill'),LIGHT);pp.append(sh)
    borders=OxmlElement('w:pBdr');x=OxmlElement('w:left');x.set(qn('w:val'),'single');x.set(qn('w:sz'),'18');x.set(qn('w:space'),'6');x.set(qn('w:color'),ACCENT);borders.append(x);pp.append(borders)


def render(name,model):
    doc=init(name)
    for pi,page in enumerate(model['pages']):
        if pi:doc.add_page_break()
        if page.get('kicker'):
            par=doc.add_paragraph();inline(par,page['kicker'],9,ACCENT);par.paragraph_format.keep_with_next=True
        title=doc.add_paragraph(page['title'],'Title' if pi==0 else 'Heading 1')
        # Place bookmark for navigable headings.
        start=OxmlElement('w:bookmarkStart');start.set(qn('w:id'),str(pi+1));start.set(qn('w:name'),f'page_{pi+1}')
        end=OxmlElement('w:bookmarkEnd');end.set(qn('w:id'),str(pi+1));title._p.insert(0,start);title._p.append(end)
        for ob in page['items']:
            typ=ob['type']
            if typ=='p':inline(doc.add_paragraph(),ob['text'])
            elif typ=='h':doc.add_paragraph(ob['text'],'Heading 2')
            elif typ=='note':inline(doc.add_paragraph(style='Caption'),ob['text'])
            elif typ=='box':addbox(doc,ob)
            elif typ=='table':addtable(doc,ob)
            elif typ=='lines':
                for _ in range(ob['count']):
                    par=doc.add_paragraph();par.paragraph_format.space_after=Pt(0);par.paragraph_format.line_spacing=Pt(15)
                    rr=par.add_run(' ');rr.font.size=Pt(9)
                    pp=par._p.get_or_add_pPr();bd=OxmlElement('w:pBdr');b=OxmlElement('w:bottom');b.set(qn('w:val'),'single');b.set(qn('w:sz'),'2');b.set(qn('w:color'),'E1DEDA');bd.append(b);pp.append(bd)
            elif typ=='toclink':
                target_idx=next(i+1 for i,pg in enumerate(model['pages']) if pg['title']==ob['target'])
                par=doc.add_paragraph();par.paragraph_format.space_after=Pt(6)
                hyper=OxmlElement('w:hyperlink');hyper.set(qn('w:anchor'),f'page_{target_idx}')
                rr=OxmlElement('w:r');tt=OxmlElement('w:t');tt.text=ob['text'];rr.append(tt);hyper.append(rr);par._p.append(hyper)
                inline(par,'  —  p. ',9.5)
                fld=OxmlElement('w:fldSimple');fld.set(qn('w:instr'),f'PAGEREF page_{target_idx} \\h');par._p.append(fld)
            elif typ=='link':
                par=doc.add_paragraph();par.paragraph_format.space_after=Pt(4);link(par,ob['text'],ob['url'])
            elif typ=='code':
                par=doc.add_paragraph();par.paragraph_format.line_spacing=1.0
                rr=par.add_run(ob['text']);rr.font.name='DejaVu Sans Mono';rr.font.size=Pt(9)
            else:raise ValueError(typ)
    out=ROOT/'documents'/(DOCNAMES[name]+'.docx');doc.save(out)
    # Markdown is a readable alternate view generated from the same JSON.
    md=['# '+TITLES[name],'','Version 0.1 — 8 septembre 2026.','']
    for page in model['pages']:
        md+=['## '+page['title'].replace('\n',' — '),'']
        for ob in page['items']:
            typ=ob['type']
            if typ in ['p','note']:md += [ob['text'],'']
            elif typ=='h':md += ['### '+ob['text'],'']
            elif typ=='box':md += ['**'+ob['title']+'**','',ob['text'],'']
            elif typ=='code':md+=['```text',ob['text'],'```','']
            elif typ=='link':md+=['['+ob['text']+']('+ob['url']+')','']
            elif typ=='toclink':md+=[ob['text']+' — voir « '+ob['target']+' ».','']
            elif typ=='lines':md+=['_Espace de réponse._','']
            elif typ=='table':
                md+=['| '+' | '.join(ob['headers'])+' |','| '+' | '.join(['---']*len(ob['headers']))+' |']
                md+=['| '+' | '.join(row)+' |' for row in ob['rows']];md+=['']
    out.with_suffix('.md').write_text('\n'.join(md)+'\n')
    print(out)


def main():
    for name in DOCNAMES:
        model=json.loads((ROOT/'documents'/(name+'.json')).read_text())
        render(name,model)
if __name__=='__main__':main()
