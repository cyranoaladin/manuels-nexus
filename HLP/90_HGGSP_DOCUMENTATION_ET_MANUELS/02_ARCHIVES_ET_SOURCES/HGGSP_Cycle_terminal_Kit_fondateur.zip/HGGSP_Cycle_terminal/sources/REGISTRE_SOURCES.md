# Registre des sources

Consultation : 2026-09-08. Les URL renvoient aux sources, qui ne sont pas réhébergées dans le kit. Les mentions « consulté » ne constituent ni une autorisation de reproduction de toutes les images ni une validation humaine du manuel.

## S01 — Programmes et ressources HGGSP — voie générale
Éditeur : Éduscol. Type : institutionnel.
https://eduscol.education.gouv.fr/5802/programmes-et-ressources-en-histoire-geographie-geopolitique-et-sciences-politiques-voie-g
Programmes en vigueur et ressources disciplinaires ; page mise à jour en mars 2026.

## S02 — Programme HGGSP de Première — BO spécial n° 1 du 22 janvier 2019
Éditeur : Ministère de l’Éducation nationale. Type : programme.
https://eduscol.education.gouv.fr/sites/default/files/document/spe576annexe1062925pdf-83244.pdf
Programme prescriptif : cinq thèmes ; tableaux thématiques aux pages 5 à 9.

## S03 — Programme HGGSP de Terminale — BO spécial n° 8 du 25 juillet 2019
Éditeur : Ministère de l’Éducation nationale. Type : programme.
https://eduscol.education.gouv.fr/sites/default/files/document/spe254annexe1159180pdf-83247.pdf
Programme prescriptif : six thèmes ; tableaux thématiques aux pages 5 à 10.

## S04 — Épreuve terminale HGGSP à compter de la session 2026 — note du 27 août 2025, NOR MENE2521923N
Éditeur : BO n° 33 du 4 septembre 2025. Type : examen.
https://www.education.gouv.fr/bo/2025/Hebdo33/MENE2521923N
Texte actuel : écrit, oral de contrôle et rotation des thèmes ; remplace la note de 2020.

## S05 — Évaluations ponctuelles : spécialité non poursuivie — version consolidée de juin 2025
Éditeur : Éduscol. Type : examen.
https://eduscol.education.gouv.fr/sites/default/files/document/ndsevaluations-ponctuelleseds-non-poursuivivoie-gjuin-2025pdf-100575.pdf
HGGSP aux pages 3–4 : composition de deux heures ; coefficient commun indiqué page 2.

## S06 — Candidats individuels au baccalauréat général et technologique
Éditeur : Éduscol. Type : examen.
https://eduscol.education.gouv.fr/5694/candidats-individuels-au-baccalaureat-general-et-au-baccalaureat-technologique
Statut, inscription, évaluations ponctuelles et articulation du cycle ; page mise à jour en mars 2026.

## S07 — Modalités d’évaluation des candidats individuels — note du 25 août 2025, NOR MENE2523743N
Éditeur : BO n° 32 du 28 août 2025. Type : examen.
https://www.education.gouv.fr/bo/2025/Hebdo32/MENE2523743N
Évaluations ponctuelles annuelles ou en fin de cycle ; choix global à l’inscription.

## S08 — Présentation du Grand oral
Éditeur : Éduscol. Type : examen.
https://eduscol.education.gouv.fr/5661/presentation-du-grand-oral
Déroulement, questions et candidats individuels ; coefficient 8 en voie générale à partir de 2027.

## S09 — Les épreuves terminales du baccalauréat général
Éditeur : Éduscol. Type : examen.
https://eduscol.education.gouv.fr/5706/les-epreuves-terminales-du-baccalaureat-general
HGGSP : écrit, quatre heures, coefficient 16 ; tableau des coefficients actualisé.

## S10 — Déclaration du 26 août 1789 des droits de l’homme et du citoyen
Éditeur : Légifrance. Type : document_primaire.
https://www.legifrance.gouv.fr/loda/id/JORFTEXT000000697056
Document primaire : article 16 utilisé dans le module 00 ; distinguer texte normatif et application.

## S11 — SOURCE_DE_VERITE.md — collection Manuels Nexus
Éditeur : Dépôt manuels-nexus. Type : projet.
https://github.com/cyranoaladin/manuels-nexus/blob/main/SOURCE_DE_VERITE.md
Document d’organisation daté du 11 août 2026, consulté en lecture seule ; ne certifie pas l’état local actuel.

## R-P01 — Première, thème 1 — Démocratie
Éditeur : Éduscol. Type : accompagnement.
https://eduscol.education.gouv.fr/sites/default/files/document/ra19lyceegspe1hggsptheme1democratie1169458pdf-83250.pdf
Ressource d’accompagnement : éclaire la mise en œuvre, sans remplacer le programme officiel.

## R-P02 — Première, thème 2 — Puissances
Éditeur : Éduscol. Type : accompagnement.
https://eduscol.education.gouv.fr/sites/default/files/document/ra19lyceegspe1hggsptheme2puissancesinter1169460pdf-83253.pdf
Ressource d’accompagnement : éclaire la mise en œuvre, sans remplacer le programme officiel.

## R-P03 — Première, thème 3 — Frontières
Éditeur : Éduscol. Type : accompagnement.
https://eduscol.education.gouv.fr/sites/default/files/document/ra19lyceegspe1hggsptheme3frontieres1206062pdf-83256.pdf
Ressource d’accompagnement : éclaire la mise en œuvre, sans remplacer le programme officiel.

## R-P04 — Première, thème 4 — S’informer
Éditeur : Éduscol. Type : accompagnement.
https://eduscol.education.gouv.fr/sites/default/files/document/ra20lyceeg1histgeogeopolitique-sciencespotheme4-sinformer-regard-critique1293847pdf-83259.pdf
Ressource d’accompagnement : éclaire la mise en œuvre, sans remplacer le programme officiel.

## R-P05 — Première, thème 5 — États et religions
Éditeur : Éduscol. Type : accompagnement.
https://eduscol.education.gouv.fr/sites/default/files/document/ra20lyceeg1histgeogeopolitique-sciencespoanalyser-relations-etats-religions1293914pdf-83262.pdf
Ressource d’accompagnement : éclaire la mise en œuvre, sans remplacer le programme officiel.

## R-T01 — Terminale, thème 1 — Nouveaux espaces de conquête
Éditeur : Éduscol. Type : accompagnement.
https://eduscol.education.gouv.fr/sites/default/files/document/ra20lyceegtspehgeotheme1espacesconquetes0021329089pdf-83265.pdf
Ressource d’accompagnement : éclaire la mise en œuvre, sans remplacer le programme officiel.

## R-T02 — Terminale, thème 2 — Guerre et paix
Éditeur : Éduscol. Type : accompagnement.
https://eduscol.education.gouv.fr/sites/default/files/document/ra22lycee-gthggsptheme-2faire-la-guerre-et-faire-la-paix-93786.pdf
Ressource d’accompagnement : éclaire la mise en œuvre, sans remplacer le programme officiel.

## R-T03 — Terminale, thème 3 — Histoire et mémoires
Éditeur : Éduscol. Type : accompagnement.
https://eduscol.education.gouv.fr/sites/default/files/document/ra22lycee-gthggsphistoire-et-memoires-93783.pdf
Ressource d’accompagnement : éclaire la mise en œuvre, sans remplacer le programme officiel.

## R-T04 — Terminale, thème 4 — Patrimoine
Éditeur : Éduscol. Type : accompagnement.
https://eduscol.education.gouv.fr/sites/default/files/document/ra25lyceegthggspidentifierprotegervaloriserpatrimoine-enjeuxgeopolitiques0pdf-121241.pdf
Ressource d’accompagnement : éclaire la mise en œuvre, sans remplacer le programme officiel.

## R-T05 — Terminale, thème 5 — Environnement
Éditeur : Éduscol. Type : accompagnement.
https://eduscol.education.gouv.fr/sites/default/files/document/ra23lyceegthggspenvironnementexploitationprotectionenjeupdf-102786.pdf
Ressource d’accompagnement : éclaire la mise en œuvre, sans remplacer le programme officiel.

## R-T06 — Terminale, thème 6 — Connaissance
Éditeur : Éduscol. Type : accompagnement.
https://eduscol.education.gouv.fr/sites/default/files/document/ra24lyceegthggspenjeuxconnaissancepdf-104487.pdf
Ressource d’accompagnement : éclaire la mise en œuvre, sans remplacer le programme officiel.

## S12 — Arborescence locale fournie par le commanditaire
Éditeur : Projet Manuels scolaires. Type : source_fournie.
Pièce fournie dans la conversation ; pas de lien public.
Fichier « Texte collé(3).txt » : organisation apparente, gabarits communs et disciplines ; aucun contenu HGGSP identifié dans ce relevé. Ne constitue pas une lecture exhaustive des sources locales.

