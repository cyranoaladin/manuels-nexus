# Carte du programme HGGSP — cycle terminal

État documentaire : 2026-09-08. Source programme : S02 (Première), S03 (Terminale).

Titres de thèmes et de rubriques repris du programme ; jalons en libellés abrégés éditoriaux. Pour le libellé intégral, consulter la page du BO indiquée. Identifiants locaux, non officiels.

**Les 78 jalons ci-dessous sont inventoriés, mais leurs cours ne sont pas encore rédigés dans ce lot.**

## P01 — Comprendre un régime politique : la démocratie

Source : S02, p. 5. Ressource d’accompagnement : R-P01.

**Introduction :** Caractéristiques des démocraties contemporaines ; comparaison avec les régimes autoritaires ; libertés, institutions et alternance.

### AXE1 — Penser la démocratie : démocratie directe et démocratie représentative

- **P01-AXE1-J01** : Être citoyen à Athènes au Ve siècle avant J.-C. : une démocratie directe mais limitée. — contenu à rédiger.
- **P01-AXE1-J02** : Participer ou être représenté : Benjamin Constant et les libertés des Anciens et des Modernes. — contenu à rédiger.

### AXE2 — Avancées et reculs des démocraties

- **P01-AXE2-J01** : Tocqueville : inquiétudes sur la démocratie et le risque de tyrannie. — contenu à rédiger.
- **P01-AXE2-J02** : Crises et fin de la démocratie au Chili de 1970 à 1973. — contenu à rédiger.
- **P01-AXE2-J03** : Du régime autoritaire à la démocratie : Portugal et Espagne de 1974 à 1982. — contenu à rédiger.

### OTC — L’Union européenne et la démocratie

- **P01-OTC-J01** : Fonctionnement de l’Union européenne : démocratie représentative et démocratie déléguée. — contenu à rédiger.
- **P01-OTC-J02** : L’Union européenne face aux citoyens et aux États : remises en question depuis 1992. — contenu à rédiger.

**Vigilance éditoriale proposée :** Distinguer principes, dispositifs et pratiques. Ne réduire ni Athènes à ses exclusions ni la démocratie contemporaine au seul scrutin. Enseigner la comparaison sans anachronisme.

**Passerelle de cycle proposée :** Connaissance et information ; construction de la paix ; pluralité des mémoires.

## P02 — Analyser les dynamiques des puissances internationales

Source : S02, p. 6. Ressource d’accompagnement : R-P02.

**Introduction :** Fondements et manifestations de la puissance : diplomatie, armée, économie, finance et culture, à partir d’exemples contemporains.

### AXE1 — Essor et déclin des puissances : un regard historique

- **P02-AXE1-J01** : L’Empire ottoman : de l’essor au déclin. — contenu à rédiger.
- **P02-AXE1-J02** : La Russie depuis 1991 : reconstruire une puissance après l’éclatement d’un empire. — contenu à rédiger.

### AXE2 — Formes indirectes de la puissance : une approche géopolitique

- **P02-AXE2-J01** : La langue comme instrument : anglais, français, francophonie et instituts Confucius. — contenu à rédiger.
- **P02-AXE2-J02** : Les nouvelles technologies : géants du numérique (GAFAM, BATX), États et organisations internationales. — contenu à rédiger.
- **P02-AXE2-J03** : Maîtriser les voies de communication : les nouvelles routes de la soie. — contenu à rédiger.

### OTC — La puissance des États-Unis aujourd’hui

- **P02-OTC-J01** : Lieux et formes de la puissance : siège de l’ONU, Hollywood, MIT notamment. — contenu à rédiger.
- **P02-OTC-J02** : Unilatéralisme et multilatéralisme : un débat international. — contenu à rédiger.
- **P02-OTC-J03** : Points d’appui et zones d’influence dans un monde multipolaire. — contenu à rédiger.

**Vigilance éditoriale proposée :** Raisonner sur les moyens, les objectifs, les résultats et les limites. Dater toutes les données contemporaines ; ne pas assimiler puissance, domination et influence.

**Passerelle de cycle proposée :** Conquête spatiale et maritime ; guerres et paix ; savoirs et cyberespace.

## P03 — Étudier les divisions politiques du monde : les frontières

Source : S02, p. 7. Ressource d’accompagnement : R-P03.

**Introduction :** Des frontières plus nombreuses, plus ou moins marquées et des espaces transfrontaliers ; distinguer limite, contrôle et interface.

### AXE1 — Tracer des frontières, approche géopolitique

- **P03-AXE1-J01** : Se protéger : le limes rhénan. — contenu à rédiger.
- **P03-AXE1-J02** : Se partager des territoires : la conférence de Berlin et le partage de l’Afrique. — contenu à rédiger.
- **P03-AXE1-J03** : Séparer deux systèmes politiques : la frontière entre les deux Corées. — contenu à rédiger.

### AXE2 — Les frontières en débat

- **P03-AXE2-J01** : Reconnaître une frontière : la frontière germano-polonaise de 1939 à 1990. — contenu à rédiger.
- **P03-AXE2-J02** : Dépasser les frontières : le droit de la mer. — contenu à rédiger.

### OTC — Les frontières internes et externes de l’Union européenne

- **P03-OTC-J01** : Schengen : venir en Europe, passer la frontière, logiques et modalités de contrôle. — contenu à rédiger.
- **P03-OTC-J02** : Les frontières d’un État adhérent. — contenu à rédiger.
- **P03-OTC-J03** : Les espaces transfrontaliers intra-européens : passer et dépasser la frontière au quotidien. — contenu à rédiger.

**Vigilance éditoriale proposée :** Faire travailler la carte comme une construction datée. Distinguer tracé, reconnaissance et contrôle. Ne pas raconter Berlin comme une unique opération instantanée de dessin de toutes les frontières.

**Passerelle de cycle proposée :** Souveraineté des espaces de conquête ; conflits territoriaux ; cyberespace.

## P04 — S’informer : un regard critique sur les sources et modes de communication

Source : S02, p. 8. Ressource d’accompagnement : R-P04.

**Introduction :** Diversité des médias et des supports ; pratiques d’information différenciées des individus, groupes et générations.

### AXE1 — Les grandes révolutions techniques de l’information

- **P04-AXE1-J01** : De l’imprimerie à la presse à grand tirage. — contenu à rédiger.
- **P04-AXE1-J02** : La radio et la télévision au XXe siècle. — contenu à rédiger.
- **P04-AXE1-J03** : Naissance et extension du réseau Internet. — contenu à rédiger.

### AXE2 — Liberté ou contrôle de l’information : un débat politique fondamental

- **P04-AXE2-J01** : Presse et opinion publique dans l’affaire Dreyfus. — contenu à rédiger.
- **P04-AXE2-J02** : L’information entre marché et État : Havas et l’AFP. — contenu à rédiger.
- **P04-AXE2-J03** : Information et propagande en temps de guerre : les médias et la guerre du Vietnam. — contenu à rédiger.

### OTC — L’information à l’heure d’Internet

- **P04-OTC-J01** : Une information fragmentée et horizontale. — contenu à rédiger.
- **P04-OTC-J02** : Témoignages et lanceurs d’alerte. — contenu à rédiger.
- **P04-OTC-J03** : Les théories du complot : une nouvelle jeunesse à l’heure d’Internet. — contenu à rédiger.

**Vigilance éditoriale proposée :** Séparer publication, source, preuve et interprétation. Vérifier origine, contexte et recoupement ; ne pas confondre pluralité des points de vue et équivalence de leur solidité.

**Passerelle de cycle proposée :** Production des connaissances ; histoire et mémoires ; conflits informationnels.

## P05 — Analyser les relations entre États et religions

Source : S02, p. 9. Ressource d’accompagnement : R-P05.

**Introduction :** Diversité juridique des liens entre État et religion ; religion officielle, séparation, liberté de conscience et liberté religieuse.

### AXE1 — Pouvoir et religion : des liens historiques traditionnels

- **P05-AXE1-J01** : Le pape et l’empereur : le couronnement de Charlemagne. — contenu à rédiger.
- **P05-AXE1-J02** : Pouvoir politique et magistère religieux : calife et empereur byzantin aux IXe et Xe siècles. — contenu à rédiger.

### AXE2 — États et religions : une inégale sécularisation

- **P05-AXE2-J01** : La laïcité en Turquie : l’abolition du califat en 1924 par Mustapha Kemal. — contenu à rédiger.
- **P05-AXE2-J02** : États et religions dans la politique intérieure des États-Unis depuis la Seconde Guerre mondiale. — contenu à rédiger.

### OTC — État et religions en Inde

- **P05-OTC-J01** : Sécularisme et dimension politique de la religion. — contenu à rédiger.
- **P05-OTC-J02** : Les minorités religieuses. — contenu à rédiger.
- **P05-OTC-J03** : Enjeux géopolitiques : l’Inde et le Pakistan. — contenu à rédiger.

**Vigilance éditoriale proposée :** Distinguer laïcité, sécularisation et sécularisme. Éviter d’attribuer une volonté uniforme à une religion ou à l’ensemble de ses fidèles ; identifier les acteurs et les périodes.

**Passerelle de cycle proposée :** Conflits et paix ; patrimoines ; pluralité des identités et des mémoires.

## T01 — De nouveaux espaces de conquête

Source : S03, p. 5. Ressource d’accompagnement : R-T01.

**Introduction :** Spécificités des océans et de l’espace ; connaître, maîtriser et redéfinir les frontières de l’exploration.

### AXE1 — Conquêtes, affirmations de puissance et rivalités

- **T01-AXE1-J01** : Enjeux géopolitiques de la conquête spatiale : guerre froide, nouveaux États et acteurs privés. — contenu à rédiger.
- **T01-AXE1-J02** : Affirmation de puissance à partir des mers : dissuasion nucléaire et forces de projection maritimes. — contenu à rédiger.

### AXE2 — Enjeux diplomatiques et coopérations

- **T01-AXE2-J01** : Coopérer pour développer la recherche : la Station spatiale internationale. — contenu à rédiger.
- **T01-AXE2-J02** : Rivalités et coopérations dans le partage, l’exploitation et la préservation des mers : Montego Bay, ZEE et biodiversité marine. — contenu à rédiger.

### OTC — La Chine : à la conquête de l’espace, des mers et des océans

- **T01-OTC-J01** : Affirmer une volonté politique : discours, investissements et appropriations. — contenu à rédiger.
- **T01-OTC-J02** : Enjeux économiques et géopolitiques considérables pour la Chine et le reste du monde. — contenu à rédiger.

**Vigilance éditoriale proposée :** Distinguer souveraineté, droits souverains et libertés de circulation. Actualiser séparément les accords maritimes et programmes spatiaux sans réécrire silencieusement le jalon officiel.

**Passerelle de cycle proposée :** Première : puissances et frontières.

## T02 — Faire la guerre, faire la paix : formes de conflits et modes de résolution

Source : S03, p. 6. Ressource d’accompagnement : R-T02.

**Introduction :** Panorama des conflits ; types, acteurs et modes de résolution ; distinguer guerre, conflit, violence et paix.

### AXE1 — La dimension politique de la guerre : des conflits interétatiques aux enjeux transnationaux

- **T02-AXE1-J01** : La guerre comme continuation de la politique : de la guerre de Sept Ans aux guerres napoléoniennes, à partir de Clausewitz. — contenu à rédiger.
- **T02-AXE1-J02** : Le modèle de Clausewitz à l’épreuve des guerres irrégulières : d’Al-Qaïda à Daech. — contenu à rédiger.

### AXE2 — Le défi de la construction de la paix

- **T02-AXE2-J01** : La paix par les traités : les traités de Westphalie en 1648. — contenu à rédiger.
- **T02-AXE2-J02** : La paix par la sécurité collective : l’ONU sous les mandats de Kofi Annan (1997–2006). — contenu à rédiger.

### OTC — Le Moyen-Orient : conflits régionaux et tentatives de paix impliquant des acteurs internationaux (étatiques et non étatiques)

- **T02-OTC-J01** : Du conflit israélo-arabe au conflit israélo-palestinien : tentatives de résolution de 1948 à nos jours. — contenu à rédiger.
- **T02-OTC-J02** : Les guerres du Golfe (1991 et 2003) et leurs prolongements : de l’interétatique à l’asymétrique. — contenu à rédiger.

**Vigilance éditoriale proposée :** Éviter les explications monocausales et les catégories figées. Dater les mises à jour ; distinguer qualification juridique, récit d’un acteur et analyse scientifique.

**Passerelle de cycle proposée :** Première : puissances, frontières, États et religions.

## T03 — Histoire et mémoires

Source : S03, p. 7. Ressource d’accompagnement : R-T03.

**Introduction :** Différencier histoire, mémoire et justice ; comprendre l’apparition des notions de crime contre l’humanité et de génocide.

### AXE1 — Histoire et mémoires des conflits

- **T03-AXE1-J01** : Les causes de la Première Guerre mondiale : un débat historique et ses implications politiques. — contenu à rédiger.
- **T03-AXE1-J02** : Mémoires et histoire de la guerre d’Algérie. — contenu à rédiger.

### AXE2 — Histoire, mémoire et justice

- **T03-AXE2-J01** : La justice à l’échelle locale : les tribunaux gacaca face au génocide des Tutsis. — contenu à rédiger.
- **T03-AXE2-J02** : La justice pénale internationale face aux conflits : le Tribunal pénal international pour l’ex-Yougoslavie. — contenu à rédiger.

### OTC — L’histoire et les mémoires du génocide des Juifs et des Tsiganes

- **T03-OTC-J01** : Les lieux de mémoire. — contenu à rédiger.
- **T03-OTC-J02** : Juger les crimes nazis après Nuremberg. — contenu à rédiger.
- **T03-OTC-J03** : Les génocides dans la littérature et le cinéma. — contenu à rédiger.

**Vigilance éditoriale proposée :** Contextualiser les témoignages et respecter les victimes. Ne pas mettre le négationnisme au rang d’une interprétation historiographique recevable. Expliquer les usages de catégories et leurs sources.

**Passerelle de cycle proposée :** Première : démocratie, information, puissance ; Terminale : justice et patrimoine.

## T04 — Identifier, protéger et valoriser le patrimoine : enjeux géopolitiques

Source : S03, p. 8. Ressource d’accompagnement : R-T04.

**Introduction :** Construction historique de la notion de patrimoine ; du legs familial au patrimoine mondial et à ses acteurs.

### AXE1 — Usages sociaux et politiques du patrimoine

- **T04-AXE1-J01** : Réaménager la mémoire : les usages de Versailles de l’Empire à nos jours. — contenu à rédiger.
- **T04-AXE1-J02** : Conflits de patrimoine : les frises du Parthénon depuis le XIXe siècle. — contenu à rédiger.

### AXE2 — Patrimoine, la préservation entre tensions et concurrences

- **T04-AXE2-J01** : Urbanisation, développement et préservation : Paris entre protection et nouvel urbanisme. — contenu à rédiger.
- **T04-AXE2-J02** : Destructions, protection et restauration du patrimoine au Mali. — contenu à rédiger.
- **T04-AXE2-J03** : Le tourisme culturel, entre valorisation et protection : Venise. — contenu à rédiger.

### OTC — La France et le patrimoine, des actions majeures de valorisation et de protection

- **T04-OTC-J01** : La gestion du patrimoine français : évolutions d’une politique publique. — contenu à rédiger.
- **T04-OTC-J02** : Valorisation et reconversion : le bassin minier du Nord-Pas-de-Calais. — contenu à rédiger.
- **T04-OTC-J03** : Patrimoine, rayonnement et diplomatie : le repas gastronomique des Français. — contenu à rédiger.

**Vigilance éditoriale proposée :** Analyser les arbitrages entre usages plutôt qu’opposer mécaniquement protection et économie. Distinguer inscription UNESCO, propriété, conservation et attractivité.

**Passerelle de cycle proposée :** Première : puissance et religions ; Terminale : environnement et mémoires.

## T05 — L’environnement, entre exploitation et protection : un enjeu planétaire

Source : S03, p. 9. Ressource d’accompagnement : R-T05.

**Introduction :** Définir l’environnement comme notion historique, sociale et politique ; repères d’histoire environnementale.

### AXE1 — Exploiter, préserver et protéger

- **T05-AXE1-J01** : Exploiter et protéger une ressource : la forêt française depuis Colbert. — contenu à rédiger.
- **T05-AXE1-J02** : Les sociétés face à leur environnement : ruptures du Néolithique et de la révolution industrielle. — contenu à rédiger.

### AXE2 — Le changement climatique : approches historique et géopolitique

- **T05-AXE2-J01** : Les fluctuations climatiques et leurs effets en Europe, du Moyen Âge au XIXe siècle. — contenu à rédiger.
- **T05-AXE2-J02** : Le climat dans les relations internationales : sommets de la Terre et COP. — contenu à rédiger.

### OTC — Les États-Unis et la question environnementale : tensions et contrastes

- **T05-OTC-J01** : L’environnement aux États-Unis depuis le XIXe siècle : État fédéral, États fédérés, protection et exploitation. — contenu à rédiger.
- **T05-OTC-J02** : Les États-Unis dans les négociations environnementales internationales : État, firmes et ONG. — contenu à rédiger.

**Vigilance éditoriale proposée :** Distinguer variabilité ancienne et réchauffement contemporain ; ne pas produire de faux équilibre sur les résultats scientifiques. Dater les politiques et séparer échelles et acteurs.

**Passerelle de cycle proposée :** Première : puissances ; Terminale : patrimoine, espaces maritimes et savoirs.

## T06 — L’enjeu de la connaissance

Source : S03, p. 10. Ressource d’accompagnement : R-T06.

**Introduction :** Société de la connaissance ; communautés savantes et scientifiques ; produire, communiquer et circuler.

### AXE1 — Produire et diffuser des connaissances

- **T06-AXE1-J01** : L’alphabétisation des femmes, du XVIe siècle à nos jours dans le monde. — contenu à rédiger.
- **T06-AXE1-J02** : La radioactivité, de 1896 aux années 1950 : échanges, coopération et rôle des individus. — contenu à rédiger.

### AXE2 — La connaissance, enjeu politique et géopolitique

- **T06-AXE2-J01** : Le renseignement au service des États : services soviétiques et américains durant la guerre froide. — contenu à rédiger.
- **T06-AXE2-J02** : La circulation des étudiants et les transferts de technologie : l’exemple de l’Inde. — contenu à rédiger.

### OTC — Le cyberespace : conflictualité et coopération entre les acteurs

- **T06-OTC-J01** : Le cyberespace entre réseaux, territoires, infrastructures, acteurs, liberté et contrôle des données. — contenu à rédiger.
- **T06-OTC-J02** : Cyberdéfense française : souveraineté nationale et coopération européenne. — contenu à rédiger.

**Vigilance éditoriale proposée :** Ne pas confondre information, savoir et connaissance validée. Cartographier les infrastructures et compétences ; analyser les asymétries sans réduire le sujet au piratage.

**Passerelle de cycle proposée :** Première : information, puissance et frontières.

