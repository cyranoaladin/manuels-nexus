# Vérification du lot fondateur HGGSP

Version examinée : 0.1 — 8 septembre 2026.

## Portée

Le contrôle concerne le dossier fondateur, le module 00, son autocorrection et leurs données de référence. Il ne concerne pas un manuel thématique déjà achevé : les onze thèmes et leurs 78 jalons sont cartographiés, mais leurs cours complets restent à rédiger.

## Vérifications observées

| Contrôle | Résultat observé | Limite |
|---|---|---|
| Tests locaux de cohérence | 24 tests réussis ; sortie dans `resultats_tests.txt` | Cohérence structurelle, renvois et calculs du module, non certification de l'histoire |
| Référentiel | 5 thèmes de Première, 6 de Terminale, 78 jalons, identifiants uniques | L'inventaire n'est pas le texte développé des cours |
| Publics et sessions | Profils séparés ; rotation 2027/2028 conservant les six thèmes dans la base | Réexamen requis en cas de modification des textes |
| Correspondances pédagogiques | 25 objets du module associés à une correction | Les formulations ouvertes admettent d'autres réponses argumentées |
| Calculs fictifs | Proportions de 78 %, 80 % et 75 % recalculées avec leur dénominateur | Aucune donnée d'enquête réelle ni preuve historique n'en est déduite |
| Longueur du modèle E8 | 129 mots par décompte de mots séparés par espaces | Convention de comptage pédagogique |
| Inspection visuelle | 34 + 18 + 8 = 60 pages examinées | Inspection de cette version, pas des exports modifiés ultérieurement |
| Reprise après inspection | R3 complétée pour les échelles ; correction E6 conforme aux quatre phrases demandées ; largeur de colonne corrigée | Les trois pages modifiées ont été examinées après nouvel export |
| Rendu final | Aucun mot extrait hors page, aucune page sans texte, aucun caractère de remplacement détecté | Ces contrôles ne suffisent pas seuls à prouver l'absence de toute collision graphique |
| Navigation | Dossier : 111 signets, 50 liens ; candidat : 44 signets, 6 liens ; correction : 24 signets | Le compagnon renvoie au registre des sources du module |
| Polices | Polices du rendu PDF incorporées ; aucun fichier de police dans le kit | Disponibilité à prévoir sur une autre machine pour réexporter le DOCX |
| Dépôt du commanditaire | Lecture uniquement, aucune écriture | L'intégration locale n'est pas réalisée |

Les détails techniques des trois PDF sont dans `preflight_pdf.json`. Les empreintes SHA-256 du kit sont dans `MANIFESTE_SHA256.json` à la racine ; ce manifeste ne s'inclut pas lui-même.

## Examen visuel et dernière itération

Tous les rendus ont été examinés. La dernière réexportation du module candidat n'a changé que sa page 14. Celle du compagnon n'a changé que ses pages 2 et 5. Les autres images sont identiques, par empreinte, aux pages déjà examinées. Les modifications n'ont pas changé le nombre de pages.

## Réserves maintenues

La charte proposée est autonome et n'est pas une nouvelle référence approuvée pour le dépôt. Aucune validation humaine indépendante, aucun visa institutionnel, aucune certification PDF/UA et aucune autorisation de publication commerciale ne sont revendiqués.

Les sources officielles ont été consultées pour le cadrage ; la future production des onze thèmes exigera une recherche documentaire et une revue disciplinaire au niveau de chaque jalon, avec vérification des citations, des cartes, des statistiques et des droits. Un contrôle automatique ne remplace pas ces opérations.
