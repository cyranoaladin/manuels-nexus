#!/usr/bin/env python3
"""Checks the delivered package structure and arithmetic, not historical truth.
Run: python verification/verifier_kit.py
No repository changes, network access or publication decisions.
"""
from pathlib import Path
import json
import unittest
import re
ROOT=Path(__file__).resolve().parents[1]
def load(rel): return json.loads((ROOT/rel).read_text(encoding='utf-8'))
P=load('referentiel/programme_cycle_terminal.json')
E=load('referentiel/profils_examens.json')
S=load('sources/registre_sources.json')
J=[j for t in P['themes'] for g in t['groups'] for j in g['jalons']]
PROF={p['id']:p for p in E['profiles']}
L=load('documents/Module_00_Candidat.json')
C=load('documents/Module_00_Autocorrection.json')
D=load('documents/Dossier_fondateur.json')
class KitChecks(unittest.TestCase):
 def test_01_theme_count(self):self.assertEqual(len(P['themes']),11)
 def test_02_level_partition(self):
  self.assertEqual(sum(t['level']=='premiere' for t in P['themes']),5)
  self.assertEqual(sum(t['level']=='terminale' for t in P['themes']),6)
 def test_03_all_three_groups(self):
  for t in P['themes']:self.assertEqual([g['kind'] for g in t['groups']],['axe1','axe2','otc'])
 def test_04_jalon_counts(self):
  self.assertEqual(len(J),78)
  for level in ['premiere','terminale']:self.assertEqual(sum(len(g['jalons']) for t in P['themes'] if t['level']==level for g in t['groups']),39)
 def test_05_unique_ids(self):
  ids=[x['id'] for x in P['themes']]+[g['id'] for t in P['themes'] for g in t['groups']]+[j['id'] for j in J]
  self.assertEqual(len(ids),len(set(ids)))
 def test_06_explicit_limits(self):
  self.assertEqual(P['full_manual_status'],'non_redige')
  self.assertIn('abrégés',P['label_policy'])
  self.assertIn('non officiels',P['label_policy'])
 def test_07_no_false_publication(self):
  for j in J:
   self.assertEqual(j['content_status'],'a_rediger');self.assertEqual(j['review_status'],'non_revu');self.assertEqual(j['course_object_ids'],[])
 def test_08_source_refs_resolve(self):
  ids={s['id'] for s in S}
  for t in P['themes']:
   self.assertIn(t['source_id'],ids);self.assertIn(t['resource_id'],ids)
  for j in J:self.assertIn(j['source_id'],ids)
 def test_09_source_page_ranges(self):
  for t in P['themes']:
   self.assertEqual(t['source_pdf_page'],t['number']+4)
   for g in t['groups']:
    for j in g['jalons']:self.assertEqual(j['source_pdf_page'],t['source_pdf_page'])
 def test_10_references_have_dates(self):
  self.assertEqual(len({s['id'] for s in S}),len(S))
  for s in S:self.assertEqual(s['consulted_on'],'2026-09-08')
 def test_11_session_rotation(self):
  for y,ts in E['written_sessions'].items():
   self.assertEqual(ts,E['rotation_rule']['even' if int(y)%2==0 else 'odd']);self.assertEqual(len(set(ts)),4)
 def test_12_full_terminale_kept(self):self.assertEqual(E['full_terminale_course'],['T01','T02','T03','T04','T05','T06'])
 def test_13_premiere_profile(self):
  p=PROF['PREMIERE_NON_POURSUIVIE'];self.assertEqual(p['duration_minutes'],120);self.assertEqual(p['coefficient'],8);self.assertIsNone(p['official_subject_choice_count']);self.assertEqual(len(p['theme_ids']),5)
 def test_14_terminale_profile(self):
  p=PROF['TERMINALE_CONSERVEE'];self.assertEqual(p['duration_minutes'],240);self.assertEqual(p['coefficient'],16);self.assertEqual(p['marks'],[10,10]);self.assertTrue(p['distinct_themes_for_three_tasks'])
 def test_15_grand_oral_profile(self):
  p=PROF['GRAND_ORAL_GENERAL_2027_PLUS'];self.assertEqual(p['coefficient'],8);self.assertEqual(p['presentation_minutes']+p['discussion_minutes'],20);self.assertTrue(p['both_retained_specialities_required'])
 def test_16_local_dates_not_invented(self):self.assertIsNone(E['administrative_local_dates'])
 def test_17_module_corrections_resolve(self):
  ob=load('referentiel/module00_objets.json')['objects'];self.assertEqual(len(ob),25)
  titles={p['title'] for p in C['pages']}
  self.assertEqual(len({o['id'] for o in ob}),25)
  for o in ob:self.assertIn(o['correction_section'],titles)
 def test_18_arithmetic_examples(self):
  self.assertEqual(156+44,200);self.assertEqual(156*100/200,78)
  self.assertEqual(45*100/60,75);self.assertEqual(24*100/30,80);self.assertEqual(21*100/28,75)
 def test_19_e8_model_length(self):
  txt=next(x['text'] for x in C['pages'][4]['items'] if x['type']=='p' and x['text'].startswith('Les pièces montrent'))
  self.assertTrue(120<=len(txt.split())<=150)
 def test_20_toc_targets(self):
  ts={p['title'] for p in D['pages']}
  for pg in D['pages']:
   for x in pg['items']:
    if x['type']=='toclink':self.assertIn(x['target'],ts)
 def test_21_no_internal_citation_tokens(self):
  for m in [D,L,C]:self.assertNotRegex(json.dumps(m,ensure_ascii=False),r'|turn\d+(?:view|file|search)\d+')
 def test_22_documents_present(self):
  for nm in ['HGGSP_Cycle_terminal_Dossier_fondateur','HGGSP_Module_00_Candidat','HGGSP_Module_00_Autocorrection']:
   for ext in ['.docx','.pdf','.md']:self.assertTrue((ROOT/'documents'/(nm+ext)).is_file())
 def test_23_fiction_explicit(self):
  text=json.dumps(L,ensure_ascii=False)
  self.assertIn('Tout le dossier ci-dessous est fictif',text)
  self.assertIn('NOUVEAU CAS FICTIF : CLAIRVAL',text);self.assertIn('NOUVEAU CAS FICTIF : BELRIVE',text)
 def test_24_no_font_files(self):
  self.assertFalse(any(p.suffix.lower() in {'.otf','.ttf','.woff','.woff2'} for p in ROOT.rglob('*')))
if __name__=='__main__':unittest.main(verbosity=2)
